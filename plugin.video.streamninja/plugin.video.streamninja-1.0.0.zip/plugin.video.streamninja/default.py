# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
#
# ESTREAMNINJA EXPERIMENTAL:
# EstreamNinja es una versión experimental donde se prueban funcionalidades que, 
# eventualmente, podrían llegar a StreamNinja. Destaca por estar desarrollada
# completamente en español.
# 
# Esta versión no está pensada para ser utilizada por el público general ni por 
# otros desarrolladores: el código carece de los comentarios adecuados, no está pulido
# y contiene elementos muertos o descartables de uso exclusivo para pruebas.
# El proyecto original tiene API para que otros addons puedan usar sus funciones.
# Esta versión es solo para uso personal.

"""
==============================================================================
LEGAL DISCLAIMER / AVISO LEGAL:

1. USO EDUCATIVO Y NEUTRALIDAD: Este software es un proyecto experimental y 
   educativo de código abierto. Funciona exclusivamente como una herramienta 
   de red pasiva que facilita la navegación e interoperabilidad de información.
2. NO ALOJAMIENTO (NO HOSTING): Este código no aloja, almacena, retransmite, 
   copia ni distribuye ningún tipo de material ni contenido audiovisual. Toda la 
   comunicación de red ocurre exclusivamente entre el dispositivo del usuario final 
   y los servidores de internet a los que este decida libremente conectarse.
3. SIN ELUSIÓN CRIPTOGRÁFICA (NO DRM BYPASS): El proyecto opera sin interferir, 
   vulnerar, desencriptar o alterar el código de ninguna medida tecnológica 
   de protección o sistema de gestión de derechos digitales cerrados (DRM).
4. EXENCIÓN TOTAL DE RESPONSABILIDAD: El uso de este código queda bajo la 
   estricta responsabilidad del usuario final. El software se proporciona 
   "tal cual" (AS IS), y sus creadores declinan cualquier responsabilidad, 
   no fomentando ni apoyando ningún uso ilícito derivado del mismo.
==============================================================================
"""
import sys
import os
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

import url_player
import url_remote
import info_addon
import stats


def _is_repo_installed():
    """Detecta si el repositorio de StreamNinja está instalado.

    Acepta variaciones razonables del nombre del repositorio
    (guiones, guiones bajos, sufijos) ya que el ID exacto puede
    variar entre versiones o forks del repo.
    """
    # 1. Comprobacion directa de las variantes mas probables
    common_ids = [
        "repository.streamninja",
        "repository.stream_ninja",
        "repository.stream-ninja",
        "repository.streamninja.oficial",
    ]
    for repo_id in common_ids:
        if xbmc.getCondVisibility("System.HasAddon({0})".format(repo_id)):
            return True

    # 2. Búsqueda difusa: recorre las carpetas de addons instaladas
    #    buscando cualquier repositorio cuyo nombre contenga "streamninja"
    try:
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        dirs, _ = xbmcvfs.listdir(addons_dir)
        for d in dirs:
            d_low = d.lower()
            if not d_low.startswith("repository."):
                continue
            # Normalizar: quitar separadores para comparar
            normalized = d_low.replace("_", "").replace("-", "").replace(".", "")
            if "streamninja" in normalized:
                if xbmc.getCondVisibility("System.HasAddon({0})".format(d)):
                    return True
    except Exception:
        pass
    return False


def _check_repo_status():
    """Verifica si el repositorio de actualizaciones está instalado."""
    if _is_repo_installed():
        xbmcgui.Dialog().ok(
            "Repositorio",
            "[COLOR green][B]INSTALADO[/B][/COLOR]\n"
            "El addon se actualiza automáticamente.",
        )
    else:
        xbmcgui.Dialog().ok(
            "Repositorio",
            "[COLOR red][B]NO INSTALADO[/B][/COLOR]\n"
            "Instala desde el Origen ZIP para\n"
            "recibir actualizaciones automáticas.",
        )


# --- Mantenimiento yt-dlp ---

def _show_ytdlp_instructions():
    """Muestra las instrucciones paso a paso de instalación de yt-dlp."""
    text = (
        "Para reproducir videos de YouTube, Dailymotion y otras webs\n"
        "necesitas instalar dos programas gratuitos en tu PC.\n"
        "No te preocupes, es facil. Sigue estos pasos:\n\n"

        "============================================\n"
        "  PRIMERO: ABRIR LA TERMINAL\n"
        "============================================\n\n"
        "La terminal es una ventana donde escribes comandos.\n\n"
        "  Windows:\n"
        "    1. Pulsa la tecla Windows del teclado\n"
        "    2. Escribe:  cmd\n"
        "    3. Haz clic en 'Simbolo del sistema'\n"
        "    Se abrira una ventana negra.\n\n"
        "    TRUCO: Para pegar un comando en esa ventana,\n"
        "    haz CLIC DERECHO con el raton (no Ctrl+V).\n\n"
        "  Mac:\n"
        "    1. Pulsa Cmd + Espacio a la vez\n"
        "    2. Escribe:  Terminal\n"
        "    3. Pulsa Enter\n\n"
        "  Linux:\n"
        "    Pulsa Ctrl + Alt + T a la vez\n\n"

        "============================================\n"
        "  PASO 1: INSTALAR PYTHON\n"
        "============================================\n\n"
        "Puede que ya lo tengas. Para comprobarlo,\n"
        "escribe en la terminal:\n\n"
        "   python --version\n\n"
        "Si aparece algo como 'Python 3.12.0', perfecto,\n"
        "ya lo tienes. Salta al Paso 2.\n\n"
        "Si da error, prueba con:\n"
        "   py --version\n\n"
        "Si tambien falla, necesitas instalarlo:\n\n"
        "   1. Ve a: https://www.python.org/downloads/\n"
        "   2. Descarga la version para tu sistema\n"
        "   3. Ejecuta el instalador\n\n"
        "   >>> MUY IMPORTANTE en Windows: <<<\n"
        "   En la primera pantalla del instalador,\n"
        "   MARCA la casilla que dice:\n"
        "       'Add Python to PATH'\n"
        "   Si no la marcas, nada funcionara.\n\n"
        "   4. Cierra la terminal y vuelve a abrirla\n\n"

        "============================================\n"
        "  PASO 2: INSTALAR YT-DLP\n"
        "============================================\n\n"
        "Escribe (o pega) este comando en la terminal:\n\n"
        '   pip install -U "yt-dlp[default]"\n\n'
        ">>> IMPORTANTE: Escribe el comando TAL CUAL, <<<\n"
        ">>> con las comillas y el [default].          <<<\n"
        ">>> Sin eso, Dailymotion no funcionara.       <<<\n\n"
        "Si 'pip' da error, prueba con:\n\n"
        '   python -m pip install -U "yt-dlp[default]"\n\n'
        "Espera a que termine (puede tardar un minuto).\n\n"

        "============================================\n"
        "  PASO 3: INSTALAR DENO (para YouTube)\n"
        "============================================\n\n"
        "YouTube necesita este programa adicional.\n"
        "Sin el, los videos de YouTube no funcionaran.\n\n"
        "  Windows:\n"
        "    Escribe en la terminal:\n"
        "    winget install DenoLand.Deno\n\n"
        "    Si 'winget' da error:\n"
        "    1. Ve a: https://github.com/denoland/deno/\n"
        "       releases/latest\n"
        "    2. Descarga deno-x86_64-pc-windows-msvc.zip\n"
        "    3. Descomprime y mueve deno.exe a C:\\Windows\\\n\n"
        "  Mac:\n"
        "    Escribe en la terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh\n\n"
        "  Linux:\n"
        "    Escribe en la terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh"
    )
    xbmcgui.Dialog().textviewer("Instrucciones de yt-dlp", text)


def _check_ytdlp_status():
    """Diagnóstico proactivo del estado de yt-dlp y utilidades en el sistema."""
    import subprocess

    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "yt-dlp no es compatible con Android.\n\n"
            "Usa un PC con Python 3.10+ instalado.",
        )
        return

    # kwargs condicional: creationflags solo existe en Windows
    kwargs = {"capture_output": True, "text": True, "timeout": 10}
    if xbmc.getCondVisibility("System.Platform.Windows"):
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

    lines = []

    # Banderas de estado lógicas (desacopladas del texto UI)
    is_ytdlp_ok = False
    is_deno_ok = False
    is_node_ok = False
    is_ejs_ok = False

    # 1. Comprobar yt-dlp
    try:
        kw_ytdlp = kwargs.copy()
        kw_ytdlp["timeout"] = 15
        proc = subprocess.run(["python", "-m", "yt_dlp", "--version"], **kw_ytdlp)
        if proc.returncode == 0:
            ver = proc.stdout.strip()
            lines.append("[COLOR green][OK][/COLOR] yt-dlp instalado: v{0}".format(ver))
            is_ytdlp_ok = True
        else:
            lines.append("[COLOR red][ERROR][/COLOR] yt-dlp encontrado pero devolvió error")
    except FileNotFoundError:
        lines.append("[COLOR red][ERROR][/COLOR] Python no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[COLOR yellow][AVISO][/COLOR] yt-dlp tardó demasiado en responder")
    except OSError as exc:
        lines.append("[COLOR red][ERROR][/COLOR] Error de sistema: {0}".format(exc))

    # 2. Comprobar Deno
    try:
        proc = subprocess.run(["deno", "--version"], **kwargs)
        if proc.returncode == 0:
            deno_ver = proc.stdout.strip().split("\n")[0]
            lines.append("[COLOR green][OK][/COLOR] Deno instalado: {0}".format(deno_ver))
            is_deno_ok = True
        else:
            lines.append("[COLOR red][NO][/COLOR] Deno no disponible")
    except (FileNotFoundError, OSError):
        lines.append("[COLOR red][NO][/COLOR] Deno no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[COLOR yellow][AVISO][/COLOR] Deno tardó demasiado")

    # 3. Comprobar Node.js
    try:
        proc = subprocess.run(["node", "--version"], **kwargs)
        if proc.returncode == 0:
            node_ver = proc.stdout.strip()
            lines.append("[COLOR green][OK][/COLOR] Node.js instalado: {0}".format(node_ver))
            is_node_ok = True
        else:
            lines.append("[COLOR red][NO][/COLOR] Node.js no disponible")
    except (FileNotFoundError, OSError):
        lines.append("[COLOR red][NO][/COLOR] Node.js no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[COLOR yellow][AVISO][/COLOR] Node.js tardó demasiado")

    # 4. Comprobar yt-dlp-ejs
    try:
        proc = subprocess.run(["python", "-c", "import yt_dlp_ejs"], **kwargs)
        if proc.returncode == 0:
            lines.append("[COLOR green][OK][/COLOR] yt-dlp-ejs instalado")
            is_ejs_ok = True
        else:
            lines.append("[COLOR red][NO][/COLOR] yt-dlp-ejs no instalado")
            lines.append('     Instálalo: pip install -U "yt-dlp[default]"')
    except (FileNotFoundError, OSError):
        lines.append("[COLOR red][NO][/COLOR] No se pudo comprobar yt-dlp-ejs")
    except subprocess.TimeoutExpired:
        pass

    # Resumen inteligente (basado en lógica, no en matching de strings de UI)
    has_js = is_deno_ok or is_node_ok
    lines.append("")
    lines.append("===== RESUMEN =====")
    if is_ytdlp_ok and has_js and is_ejs_ok:
        lines.append("[COLOR green]Todo OK. YouTube debería funcionar correctamente.[/COLOR]")
    elif is_ytdlp_ok and has_js and not is_ejs_ok:
        lines.append("[COLOR yellow]Falta yt-dlp-ejs. Ejecuta:[/COLOR]")
        lines.append('   pip install -U "yt-dlp[default]"')
    elif is_ytdlp_ok and not has_js:
        lines.append("[COLOR yellow]Falta un runtime JS (Deno o Node.js).[/COLOR]")
        lines.append("YouTube podría fallar sin él.")
        lines.append("Pulsa 'Instrucciones' en el menú para más info.")
    else:
        lines.append("[COLOR red]yt-dlp no detectado o fallando.[/COLOR]")
        lines.append("Pulsa 'Instrucciones' en el menú para más info.")

    xbmcgui.Dialog().textviewer("StreamNinja — Estado de yt-dlp", "\n".join(lines))


def _copy_to_clipboard(text):
    """Copia texto al portapapeles del sistema operativo."""
    import subprocess
    import shutil
    try:
        if xbmc.getCondVisibility("System.Platform.Windows"):
            p = subprocess.Popen(
                ["clip"], stdin=subprocess.PIPE, text=True,
                encoding="utf-8",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            p.communicate(input=text)
            return True
        elif xbmc.getCondVisibility("System.Platform.OSX"):
            p = subprocess.Popen(
                ["pbcopy"], stdin=subprocess.PIPE, text=True,
                encoding="utf-8",
            )
            p.communicate(input=text)
            return True
        elif xbmc.getCondVisibility("System.Platform.Linux"):
            if shutil.which("xclip"):
                p = subprocess.Popen(
                    ["xclip", "-selection", "clipboard"],
                    stdin=subprocess.PIPE, text=True, encoding="utf-8",
                )
                p.communicate(input=text)
                return True
            elif shutil.which("xsel"):
                p = subprocess.Popen(
                    ["xsel", "--clipboard", "--input"],
                    stdin=subprocess.PIPE, text=True, encoding="utf-8",
                )
                p.communicate(input=text)
                return True
    except Exception:
        pass
    # Fallback universal via tkinter
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(text)
        r.update()
        r.destroy()
        return True
    except Exception:
        pass
    return False


def _ytdlp_menu():
    """Submenú de mantenimiento de yt-dlp."""
    opts = [
        "Instrucciones: instalar / actualizar yt-dlp",
        "Comprobar estado de yt-dlp",
        "Copiar comandos de instalación al portapapeles",
    ]
    sel = xbmcgui.Dialog().select("Mantenimiento PC (yt-dlp)", opts)
    if sel == 0:
        _show_ytdlp_instructions()
    elif sel == 1:
        _check_ytdlp_status()
    elif sel == 2:
        cmd_ytdlp = 'pip install -U "yt-dlp[default]"'
        if xbmc.getCondVisibility("System.Platform.Windows"):
            cmd_deno = "winget install DenoLand.Deno"
        else:
            cmd_deno = "curl -fsSL https://deno.land/install.sh | sh"
        full_text = "{0}\n{1}".format(cmd_ytdlp, cmd_deno)
        if _copy_to_clipboard(full_text):
            xbmcgui.Dialog().ok(
                "Portapapeles",
                "Los comandos se han copiado.\n"
                "Pegalos en tu terminal (clic derecho\n"
                "o Ctrl+V) y pulsa Enter.",
            )
        else:
            xbmcgui.Dialog().ok(
                "Error",
                "No se pudo copiar al portapapeles.\n\n"
                "Copialos manualmente desde las\n"
                "instrucciones.",
            )


# --- Auto-instaladores desde GitHub ---

def _generic_github_installer(nombre, api_url, target_id):
    """Descarga e instala un addon desde GitHub Releases.

    Busca el primer asset .zip de la ultima release, valida
    su integridad, lo extrae en la carpeta de addons y lo activa.
    """
    import requests
    import zipfile

    dp = xbmcgui.DialogProgress()
    dp.create("StreamNinja", "Descargando {0}...".format(nombre))
    zip_path = None
    try:
        dp.update(5, "Buscando ultima version...")
        r = requests.get(api_url, timeout=15)
        r.raise_for_status()
        assets = r.json().get("assets", [])
        zip_url = None
        for asset in assets:
            if asset.get("name", "").endswith(".zip"):
                zip_url = asset["browser_download_url"]
                break
        if not zip_url:
            raise ValueError(
                "No se encontro ningun archivo .zip en la release")

        dp.update(10, "Descargando desde GitHub...")
        r_zip = requests.get(zip_url, timeout=60, allow_redirects=True)
        r_zip.raise_for_status()

        # Validar magic bytes del ZIP
        if len(r_zip.content) < 4 or r_zip.content[:2] != b"PK":
            raise ValueError("El archivo descargado no es un ZIP valido")

        # Guardar en temporal
        zip_path = os.path.join(
            xbmcvfs.translatePath("special://temp/"),
            "{0}.zip".format(target_id),
        )
        with open(zip_path, "wb") as f:
            f.write(r_zip.content)

        dp.update(50, "Extrayendo addon...")
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        with zipfile.ZipFile(zip_path, "r") as zf:
            # Proteccion contra path traversal
            for entry in zf.namelist():
                resolved = os.path.realpath(
                    os.path.join(addons_dir, entry))
                if not resolved.startswith(os.path.realpath(addons_dir)):
                    raise ValueError(
                        "ZIP contiene ruta sospechosa: {0}".format(entry))
            zf.extractall(addons_dir)

        dp.update(80, "Actualizando addons locales...")
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.sleep(2000)
        xbmc.executebuiltin("EnableAddon({0})".format(target_id))
        xbmc.sleep(1000)
        dp.close()
        xbmcgui.Dialog().notification(
            "StreamNinja",
            "{0} instalado correctamente".format(nombre),
            xbmcgui.NOTIFICATION_INFO, 5000,
        )
        xbmc.executebuiltin("Container.Refresh")
    except Exception as exc:
        dp.close()
        xbmc.log(
            "[StreamNinja] Error instalando {0}: {1}".format(nombre, exc),
            xbmc.LOGWARNING,
        )
        choice = xbmcgui.Dialog().yesno(
            "Error de instalacion",
            "No se pudo instalar {0}.\n\n"
            "Error: {1}\n\n"
            "Puede que necesites activar\n"
            "'Origenes desconocidos' en Ajustes.\n"
            "¿Abrir Ajustes del Sistema?".format(
                nombre, str(exc)[:150]),
        )
        if choice:
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


def _loiolog_install():
    """Menú de instalación de loiolog con opción automática y manual."""
    opts = ["Instalar automáticamente", "Ver instrucciones manuales"]
    sel = xbmcgui.Dialog().select("loiolog — Gestor Avanzado de Logs", opts)
    if sel == 0:
        _generic_github_installer(
            "loiolog",
            "https://api.github.com/repos/loioloio/loiolog/releases/latest",
            "plugin.program.loiolog",
        )
    elif sel == 1:
        xbmcgui.Dialog().ok(
            "Instalación manual",
            "Descarga el ZIP desde:\n"
            "github.com/loioloio/loiolog/releases\n\n"
            "En Kodi: Addons > Instalar desde ZIP.",
        )


def _flowfav_install():
    """Instala Flow FavManager desde GitHub Releases."""
    _generic_github_installer(
        "Flow FavManager",
        "https://api.github.com/repos/loioloio/flowfav/releases/latest",
        "plugin.program.flowfavmanager",
    )


def _user_message_dialog():
    """Abre el teclado de Kodi para que el usuario escriba un reporte o comentario."""
    addon = xbmcaddon.Addon()
    existing_msg = addon.getSetting('user_message').strip()

    kb = xbmc.Keyboard(existing_msg, "Reportar un problema o dejar un comentario (max. 150 caracteres)")
    kb.doModal()

    if not kb.isConfirmed():
        return

    raw_msg = kb.getText().strip()
    new_msg = raw_msg[:150]

    # Avisar al usuario si su mensaje fue recortado
    if len(raw_msg) > 150:
        continuar = xbmcgui.Dialog().yesno(
            "Mensaje demasiado largo",
            "Tu mensaje supera los 150 caracteres y sera recortado.\n\n"
            "Asi es como llegara al equipo de StreamNinja:\n\n"
            "\"{0}...\"\n\n"
            "\u00bfGuardar igualmente?".format(new_msg[:80])
        )
        if not continuar:
            return

    addon.setSetting('user_message', new_msg)

    if new_msg:
        xbmcgui.Dialog().ok(
            "Mensaje guardado",
            "Tu reporte se ha guardado y se enviara automaticamente\n"
            "al equipo de StreamNinja.\n\n"
            "[COLOR yellow]Nota:[/COLOR] Si vuelves aqui y borras el texto,\n"
            "el reporte tambien desaparecera."
        )
    else:
        xbmcgui.Dialog().ok(
            "Mensaje borrado",
            "Has dejado el mensaje en blanco.\n"
            "El reporte ha sido eliminado."
        )


# --- Mis Descargas ---

def _show_downloads():
    """Genera el directorio visual de descargas locales.

    Muestra un enlace a Elementum (si esta instalado), el historial
    de archivos descargados con verificacion de existencia en disco,
    y una nota legal al final.
    """
    import download_manager

    h = int(sys.argv[1])
    url_base = sys.argv[0]

    # Historial de descargas propias
    downloads = download_manager.get_downloads()
    if not downloads:
        li = xbmcgui.ListItem(label="No hay historial de descargas")
        li.setArt({"icon": "DefaultIconInfo.png"})
        li.setInfo("video", {
            "plot": "Cuando descargues un video, aparecera aqui.\n"
                    "Usa Abrir URL > Descargar para guardar contenido.",
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url="", listitem=li, isFolder=False,
        )
    else:
        for entry in downloads:
            file_path = entry.get("path", "")
            title = entry.get("title", "Sin titulo")
            date = entry.get("date", "")
            file_exists = os.path.exists(file_path)

            if file_exists:
                label = "{0} ({1})".format(title, date)
            else:
                label = "[COLOR grey][ELIMINADO][/COLOR] {0}".format(title)

            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": "DefaultVideo.png"})
            li.setInfo("video", {
                "title": title,
                "plot": "Archivo: {0}\nDescargado el: {1}".format(
                    file_path, date),
            })

            # Menu contextual
            cm = [
                ("Quitar del historial",
                 "RunPlugin({0}?action=remove_download&dl_path={1})".format(
                     url_base,
                     urllib.parse.quote(file_path, safe=""))),
            ]
            if file_exists:
                li.setProperty("IsPlayable", "true")
                cm.append(
                    ("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]",
                     "RunPlugin({0}?action=delete_download_file"
                     "&dl_path={1}&title={2})".format(
                         url_base,
                         urllib.parse.quote(file_path, safe=""),
                         urllib.parse.quote(title, safe=""))))

            li.addContextMenuItems(cm)
            play_url = file_path if file_exists else ""
            xbmcplugin.addDirectoryItem(
                handle=h, url=play_url, listitem=li,
                isFolder=not file_exists,
            )

    xbmcplugin.endOfDirectory(h)


def _delete_download_file(file_path, title):
    """Elimina un archivo descargado del disco y del historial.

    Pide confirmacion explicita al usuario antes de borrar para
    evitar perdidas accidentales de datos.
    """
    import download_manager

    display_title = title or "Sin titulo"
    display_path = file_path or ""

    if not display_path:
        return

    confirmed = xbmcgui.Dialog().yesno(
        "Eliminar Archivo",
        "Vas a eliminar este archivo del disco:\n\n"
        "[B]{0}[/B]\n\n"
        "Esta accion es irreversible.".format(display_title),
    )
    if not confirmed:
        return

    try:
        if os.path.exists(display_path):
            os.remove(display_path)
            download_manager.remove_download(display_path)
            xbmcgui.Dialog().notification(
                "StreamNinja", "Archivo eliminado",
                xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "El archivo ya no existe en esa ruta.")
            download_manager.remove_download(display_path)
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "No se pudo eliminar:\n{0}".format(str(exc)[:200]))

    xbmc.executebuiltin("Container.Refresh")


# --- Constructor visual del menú avanzado ---

def advanced_menu():
    """Genera el directorio de Mantenimiento y Diagnóstico de StreamNinja.

    Los ajustes de motor (Anti-Errores, Modo Descarga, Ruta) se
    gestionan desde la ventana nativa de Kodi (settings.xml).
    Este menu conserva las herramientas operativas e interactivas.
    """
    h = int(sys.argv[1])
    url_base = sys.argv[0]

    # 1. Mantenimiento yt-dlp (solo plataformas de escritorio)
    if xbmc.getCondVisibility(
        "System.Platform.Windows | System.Platform.Linux | "
        "System.Platform.OSX"
    ):
        li = xbmcgui.ListItem("Mantenimiento PC (yt-dlp)")
        li.setArt({"icon": "DefaultAddonService.png"})
        li.setInfo("video", {
            "plot": "Instrucciones para instalar yt-dlp en tu PC,\n"
                    "diagnostico del estado actual, y copia de\n"
                    "los comandos al portapapeles.",
        })
        xbmcplugin.addDirectoryItem(
            h, "{0}?action=ytdlp_menu".format(url_base), li, False,
        )

    # 2. loiolog
    if xbmc.getCondVisibility("System.HasAddon(plugin.program.loiolog)"):
        li = xbmcgui.ListItem(
            "loiolog \u2014 Gestor Avanzado de Logs \u2014 "
            "[COLOR green]INSTALADO[/COLOR]"
        )
        li.setArt({"icon": "DefaultAddonService.png"})
        li.setInfo("video", {
            "plot": "Herramienta avanzada para ver y filtrar\n"
                    "el log de Kodi. Pulsa para abrir.",
        })
        xbmcplugin.addDirectoryItem(
            h, "{0}?action=open_loiolog".format(url_base), li, False,
        )
    else:
        li = xbmcgui.ListItem(
            "loiolog \u2014 Gestor Avanzado de Logs \u2014 "
            "[COLOR red]NO INSTALADO[/COLOR]"
        )
        li.setArt({"icon": "DefaultAddonService.png"})
        li.setInfo("video", {
            "plot": "Herramienta para diagnosticar problemas.\n"
                    "Pulsa para instalar desde GitHub.",
        })
        xbmcplugin.addDirectoryItem(
            h, "{0}?action=loiolog_install".format(url_base), li, False,
        )

    # 3. Estado del repositorio
    if _is_repo_installed():
        li = xbmcgui.ListItem(
            "Repositorio: [COLOR green]INSTALADO[/COLOR]"
        )
    else:
        li = xbmcgui.ListItem(
            "Repositorio: [COLOR red]NO INSTALADO[/COLOR]"
        )
    li.setArt({"icon": "DefaultAddonRepository.png"})
    li.setInfo("video", {
        "plot": "Verifica que el repositorio esta vinculado\n"
                "para recibir actualizaciones automaticas.",
    })
    xbmcplugin.addDirectoryItem(
        h, "{0}?action=check_repo_status".format(url_base), li, False,
    )

    # 4. Enviar reporte
    addon = xbmcaddon.Addon()
    existing_msg = addon.getSetting('user_message').strip()
    msg_label = (
        "Enviar Reporte \u2014 [COLOR green]Tienes uno guardado[/COLOR]"
        if existing_msg else
        "Enviar Reporte"
    )
    li = xbmcgui.ListItem(msg_label)
    li.setArt({"icon": "DefaultAddonContextItem.png"})
    li.setInfo("video", {
        "plot": "Reporta un problema o deja un comentario (max. 150 caracteres)\n"
                "que llegara directamente al equipo de StreamNinja.\n"
                "Ideal para errores u opiniones.",
    })
    xbmcplugin.addDirectoryItem(
        h, "{0}?action=user_message_dialog".format(url_base), li, False,
    )

    xbmcplugin.endOfDirectory(h)


def _parse_qs(qs):
    _seed = "cnViZW5zZGZhMWxhYmVybnQ="
    return dict(urllib.parse.parse_qsl(qs))

def _ensure_disclaimer_file(addon):
    """Genera un archivo AVISO_LEGAL.txt en la carpeta de configuracion del addon (CYA legal)."""
    try:
        prof = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        if not os.path.exists(prof):
            os.makedirs(prof)
        disc_path = os.path.join(prof, "AVISO_LEGAL.txt")
        if not os.path.exists(disc_path):
            with open(disc_path, "w", encoding="utf-8") as f:
                f.write(
                    "*** AVISO IMPORTANTE SOBRE EL USO DE CREDENCIALES ***\n\n"
                    "Los desarrolladores de StreamNinja NO promueven, facilitan ni aprueban\n"
                    "la compartición de tokens, cuentas o credenciales de servicios de terceros.\n\n"
                    "La funcionalidad de inicio de sesión de este addon ha sido desarrollada\n"
                    "EXCLUSIVAMENTE para uso estrictamente personal. Su objetivo es permitir a\n"
                    "los usuarios legítimos disfrutar del contenido al\n"
                    "que tienen derecho legal en la interfaz de Kodi.\n\n"
                    "Cualquier extracción, copia, distribución o compartición de los archivos\n"
                    "de esta carpeta (incluyendo 'auth_vault.json') con terceras personas es\n"
                    "responsabilidad única y exclusiva del usuario, y va contra la filosofía del proyecto.\n\n"
                    "Aclaración técnica: Las credenciales se guardan de forma visible porque Kodi es incapaz\n"
                    "de leer archivos encriptados. Si existiera cualquier manera de encriptar\n"
                    "las credenciales, se habría hecho sin dudarlo.\n\n"
                    "StreamNinja no almacena credenciales en servidores externos ni se hace\n"
                    "responsable del mal uso de las herramientas aquí proporcionadas.\n"
                )
    except Exception:
        pass

def main():
    addon = xbmcaddon.Addon()
    _ensure_disclaimer_file(addon)

    stats.ping()
    qs = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = _parse_qs(qs)
    action = params.get("action", "")

    try:
        if not action or action == "url_dialog":
            url_player.open_url_dialog()
        elif action == "url_input":
            url_player.url_input()
        elif action == "url_play_clipboard":
            try:
                win = xbmcgui.Window(10000)
                clipboard_url = win.getProperty("streamninja.clipboard.url").strip()
                if clipboard_url:
                    url_player.play_url_action(clipboard_url)
                else:
                    xbmcgui.Dialog().notification("StreamNinja", "Portapapeles vacío", xbmcgui.NOTIFICATION_WARNING)
            except Exception as e:
                xbmc.log("[StreamNinja] Error leyendo portapapeles: {0}".format(e), xbmc.LOGWARNING)
        elif action == "url_clipboard_clear":
            try:
                win = xbmcgui.Window(10000)
                win.clearProperty("streamninja.clipboard.url")

                xbmc.executebuiltin("Container.Refresh")
                xbmcgui.Dialog().notification("StreamNinja", "Botón quitado", xbmcgui.NOTIFICATION_INFO, 1500)
            except Exception as e:
                xbmc.log("[StreamNinja] Error limpiando portapapeles: {0}".format(e), xbmc.LOGWARNING)
        elif action == "url_remote":
            url_remote.start_remote()
        elif action == "url_scan":
            url_player.scan_videos_dialog()
        elif action == "url_history":
            url_player.url_history_menu()
        elif action == "url_bookmarks":
            url_player.url_bookmarks_menu()
        elif action in ("url_bookmark_add", "url_bookmark_save_from_history"):
            url = params.get("url")
            if url:
                url_player.bookmark_save_from_history(url)
        elif action in ("url_bookmark_remove", "url_bookmark_delete"):
            url = params.get("url")
            if url:
                url_player.bookmark_delete(url)
        elif action == "url_bookmark_rename":
            url = params.get("url")
            if url:
                url_player.bookmark_rename(url)
        elif action in ("history_clear", "url_history_clear"):
            url_player.history_clear()
        elif action in ("history_remove", "url_history_remove"):
            url = params.get("url")
            if url:
                url_player.history_remove(url)
        elif action == "url_play":
            url = params.get("url")
            if url:
                url_player.play_url_action(url)
        elif action == "url_download":
            url = params.get("url", "")
            if url:
                url_player._resolve_and_download(url)
        elif action == "api_resolve":
            url = params.get("url")
            if url:
                url_player.api_resolve_action(url)
        elif action == "pv":
            url = params.get("vid") or params.get("url")
            if url:
                url_player.play_url_action(url)
        elif action == "copy_url":
            url = params.get("url")
            if url:
                xbmcgui.Window(10000).setProperty("streamninja.clipboard.url", url)
                xbmcgui.Dialog().notification("StreamNinja", "URL copiada al Portapapeles", xbmcgui.NOTIFICATION_INFO, 1500)
        elif action == "open_login":
            url_player.open_login_dialog()
        elif action == "open_settings":
            xbmcaddon.Addon("plugin.video.streamninja").openSettings()
            xbmc.executebuiltin("Container.Refresh")
        elif action == "info_menu":
            info_addon.info_menu()
        elif action == "show_universo":
            info_addon.show_universo()
        elif action == "info":
            info_addon.info()
        elif action == "advanced_menu":
            advanced_menu()

        elif action == "check_repo_status":
            _check_repo_status()
        elif action == "loiolog_install":
            _loiolog_install()
        elif action == "open_loiolog":
            xbmc.executebuiltin("RunAddon(plugin.program.loiolog)")
        elif action == "flowfav_install":
            _flowfav_install()
        elif action == "ytdlp_menu":
            _ytdlp_menu()
        elif action == "user_message_dialog":
            _user_message_dialog()
        elif action == "open_flowfav":
            xbmc.executebuiltin(
                "RunAddon(plugin.program.flowfavmanager)")

        # --- Mis Descargas ---
        elif action == "show_downloads":
            _show_downloads()
        elif action == "remove_download":
            import download_manager
            dl_path = params.get("dl_path", "")
            if dl_path:
                download_manager.remove_download(dl_path)
                xbmc.executebuiltin("Container.Refresh")
        elif action == "delete_download_file":
            _delete_download_file(
                params.get("dl_path", ""),
                params.get("title", ""))

    except Exception as e:
        xbmc.log("[StreamNinja] Error in default.py routing: {0}".format(e), xbmc.LOGERROR)

if __name__ == "__main__":
    main()

