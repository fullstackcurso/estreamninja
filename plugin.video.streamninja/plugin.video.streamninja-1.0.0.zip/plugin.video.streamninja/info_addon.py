# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
#
# ESTREAMNINJA EXPERIMENTAL:
# EstreamNinja es una versión experimental donde se prueban funcionalidades que, 
# eventualmente, podrían llegar a StreamNinja. Destaca por estar desarrollada
# completamente en español.
# 
# Esta versión no está pensada para ser utilizada por el público general ni por 
# otros desarrolladores: el código carece de los comentarios adecuados, no está pulido
# y contiene elementos muertos o descartables de uso exclusivo para pruebas.
"""
Modulo de informacion del addon.

Gestiona el submenu de informacion, el aviso legal
y la descarga en segundo plano de recursos graficos
para el dialogo Universo.
"""
import sys
import os
import threading
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _get_handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _bg_download_ascii():
    """Descarga en segundo plano la imagen de fondo para el dialogo Universo. Easter egg."""
    import time as _t
    _t.sleep(5)
    _profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(_profile):
        os.makedirs(_profile)
    _dst = os.path.join(_profile, 'sn.jpg')
    if os.path.exists(_dst):
        return
    try:
        import requests
        import base64
        _url_b64 = b'aHR0cHM6Ly9naXRodWIuY29tL2Z1bGxzdGFja2N1cnNvL1J1dGEtRnVsbHN0YWNrL3JlbGVhc2VzL2Rvd25sb2FkL0NvcGlhX1JlYWRtZS9zbi5qcGc='
        _url = base64.b64decode(_url_b64).decode('utf-8')
        r = requests.get(_url, timeout=10)
        if r.status_code == 200 and len(r.content) > 1000:
            with open(_dst, 'wb') as f:
                f.write(r.content)
    except Exception:
        pass


def start_bg_download():
    threading.Thread(target=_bg_download_ascii, daemon=True).start()


def info_menu():
    """Submenu de informacion del addon."""
    h = _get_handle()
    li = xbmcgui.ListItem(label="[COLOR skyblue]Universo EspaKodi[/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_universo"), listitem=li, isFolder=False)

    li3 = xbmcgui.ListItem(label="Información del Addon v{0}".format(xbmcaddon.Addon().getAddonInfo('version')))
    li3.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="info"), listitem=li3, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def show_universo():
    """Abre la ventana grafica Universo EspaKodi."""
    import universo
    universo.show()


def info():
    """Muestra el aviso legal e informacion del addon."""
    t = (
        "[COLOR skyblue][B]ESTREAMNINJA[/B][/COLOR]"
        " es una versión experimental en español derivada de StreamNinja, con funciones que podrían o no llegar a integrarse en el proyecto principal.\n"
        "Repositorio: [COLOR lightblue]github.com/fullstackcurso[/COLOR]\n"
        "Contacto: [COLOR lightblue]t.me/rubensdfa1laberot[/COLOR]\n\n"
        "----------------------------------------------------------\n"
        "[COLOR red][B]AVISO LEGAL[/B][/COLOR]\n"
        "----------------------------------------------------------\n\n"
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. No tiene ninguna afiliación "
        "ni vinculación con ninguna plataforma oficial.\n\n"
        "[B]2. Naturaleza Técnica:[/B]\n"
        "Este software actúa como una pasarela de red. No contiene, "
        "aloja ni sube contenido protegido. Se limita a establecer conexiones "
        "hacia las direcciones de internet elegidas libremente por el usuario.\n\n"
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El usuario es el único responsable de verificar la legalidad "
        "del acceso a los contenidos según las leyes de su país. "
        "Este addon se proporciona \"tal cual\", sin garantías de ningún tipo. "
        "StreamNinja no se hace responsable de la información transmitida "
        "por la red local o remota a la que decidas conectarte.\n\n"
        "[B]4. Naturaleza del proyecto:[/B]\n"
        "Es GRATUITO y sin ánimo de lucro.\n\n"
        "[B]5. Telemetría Anónima:[/B]\n"
        "Para decidir qué versiones requieren soporte prioritario, se envía de forma anónima el sistema operativo, "
        "versión del addon y de Kodi. Con esto solo se actualizan porcentajes, no se guarda ninguna información personal ni IPs. "
        "Este proyecto defiende la privacidad absoluta y no se tiene el más mínimo interés en rastrear, perfilar ni vigilar a los usuarios.\n\n"
        "[B]6. Contacto y Retirada:[/B]\n"
        "Si es titular de derechos y considera que este código viola alguna "
        "política, contacte a través de Telegram."
    )
    xbmcgui.Dialog().textviewer("Información de StreamNinja", t)
