# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
"""
Gestiona el historial de descargas locales del addon.

Almacena un registro persistente en ``downloads_history.json`` dentro
del directorio de perfil del addon (``special://profile/``).  Las
entradas se mantienen en orden cronologico inverso y se limitan a un
maximo configurable para evitar crecimiento descontrolado.
"""
import json
import os
import time

import xbmcaddon
import xbmcvfs

# Limite de entradas almacenadas en el historial.
_MAX_ENTRIES = 50

# Ruta al JSON de historial (se crea bajo demanda).
_HISTORY_FILE = None


def _get_history_path():
    """Devuelve la ruta absoluta al fichero de historial.

    Crea el directorio de perfil si aun no existe.
    """
    global _HISTORY_FILE
    if _HISTORY_FILE is None:
        profile = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile"))
        if not os.path.exists(profile):
            os.makedirs(profile)
        _HISTORY_FILE = os.path.join(profile, "downloads_history.json")
    return _HISTORY_FILE


def get_downloads():
    """Lee el historial de descargas y devuelve una lista de dicts.

    Cada entrada contiene las claves ``title``, ``path``, ``source``
    y ``date``.  Si el fichero no existe o esta corrupto, devuelve
    una lista vacia sin propagar excepciones.
    """
    path = _get_history_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, list):
            return []
        return data
    except (json.JSONDecodeError, IOError, OSError):
        return []


def log_download(title, file_path, source=""):
    """Registra una nueva descarga al inicio del historial.

    Args:
        title:     Titulo legible del contenido descargado.
        file_path: Ruta absoluta al archivo guardado en disco.
        source:    Identificador del motor usado (``MP4``, ``HLS``,
                   ``YT-DLP``).
    """
    downloads = get_downloads()
    entry = {
        "title": str(title),
        "path": str(file_path),
        "source": str(source),
        "date": time.strftime("%d/%m/%Y %H:%M"),
    }
    downloads.insert(0, entry)
    downloads = downloads[:_MAX_ENTRIES]
    _save(downloads)


def remove_download(file_path):
    """Elimina del historial todas las entradas cuya ruta coincida.

    No toca el archivo fisico en disco; solo actualiza el JSON.
    """
    downloads = get_downloads()
    filtered = [d for d in downloads if d.get("path") != file_path]
    _save(filtered)


def _save(data):
    """Escribe la lista de descargas al fichero JSON de forma atomica."""
    path = _get_history_path()
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except (IOError, OSError):
        # Intento directo si el rename falla (p.ej. fs sin soporte)
        try:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False)
        except (IOError, OSError):
            pass
