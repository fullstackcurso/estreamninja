# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE para mas detalles.
"""
HUD de estadísticas P2P sobre el reproductor de vídeo de Kodi (ventana 12901),
equivalente al OSD de Horus. Diseño defensivo:

  - Un único dueño: un token de generación protegido por lock. Cada start() invalida
    al hilo anterior, así reproducir dos streams seguidos no deja dos juegos de
    controles colgados en la ventana.
  - El hilo NUNCA puede romper la reproducción: todo va en try/except y los controles
    se retiran en finally (fin de reproducción, apagado de Kodi o relevo de generación).
  - Sin red mientras el OSD está oculto: solo se sondea stat_url cuando el usuario abre
    el OSD de vídeo. Cuando no se usa, no consume nada.

El fondo usa resources/media/white.png teñido (truco estándar de Kodi: textura blanca
de 1px + colorDiffuse), que existe siempre, en vez de depender de texturas del skin.
"""
import os
import threading
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_VIDEO_OSD = 12901

_lock = threading.Lock()
_generation = 0  # el hilo solo actúa mientras su generación siga siendo la vigente


def start(stat_url):
    """Arranca el HUD para la sesión cuyo stat_url se pasa. Invalida cualquier HUD previo
    (el token de generación hace que el hilo anterior salga y retire sus controles)."""
    if not stat_url:
        return
    global _generation
    with _lock:
        _generation += 1
        my_gen = _generation
    threading.Thread(target=_run, args=(stat_url, my_gen), daemon=True).start()


def _media(name):
    return os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media", name)


def _skin_resolution():
    """(ancho, alto) del skin para anclar el panel arriba a la derecha en cualquier resolución."""
    try:
        tree = ET.parse(xbmcvfs.translatePath("special://skin/addon.xml"))
        res = tree.find("./extension/res")
        if res is None:
            res = tree.find("./res")
        return int(res.attrib["width"]), int(res.attrib["height"])
    except Exception:
        return 1280, 720


class _Hud:
    def __init__(self):
        screen_w, _ = _skin_resolution()
        pw, ph = 380, 156
        x = max(0, screen_w - pw - 40)
        y = 60
        tx, tw = x + 20, pw - 40

        bg = xbmcgui.ControlImage(x, y, pw, ph, _media("white.png"))
        try:
            bg.setColorDiffuse("0xD90A0E14")
        except Exception:
            pass
        self.l_title = xbmcgui.ControlLabel(tx, y + 12, tw, 26, "StreamNinja · AceStream",
                                            textColor="0xFF22D3EE")
        self.l_status = xbmcgui.ControlLabel(tx, y + 46, tw, 24, "", textColor="0xFFFFFFFF")
        self.l_speed = xbmcgui.ControlLabel(tx, y + 76, tw, 24, "", textColor="0xFFFFFFFF")
        self.l_peers = xbmcgui.ControlLabel(tx, y + 106, tw, 24, "", textColor="0xFFFFFFFF")
        self._controls = [bg, self.l_title, self.l_status, self.l_speed, self.l_peers]

        self._win = xbmcgui.Window(_VIDEO_OSD)
        self._added = False

    def show(self):
        if self._added:
            return
        for c in self._controls:
            self._win.addControl(c)
        self._added = True

    def hide(self):
        if not self._added:
            return
        self._added = False
        for c in self._controls:
            try:
                self._win.removeControl(c)
            except Exception:
                pass

    def update(self, data):
        # Solo métricas de unidad verificada: status, peers y speed_down (KB/s, como usa
        # el prebuffer). speed_up se muestra si el motor lo aporta. No mostramos totales
        # de bajada/subida porque su unidad en la API no está confirmada.
        status = data.get("status", "")
        peers = data.get("peers", 0)
        down = data.get("speed_down", 0)
        up = data.get("speed_up", 0)
        self.l_status.setLabel("Estado: {0}".format(status or "—"))
        self.l_speed.setLabel(
            "[COLOR FF86EFAC]↓ {0} KB/s[/COLOR]    [COLOR FFFCA5A5]↑ {1} KB/s[/COLOR]".format(down, up))
        self.l_peers.setLabel("Fuentes (peers): {0}".format(peers))


def _stats(stat_url):
    """GET de stats reutilizando el cliente del reproductor; tolera el wrapper {response:{}}."""
    import acestream_player
    raw = acestream_player._api_get(stat_url, timeout=3)
    if not isinstance(raw, dict):
        return {}
    inner = raw.get("response")
    return inner if isinstance(inner, dict) else raw


def _run(stat_url, my_gen):
    monitor = xbmc.Monitor()
    player = xbmc.Player()

    # Esperar al inicio real del AV; arrancar el bucle con isPlaying()==False lo cerraría
    # de inmediato y nunca se vería el OSD.
    for _ in range(150):  # ~30 s en pasos de 200 ms
        if my_gen != _generation or monitor.abortRequested():
            return
        if player.isPlaying():
            break
        if monitor.waitForAbort(0.2):
            return
    else:
        return  # el AV nunca arrancó

    # Fichero de NUESTRA sesión; si cambia, otra reproducción tomó el relevo y no debemos
    # dejar el OSD encima (no comparamos contra playback_url porque Kodi puede normalizarlo).
    try:
        our_file = player.getPlayingFile()
    except Exception:
        our_file = ""

    hud = None
    visible = False
    try:
        hud = _Hud()
        while my_gen == _generation and not monitor.abortRequested():
            if not player.isPlaying():
                break
            try:
                current = player.getPlayingFile()
            except Exception:
                current = ""
            if our_file and current and current != our_file:
                break
            osd_open = xbmc.getCondVisibility("Window.IsActive(videoosd)")
            if osd_open and not visible:
                hud.show()
                visible = True
            elif not osd_open and visible:
                hud.hide()
                visible = False
            if visible:
                hud.update(_stats(stat_url))
            if monitor.waitForAbort(1):
                break
    except Exception as e:
        xbmc.log("[StreamNinja/acestream_osd] {0}".format(e), xbmc.LOGWARNING)
    finally:
        if hud is not None:
            hud.hide()
