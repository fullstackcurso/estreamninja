﻿# -*- coding: utf-8 -*-
# StreamNinja; Copyright (C) 2024-2026 RubénSDFA1laberot
# Licencia: Consulta el archivo LICENSE.
"""Grabador nativo HLS para el PVR."""
import collections
import errno
import os
import re
import shutil
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
from _user_agents import UA_DESKTOP
import xbmcgui

_PLAYLIST_MAX_BYTES = 8 * 1024 * 1024  # Guard: ningún manifest HLS legítimo supera esto
_SEGMENT_CHUNK_BYTES = 64 * 1024  # Tamaño de bloque al volcar segmentos a disco
_MIN_FREE_SPACE_BYTES = 500 * 1024 * 1024  # Aborta la grabación si el disco baja de aquí
_FFMPEG_STDERR_RING_LINES = 800  # ~64KB de cola de stderr para diagnosticar fallos de FFmpeg
_DISK_CHECK_INTERVAL_S = 30  # Cada cuánto se comprueba el espacio libre durante la grabación

# En Windows, lanzar ffmpeg.exe sin esto abre un parpadeo de consola en cada grabación.
_FFMPEG_CREATIONFLAGS = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0


def ffmpeg_available():
    return shutil.which('ffmpeg') is not None


class HLSRecorder(threading.Thread):
    def __init__(self, m3u8_url, output_file, name="", max_duration_mins=0, max_bandwidth=0,
                 callback_progress=None, callback_finish=None, compress=False, compress_crf=26):
        super().__init__()
        self.m3u8_url = m3u8_url
        self.output_file = output_file
        self.channel_name = name
        self.max_duration_mins = max_duration_mins
        self.max_bandwidth = max_bandwidth
        self.callback_progress = callback_progress
        self.callback_finish = callback_finish
        self.compress = compress
        self.compress_crf = compress_crf

        self.daemon = True
        self._stop_event = threading.Event()
        self._monitor = xbmc.Monitor()
        self.downloaded_bytes = 0

        self.downloaded_queue = collections.deque(maxlen=1000)
        self.downloaded_set = set()

        self.start_time = time.time()
        self.is_recording = False
        self.quality_status = "pending"  # pending | matched | single | forced_lowest | error
        self.playlist_resolved = threading.Event()
        self.error_msg = ""

        self.ua = UA_DESKTOP

    def stop(self):
        self._stop_event.set()

    def get_run_time_mins(self):
        return int((time.time() - self.start_time) / 60)

    def format_bytes(self, num):
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if num < 1024.0:
                return "{0:3.1f} {1}".format(num, unit)
            num /= 1024.0
        return "{0:.1f} PB".format(num)

    def _sleep(self, secs):
        # Sondeo en intervalos cortos para que _stop_event interrumpa el sleep
        end = time.time() + secs
        while time.time() < end:
            if self._stop_event.is_set():
                return
            remaining = end - time.time()
            if remaining <= 0:
                break
            self._monitor.waitForAbort(min(0.5, remaining))

    def _should_stop(self):
        return (
            self._stop_event.is_set()
            or self._monitor.abortRequested()
            or xbmcgui.Window(10000).getProperty("streamninja_force_stop") == "1"
        )

    def _http_get(self, url):
        """Descarga un manifest/playlist como texto, acotado a _PLAYLIST_MAX_BYTES."""
        req = urllib.request.Request(url, headers={"User-Agent": self.ua})
        resp = urllib.request.urlopen(req, timeout=15)
        try:
            data = resp.read(_PLAYLIST_MAX_BYTES)
        finally:
            resp.close()
        return data.decode('utf-8', errors='ignore')

    def _download_segment(self, url, fout):
        """Vuelca un segmento HLS a disco por bloques, sin cargarlo entero en RAM.

        Unidad todo-o-nada: el flush va aquí dentro, así que si la descarga o el
        volcado a disco fallan a mitad se revierten los bytes ya escritos
        (seek+truncate). Evita dejar un segmento truncado o duplicado en el .ts.
        Devuelve los bytes escritos.
        """
        req = urllib.request.Request(url, headers={"User-Agent": self.ua})
        resp = urllib.request.urlopen(req, timeout=15)
        start_pos = fout.tell()
        written = 0
        try:
            while True:
                buf = resp.read(_SEGMENT_CHUNK_BYTES)
                if not buf:
                    break
                fout.write(buf)
                written += len(buf)
            fout.flush()
        except Exception:
            # Revertir el segmento parcial sin enmascarar el error original
            try:
                fout.seek(start_pos)
                fout.truncate()
            except OSError as cleanup_err:
                xbmc.log("[StreamNinja/PVR] No se pudo revertir segmento parcial: {0}".format(cleanup_err), xbmc.LOGWARNING)
            raise
        finally:
            resp.close()
        return written

    def _resolve_master_playlist(self, url):
        try:
            content = self._http_get(url)
            lines = content.splitlines()
            variants = []
            for i, line in enumerate(lines):
                if line.startswith("#EXT-X-STREAM-INF"):
                    bw = 0
                    m = re.search(r'BANDWIDTH=(\d+)', line)
                    if m:
                        bw = int(m.group(1))
                    for j in range(i + 1, len(lines)):
                        candidate = lines[j].strip()
                        if candidate and not candidate.startswith("#"):
                            variants.append((bw, urllib.parse.urljoin(url, candidate)))
                            break

            if variants:
                variants.sort(key=lambda x: x[0], reverse=True)

                if self.max_bandwidth > 0:
                    eligible = [v for v in variants if v[0] <= self.max_bandwidth]
                    if eligible:
                        chosen = eligible[0]
                        self.quality_status = "matched"
                    else:
                        chosen = variants[-1]
                        self.quality_status = "forced_lowest"
                        xbmc.log(
                            "[StreamNinja/PVR] Ninguna variante cumple el limite de {0} bps. Usando la mas baja: {1} bps".format(self.max_bandwidth, chosen[0]),
                            xbmc.LOGWARNING
                        )
                else:
                    chosen = variants[0]
                    self.quality_status = "matched"

                xbmc.log("[StreamNinja/PVR] Variantes disponibles: {0}".format([(v[0], v[1].split('/')[-1]) for v in variants]), xbmc.LOGINFO)
                xbmc.log("[StreamNinja/PVR] Variante elegida: {0} bps".format(chosen[0]), xbmc.LOGINFO)

                if len(variants) <= 1:
                    xbmc.log("[StreamNinja/PVR] La lista maestra solo contenia una variante de calidad.", xbmc.LOGINFO)
                    self.quality_status = "single"

                return chosen[1]

            xbmc.log("[StreamNinja/PVR] Canal sin lista maestra de variantes. Se grabará en la única calidad disponible.", xbmc.LOGINFO)
            self.quality_status = "single"
            return url
        except (urllib.error.URLError, ValueError, OSError) as e:
            xbmc.log("[StreamNinja/PVR] Error resolving master playlist: {0}".format(e), xbmc.LOGWARNING)
            self.quality_status = "error"
            return url

    def _disk_too_low(self, path):
        try:
            return shutil.disk_usage(os.path.dirname(path)).free < _MIN_FREE_SPACE_BYTES
        except OSError:
            return False

    def _run_ffmpeg(self, playlist_url, partial_file):
        # Pre-check AES: FFmpeg fallaría silenciosamente sin mensaje descriptivo
        try:
            content = self._http_get(playlist_url)
            if '#EXT-X-KEY:METHOD=AES-128' in content or '#EXT-X-KEY:METHOD=SAMPLE-AES' in content:
                xbmc.log("[StreamNinja/PVR] Canal encriptado (AES). Abortando.", xbmc.LOGWARNING)
                self.error_msg = "El canal está encriptado con clave externa (AES). La copia nativa descargaría bytes ilegibles, por seguridad se ha cancelado."
                return
        except (urllib.error.URLError, OSError):
            pass  # Si no se puede hacer el check, se intenta igualmente con FFmpeg

        cmd = [
            'ffmpeg', '-hide_banner', '-loglevel', 'warning',
            '-user_agent', self.ua,
            '-rw_timeout', '15000000',
            '-reconnect', '1', '-reconnect_streamed', '1',
            '-i', playlist_url,
            '-c:v', 'libx264', '-crf', str(self.compress_crf), '-preset', 'veryfast',
            '-c:a', 'aac', '-b:a', '96k',
            '-f', 'mp4',
            '-movflags', '+frag_keyframe+empty_moov+default_base_moof',
            '-y', partial_file,
        ]
        xbmc.log("[StreamNinja/PVR] FFmpeg iniciado: {0}".format(self.channel_name), xbmc.LOGINFO)
        proc = subprocess.Popen(
            cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            creationflags=_FFMPEG_CREATIONFLAGS,
        )

        # FFmpeg escribe los errores a stderr; sin drenarlo en un hilo, el pipe se
        # llena y FFmpeg se bloquea. Guardamos solo la cola para el diagnóstico.
        stderr_ring = collections.deque(maxlen=_FFMPEG_STDERR_RING_LINES)

        def _drain_stderr():
            # Hilo daemon de solo lectura; cualquier fallo (incluido cerrar el pipe
            # bajo un readline bloqueado, que lanza ValueError) solo debe terminarlo.
            try:
                for line in iter(proc.stderr.readline, b''):
                    stderr_ring.append(line)
            except Exception as e:
                xbmc.log("[StreamNinja/PVR] Lector de stderr FFmpeg terminó: {0!r}".format(e), xbmc.LOGDEBUG)

        reader = threading.Thread(target=_drain_stderr, daemon=True)
        reader.start()

        next_disk_check = time.time() + _DISK_CHECK_INTERVAL_S
        stopped_by_us = False
        try:
            while proc.poll() is None:
                if self._should_stop() or (self.max_duration_mins > 0 and self.get_run_time_mins() >= self.max_duration_mins):
                    proc.terminate()
                    stopped_by_us = True
                    break
                if time.time() >= next_disk_check:
                    next_disk_check = time.time() + _DISK_CHECK_INTERVAL_S
                    if self._disk_too_low(partial_file):
                        xbmc.log("[StreamNinja/PVR] Espacio en disco bajo el umbral. Parando FFmpeg.", xbmc.LOGERROR)
                        self.error_msg = "La grabación se detuvo: queda muy poco espacio libre en el disco duro."
                        proc.terminate()
                        stopped_by_us = True
                        break
                try:
                    if os.path.exists(partial_file):
                        self.downloaded_bytes = os.path.getsize(partial_file)
                except OSError:
                    pass
                if self.callback_progress:
                    self.callback_progress(self, "downloading")
                self._sleep(2)
        finally:
            if proc.poll() is None:
                proc.terminate()
                stopped_by_us = True
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            reader.join(timeout=2.0)
            try:
                if proc.stderr:
                    proc.stderr.close()
            except OSError:
                pass

        # Si FFmpeg murió solo con error (no lo paramos nosotros), es un fallo real
        if not stopped_by_us and proc.returncode != 0 and not self.error_msg:
            tail = b''.join(stderr_ring).decode('utf-8', errors='ignore').strip()[-300:].replace('\n', ' | ')
            detail = tail or "sin salida de error"
            self.error_msg = (
                "No se pudo grabar en MP4 (FFmpeg código {0}): {1}. "
                "Prueba a grabarlo en formato TS nativo.".format(proc.returncode, detail)
            )
            xbmc.log("[StreamNinja/PVR] FFmpeg salió con código {0}: {1}".format(proc.returncode, tail), xbmc.LOGWARNING)

        try:
            if os.path.exists(partial_file):
                self.downloaded_bytes = os.path.getsize(partial_file)
        except OSError:
            pass

    def _run_raw(self, playlist_url, partial_file):
        with open(partial_file, "wb") as f_out:
            consecutive_errors = 0
            empty_cycles = 0
            next_disk_check = time.time() + _DISK_CHECK_INTERVAL_S

            while not self._should_stop():
                if self.max_duration_mins > 0 and self.get_run_time_mins() >= self.max_duration_mins:
                    xbmc.log("[StreamNinja/PVR] Temporizador alcanzado ({0} min).".format(self.max_duration_mins), xbmc.LOGINFO)
                    break

                if time.time() >= next_disk_check:
                    next_disk_check = time.time() + _DISK_CHECK_INTERVAL_S
                    if self._disk_too_low(partial_file):
                        xbmc.log("[StreamNinja/PVR] Espacio en disco bajo el umbral. Parando.", xbmc.LOGERROR)
                        self.error_msg = "La grabación se detuvo: queda muy poco espacio libre en el disco duro."
                        break

                try:
                    content = self._http_get(playlist_url)
                    lines = content.splitlines()
                    chunks_downloaded_in_cycle = 0

                    for line in lines:
                        line = line.strip()
                        if not line:
                            continue

                        if line.startswith("#EXT-X-KEY:METHOD=AES-128") or line.startswith("#EXT-X-KEY:METHOD=SAMPLE-AES"):
                            xbmc.log("[StreamNinja/PVR] Canal encriptado (AES). Abortando.", xbmc.LOGWARNING)
                            self.error_msg = "El canal está encriptado con clave externa (AES). La copia nativa descargaría bytes ilegibles, por seguridad se ha cancelado."
                            self._stop_event.set()
                            break

                        if line.startswith("#EXT-X-ENDLIST"):
                            xbmc.log("[StreamNinja/PVR] Endlist alcanzada. VOD descargado.", xbmc.LOGINFO)
                            self.error_msg = ""
                            self._stop_event.set()
                            break

                        if line.startswith("#"):
                            continue

                        chunk_url = urllib.parse.urljoin(playlist_url, line)
                        chunk_id = line

                        if chunk_id not in self.downloaded_set:
                            if self._should_stop():
                                break

                            if self.callback_progress:
                                self.callback_progress(self, "downloading")

                            written = self._download_segment(chunk_url, f_out)
                            self.downloaded_bytes += written

                            if len(self.downloaded_queue) == 1000:
                                oldest = self.downloaded_queue.popleft()
                                self.downloaded_set.discard(oldest)

                            self.downloaded_queue.append(chunk_id)
                            self.downloaded_set.add(chunk_id)
                            chunks_downloaded_in_cycle += 1

                    if self._should_stop():
                        break

                    if chunks_downloaded_in_cycle > 0:
                        consecutive_errors = 0
                        empty_cycles = 0
                        self._sleep(1)
                    else:
                        empty_cycles += 1
                        if empty_cycles > 120:
                            xbmc.log("[StreamNinja/PVR] Demasiados ciclos sin datos nuevos.", xbmc.LOGWARNING)
                            self.error_msg = "El canal dejó de emitir datos."
                            break
                        self._sleep(3)
                        if self.callback_progress:
                            self.callback_progress(self, "waiting")

                except urllib.error.HTTPError as e:
                    if getattr(e, 'code', None) in (404, 403, 410, 451):
                        xbmc.log("[StreamNinja/PVR] Servidor respondio HTTP {0}. Emision terminada.".format(e.code), xbmc.LOGINFO)
                        self.error_msg = ""
                        break
                    consecutive_errors += 1
                    xbmc.log("[StreamNinja/PVR] Error HTTP temporal {0}.".format(getattr(e, 'code', '?')), xbmc.LOGWARNING)
                    if self.callback_progress:
                        self.callback_progress(self, "reconnecting")
                    self._sleep(5)

                except urllib.error.URLError as e:
                    consecutive_errors += 1
                    xbmc.log("[StreamNinja/PVR] Error de red (intento {0}): {1}".format(consecutive_errors, e.reason), xbmc.LOGWARNING)
                    if self.callback_progress:
                        self.callback_progress(self, "reconnecting")
                    self._sleep(5)
                    if consecutive_errors > 720:
                        self.error_msg = "Se perdió la conexión por demasiado tiempo."
                        break

                except OSError as e:
                    if getattr(e, 'errno', None) == errno.ENOSPC:
                        xbmc.log("[StreamNinja/PVR] Sin espacio en disco (ENOSPC).", xbmc.LOGERROR)
                        self.error_msg = "La grabación se detuvo porque no hay espacio libre en el disco duro."
                        self._stop_event.set()
                        break
                    consecutive_errors += 1
                    xbmc.log("[StreamNinja/PVR] Error OS: {0}".format(e), xbmc.LOGWARNING)
                    self._sleep(5)
                    if consecutive_errors > 20:
                        self.error_msg = "Error persistente del sistema de archivos: {0}".format(e)
                        break

                except Exception as e:
                    consecutive_errors += 1
                    xbmc.log("[StreamNinja/PVR] Error inesperado (intento {0}): {1}".format(consecutive_errors, e), xbmc.LOGWARNING)
                    if self.callback_progress:
                        self.callback_progress(self, "reconnecting")
                    self._sleep(5)
                    if consecutive_errors > 720:
                        self.error_msg = "Se perdió la conexión por demasiado tiempo."
                        break

    def run(self):
        self.is_recording = True
        xbmc.log("[StreamNinja/PVR] Grabacion iniciada: {0}".format(self.channel_name), xbmc.LOGINFO)
        partial_file = self.output_file + '.partial'

        try:
            os.makedirs(os.path.dirname(self.output_file), exist_ok=True)

            if self.compress and not ffmpeg_available():
                xbmc.log("[StreamNinja/PVR] FFmpeg no está en el PATH; no se puede comprimir.", xbmc.LOGWARNING)
                self.error_msg = "Para grabar en MP4 se necesita FFmpeg instalado en el sistema y no se ha encontrado. Desactiva la compresión en los ajustes del PVR para grabar en formato TS nativo."
                return

            best_playlist_url = self._resolve_master_playlist(self.m3u8_url)
            self.playlist_resolved.set()
            xbmc.log("[StreamNinja/PVR] M3U8 objetivo: {0}".format(best_playlist_url), xbmc.LOGINFO)

            if self.compress:
                self._run_ffmpeg(best_playlist_url, partial_file)
            else:
                self._run_raw(best_playlist_url, partial_file)

        except Exception as e:
            self.error_msg = str(e)
            xbmc.log("[StreamNinja/PVR] Error fatal del hilo: {0}".format(e), xbmc.LOGERROR)

        finally:
            self.is_recording = False
            self.playlist_resolved.set()

            if os.path.exists(partial_file):
                try:
                    if os.path.getsize(partial_file) > 0:
                        os.replace(partial_file, self.output_file)
                    else:
                        os.remove(partial_file)
                        xbmc.log("[StreamNinja/PVR] Archivo vacio eliminado: {0}".format(partial_file), xbmc.LOGINFO)
                except OSError as rename_err:
                    xbmc.log("[StreamNinja/PVR] No se pudo renombrar el parcial: {0}".format(rename_err), xbmc.LOGERROR)
                    if not self.error_msg:
                        self.error_msg = "La grabación se guardó pero quedó con el nombre temporal '{0}' en la carpeta de grabaciones. Puedes renombrarla a mano quitando '.partial'.".format(os.path.basename(partial_file))

            xbmc.log("[StreamNinja/PVR] Hilo de grabacion finalizado: {0}".format(self.channel_name), xbmc.LOGINFO)
            if self.callback_finish:
                self.callback_finish(self)
