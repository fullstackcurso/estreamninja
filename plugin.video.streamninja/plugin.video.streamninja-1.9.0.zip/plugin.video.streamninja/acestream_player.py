﻿# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE para mas detalles.
"""
Reproductor AceStream nativo: habla directamente con el motor AceStream local
(API HTTP en el puerto 6878) sin depender de Horus.

Requiere que el motor ya esté escuchando; NO lo instala ni lo arranca. Si el motor
no responde, play() devuelve False y el llamador cae a su cadena de fallback.

API del motor verificada en wiki.acestream.media/Engine_HTTP_API:
  - GET /ace/getstream?id=<40hex>&format=json -> {playback_url, stat_url, command_url}
  - GET stat_url -> {status: "prebuf"|"dl", peers, speed_down (KB/s), total_progress}
    total_progress solo es válido en VOD; en canales en directo no existe.
  - GET command_url?method=stop -> cierra la sesión P2P.
"""
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

# Player con callbacks vivo mientras dura la reproducción; si se recolectara por GC
# dejaría de recibir onPlayBack* y la sesión nunca se cerraría.
_active_player = None


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[StreamNinja/acestream] {0}".format(msg), level)


def _api_get(url, timeout):
    """GET que devuelve el dict JSON del motor, o None ante cualquier fallo."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "StreamNinja"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, OSError, ValueError):
        return None


def _settings():
    addon = xbmcaddon.Addon()
    ip = addon.getSetting("acestream_ip") or "127.0.0.1"
    port = addon.getSetting("acestream_port") or "6878"
    try:
        timeout = int(addon.getSetting("acestream_timeout") or 45)
    except ValueError:
        timeout = 45
    return ip, port, max(10, timeout)


def engine_alive(ip, port, timeout=2):
    """True si el motor responde a get_version (liveness + readiness en una llamada)."""
    res = _api_get(
        "http://{0}:{1}/webui/api/service?method=get_version&format=json".format(ip, port),
        timeout,
    )
    if not isinstance(res, dict):
        return False
    # La respuesta puede venir como {"result": {"version": ...}} o plana {"version": ...}.
    inner = res.get("result") if isinstance(res.get("result"), dict) else res
    return bool(inner.get("version"))


def _open_session(ip, port, selector):
    """Abre una sesión de stream. *selector* es el fragmento de query que identifica el
    contenido: 'id=<hash>' (content id), 'infohash=<hash>' (torrent) o 'url=<urlencoded>'
    (link a un .torrent; el motor lo descarga y parsea él mismo). Devuelve
    (playback_url, stat_url, command_url) o None."""
    res = _api_get(
        "http://{0}:{1}/ace/getstream?{2}&format=json".format(ip, port, selector),
        timeout=15,
    )
    if not isinstance(res, dict):
        return None
    # Algunas versiones envuelven el contenido en {"response": {...}, "error": ...};
    # otras lo devuelven plano. Toleramos ambas.
    if res.get("error"):
        _log("el motor devolvió error: {0}".format(res["error"]), xbmc.LOGWARNING)
        return None
    data = res.get("response") if isinstance(res.get("response"), dict) else res
    playback = data.get("playback_url")
    if not playback:
        return None
    return playback, data.get("stat_url"), data.get("command_url")


def _stop_session(command_url):
    if command_url:
        _api_get(command_url + "?method=stop", timeout=5)


def _prebuffer(stat_url, command_url, timeout):
    """Diálogo de precarga hasta status='dl'. Devuelve True si listo para reproducir,
    False si se canceló/agotó. Cierra la sesión si el usuario cancela."""
    monitor = xbmc.Monitor()
    dp = xbmcgui.DialogProgress()
    dp.create("StreamNinja", "Conectando con la red AceStream...")
    # Tiempo de pared real; si el poll de stats se ralentiza, el timeout debe seguir
    # midiéndose en segundos reales, no en número de vueltas del bucle.
    start = time.time()
    deadline = start + timeout
    # Tope absoluto; aunque el motor siga en 'prebuf', no esperamos indefinidamente.
    hard_deadline = start + timeout + 120
    try:
        while True:
            now = time.time()
            elapsed = int(now - start)
            if now >= deadline:
                break
            if dp.iscanceled() or monitor.abortRequested():
                _stop_session(command_url)
                return False

            stats = _api_get(stat_url, timeout=3) or {}
            data = stats.get("response", stats) if isinstance(stats, dict) else {}
            status = data.get("status")
            if status == "dl":
                return True

            # Mientras el motor prebufferiza activamente, dale más margen (redes lentas o
            # pocos peers) en vez de cortar por el timeout base. Acotado por hard_deadline.
            if status == "prebuf":
                deadline = min(now + timeout, hard_deadline)

            peers = data.get("peers", 0)
            speed = data.get("speed_down", 0)  # ya viene en KB/s
            # total_progress solo existe en VOD; en directo movemos la barra con el
            # tiempo transcurrido solo para dar feedback visual, no es buffer real.
            try:
                pct = int(data.get("total_progress") or 0)
            except (TypeError, ValueError):
                pct = 0
            if pct <= 0:
                pct = min(95, int(elapsed * 100 / timeout))
            dp.update(
                pct,
                "Conectando: {0} fuentes · {1} KB/s\nTiempo: {2}s".format(
                    peers, speed, elapsed),
            )

            if monitor.waitForAbort(1):  # sleep de 1s interrumpible por apagado de Kodi
                _stop_session(command_url)
                return False
    finally:
        dp.close()

    # Timeout sin llegar a 'dl': ofrecer reproducir igualmente en vez de fallar seco.
    if xbmcgui.Dialog().yesno(
            "StreamNinja",
            "El buffer va lento (sin fuentes suficientes).\n\n¿Reproducir igualmente?"):
        return True
    _stop_session(command_url)
    return False


class _AcePlayer(xbmc.Player):
    """Cierra la sesión P2P del motor cuando termina la reproducción."""

    def __init__(self, command_url):
        super().__init__()
        self._command_url = command_url

    def _cleanup(self):
        cmd, self._command_url = self._command_url, None
        if cmd:
            _stop_session(cmd)

    def onPlayBackStopped(self):
        self._cleanup()

    def onPlayBackEnded(self):
        self._cleanup()

    def onPlayBackError(self):
        self._cleanup()


def _play_session(ip, port, selector, timeout, label, icon="", plot=""):
    """Abre, prebufferea y reproduce una sesión del motor. Devuelve True si el motor
    gestionó la petición (reprodujo o el usuario canceló) y False si no devolvió sesión.
    """
    global _active_player
    session = _open_session(ip, port, selector)
    if not session:
        return False
    playback_url, stat_url, command_url = session

    # Desde aquí el motor responde y hay interacción con el usuario; si cancela o el
    # buffer no llega, es decisión suya, no un fallo -> True (no caer al fallback).
    if stat_url and not _prebuffer(stat_url, command_url, timeout):
        return True

    li = xbmcgui.ListItem(label=label, path=playback_url)
    li.setContentLookup(False)  # evita el probe HEAD que cuelga con MPEG-TS progresivo
    li.setProperty("IsPlayable", "true")
    if icon:
        li.setArt({"icon": icon, "thumb": icon})
    li.setInfo("video", {"title": label, "plot": plot} if plot else {"title": label})

    # Si había otra sesión AceStream en curso, ciérrala de forma determinista antes de
    # arrancar esta; al sobrescribir _active_player el anterior podría recolectarse por
    # GC y no llegar a disparar su callback de stop, dejando su sesión abierta.
    if _active_player is not None:
        _active_player._cleanup()

    _active_player = _AcePlayer(command_url)
    _active_player.play(playback_url, li)

    # OSD de estadísticas P2P (opcional). Import perezoso; si está desactivado o el módulo
    # falla, la reproducción no se ve afectada en absoluto.
    if stat_url and xbmcaddon.Addon().getSetting("acestream_show_osd") != "false":
        try:
            import acestream_osd
            acestream_osd.start(stat_url)
        except Exception as e:
            _log("OSD no disponible: {0}".format(e), xbmc.LOGWARNING)
    return True


def play(content_id, title="", icon="", plot=""):
    """Reproduce un content ID AceStream (40 hex) vía el motor local.

    Devuelve True si el motor gestionó la petición (reprodujo, o el usuario canceló
    el prebuffering: en ambos casos NO debe caerse a Horus). Devuelve False
    solo si el motor no está disponible o no devolvió sesión, para que el llamador
    siga con su cadena de fallback.
    """
    ip, port, timeout = _settings()
    if not engine_alive(ip, port):
        return False
    return _play_session(ip, port, "id={0}".format(content_id), timeout,
                         title or "AceStream", icon, plot)


def _torrent_selector(value):
    """Selector de query para el motor a partir de un magnet o una URL .torrent.
    Magnet -> 'infohash=<btih 40hex>'. URL .torrent -> 'url=<urlencoded>' (el motor la
    descarga y parsea). None si es un magnet sin infohash hex de 40 (base32 / BT v2,
    que el motor no soporta)."""
    if value.lower().startswith("magnet:"):
        m = re.search(r"urn:btih:([a-fA-F0-9]{40})", value, re.I)
        return "infohash={0}".format(m.group(1).lower()) if m else None
    return "url={0}".format(urllib.parse.quote(value, safe=""))


def play_torrent(value, title="", icon="", plot=""):
    """Reproduce un magnet o una URL .torrent con el motor AceStream local.

    Mismo contrato de retorno que play(): True si el motor lo gestionó, False si no está
    disponible o no se pudo construir la petición (el llamador hace su fallback).
    """
    ip, port, timeout = _settings()
    if not engine_alive(ip, port):
        return False
    selector = _torrent_selector(value)
    if not selector:
        return False
    return _play_session(ip, port, selector, timeout,
                         title or "AceStream Torrent", icon, plot)
