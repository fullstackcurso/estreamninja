# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE para mas detalles.
"""
Generador de códigos QR para la interfaz del servidor remoto.

Encapsula la generación de imágenes PNG a partir de una URL y su escritura
en disco. El ciclo de vida del archivo temporal es responsabilidad del
llamador: debe invocar cleanup() cuando la imagen ya no sea necesaria.

Depende de la librería segno (pure Python, BSD), incluida en lib/segno/.
Si por cualquier motivo segno no está disponible, generate() devuelve None
y el llamador debe degradar la interfaz limpiamente.
"""
import os
import sys
import tempfile


# --- Constantes ---

# Factor de escala del módulo QR en píxeles. Con scale=8 una URL de
# ~22 caracteres genera un QR versión 2 de ~176x176px, perfectamente
# visible en la distancia TV habitual.
_QR_SCALE = 8

# Nombre fijo del archivo temporal (en directorio del sistema operativo).
# Un nombre determinista evita acumulación de basura si el addon se cierra
# de forma abrupta; la siguiente ejecución simplemente sobreescribe.
_TMP_FILENAME = "streamninja_remote_qr.png"


# --- API pública ---

def generate(url):
    """Genera un código QR como PNG y lo escribe en un archivo temporal.

    El PNG se almacena en el directorio temporal del sistema operativo bajo
    el nombre ``streamninja_remote_qr.png``.

    Args:
        url: Cadena de texto a codificar en el QR. Típicamente una URL HTTP
             de la forma ``http://192.168.1.x:8089``.

    Returns:
        Ruta absoluta al archivo PNG generado, o ``None`` si la generación
        falla por cualquier motivo.
    """
    if not url:
        return None

    segno = _import_segno()
    if segno is None:
        return None

    try:
        output_path = os.path.join(tempfile.gettempdir(), _TMP_FILENAME)
        qr = segno.make(url, micro=False, error="M")
        qr.save(
            output_path,
            kind="png",
            scale=_QR_SCALE,
            dark="#000000",
            light="#ffffff",
            border=2,
        )
        return output_path
    except Exception:
        return None


def cleanup(path):
    """Elimina el archivo PNG del QR del disco.

    Es seguro llamar a esta función aunque ``path`` sea None o el archivo
    ya no exista.

    Args:
        path: Ruta devuelta por :func:`generate`, o ``None``.
    """
    if not path:
        return
    try:
        os.remove(path)
    except OSError:
        pass


# --- Internals ---

def _import_segno():
    """Importa segno priorizando la copia empaquetada con el addon.

    Añade ``lib/`` a sys.path (solo una vez) para que la copia local tenga
    precedencia sobre cualquier instalación del sistema. Si segno no está
    disponible en ninguna de las dos ubicaciones, devuelve None para que el
    llamador pueda degradar la interfaz limpiamente.
    """
    # Ruta a lib/ relativa a este mismo fichero (funciona desde cualquier CWD)
    lib_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib")

    if lib_dir not in sys.path:
        sys.path.insert(0, lib_dir)

    try:
        import segno  # noqa: PLC0415
        return segno
    except ImportError:
        return None
