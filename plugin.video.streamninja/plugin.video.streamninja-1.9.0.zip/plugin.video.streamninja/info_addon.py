﻿# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE para mas detalles.
#
# ESTREAMNINJA EXPERIMENTAL:
# EstreamNinja es una versión experimental donde se prueban funcionalidades que, 
# eventualmente, podrían llegar a StreamNinja. Destaca por estar desarrollada
# completamente en español.
# 
# Esta versión no está pensada para ser utilizada por el público general ni por 
# otros desarrolladores: el código carece de los comentarios adecuados, no está pulido
# y contiene elementos muertos o descartables de uso exclusivo para pruebas.
"""
Modulo de informacion del addon.

Gestiona el submenu de informacion, el aviso legal
y la descarga en segundo plano de recursos graficos
para el dialogo Universo.
"""
import sys
import os
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmcaddon

_MEDIA = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _get_handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1



def info_menu():
    """Submenu de informacion del addon."""
    h = _get_handle()
    li = xbmcgui.ListItem(label="[COLOR skyblue]Universo EspaKodi[/COLOR]")
    li.setArt({"icon": os.path.join(_MEDIA, "info_universo.png")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_universo"), listitem=li, isFolder=False)

    li3 = xbmcgui.ListItem(label="Información del Addon v{0}".format(xbmcaddon.Addon().getAddonInfo('version')))
    li3.setArt({"icon": os.path.join(_MEDIA, "info_version.png")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="info"), listitem=li3, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def show_universo():
    """Abre la ventana grafica Universo EspaKodi."""
    import universo
    universo.show()


def info():
    """Muestra el aviso legal e informacion del addon."""
    t = (
        "[COLOR skyblue][B]ESTREAMNINJA[/B][/COLOR]"
        " es una versión experimental en español derivada de StreamNinja, con funciones que podrían o no llegar a integrarse en el proyecto principal.\n\n"
        "----------------------------------------------------------\n"
        "[COLOR red][B]AVISO LEGAL[/B][/COLOR]\n"
        "----------------------------------------------------------\n\n"
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. No tiene ninguna afiliación "
        "ni vinculación con ninguna plataforma oficial.\n\n"
        "[B]2. Naturaleza Técnica:[/B]\n"
        "Este software actúa como una pasarela de red. No contiene, "
        "aloja ni sube contenido protegido. Se limita a establecer conexiones "
        "hacia las direcciones de internet elegidas libremente por el usuario.\n\n"
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El usuario es el único responsable de verificar la legalidad "
        "del acceso a los contenidos según las leyes de su país. "
        "Este addon se proporciona \"tal cual\", sin garantías de ningún tipo. "
        "StreamNinja no se hace responsable de la información transmitida "
        "por la red local o remota a la que decidas conectarte.\n\n"
        "[B]4. Naturaleza del proyecto:[/B]\n"
        "Es GRATUITO y sin ánimo de lucro."
    )
    xbmcgui.Dialog().textviewer("Información de StreamNinja", t)
