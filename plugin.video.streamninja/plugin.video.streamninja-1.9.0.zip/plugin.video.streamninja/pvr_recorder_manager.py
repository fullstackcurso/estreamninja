﻿# -*- coding: utf-8 -*-
# StreamNinja; Copyright (C) 2024-2026 RubénSDFA1laberot
# Licencia: Consulta el archivo LICENSE.
# Coordinador de Interfaz y Background para el PVR HLS

import os
import re
import time
import urllib.parse
import xbmc
import xbmcgui
import xbmcaddon
from datetime import datetime

from hls_recorder import HLSRecorder, ffmpeg_available

_KODI_WINDOW = xbmcgui.Window(10000)
_ACTIVE_REC_PROP = "streamninja_active_recordings"


def _active_recordings_count():
    try:
        return int(_KODI_WINDOW.getProperty(_ACTIVE_REC_PROP) or "0")
    except ValueError:
        return 0


def _inc_active_recordings():
    _KODI_WINDOW.setProperty(_ACTIVE_REC_PROP, str(_active_recordings_count() + 1))


def _dec_active_recordings():
    # Al llegar a 0 se borra la property (no se deja "0"): así "vacío" sigue
    # significando "ninguna activa" y los checks de verdad existentes valen igual.
    n = _active_recordings_count() - 1
    if n > 0:
        _KODI_WINDOW.setProperty(_ACTIVE_REC_PROP, str(n))
    else:
        _KODI_WINDOW.clearProperty(_ACTIVE_REC_PROP)


def _get_setting(setting_id):
    return xbmcaddon.Addon().getSetting(setting_id)


def get_record_path():
    path = _get_setting("record_path")
    if not path:
        if not xbmcgui.Dialog().yesno(
            "Carpeta no configurada",
            "No has configurado dónde guardar las grabaciones.\n\n¿Quieres elegir la carpeta ahora?"
        ):
            return ""
        path = xbmcgui.Dialog().browse(3, "Elige dónde guardar las grabaciones en directo", "files")
        if path:
            xbmcaddon.Addon().setSetting("record_path", path)
    return path


def _parse_time_label(label):
    """Convierte '1 hora', '1h 30min', '30 min', '45' a minutos. Devuelve 0 si no aplica."""
    if not label:
        return 0
    label = label.strip().lower()
    if label in ("ahora", "sin límite", "sin limite", "infinito", ""):
        return 0

    m = re.match(r'^(\d+)\s*h\s*(\d+)\s*min', label)
    if m:
        return int(m.group(1)) * 60 + int(m.group(2))

    m = re.match(r'^(\d+)\s*hora', label)
    if m:
        return int(m.group(1)) * 60

    m = re.match(r'^(\d+)\s*min', label)
    if m:
        return int(m.group(1))

    try:
        return int(label)
    except ValueError:
        return 0


def get_timer_mins():
    return _parse_time_label(_get_setting("record_timer"))


def get_delay_mins():
    return _parse_time_label(_get_setting("record_delay"))


def get_max_bandwidth():
    # record_quality es type="enum": Kodi devuelve el índice (0=Máxima, 1=720, 2=480, 3=360),
    # no el texto. El bps de cada índice; 0 = sin tope.
    caps = (0, 3_000_000, 1_500_000, 800_000)
    try:
        idx = int(_get_setting("record_quality") or 0)
    except ValueError:
        idx = 0
    return caps[idx] if 0 <= idx < len(caps) else 0


def get_record_format():
    """Devuelve 'ask' | 'ts' | 'mp4' según el ajuste de formato."""
    # record_format es type="enum": Kodi devuelve el índice (0=Preguntar, 1=TS, 2=MP4).
    try:
        idx = int(_get_setting("record_format") or 0)
    except ValueError:
        idx = 0
    return ("ask", "ts", "mp4")[idx] if 0 <= idx < 3 else "ask"


def _sanitize_filename(raw_name):
    safe = "".join(c for c in raw_name if c.isalnum() or c in (' ', '-', '_')).strip()
    if not safe:
        safe = "Grabacion_HLS"
    # Margen suficiente bajo PATH_MAX (260) tras concatenar carpeta + timestamp + extensión.
    return safe[:80]


def _get_pvr_subfolder(base_path):
    pvr_dir = os.path.join(base_path, "Grabaciones_PVR")
    if not os.path.exists(pvr_dir):
        os.makedirs(pvr_dir, exist_ok=True)
    return pvr_dir


def _validate_stream_url(url):
    """True si url es http/https y no trae pipe-headers de Kodi.

    El grabador pasa la URL tal cual a urllib (TS) y a FFmpeg `-i` (MP4); ninguno
    entiende el formato `url|Header=Value`, así que se rechaza aquí en lugar de
    dejar que el upstream responda 4xx con un fallo opaco.
    """
    if not url or not url.strip():
        return False
    u = url.strip()
    if '|' in u:
        return False
    return urllib.parse.urlparse(u).scheme.lower() in ('http', 'https')


def _recover_orphan_partials(pvr_dir):
    """Promueve a su nombre final los .partial que quedaron de un cierre forzado.

    El caller la invoca una sola vez por sesión, en la primera grabación, cuando
    aún no existe ningún .partial vivo: así nunca toca uno que se esté escribiendo.
    Devuelve cuántas grabaciones se recuperaron.
    """
    recovered = 0
    try:
        entries = os.listdir(pvr_dir)
    except OSError:
        return 0
    for entry in entries:
        if not entry.endswith('.partial'):
            continue
        partial = os.path.join(pvr_dir, entry)
        final = partial[:-len('.partial')]
        try:
            if os.path.getsize(partial) == 0:
                os.remove(partial)
                continue
            # Si el final ya existe es una grabación buena; el .partial es residuo.
            if os.path.exists(final):
                os.remove(partial)
                continue
            os.replace(partial, final)
            recovered += 1
            xbmc.log("[StreamNinja/PVR] Grabación huérfana recuperada: {0}".format(entry), xbmc.LOGINFO)
        except OSError as e:
            xbmc.log("[StreamNinja/PVR] No se pudo recuperar {0}: {1!r}".format(entry, e), xbmc.LOGWARNING)
    return recovered


def start_recording_ui(url, canonical_name):
    if not _validate_stream_url(url):
        xbmcgui.Dialog().ok(
            "URL no válida",
            "La dirección del canal no es http/https o incluye cabeceras que el "
            "grabador no admite. No se puede grabar este enlace."
        )
        return

    dest_path = get_record_path()
    if not dest_path:
        return

    # falla si la ruta no existe (USB no montado, red caída)
    if not os.path.isdir(dest_path):
        xbmcgui.Dialog().ok(
            "Error de grabación",
            "La carpeta de grabaciones no existe o no es accesible:\n\n{0}\n\nComprueba que el disco o USB está conectado.".format(dest_path)
        )
        return

    mins = get_timer_mins()
    delay_mins = get_delay_mins()
    pvr_dir = _get_pvr_subfolder(dest_path)

    # Recuperar .partial de un cierre forzado anterior, una sola vez por sesión.
    # Un huérfano solo aparece tras un cierre forzado, que implica reiniciar Kodi;
    # las window properties se borran en ese reinicio, así que el marcador está
    # vacío en cada sesión nueva. Recuperamos en la primera grabación de la sesión:
    # en ese instante aún no se ha creado ningún .partial vivo (el recorder de esta
    # grabación arranca más abajo), por lo que es imposible pisar una grabación en
    # curso aunque haya varias de fondo. Las siguientes grabaciones ya no recuperan.
    if not _KODI_WINDOW.getProperty("streamninja_orphans_recovered"):
        _KODI_WINDOW.setProperty("streamninja_orphans_recovered", "1")
        recovered = _recover_orphan_partials(pvr_dir)
        if recovered:
            xbmcgui.Dialog().notification(
                "StreamNinja",
                "Recuperada(s) {0} grabación(es) de un cierre anterior.".format(recovered),
                xbmcgui.NOTIFICATION_INFO, 4000
            )

    fmt = get_record_format()
    has_ffmpeg = ffmpeg_available()
    if fmt == "mp4":
        compress = has_ffmpeg
        if not has_ffmpeg:
            xbmcgui.Dialog().notification(
                "StreamNinja", "FFmpeg no disponible. Se graba en TS nativo.",
                xbmcgui.NOTIFICATION_WARNING, 5000
            )
    elif fmt == "ts":
        compress = False
    else:  # "ask"
        compress = has_ffmpeg and bool(xbmcgui.Dialog().yesno(
            "Formato de grabación",
            "¿Grabar en MP4 comprimido?\n\nArchivo un 50-70% más pequeño, compatible con cualquier reproductor.",
            nolabel="TS nativo",
            yeslabel="MP4 comprimido",
        ))

    if delay_mins > 0:
        dp_delay = xbmcgui.DialogProgress()
        dp_delay.create(
            "Grabación programada: {0}".format(canonical_name),
            "La grabación comenzará en {0} minutos...\nPulsa cancelar para abortar.".format(delay_mins)
        )
        total_secs = delay_mins * 60
        elapsed = 0
        monitor = xbmc.Monitor()
        while elapsed < total_secs:
            if dp_delay.iscanceled():
                dp_delay.close()
                xbmcgui.Dialog().notification("StreamNinja", "Grabación programada cancelada.", xbmcgui.NOTIFICATION_INFO)
                return
            remaining = total_secs - elapsed
            rm = remaining // 60
            rs = remaining % 60
            pct = int((elapsed / float(total_secs)) * 100)
            dp_delay.update(pct, "Faltan {0}m {1}s para empezar a grabar...".format(rm, rs))
            if monitor.waitForAbort(1):
                dp_delay.close()
                return
            elapsed += 1
        dp_delay.close()

    safe_name = _sanitize_filename(canonical_name)
    date_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    ext = 'mp4' if compress else 'ts'
    filename = "{0} - {1}.{2}".format(safe_name, date_str, ext)

    fmt_label = ext.upper()
    out_file = os.path.join(pvr_dir, filename)
    # Reserva atomica del nombre: en vez de un exists() racy, se crea el .partial
    # con O_EXCL. Cierra la ventana en que dos grabaciones del mismo canal en el
    # mismo segundo elegirian el mismo nombre (el exists() las dejaba pasar a las
    # dos y la segunda truncaba el .partial de la primera). El recorder reabre este
    # mismo .partial (raw con 'wb', ffmpeg con -y) y su finally borra los vacios.
    suffix = 2
    while True:
        if not os.path.exists(out_file):
            try:
                fd = os.open(out_file + ".partial",
                             os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.close(fd)
                break
            except FileExistsError:
                pass
        out_file = os.path.join(
            pvr_dir, "{0} - {1} ({2}).{3}".format(safe_name, date_str, suffix, ext))
        suffix += 1
    max_bw = get_max_bandwidth()
    xbmc.log("[StreamNinja/PVR] Grabacion iniciada. Destino: {0} | Calidad max: {1} bps | Formato: {2}".format(out_file, max_bw if max_bw else 'Sin limite', ext), xbmc.LOGINFO)

    _inc_active_recordings()

    try:
        recorder = HLSRecorder(url, out_file, name=canonical_name, max_duration_mins=mins, max_bandwidth=max_bw, compress=compress)
        recorder.start()

        dp = xbmcgui.DialogProgress()
        dp.create("Grabando ({0}): {1}".format(fmt_label, canonical_name), "Conectando al stream en directo...")

        in_background = False
        bg_dp = None

        recorder.playlist_resolved.wait(timeout=10)
        start_time = time.time()  # Empieza a contar después de resolver la playlist, no antes
        if max_bw > 0 and recorder.quality_status != "matched":
            if recorder.quality_status == "forced_lowest":
                xbmcgui.Dialog().notification(
                    "StreamNinja", "No hay calidad tan baja. Se graba en la más baja disponible.",
                    xbmcgui.NOTIFICATION_WARNING, 5000
                )
            elif recorder.quality_status in ("single", "error"):
                xbmcgui.Dialog().notification(
                    "StreamNinja", "Este canal solo ofrece una calidad. Se graba en la disponible.",
                    xbmcgui.NOTIFICATION_INFO, 4000
                )

        while recorder.is_alive():
            if not in_background and dp.iscanceled():
                ans = xbmcgui.Dialog().yesno(
                    "Grabar en Segundo Plano",
                    "Has pulsado cancelar en la ventana principal.\n¿Quieres detener la grabación o dejarla funcionando de fondo?",
                    nolabel="Detener y Guardar",
                    yeslabel="Seguir de fondo"
                )

                if not ans:  # 0 -> Detener
                    dp.update(100, "Cerrando archivo...")
                    recorder.stop()
                    recorder.join(timeout=5.0)
                    break
                else:  # 1 -> Segundo plano
                    dp.close()
                    in_background = True
                    bg_dp = xbmcgui.DialogProgressBG()
                    bg_dp.create("StreamNinja: Grabando", canonical_name)

            run_mins = recorder.get_run_time_mins()
            run_secs = int(time.time() - start_time)

            if mins > 0:
                pct = min(int((run_mins / float(mins)) * 100), 100)
            else:
                pct = run_secs % 100  # Sin límite: barra de actividad cíclica (indica "vivo")

            sin_datos = (recorder.downloaded_bytes == 0 and run_secs > 10)
            estado_red = "[COLOR orange]Reconectando...[/COLOR]" if sin_datos else "Conexión estable"

            if in_background:
                if bg_dp and not bg_dp.isFinished():
                    bg_msg = "Datos: {0} | {1}".format(recorder.format_bytes(recorder.downloaded_bytes), estado_red)
                    bg_dp.update(pct, heading="Grabando ({0}): {1}".format(fmt_label, canonical_name), message=bg_msg)
            else:
                line1 = "Duración actual: {0} min / {1}  [{2}]".format(
                    run_mins, "{0} min".format(mins) if mins > 0 else "Infinito", fmt_label
                )
                line2 = "Descargado: {0}".format(recorder.format_bytes(recorder.downloaded_bytes))
                line3 = "Estado de red: {0}".format(estado_red)
                dp.update(pct, line1 + "\n" + line2 + "\n" + line3)

            time.sleep(0.5)

        if in_background and bg_dp:
            bg_dp.close()
        elif not in_background:
            dp.close()

        if recorder.error_msg:
            xbmcgui.Dialog().ok("Error en grabación", recorder.error_msg)
        elif recorder.downloaded_bytes == 0:
            xbmcgui.Dialog().notification(
                "Grabación fallida",
                "No se pudo descargar ningún dato del canal.",
                xbmcgui.NOTIFICATION_WARNING
            )
        else:
            xbmcgui.Dialog().notification(
                "Grabación Completada",
                "{0} ({1})".format(canonical_name, recorder.format_bytes(recorder.downloaded_bytes)),
                xbmcgui.NOTIFICATION_INFO, 5000
            )
    finally:
        _dec_active_recordings()


def stop_all_recordings():
    if _active_recordings_count() <= 0:
        xbmcgui.Dialog().notification("StreamNinja", "No hay grabaciones activas.", xbmcgui.NOTIFICATION_INFO)
        return

    if xbmcgui.Dialog().yesno(
        "Detener Grabaciones",
        "¿Estás seguro de que quieres finalizar todas las grabaciones en directo en segundo plano?"
    ):
        _KODI_WINDOW.setProperty("streamninja_force_stop", "1")
        xbmcgui.Dialog().notification(
            "StreamNinja", "Señal de cierre enviada. Tardará unos segundos.",
            xbmcgui.NOTIFICATION_INFO
        )
        # Esperar a que cada grabación observe la señal y se decremente en su
        # propio finally, en vez de un sleep fijo de 3s; un recorder bloqueado en
        # un segmento (timeout de 15s) o en un _sleep de reconexión puede tardar
        # más de 3s en comprobar _should_stop(), y con el sleep corto la señal
        # desaparecía antes de que la viese y seguía grabando para siempre.
        monitor = xbmc.Monitor()
        deadline = time.time() + 20
        while _active_recordings_count() > 0 and time.time() < deadline:
            if monitor.waitForAbort(0.5):
                break
        # La señal se limpia siempre; dejarla activa abortaría cualquier grabación
        # futura. No se toca el contador (cada grabación lo decrementa en su
        # finally), así un reintento refleja las que de verdad sigan vivas.
        _KODI_WINDOW.clearProperty("streamninja_force_stop")
        if _active_recordings_count() > 0:
            xbmcgui.Dialog().notification(
                "StreamNinja", "Algunas grabaciones aún se están cerrando.",
                xbmcgui.NOTIFICATION_WARNING
            )