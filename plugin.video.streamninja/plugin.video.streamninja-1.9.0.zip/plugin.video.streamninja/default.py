# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE para mas detalles.
#
# ESTREAMNINJA EXPERIMENTAL:
# EstreamNinja es una versión experimental donde se prueban funcionalidades que, 
# eventualmente, podrían llegar a StreamNinja. Destaca por estar desarrollada
# completamente en español.
# 
# Esta versión no está pensada para ser utilizada por el público general ni por 
# otros desarrolladores: el código carece de los comentarios adecuados, no está pulido
# y contiene elementos muertos o descartables de uso exclusivo para pruebas.
# El proyecto original tiene API para que otros addons puedan usar sus funciones.
# Esta versión es solo para uso personal.

"""
==============================================================================
LEGAL DISCLAIMER / AVISO LEGAL:

1. USO EDUCATIVO Y NEUTRALIDAD: Este software es un proyecto experimental y 
   educativo de código abierto. Funciona exclusivamente como una herramienta 
   de red pasiva que facilita la navegación e interoperabilidad de información.
2. NO ALOJAMIENTO (NO HOSTING): Este código no aloja, almacena, retransmite, 
   copia ni distribuye ningún tipo de material ni contenido audiovisual. Toda la 
   comunicación de red ocurre exclusivamente entre el dispositivo del usuario final 
   y los servidores de internet a los que este decida libremente conectarse.
3. SIN ELUSIÓN CRIPTOGRÁFICA (NO DRM BYPASS): El proyecto opera sin interferir, 
   vulnerar, desencriptar o alterar el código de ninguna medida tecnológica 
   de protección o sistema de gestión de derechos digitales cerrados (DRM).
4. EXENCIÓN TOTAL DE RESPONSABILIDAD: El uso de este código queda bajo la 
   estricta responsabilidad del usuario final. El software se proporciona 
   "tal cual" (AS IS), y sus creadores declinan cualquier responsabilidad, 
   no fomentando ni apoyando ningún uso ilícito derivado del mismo.
==============================================================================
"""
import sys
import os
import re
import threading
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

import url_player
import url_remote
import info_addon
import stats

_MEDIA = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")

# --- Accesibilidad: negrita, modo de color y símbolos en todos los menús ---
# Monkey-patch de xbmcgui.ListItem para transformar cada etiqueta.
# Las variables globales se releen en main() en cada invocación; el toggle se aplica
# al instante (Container.Refresh) aunque Kodi reutilice el intérprete.

_ACC_COLOR_NAMES = {
    'none':        'Sin modificar (colores originales)',
    'white':       'Texto blanco (todos los colores → blanco)',
    'daltonic_rg': 'Daltónico rojo-verde (deuteranopia/protanopia)',
    'daltonic_by': 'Daltónico azul-amarillo (tritanopia)',
    'hc_dark':     'Alto contraste — fondo oscuro (amarillo)',
    'hc_light':    'Alto contraste — fondo claro (negro)',
}
_ACC_COLOR_KEYS = list(_ACC_COLOR_NAMES.keys())
_ACC_COLOR_LABELS = list(_ACC_COLOR_NAMES.values())


def _acc_color_index_to_key(raw):
    """Valor almacenado de acc_color_mode -> clave interna.
    Acepta indice numerico ('0'..), clave legada ('hc_dark') o vacio."""
    if not raw:
        return _ACC_COLOR_KEYS[0]
    try:
        idx = int(raw)
    except ValueError:
        return raw if raw in _ACC_COLOR_KEYS else _ACC_COLOR_KEYS[0]
    return _ACC_COLOR_KEYS[idx] if 0 <= idx < len(_ACC_COLOR_KEYS) else _ACC_COLOR_KEYS[0]


_BOLD_ENABLED = True
_ACC_COLOR_MODE = 'none'
_ACC_STRIP_SYMBOLS = False

try:
    _acc_init = xbmcaddon.Addon()
    _BOLD_ENABLED = _acc_init.getSetting('bold_labels') != 'false'
    _ACC_COLOR_MODE = _acc_color_index_to_key(_acc_init.getSetting('acc_color_mode'))
    _ACC_STRIP_SYMBOLS = _acc_init.getSetting('acc_strip_symbols') == 'true'
    del _acc_init
except Exception:
    pass

_OrigListItem = getattr(xbmcgui, '_OrigListItemSN', None) or xbmcgui.ListItem
xbmcgui._OrigListItemSN = _OrigListItem

_ACC_DRG_MAP = {
    'red': 'orange', 'tomato': 'orange', 'crimson': 'orange',
    'maroon': 'orange', 'coral': 'orange', 'firebrick': 'orange',
    'green': 'cyan', 'lime': 'cyan', 'limegreen': 'cyan',
    'mediumseagreen': 'cyan', 'palegreen': 'cyan', 'springgreen': 'cyan',
    'darkgreen': 'cyan', 'forestgreen': 'cyan', 'seagreen': 'cyan',
    'aqua': 'cyan', 'cyan': 'cyan', 'deepskyblue': 'deepskyblue',
    'skyblue': 'skyblue', 'lightskyblue': 'lightskyblue',
    'royalblue': 'royalblue', 'cornflowerblue': 'cornflowerblue', 'blue': 'blue',
    'gold': 'yellow', 'khaki': 'yellow', 'yellow': 'yellow',
    'gray': 'gray', 'grey': 'grey', 'white': 'white',
    'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
    'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
    'black': 'black', 'silver': 'silver',
}
_ACC_DBY_MAP = {
    'yellow': 'magenta', 'gold': 'magenta', 'khaki': 'magenta',
    'lemonchiffon': 'magenta', 'lightyellow': 'magenta',
    'blue': 'red', 'deepskyblue': 'red', 'royalblue': 'red',
    'cornflowerblue': 'red', 'lightskyblue': 'red', 'navy': 'red',
    'aqua': 'red', 'cyan': 'red', 'teal': 'red', 'turquoise': 'red',
    'skyblue': 'red', 'steelblue': 'red', 'cadetblue': 'red',
    'gray': 'gray', 'grey': 'grey', 'white': 'white',
    'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
    'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
    'black': 'black', 'silver': 'silver',
}
_ACC_HCD_KEEP_RED = frozenset({'red', 'tomato', 'crimson', 'maroon', 'coral', 'firebrick'})
_ACC_COLOR_RE = re.compile(r'\[COLOR\s+([a-zA-Z0-9]+)\]')
_ACC_SYMBOL_TABLE = str.maketrans({'★': '*', '●': '*', '○': '-', '▲': '^', '▼': 'v', '◑': '~', '◐': '~'})


def _acc_remap(match):
    c = match.group(1).lower()
    if _ACC_COLOR_MODE == 'white':
        return '[COLOR white]'
    if _ACC_COLOR_MODE == 'daltonic_rg':
        return '[COLOR {0}]'.format(_ACC_DRG_MAP.get(c, 'white'))
    if _ACC_COLOR_MODE == 'daltonic_by':
        return '[COLOR {0}]'.format(_ACC_DBY_MAP.get(c, 'white'))
    if _ACC_COLOR_MODE == 'hc_dark':
        return '[COLOR {0}]'.format(c if c in _ACC_HCD_KEEP_RED else 'yellow')
    if _ACC_COLOR_MODE == 'hc_light':
        return '[COLOR {0}]'.format(c if c in _ACC_HCD_KEEP_RED else 'black')
    return match.group(0)


def _acc_transform(s):
    if not isinstance(s, str) or not s:
        return s
    if _ACC_STRIP_SYMBOLS:
        s = s.translate(_ACC_SYMBOL_TABLE)
    if _BOLD_ENABLED:
        if '[B]' not in s:
            s = '[B]' + s + '[/B]'
    else:
        s = s.replace('[B]', '').replace('[/B]', '')
    if _ACC_COLOR_MODE not in ('', 'none'):
        s = _ACC_COLOR_RE.sub(_acc_remap, s)
    return s


def _ListItemBold(*args, **kwargs):
    if 'label' in kwargs:
        kwargs['label'] = _acc_transform(kwargs['label'])
    elif args:
        args = (_acc_transform(args[0]),) + args[1:]
    if 'label2' in kwargs:
        kwargs['label2'] = _acc_transform(kwargs['label2'])
    elif len(args) >= 2:
        args = (args[0], _acc_transform(args[1])) + args[2:]
    return _OrigListItem(*args, **kwargs)


xbmcgui.ListItem = _ListItemBold


def _accessibility_menu():
    h = url_player._get_handle()
    bold_on = xbmcaddon.Addon().getSetting('bold_labels') != 'false'
    cur_mode = _acc_color_index_to_key(xbmcaddon.Addon().getSetting('acc_color_mode'))
    sym_on = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'

    mode_name = _ACC_COLOR_NAMES.get(cur_mode, _ACC_COLOR_NAMES['none'])

    li = xbmcgui.ListItem(label='Modo de color: [COLOR deepskyblue]{0}[/COLOR]'.format(mode_name))
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': (
        'Selecciona cómo se muestran los colores en todos los menús.\n\n'
        'El cambio se aplica al instante al pulsar.'
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=url_player._u(action='acc_set_color_mode'), listitem=li, isFolder=False)

    bold_label = ('Negrita en todos los menús: [COLOR lime]ACTIVADA[/COLOR]' if bold_on
                  else 'Negrita en todos los menús: [COLOR grey]DESACTIVADA[/COLOR]')
    li = xbmcgui.ListItem(label=bold_label)
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': (
        'Muestra todas las etiquetas del addon en negrita.\n\n'
        'Útil para baja visión o dificultad para leer texto fino.\n\n'
        'El cambio se aplica al instante al pulsar.'
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=url_player._u(action='acc_toggle_bold'), listitem=li, isFolder=False)

    sym_label = ('Reemplazar símbolos (★●▲▼ → *-^v): [COLOR lime]ACTIVADO[/COLOR]' if sym_on
                 else 'Reemplazar símbolos (★●▲▼ → *-^v): [COLOR grey]DESACTIVADO[/COLOR]')
    li = xbmcgui.ListItem(label=sym_label)
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': (
        'Sustituye los símbolos Unicode (★ ● ○ ▲ ▼ ◑ ◐) '
        'por equivalentes de texto (* - ^ v ~).\n\n'
        'Útil para lectores de pantalla o fuentes sin estos caracteres.\n\n'
        'El cambio se aplica al instante al pulsar.'
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=url_player._u(action='acc_toggle_symbols'), listitem=li, isFolder=False)

    # cacheToDisc=False: el listado depende de settings mutables; debe re-renderizarse siempre.
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _acc_toggle_bold():
    cur = xbmcaddon.Addon().getSetting('bold_labels') != 'false'
    xbmcaddon.Addon().setSetting('bold_labels', 'false' if cur else 'true')
    msg = 'DESACTIVADA' if cur else 'ACTIVADA'
    xbmcgui.Dialog().notification('Accesibilidad', 'Negrita {0}'.format(msg), xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _acc_set_color_mode():
    cur_idx = _ACC_COLOR_KEYS.index(_acc_color_index_to_key(xbmcaddon.Addon().getSetting('acc_color_mode')))
    sel = xbmcgui.Dialog().select('Modo de color — Accesibilidad', _ACC_COLOR_LABELS, preselect=cur_idx)
    if sel < 0:
        return
    xbmcaddon.Addon().setSetting('acc_color_mode', str(sel))
    xbmcgui.Dialog().notification('Accesibilidad', 'Color: {0}'.format(_ACC_COLOR_LABELS[sel][:40]), xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _acc_toggle_symbols():
    cur = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'
    xbmcaddon.Addon().setSetting('acc_strip_symbols', 'false' if cur else 'true')
    msg = 'DESACTIVADO' if cur else 'ACTIVADO'
    xbmcgui.Dialog().notification('Accesibilidad', 'Reemplazo de símbolos {0}'.format(msg), xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


_ENUM_OPTIONS = {
    'dm_safe_level': (
        'Modo Anti-Errores Dailymotion',
        ['Desactivado', 'Básico (Móvil + Cookies)',
         'Extremo (Todas las técnicas)', 'YT-DLP (TLS Spoofing)'],
    ),
    'dl_mode': (
        'Modo de Descarga',
        ['Directo (Elegir calidad)', 'Safe Mode (Mejor MP4)',
         'HLS (Segmentos)', 'YT-DLP (Python 3.10+)', 'Ultra (1080p)'],
    ),
    'webremote_mode': (
        'Modo de conexión remota',
        ['Red local', 'Internet (relay ntfy.sh)'],
    ),
    'record_format': (
        'Formato de grabación',
        ['Preguntar', 'TS nativo', 'MP4 (requiere FFmpeg)'],
    ),
    'record_quality': (
        'Calidad máxima a grabar',
        ['Máxima (1080p)', 'Alta (720p)', 'Media (480p)', 'Baja (360p)'],
    ),
}


def _settings_add_toggle(h, a, setting_id, label, plot):
    val = a.getSetting(setting_id) != 'false'
    state = '[COLOR green]ACTIVADO[/COLOR]' if val else '[COLOR grey]DESACTIVADO[/COLOR]'
    li = xbmcgui.ListItem(label='{0}: {1}'.format(label, state))
    icon_path = os.path.join(_MEDIA, 'settings_{0}.png'.format(setting_id))
    if not os.path.exists(icon_path):
        icon_path = os.path.join(_MEDIA, 'opciones.png')
    li.setArt({'icon': icon_path})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=url_player._u(action='settings_toggle', setting_id=setting_id, name=label),
        listitem=li, isFolder=False,
    )


def _settings_add_enum(h, a, setting_id, label, plot):
    _, values = _ENUM_OPTIONS[setting_id]
    try:
        idx = int(a.getSetting(setting_id) or '0')
    except ValueError:
        idx = 0
    cur = values[idx] if 0 <= idx < len(values) else values[0]
    li = xbmcgui.ListItem(label='{0}: [COLOR deepskyblue]{1}[/COLOR]'.format(label, cur))
    icon_path = os.path.join(_MEDIA, 'settings_{0}.png'.format(setting_id))
    if not os.path.exists(icon_path):
        icon_path = os.path.join(_MEDIA, 'opciones.png')
    li.setArt({'icon': icon_path})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=url_player._u(action='settings_set_enum', setting_id=setting_id, name=label),
        listitem=li, isFolder=False,
    )


def _settings_add_folder(h, label, action, icon, plot):
    li = xbmcgui.ListItem(label='[COLOR white][B]{0}[/B][/COLOR]'.format(label))
    li.setArt({'icon': os.path.join(_MEDIA, icon)})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(
        handle=h, url=url_player._u(action=action), listitem=li, isFolder=True
    )


def _settings_add_input(h, a, setting_id, label, input_type='text', plot='', min_val=None, max_val=None, step=None, secret=False):
    cur = a.getSetting(setting_id)
    if not cur:
        shown = '[COLOR grey](sin definir)[/COLOR]'
    elif secret:
        # No exponer claves secretas (topic ntfy) en pantalla al navegar el menu.
        shown = '[COLOR lime]configurado[/COLOR]'
    else:
        shown = cur
    li = xbmcgui.ListItem(label='{0}: [COLOR deepskyblue]{1}[/COLOR]'.format(label, shown))
    icon_path = os.path.join(_MEDIA, 'settings_{0}.png'.format(setting_id))
    if not os.path.exists(icon_path):
        icon_path = os.path.join(_MEDIA, 'opciones.png')
    li.setArt({'icon': icon_path})
    li.setInfo('video', {'plot': plot})
    # urlencode serializa None como "None"; solo se pasan los parametros presentes.
    kw = {'action': 'settings_input', 'setting_id': setting_id, 'name': label, 'input_type': input_type}
    if min_val is not None:
        kw['min_val'] = min_val
    if max_val is not None:
        kw['max_val'] = max_val
    if step is not None:
        kw['step'] = step
    xbmcplugin.addDirectoryItem(
        handle=h, url=url_player._u(**kw), listitem=li, isFolder=False,
    )


def _settings_input(setting_id, name='', input_type='text', min_val=None, max_val=None, step=None):
    if not setting_id:
        return
    addon = xbmcaddon.Addon()
    cur = addon.getSetting(setting_id)

    if input_type == 'folder':
        val = xbmcgui.Dialog().browse(3, name or 'Carpeta', 'files', '', False, False, cur)
        if not val or val == cur:
            return
    elif input_type == 'range':
        # Equivalente al slider nativo; selector navegable con mando (sin teclado).
        lo = int(min_val) if min_val is not None else 0
        hi = int(max_val) if max_val is not None else 100
        stp = int(step) if step is not None else 1
        valores = list(range(lo, hi + 1, stp))
        try:
            cur_n = int(cur)
        except ValueError:
            cur_n = lo
        pre = min(range(len(valores)), key=lambda i: abs(valores[i] - cur_n))
        sel = xbmcgui.Dialog().select(name or 'Valor', [str(v) for v in valores], preselect=pre)
        if sel < 0:
            return
        val = str(valores[sel])
    elif input_type == 'number':
        raw = xbmcgui.Dialog().input(name or 'Valor', defaultt=cur, type=xbmcgui.INPUT_NUMERIC)
        if not raw:
            return
        try:
            num = int(raw)
        except ValueError:
            return
        lo = int(min_val) if min_val is not None else None
        hi = int(max_val) if max_val is not None else None
        if (lo is not None and num < lo) or (hi is not None and num > hi):
            xbmcgui.Dialog().notification(
                'Ajustes', 'Fuera de rango ({0}-{1})'.format(lo, hi),
                xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        val = str(num)
    else:  # text: vacio es valido (IP, ntfy, duracion); cancelar != confirmar vacio
        kb = xbmc.Keyboard(cur, name or 'Valor')
        kb.doModal()
        if not kb.isConfirmed():
            return
        val = kb.getText().strip()

    addon.setSetting(setting_id, val)
    xbmcgui.Dialog().notification('Ajustes', '{0} guardado'.format(name or setting_id),
                                  xbmcgui.NOTIFICATION_INFO, 1500)
    xbmc.executebuiltin('Container.Refresh')


def _settings_menu():
    h = url_player._get_handle()

    import remote_loader
    remote_loader.load_all_masters()
    import sys
    for i in range(5, 0, -1):
        mod_name = 'remote_login_' + str(i)
        if mod_name in sys.modules and hasattr(sys.modules[mod_name], 'open_login_dialog'):
            li = xbmcgui.ListItem(label="[COLOR white][B]Login[/B][/COLOR]")
            li.setArt({"icon": os.path.join(_MEDIA, "adv_usuario.png")})
            li.setInfo("video", {
                "plot": "Inicia sesión en tus cuentas de plataformas compatibles para acceder a contenido restringido."
            })
            xbmcplugin.addDirectoryItem(
                handle=h, url=url_player._u(action="open_login"), listitem=li, isFolder=False
            )
            break

    _settings_add_folder(
        h, 'Nube y Debrid', 'debrid_config', 'cloud_debrid.png',
        "Vincula tu cuenta de AllDebrid, Real-Debrid, TorBox o Premiumize "
        "para resolver magnets y enlaces de hosters premium con tu nube.\n\n"
        "Una vez vinculada aparece el acceso 'Mi nube' en el menú principal.",
    )
    _settings_add_folder(
        h, 'Control Remoto', 'settings_remote_menu', 'settings_webremote_mode.png',
        'Control remoto desde el móvil o PC: código QR, seguridad por token o PIN, '
        'modo de conexión (red local o internet) y confirmación al recibir URLs.',
    )
    _settings_add_folder(
        h, 'Descargas y Grabación', 'settings_downloads_menu', 'settings_dl_mode.png',
        'Modo de descarga de vídeos, formato y calidad de las grabaciones de directos, '
        'y el modo anti-errores de Dailymotion.',
    )
    _settings_add_folder(
        h, 'AceStream', 'settings_acestream_menu', 'settings_acestream_enabled.png',
        'Motor AceStream local para enlaces acestream://, estadísticas P2P en pantalla '
        'y, en Android, abrir en la app oficial.',
    )
    _settings_add_folder(
        h, 'General', 'settings_general_menu', 'url_config.png',
        'Opciones del menú contextual de Kodi ("Abrir/Copiar a StreamNinja").',
    )
    _settings_add_folder(
        h, 'Accesibilidad', 'accessibility_menu', 'adv_accesibilidad.png',
        'Negrita en menús, modo de color para daltonismo o alto contraste, '
        'y sustitución de símbolos Unicode.',
    )
    _settings_add_folder(
        h, 'Mantenimiento y Diagnóstico', 'advanced_menu', 'adv_debug.png',
        "Herramientas de diagnostico e integridad:\n"
        "mantenimiento yt-dlp, logs avanzados\n"
        "e inspeccion del repositorio de StreamNinja.",
    )

    li = xbmcgui.ListItem(label='[COLOR grey]Ajustes completos (diálogo nativo Kodi)[/COLOR]')
    li.setArt({'icon': os.path.join(_MEDIA, 'settings_native.png')})
    li.setInfo('video', {'plot': (
        'Abre el diálogo de ajustes nativo de Kodi.\n\n'
        'Necesario para editar ajustes de texto: contraseñas, rutas de descarga, '
        'puertos, canal ntfy, IP y puerto de AceStream, credenciales de Atresplayer, '
        'y URLs de conectores.'
    )})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=url_player._u(action='open_settings_native'),
        listitem=li, isFolder=False,
    )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_remote_menu():
    h = url_player._get_handle()
    a = xbmcaddon.Addon()
    _settings_add_toggle(
        h, a, 'enable_qr_remote',
        'QR en servidor remoto',
        'Muestra un código QR al iniciar el servidor remoto.\n\n'
        'Facilita conectar el móvil o PC sin tener que teclear la URL a mano.',
    )
    _settings_add_toggle(
        h, a, 'remote_secure',
        'Servidor local seguro (exigir token)',
        'Requiere que el cliente incluya un token de autenticación al enviar URLs.\n\n'
        'El token se incluye automáticamente en el QR y la URL generada. '
        'Actívalo si otros dispositivos en tu red local no deben poder enviar URLs.',
    )
    _settings_add_toggle(
        h, a, 'remote_pin',
        'Emparejar con PIN',
        'En lugar de incluir el token en el QR, muestra un PIN numérico en la TV.\n\n'
        'Tecleas el PIN en el móvil o PC para conectarte. Más seguro porque el token '
        'nunca viaja por la red hasta que el PIN es introducido.',
    )
    _settings_add_input(
        h, a, 'remote_port', 'Puerto del servidor', 'number',
        'Puerto en el que escucha el servidor remoto.\n\n'
        'Entre 1024 y 65535. Requiere reiniciar Kodi para aplicar el cambio.',
        min_val=1024, max_val=65535,
    )
    _settings_add_input(
        h, a, 'remote_ip', 'IP de escucha', 'text',
        'IP en la que escucha el servidor.\n\n'
        'Vacío = todas las interfaces; 127.0.0.1 = solo este equipo.',
    )
    _settings_add_enum(
        h, a, 'webremote_mode',
        'Modo de conexión remota',
        'Cómo llegan las URLs enviadas desde el móvil o PC.\n\n'
        'En red local el cliente se conecta directamente a la IP de Kodi dentro de '
        'tu casa, más rápido y sin pasar por servidores externos. El modo internet '
        'retransmite las URLs a través de ntfy.sh, lo que te permite enviar desde '
        'fuera a costa de que los datos pasen por un servidor público.',
    )
    _settings_add_toggle(
        h, a, 'webremote_confirm',
        'Pedir confirmación al recibir URL',
        'Muestra un diálogo de confirmación antes de reproducir cada URL recibida '
        'desde el móvil o PC.\n\n'
        'Útil si compartes el servidor con otras personas en la misma red.',
    )
    # ntfy solo aplica en modo Internet (webremote_mode=1); el nativo los oculta
    # igual con visible="eq(-2,1)"/"eq(-3,1)".
    if a.getSetting('webremote_mode') == '1':
        _settings_add_input(
            h, a, 'webremote_server', 'Servidor ntfy', 'text',
            'Servidor ntfy para el relay por internet.\n\n'
            'Vacío = ntfy.sh (el público por defecto). Solo para uso avanzado.',
        )
        _settings_add_input(
            h, a, 'webremote_topic', 'Canal / topic (clave secreta)', 'text',
            'Es tu CLAVE secreta del canal ntfy.\n\n'
            'Vacío = se genera uno aleatorio. Escanea el QR para no teclearlo a mano.',
            secret=True,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_downloads_menu():
    h = url_player._get_handle()
    a = xbmcaddon.Addon()
    _settings_add_enum(
        h, a, 'dl_mode',
        'Modo de Descarga',
        'Método usado al descargar vídeos a disco.\n\n'
        'El modo directo te deja elegir la calidad a mano y Safe Mode escoge el mejor '
        'MP4 por ti. HLS sirve para los streams en directo, que baja segmento a '
        'segmento. Los modos YT-DLP y Ultra usan yt-dlp (Ultra fuerza 1080p) y '
        'necesitan Python 3.10 o superior.',
    )
    _settings_add_input(
        h, a, 'download_path', 'Carpeta de descargas', 'folder',
        'Carpeta donde se guardan los vídeos descargados.',
    )
    _settings_add_enum(
        h, a, 'dm_safe_level',
        'Modo Anti-Errores Dailymotion',
        'Técnica para evitar errores al reproducir vídeos de Dailymotion.\n\n'
        'El modo básico emula un cliente móvil con cookies y suele bastar. El extremo '
        'añade todas las técnicas disponibles, y el modo YT-DLP recurre a TLS spoofing '
        '(necesita yt-dlp instalado). Déjalo desactivado mientras no tengas fallos.',
    )
    _settings_add_enum(
        h, a, 'record_format',
        'Formato de grabación',
        'Contenedor en el que se guardan las grabaciones de streams en directo.\n\n'
        'Preguntar deja elegir en cada grabación. TS nativo guarda el flujo tal cual, '
        'sin recodificar, y siempre está disponible. MP4 es más compatible pero '
        'necesita FFmpeg instalado.',
    )
    _settings_add_enum(
        h, a, 'record_quality',
        'Calidad máxima a grabar',
        'Tope de calidad cuando el stream ofrece varias resoluciones.\n\n'
        'Con Máxima no se descarta nada. Las demás opciones ignoran las pistas que '
        'superen esa resolución, útil para ahorrar espacio o ancho de banda.',
    )
    _settings_add_input(
        h, a, 'record_path', 'Carpeta de grabaciones', 'folder',
        'Carpeta donde se guardan las grabaciones de directos.',
    )
    _settings_add_input(
        h, a, 'record_timer', 'Duración máxima', 'text',
        'Tiempo máximo de grabación (ej: "1 hora", "30 min").\n\n'
        'Vacío = sin límite.',
    )
    _settings_add_input(
        h, a, 'record_delay', 'Retraso antes de empezar', 'text',
        'Espera antes de iniciar la grabación (ej: "5 min").\n\n'
        'Vacío = empezar ahora.',
    )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_acestream_menu():
    h = url_player._get_handle()
    a = xbmcaddon.Addon()
    _settings_add_toggle(
        h, a, 'acestream_enabled',
        'Motor AceStream local',
        'Usa el motor AceStream instalado localmente para reproducir enlaces acestream://.\n\n'
        'Desactívalo solo si prefieres usar Horus como intermediario.',
    )
    _settings_add_input(
        h, a, 'acestream_ip', 'IP del motor', 'text',
        'IP del motor AceStream.\n\n'
        '127.0.0.1 = motor local en este equipo.',
    )
    _settings_add_input(
        h, a, 'acestream_port', 'Puerto del motor', 'number',
        'Puerto HTTP del motor AceStream (por defecto 6878).',
        min_val=1, max_val=65535,
    )
    _settings_add_input(
        h, a, 'acestream_timeout', 'Tiempo máximo de precarga (s)', 'range',
        'Segundos de espera para la precarga P2P antes de empezar.\n\n'
        'Entre 10 y 180, en pasos de 5.',
        min_val=10, max_val=180, step=5,
    )
    _settings_add_toggle(
        h, a, 'acestream_show_osd',
        'Estadísticas P2P en pantalla (AceStream)',
        'Muestra velocidad, fuentes (peers) y estado sobre el reproductor al abrir el OSD '
        'de vídeo durante una reproducción AceStream.\n\n'
        'Solo afecta a AceStream.',
    )
    if xbmc.getCondVisibility("System.Platform.Android"):
        _settings_add_toggle(
            h, a, 'acestream_android_external',
            'Abrir AceStream en la app oficial (Android)',
            'En Android, envía el enlace AceStream a la app oficial de AceStream en lugar '
            'de reproducirlo con el motor local.\n\n'
            'Requiere tener instalada la app de AceStream.',
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_general_menu():
    h = url_player._get_handle()
    a = xbmcaddon.Addon()
    _settings_add_toggle(
        h, a, 'enable_context_play',
        'Menú contextual "Abrir con StreamNinja"',
        'Muestra la opción "Abrir con StreamNinja" en el menú contextual '
        '(clic derecho) de otros addons de Kodi.\n\n'
        'Permite reproducir directamente con StreamNinja sin salir del addon actual.',
    )
    _settings_add_toggle(
        h, a, 'enable_context_copy',
        'Menú contextual "Copiar a StreamNinja"',
        'Muestra la opción "Copiar a StreamNinja" en el menú contextual de otros addons.\n\n'
        'Copia la URL al portapapeles de Kodi para pegarla más tarde en StreamNinja.',
    )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_toggle(setting_id, name=''):
    if not setting_id:
        return
    cur = xbmcaddon.Addon().getSetting(setting_id) != 'false'
    xbmcaddon.Addon().setSetting(setting_id, 'false' if cur else 'true')
    estado = 'DESACTIVADO' if cur else 'ACTIVADO'
    xbmcgui.Dialog().notification('Ajustes', '{0}: {1}'.format(name or setting_id, estado),
                                  xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _settings_set_enum(setting_id, name=''):
    if setting_id not in _ENUM_OPTIONS:
        return
    title, values = _ENUM_OPTIONS[setting_id]
    try:
        cur_idx = int(xbmcaddon.Addon().getSetting(setting_id) or '0')
    except ValueError:
        cur_idx = 0
    sel = xbmcgui.Dialog().select(title, values, preselect=cur_idx)
    if sel >= 0:
        xbmcaddon.Addon().setSetting(setting_id, str(sel))
        xbmcgui.Dialog().notification('Ajustes', '{0}: {1}'.format(name or title, values[sel]),
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')


def _is_repo_installed():
    """Detecta si el repositorio de StreamNinja está instalado.

    Acepta variaciones razonables del nombre del repositorio
    (guiones, guiones bajos, sufijos) ya que el ID exacto puede
    variar entre versiones o forks del repo.
    """
    # 1. Comprobacion directa de las variantes mas probables
    common_ids = [
        "repository.streamninja",
        "repository.stream_ninja",
        "repository.stream-ninja",
        "repository.streamninja.oficial",
    ]
    for repo_id in common_ids:
        if xbmc.getCondVisibility("System.HasAddon({0})".format(repo_id)):
            return True

    # 2. Búsqueda difusa: recorre las carpetas de addons instaladas
    #    buscando cualquier repositorio cuyo nombre contenga "streamninja"
    try:
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        dirs, _ = xbmcvfs.listdir(addons_dir)
        for d in dirs:
            d_low = d.lower()
            if not d_low.startswith("repository."):
                continue
            # Normalizar: quitar separadores para comparar
            normalized = d_low.replace("_", "").replace("-", "").replace(".", "")
            if "streamninja" in normalized:
                if xbmc.getCondVisibility("System.HasAddon({0})".format(d)):
                    return True
    except Exception:
        pass
    return False


def _check_repo_status():
    """Verifica si el repositorio de actualizaciones está instalado."""
    if _is_repo_installed():
        xbmcgui.Dialog().ok(
            "Repositorio",
            "[COLOR green][B]INSTALADO[/B][/COLOR]\n"
            "El addon se actualiza automáticamente.",
        )
    else:
        xbmcgui.Dialog().ok(
            "Repositorio",
            "[COLOR red][B]NO INSTALADO[/B][/COLOR]\n"
            "Instala desde el Origen ZIP para\n"
            "recibir actualizaciones automáticas.",
        )


# --- Mantenimiento yt-dlp ---

def _show_ytdlp_instructions():
    """Muestra las instrucciones paso a paso de instalación de yt-dlp."""
    text = (
        "Para reproducir videos de YouTube, Dailymotion y otras webs\n"
        "necesitas instalar dos programas gratuitos en tu PC.\n"
        "No te preocupes, es facil. Sigue estos pasos:\n\n"

        "============================================\n"
        "  PRIMERO: ABRIR LA TERMINAL\n"
        "============================================\n\n"
        "La terminal es una ventana donde escribes comandos.\n\n"
        "  Windows:\n"
        "    1. Pulsa la tecla Windows del teclado\n"
        "    2. Escribe:  cmd\n"
        "    3. Haz clic en 'Simbolo del sistema'\n"
        "    Se abrira una ventana negra.\n\n"
        "    TRUCO: Para pegar un comando en esa ventana,\n"
        "    haz CLIC DERECHO con el raton (no Ctrl+V).\n\n"
        "  Mac:\n"
        "    1. Pulsa Cmd + Espacio a la vez\n"
        "    2. Escribe:  Terminal\n"
        "    3. Pulsa Enter\n\n"
        "  Linux:\n"
        "    Pulsa Ctrl + Alt + T a la vez\n\n"

        "============================================\n"
        "  PASO 1: INSTALAR PYTHON\n"
        "============================================\n\n"
        "Puede que ya lo tengas. Para comprobarlo,\n"
        "escribe en la terminal:\n\n"
        "   python --version\n\n"
        "Si aparece algo como 'Python 3.12.0', perfecto,\n"
        "ya lo tienes. Salta al Paso 2.\n\n"
        "Si da error, prueba con:\n"
        "   py --version\n\n"
        "Si tambien falla, necesitas instalarlo:\n\n"
        "   1. Ve a: https://www.python.org/downloads/\n"
        "   2. Descarga la version para tu sistema\n"
        "   3. Ejecuta el instalador\n\n"
        "   >>> MUY IMPORTANTE en Windows: <<<\n"
        "   En la primera pantalla del instalador,\n"
        "   MARCA la casilla que dice:\n"
        "       'Add Python to PATH'\n"
        "   Si no la marcas, nada funcionara.\n\n"
        "   4. Cierra la terminal y vuelve a abrirla\n\n"

        "============================================\n"
        "  PASO 2: INSTALAR YT-DLP\n"
        "============================================\n\n"
        "Escribe (o pega) este comando en la terminal:\n\n"
        '   pip install -U "yt-dlp[default]"\n\n'
        ">>> IMPORTANTE: Escribe el comando TAL CUAL, <<<\n"
        ">>> con las comillas y el [default].          <<<\n"
        ">>> Sin eso, Dailymotion no funcionara.       <<<\n\n"
        "Si 'pip' da error, prueba con:\n\n"
        '   python -m pip install -U "yt-dlp[default]"\n\n'
        "Espera a que termine (puede tardar un minuto).\n\n"

        "============================================\n"
        "  PASO 3: INSTALAR DENO (para YouTube)\n"
        "============================================\n\n"
        "YouTube necesita este programa adicional.\n"
        "Sin el, los videos de YouTube no funcionaran.\n\n"
        "  Windows:\n"
        "    Escribe en la terminal:\n"
        "    winget install DenoLand.Deno\n\n"
        "    Si 'winget' da error:\n"
        "    1. Ve a: https://github.com/denoland/deno/\n"
        "       releases/latest\n"
        "    2. Descarga deno-x86_64-pc-windows-msvc.zip\n"
        "    3. Descomprime y mueve deno.exe a C:\\Windows\\\n\n"
        "  Mac:\n"
        "    Escribe en la terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh\n\n"
        "  Linux:\n"
        "    Escribe en la terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh"
    )
    xbmcgui.Dialog().textviewer("Instrucciones de yt-dlp", text)


def _probe_ytdlp_status():
    """Comprueba yt-dlp y utilidades vía subprocess. Devuelve las líneas del informe.

    Bloquea hasta varios segundos: pensada para correr en un hilo aparte.
    """
    import subprocess

    # kwargs condicional: creationflags solo existe en Windows
    kwargs = {"capture_output": True, "text": True, "timeout": 10}
    if xbmc.getCondVisibility("System.Platform.Windows"):
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

    lines = []

    # Banderas de estado lógicas (desacopladas del texto UI)
    is_ytdlp_ok = False
    is_deno_ok = False
    is_node_ok = False
    is_ejs_ok = False

    # 1. Comprobar yt-dlp
    try:
        kw_ytdlp = kwargs.copy()
        kw_ytdlp["timeout"] = 15
        proc = subprocess.run(["python", "-m", "yt_dlp", "--version"], **kw_ytdlp)
        if proc.returncode == 0:
            ver = proc.stdout.strip()
            lines.append("[COLOR green][OK][/COLOR] yt-dlp instalado: v{0}".format(ver))
            is_ytdlp_ok = True
        else:
            lines.append("[COLOR red][ERROR][/COLOR] yt-dlp encontrado pero devolvió error")
    except FileNotFoundError:
        lines.append("[COLOR red][ERROR][/COLOR] Python no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[COLOR yellow][AVISO][/COLOR] yt-dlp tardó demasiado en responder")
    except OSError as exc:
        lines.append("[COLOR red][ERROR][/COLOR] Error de sistema: {0}".format(exc))

    # 2. Comprobar Deno
    try:
        proc = subprocess.run(["deno", "--version"], **kwargs)
        if proc.returncode == 0:
            deno_ver = proc.stdout.strip().split("\n")[0]
            lines.append("[COLOR green][OK][/COLOR] Deno instalado: {0}".format(deno_ver))
            is_deno_ok = True
        else:
            lines.append("[COLOR red][NO][/COLOR] Deno no disponible")
    except (FileNotFoundError, OSError):
        lines.append("[COLOR red][NO][/COLOR] Deno no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[COLOR yellow][AVISO][/COLOR] Deno tardó demasiado")

    # 3. Comprobar Node.js
    try:
        proc = subprocess.run(["node", "--version"], **kwargs)
        if proc.returncode == 0:
            node_ver = proc.stdout.strip()
            lines.append("[COLOR green][OK][/COLOR] Node.js instalado: {0}".format(node_ver))
            is_node_ok = True
        else:
            lines.append("[COLOR red][NO][/COLOR] Node.js no disponible")
    except (FileNotFoundError, OSError):
        lines.append("[COLOR red][NO][/COLOR] Node.js no encontrado en PATH")
    except subprocess.TimeoutExpired:
        lines.append("[COLOR yellow][AVISO][/COLOR] Node.js tardó demasiado")

    # 4. Comprobar yt-dlp-ejs
    try:
        proc = subprocess.run(["python", "-c", "import yt_dlp_ejs"], **kwargs)
        if proc.returncode == 0:
            lines.append("[COLOR green][OK][/COLOR] yt-dlp-ejs instalado")
            is_ejs_ok = True
        else:
            lines.append("[COLOR red][NO][/COLOR] yt-dlp-ejs no instalado")
            lines.append('     Instálalo: pip install -U "yt-dlp[default]"')
    except (FileNotFoundError, OSError):
        lines.append("[COLOR red][NO][/COLOR] No se pudo comprobar yt-dlp-ejs")
    except subprocess.TimeoutExpired:
        pass

    # Resumen inteligente (basado en lógica, no en matching de strings de UI)
    has_js = is_deno_ok or is_node_ok
    lines.append("")
    lines.append("===== RESUMEN =====")
    if is_ytdlp_ok and has_js and is_ejs_ok:
        lines.append("[COLOR green]Todo OK. YouTube debería funcionar correctamente.[/COLOR]")
    elif is_ytdlp_ok and has_js and not is_ejs_ok:
        lines.append("[COLOR yellow]Falta yt-dlp-ejs. Ejecuta:[/COLOR]")
        lines.append('   pip install -U "yt-dlp[default]"')
    elif is_ytdlp_ok and not has_js:
        lines.append("[COLOR yellow]Falta un runtime JS (Deno o Node.js).[/COLOR]")
        lines.append("YouTube podría fallar sin él.")
        lines.append("Pulsa 'Instrucciones' en el menú para más info.")
    else:
        lines.append("[COLOR red]yt-dlp no detectado o fallando.[/COLOR]")
        lines.append("Pulsa 'Instrucciones' en el menú para más info.")

    return lines


def _check_ytdlp_status():
    """Diagnóstico proactivo del estado de yt-dlp; corre fuera del hilo de UI."""
    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "yt-dlp no es compatible con Android.\n\n"
            "Usa un PC con Python 3.10+ instalado.",
        )
        return

    result = {}

    def _worker():
        try:
            result["lines"] = _probe_ytdlp_status()
        except Exception as exc:  # un diagnóstico no debe propagar y romper el menú
            result["error"] = str(exc)
            xbmc.log("[StreamNinja] Error sondeando yt-dlp: {0}".format(exc), xbmc.LOGERROR)

    worker = threading.Thread(target=_worker)
    worker.daemon = True
    worker.start()

    dp = xbmcgui.DialogProgress()
    dp.create("StreamNinja", "Comprobando yt-dlp y utilidades del sistema...")
    cancelled = False
    pct = 0
    while worker.is_alive():
        if dp.iscanceled():
            cancelled = True
            break
        pct = min(95, pct + 5)  # sube y se mantiene cerca del final mientras trabaja
        dp.update(pct)
        xbmc.sleep(150)
    dp.close()

    if cancelled:
        return  # el hilo daemon termina solo cuando acaben los subprocess
    if "lines" in result:
        xbmcgui.Dialog().textviewer("StreamNinja — Estado de yt-dlp", "\n".join(result["lines"]))
    else:
        xbmcgui.Dialog().ok("StreamNinja", "No se pudo completar el diagnóstico de yt-dlp. Revisa el log de Kodi para más detalles.")


def _copy_to_clipboard(text):
    """Copia texto al portapapeles del sistema operativo."""
    import subprocess
    import shutil

    def _pipe_to(cmd, **extra):
        # timeout evita que la UI se cuelgue indefinidamente si el helper bloquea
        try:
            p = subprocess.Popen(
                cmd, stdin=subprocess.PIPE, text=True, encoding="utf-8", **extra)
        except OSError as exc:
            xbmc.log("[StreamNinja] Portapapeles: no se pudo lanzar {0}: {1}".format(cmd[0], exc), xbmc.LOGWARNING)
            return False
        try:
            p.communicate(input=text, timeout=5)
            return p.returncode == 0
        except subprocess.TimeoutExpired:
            p.kill()
            p.communicate()
            xbmc.log("[StreamNinja] Portapapeles: {0} no respondió a tiempo".format(cmd[0]), xbmc.LOGWARNING)
            return False

    if xbmc.getCondVisibility("System.Platform.Windows"):
        if _pipe_to(["clip"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)):
            return True
    elif xbmc.getCondVisibility("System.Platform.OSX"):
        if _pipe_to(["pbcopy"]):
            return True
    elif xbmc.getCondVisibility("System.Platform.Linux"):
        if shutil.which("xclip"):
            if _pipe_to(["xclip", "-selection", "clipboard"]):
                return True
        elif shutil.which("xsel"):
            if _pipe_to(["xsel", "--clipboard", "--input"]):
                return True

    # Fallback universal via tkinter (rara vez disponible en cajas Kodi)
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(text)
        r.update()
        r.destroy()
        return True
    except Exception as exc:
        xbmc.log("[StreamNinja] Portapapeles: fallback tkinter no disponible: {0}".format(exc), xbmc.LOGDEBUG)
    return False


def _ytdlp_menu():
    """Submenú de mantenimiento de yt-dlp."""
    opts = [
        "Instrucciones: instalar / actualizar yt-dlp",
        "Comprobar estado de yt-dlp",
        "Copiar comandos de instalación al portapapeles",
    ]
    sel = xbmcgui.Dialog().select("Mantenimiento PC (yt-dlp)", opts)
    if sel == 0:
        _show_ytdlp_instructions()
    elif sel == 1:
        _check_ytdlp_status()
    elif sel == 2:
        cmd_ytdlp = 'pip install -U "yt-dlp[default]"'
        if xbmc.getCondVisibility("System.Platform.Windows"):
            cmd_deno = "winget install DenoLand.Deno"
        else:
            cmd_deno = "curl -fsSL https://deno.land/install.sh | sh"
        full_text = "{0}\n{1}".format(cmd_ytdlp, cmd_deno)
        if _copy_to_clipboard(full_text):
            xbmcgui.Dialog().ok(
                "Portapapeles",
                "Los comandos se han copiado.\n"
                "Pegalos en tu terminal (clic derecho\n"
                "o Ctrl+V) y pulsa Enter.",
            )
        else:
            xbmcgui.Dialog().ok(
                "Error",
                "No se pudo copiar al portapapeles.\n\n"
                "Copialos manualmente desde las\n"
                "instrucciones.",
            )


# --- Auto-instaladores desde GitHub ---

def _generic_github_installer(nombre, api_url, target_id):
    """Descarga e instala un addon desde GitHub Releases.

    Busca el primer asset .zip de la ultima release, valida
    su integridad, lo extrae en la carpeta de addons y lo activa.
    """
    import requests
    import zipfile

    dp = xbmcgui.DialogProgress()
    dp.create("StreamNinja", "Descargando {0}...".format(nombre))
    zip_path = None
    try:
        dp.update(5, "Buscando ultima version...")
        r = requests.get(api_url, timeout=15)
        r.raise_for_status()
        assets = r.json().get("assets", [])
        zip_url = None
        for asset in assets:
            if asset.get("name", "").endswith(".zip"):
                zip_url = asset["browser_download_url"]
                break
        if not zip_url:
            raise ValueError(
                "No se encontro ningun archivo .zip en la release")

        dp.update(10, "Descargando desde GitHub...")
        r_zip = requests.get(zip_url, timeout=60, allow_redirects=True)
        r_zip.raise_for_status()

        # Validar magic bytes del ZIP
        if len(r_zip.content) < 4 or r_zip.content[:2] != b"PK":
            raise ValueError("El archivo descargado no es un ZIP valido")

        # Guardar en temporal
        zip_path = os.path.join(
            xbmcvfs.translatePath("special://temp/"),
            "{0}.zip".format(target_id),
        )
        with open(zip_path, "wb") as f:
            f.write(r_zip.content)

        dp.update(50, "Extrayendo addon...")
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        with zipfile.ZipFile(zip_path, "r") as zf:
            # Proteccion contra path traversal
            for entry in zf.namelist():
                resolved = os.path.realpath(
                    os.path.join(addons_dir, entry))
                if not resolved.startswith(os.path.realpath(addons_dir)):
                    raise ValueError(
                        "ZIP contiene ruta sospechosa: {0}".format(entry))
            zf.extractall(addons_dir)

        dp.update(80, "Actualizando addons locales...")
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.sleep(2000)
        xbmc.executebuiltin("EnableAddon({0})".format(target_id))
        xbmc.sleep(1000)
        dp.close()
        xbmcgui.Dialog().notification(
            "StreamNinja",
            "{0} instalado correctamente".format(nombre),
            xbmcgui.NOTIFICATION_INFO, 5000,
        )
        xbmc.executebuiltin("Container.Refresh")
    except Exception as exc:
        dp.close()
        xbmc.log(
            "[StreamNinja] Error instalando {0}: {1}".format(nombre, exc),
            xbmc.LOGWARNING,
        )
        choice = xbmcgui.Dialog().yesno(
            "Error de instalacion",
            "No se pudo instalar {0}.\n\n"
            "Error: {1}\n\n"
            "Puede que necesites activar\n"
            "'Origenes desconocidos' en Ajustes.\n"
            "¿Abrir Ajustes del Sistema?".format(
                nombre, str(exc)[:150]),
        )
        if choice:
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


def _loiolog_install():
    """Menú de instalación de loiolog con opción automática y manual."""
    opts = ["Instalar automáticamente", "Ver instrucciones manuales"]
    sel = xbmcgui.Dialog().select("loiolog — Gestor Avanzado de Logs", opts)
    if sel == 0:
        _generic_github_installer(
            "loiolog",
            "https://api.github.com/repos/loioloio/loiolog/releases/latest",
            "plugin.program.loiolog",
        )
    elif sel == 1:
        xbmcgui.Dialog().ok(
            "Instalación manual",
            "Descarga el ZIP desde:\n"
            "github.com/loioloio/loiolog/releases\n\n"
            "En Kodi: Addons > Instalar desde ZIP.",
        )


def _flowfav_install():
    """Instala Flow FavManager desde GitHub Releases."""
    _generic_github_installer(
        "Flow FavManager",
        "https://api.github.com/repos/loioloio/flowfav/releases/latest",
        "plugin.program.flowfavmanager",
    )


def _user_message_dialog():
    """Abre el teclado de Kodi para que el usuario escriba un reporte o comentario."""
    addon = xbmcaddon.Addon()
    existing_msg = addon.getSetting('user_message').strip()

    kb = xbmc.Keyboard(existing_msg, "Reportar un problema o dejar un comentario (max. 150 caracteres)")
    kb.doModal()

    if not kb.isConfirmed():
        return

    raw_msg = kb.getText().strip()
    new_msg = raw_msg[:150]

    # Avisar al usuario si su mensaje fue recortado
    if len(raw_msg) > 150:
        continuar = xbmcgui.Dialog().yesno(
            "Mensaje demasiado largo",
            "Tu mensaje supera los 150 caracteres y sera recortado.\n\n"
            "Asi es como llegara al equipo de StreamNinja:\n\n"
            "\"{0}...\"\n\n"
            "\u00bfGuardar igualmente?".format(new_msg[:80])
        )
        if not continuar:
            return

    addon.setSetting('user_message', new_msg)

    if new_msg:
        xbmcgui.Dialog().ok(
            "Mensaje guardado",
            "Tu reporte se ha guardado y se enviara automaticamente\n"
            "al equipo de StreamNinja.\n\n"
            "[COLOR yellow]Nota:[/COLOR] Si vuelves aqui y borras el texto,\n"
            "el reporte tambien desaparecera."
        )
    else:
        xbmcgui.Dialog().ok(
            "Mensaje borrado",
            "Has dejado el mensaje en blanco.\n"
            "El reporte ha sido eliminado."
        )


def _show_telemetry_info():
    """Muestra información detallada sobre el reporte anónimo y permite enviarlo."""
    plot_text = (
        'Envía de forma anónima el identificador y versión del addon, versión de Kodi, sistema operativo y la fecha de la última conexión (para limpiar registros inactivos). '
        'No se almacenan IPs ni datos personales. Solo un identificador aleatorio (UUID) para no contar dos veces la misma instalación, junto con el mensaje opcional de "Enviar Reporte". Esto ayuda a planificar las actualizaciones y el soporte. '
        '¿Deseas enviar el reporte ahora mismo?'
    )
    confirm = xbmcgui.Dialog().yesno(
        "Reporte anónimo",
        plot_text,
        nolabel="Cerrar",
        yeslabel="Enviar ahora"
    )
    if confirm:
        import stats
        old_sync = stats._load_data().get('last_sync', 0)
        result = {}

        def _worker():
            try:
                stats._do_ping()
                result['done'] = True
            except Exception as e:
                result['error'] = str(e)

        t = threading.Thread(target=_worker, daemon=True)
        t.start()

        dp = xbmcgui.DialogProgress()
        dp.create('StreamNinja', 'Enviando reporte anónimo...')
        pct = 0
        while t.is_alive():
            if dp.iscanceled():
                break
            pct = min(95, pct + 5)
            dp.update(pct)
            xbmc.sleep(150)
        dp.close()

        new_sync = stats._load_data().get('last_sync', 0)
        if new_sync > old_sync:
            xbmcgui.Dialog().ok("Reporte anónimo", "El reporte se ha enviado correctamente a los servidores del proyecto.")
        else:
            xbmcgui.Dialog().ok("Reporte anónimo", "No se pudo enviar el reporte. Revisa tu conexión de red o vuelve a intentarlo más tarde.")


# --- Mis Descargas ---

def _show_downloads():
    """Genera el directorio visual de descargas locales.

    Muestra un enlace a Elementum (si esta instalado), el historial
    de archivos descargados con verificacion de existencia en disco,
    y una nota legal al final.
    """
    import download_manager

    h = url_player._get_handle()
    url_base = sys.argv[0]

    # Historial de descargas propias
    downloads = download_manager.get_downloads()
    if not downloads:
        li = xbmcgui.ListItem(label="No hay historial de descargas")
        li.setArt({"icon": "DefaultIconInfo.png"})
        li.setInfo("video", {
            "plot": "Cuando descargues un video, aparecera aqui.\n"
                    "Usa Abrir URL > Descargar para guardar contenido.",
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url=url_player._u(action="noop"), listitem=li, isFolder=False,
        )
    else:
        for entry in downloads:
            file_path = entry.get("path", "")
            title = entry.get("title", "Sin titulo")
            date = entry.get("date", "")
            file_exists = os.path.exists(file_path)

            if file_exists:
                label = "{0} ({1})".format(title, date)
            else:
                label = "[COLOR grey][ELIMINADO][/COLOR] {0}".format(title)

            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": "DefaultVideo.png"})
            li.setInfo("video", {
                "title": title,
                "plot": "Archivo: {0}\nDescargado el: {1}".format(
                    file_path, date),
            })

            # Menu contextual
            cm = [
                ("Quitar del historial",
                 "RunPlugin({0}?action=remove_download&dl_path={1})".format(
                     url_base,
                     urllib.parse.quote(file_path, safe=""))),
            ]
            if file_exists:
                li.setProperty("IsPlayable", "true")
                cm.append(
                    ("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]",
                     "RunPlugin({0}?action=delete_download_file"
                     "&dl_path={1}&title={2})".format(
                         url_base,
                         urllib.parse.quote(file_path, safe=""),
                         urllib.parse.quote(title, safe=""))))

            li.addContextMenuItems(cm)
            # Archivo presente -> ruta reproducible (IsPlayable ya marcado arriba).
            # Archivo borrado -> noop: clicar no hace nada en vez de intentar abrir
            # una ruta vacía (evita el "Error de reproducción" y la navegación a "").
            play_url = file_path if file_exists else url_player._u(action="noop")
            xbmcplugin.addDirectoryItem(
                handle=h, url=play_url, listitem=li, isFolder=False,
            )

    xbmcplugin.endOfDirectory(h)


def _delete_download_file(file_path, title):
    """Elimina un archivo descargado del disco y del historial.

    Pide confirmacion explicita al usuario antes de borrar para
    evitar perdidas accidentales de datos.
    """
    import download_manager

    display_title = title or "Sin titulo"
    display_path = file_path or ""

    if not display_path:
        return

    confirmed = xbmcgui.Dialog().yesno(
        "Eliminar Archivo",
        "Vas a eliminar este archivo del disco:\n\n"
        "[B]{0}[/B]\n\n"
        "Esta accion es irreversible.".format(display_title),
    )
    if not confirmed:
        return

    try:
        if os.path.exists(display_path):
            os.remove(display_path)
            download_manager.remove_download(display_path)
            xbmcgui.Dialog().notification(
                "StreamNinja", "Archivo eliminado",
                xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "El archivo ya no existe en esa ruta.")
            download_manager.remove_download(display_path)
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "No se pudo eliminar:\n{0}".format(str(exc)[:200]))

    xbmc.executebuiltin("Container.Refresh")


# --- Constructor visual del menú avanzado ---

def advanced_menu():
    """Genera el directorio de Mantenimiento y Diagnóstico de StreamNinja.

    Los ajustes de motor (Anti-Errores, Modo Descarga, Ruta) se
    gestionan desde la ventana nativa de Kodi (settings.xml).
    Este menu conserva las herramientas operativas e interactivas.
    """
    h = url_player._get_handle()
    url_base = sys.argv[0]

    # 1. Mantenimiento yt-dlp (solo plataformas de escritorio)
    if xbmc.getCondVisibility(
        "System.Platform.Windows | System.Platform.Linux | "
        "System.Platform.OSX"
    ):
        li = xbmcgui.ListItem("[COLOR white]Mantenimiento PC (yt-dlp)[/COLOR]")
        li.setArt({"icon": os.path.join(_MEDIA, "adv_ytdlp.png")})
        li.setInfo("video", {
            "plot": "Instrucciones para instalar yt-dlp en tu PC,\n"
                    "diagnostico del estado actual, y copia de\n"
                    "los comandos al portapapeles.",
        })
        xbmcplugin.addDirectoryItem(
            h, "{0}?action=ytdlp_menu".format(url_base), li, False,
        )

    # 2. loiolog
    if xbmc.getCondVisibility("System.HasAddon(plugin.program.loiolog)"):
        li = xbmcgui.ListItem(
            "[COLOR white]loiolog \u2014 Gestor Avanzado de Logs \u2014 "
            "[COLOR green]INSTALADO[/COLOR][/COLOR]"
        )
        li.setArt({"icon": os.path.join(_MEDIA, "adv_log.png")})
        li.setInfo("video", {
            "plot": "Herramienta avanzada para ver y filtrar\n"
                    "el log de Kodi. Pulsa para abrir.",
        })
        xbmcplugin.addDirectoryItem(
            h, "{0}?action=open_loiolog".format(url_base), li, False,
        )
    else:
        li = xbmcgui.ListItem(
            "[COLOR white]loiolog \u2014 Gestor Avanzado de Logs \u2014 "
            "[COLOR red]NO INSTALADO[/COLOR][/COLOR]"
        )
        li.setArt({"icon": os.path.join(_MEDIA, "adv_log.png")})
        li.setInfo("video", {
            "plot": "Herramienta para diagnosticar problemas.\n"
                    "Pulsa para instalar desde GitHub.",
        })
        xbmcplugin.addDirectoryItem(
            h, "{0}?action=loiolog_install".format(url_base), li, False,
        )

    # 3. Estado del repositorio
    if _is_repo_installed():
        li = xbmcgui.ListItem(
            "Repositorio: [COLOR green]INSTALADO[/COLOR]"
        )
    else:
        li = xbmcgui.ListItem(
            "Repositorio: [COLOR red]NO INSTALADO[/COLOR]"
        )
    li.setArt({"icon": "DefaultAddonRepository.png"})
    li.setInfo("video", {
        "plot": "Verifica que el repositorio esta vinculado\n"
                "para recibir actualizaciones automaticas.",
    })
    xbmcplugin.addDirectoryItem(
        h, "{0}?action=check_repo_status".format(url_base), li, False,
    )

    # 4. Enviar reporte
    addon = xbmcaddon.Addon()
    existing_msg = addon.getSetting('user_message').strip()
    msg_label = (
        "Enviar Reporte \u2014 [COLOR green]Tienes uno guardado[/COLOR]"
        if existing_msg else
        "Enviar Reporte"
    )
    li = xbmcgui.ListItem(msg_label)
    li.setArt({"icon": "DefaultAddonContextItem.png"})
    li.setInfo("video", {
        "plot": "Reporta un problema o deja un comentario (max. 150 caracteres)\n"
                "que llegara directamente al equipo de StreamNinja.\n"
                "Ideal para errores u opiniones.",
    })
    xbmcplugin.addDirectoryItem(
        h, "{0}?action=user_message_dialog".format(url_base), li, False,
    )

    # 5. Reporte anónimo
    li = xbmcgui.ListItem(label='Reporte anónimo')
    icon_path = os.path.join(_MEDIA, 'settings_enable_telemetry.png')
    if not os.path.exists(icon_path):
        icon_path = os.path.join(_MEDIA, 'opciones.png')
    li.setArt({'icon': icon_path})
    plot_text = (
        'Envía de forma anónima el identificador y versión del addon, versión de Kodi, sistema operativo y la fecha de la última conexión (para limpiar registros inactivos).\n\n'
        'No se almacenan IPs ni datos personales. Solo un identificador aleatorio (UUID) para no contar dos veces la misma instalación, junto con el mensaje opcional de "Enviar Reporte". Esto ayuda a planificar las actualizaciones y el soporte.'
    )
    li.setInfo('video', {'plot': plot_text})
    xbmcplugin.addDirectoryItem(
        h, "{0}?action=show_telemetry_info".format(url_base), li, False,
    )

    xbmcplugin.endOfDirectory(h)


def _parse_qs(qs):
    _seed = "cnViZW5zZGZhMWxhYmVybnQ="
    return dict(urllib.parse.parse_qsl(qs))

def _ensure_disclaimer_file(addon):
    """Genera un archivo AVISO_CREDENCIALES.txt en la carpeta de configuracion del addon (CYA legal)."""
    try:
        prof = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        os.makedirs(prof, exist_ok=True)
        disc_path = os.path.join(prof, "AVISO_CREDENCIALES.txt")
        if not os.path.exists(disc_path):
            with open(disc_path, "w", encoding="utf-8") as f:
                f.write(
                    "*** AVISO IMPORTANTE SOBRE EL USO DE CREDENCIALES ***\n\n"
                    "Los desarrolladores de StreamNinja NO promueven, facilitan ni aprueban\n"
                    "la compartición de tokens, cuentas o credenciales de servicios de terceros.\n\n"
                    "La funcionalidad de inicio de sesión de este addon ha sido desarrollada\n"
                    "EXCLUSIVAMENTE para uso estrictamente personal. Su objetivo es permitir a\n"
                    "los usuarios legítimos disfrutar del contenido al\n"
                    "que tienen derecho legal en la interfaz de Kodi.\n\n"
                    "Cualquier extracción, copia, distribución o compartición de los archivos\n"
                    "de esta carpeta (incluyendo 'auth_vault.json') con terceras personas es\n"
                    "responsabilidad única y exclusiva del usuario, y va contra la filosofía del proyecto.\n\n"
                    "Aclaración técnica: Las credenciales se guardan de forma visible porque Kodi es incapaz\n"
                    "de leer archivos encriptados. Si existiera cualquier manera de encriptar\n"
                    "las credenciales, se habría hecho sin dudarlo.\n\n"
                    "StreamNinja no almacena credenciales en servidores externos ni se hace\n"
                    "responsable del mal uso de las herramientas aquí proporcionadas.\n"
                )
    except Exception:
        pass

def main():
    addon = xbmcaddon.Addon()
    global _BOLD_ENABLED, _ACC_COLOR_MODE, _ACC_STRIP_SYMBOLS
    _BOLD_ENABLED = addon.getSetting('bold_labels') != 'false'
    _raw_color = addon.getSetting('acc_color_mode')
    _ACC_COLOR_MODE = _acc_color_index_to_key(_raw_color)
    # Migracion: las versiones antiguas guardaban la clave ('hc_dark'); el enum
    # nativo espera indice. Reescribimos una vez para que ambos queden consistentes.
    if _raw_color and not _raw_color.isdigit():
        addon.setSetting('acc_color_mode', str(_ACC_COLOR_KEYS.index(_ACC_COLOR_MODE)))
    _ACC_STRIP_SYMBOLS = addon.getSetting('acc_strip_symbols') == 'true'
    _ensure_disclaimer_file(addon)

    stats.ping()
    qs = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = _parse_qs(qs)
    action = params.get("action", "")

    try:
        if not action or action == "url_dialog":
            url_player.open_url_dialog()
        elif action == "url_input":
            url_player.url_input()
        elif action == "url_play_clipboard":
            try:
                win = xbmcgui.Window(10000)
                clipboard_url = win.getProperty("streamninja.clipboard.url").strip()
                if clipboard_url:
                    url_player.play_url_action(clipboard_url)
                else:
                    xbmcgui.Dialog().notification("StreamNinja", "Portapapeles vacío", xbmcgui.NOTIFICATION_WARNING)
            except Exception as e:
                xbmc.log("[StreamNinja] Error leyendo portapapeles: {0}".format(e), xbmc.LOGWARNING)
        elif action == "url_clipboard_clear":
            try:
                win = xbmcgui.Window(10000)
                win.clearProperty("streamninja.clipboard.url")

                xbmc.executebuiltin("Container.Refresh")
                xbmcgui.Dialog().notification("StreamNinja", "Botón quitado", xbmcgui.NOTIFICATION_INFO, 1500)
            except Exception as e:
                xbmc.log("[StreamNinja] Error limpiando portapapeles: {0}".format(e), xbmc.LOGWARNING)
        elif action == "url_remote":
            url_remote.start_remote()
        elif action == "url_scan":
            url_player.scan_videos_dialog()
        elif action == "scan_history":
            url_player.scan_history_menu()
        elif action == "scan_url":
            url = params.get("url")
            if url:
                url_player._run_scan(url)
        elif action == "scan_history_remove":
            url = params.get("url")
            if url:
                url_player._remove_from_scan_history(url)
                xbmc.executebuiltin("Container.Refresh")
        elif action == "scan_history_clear":
            url_player._clear_scan_history()
            xbmc.executebuiltin("Container.Refresh")
        elif action == "url_history":
            url_player.url_history_menu()
        elif action == "url_bookmarks":
            url_player.url_bookmarks_menu()
        elif action in ("url_bookmark_add", "url_bookmark_save_from_history"):
            url = params.get("url")
            if url:
                url_player.bookmark_save_from_history(url)
        elif action in ("url_bookmark_remove", "url_bookmark_delete"):
            url = params.get("url")
            if url:
                url_player.bookmark_delete(url)
        elif action == "url_bookmark_rename":
            url = params.get("url")
            if url:
                url_player.bookmark_rename(url)
        elif action in ("history_clear", "url_history_clear"):
            url_player.history_clear()
        elif action in ("history_remove", "url_history_remove"):
            url = params.get("url")
            if url:
                url_player.history_remove(url)
        elif action == "url_play":
            url = params.get("url")
            if url:
                url_player.play_url_action(url)
        elif action == "acestream":
            # Punto de entrada compatible con Horus: el action=play&id/url/infohash de Horus
            # se mapea a action=acestream&... en StreamNinja. Permite que otros addons llamen
            # a StreamNinja con el mismo patrón sin colisionar con Horus.
            url_player.play_acestream(
                content_id=params.get("id"),
                ace_url=params.get("url"),
                infohash=params.get("infohash"),
                title=params.get("title", ""),
                icon=params.get("iconimage", ""),
                plot=params.get("plot", ""),
            )
        elif action == "url_download":
            url = params.get("url", "")
            if url:
                url_player._resolve_and_download(url)
        elif action == "api_resolve":
            url = params.get("url")
            if url:
                url_player.api_resolve_action(url)
        elif action == "pv":
            url = params.get("vid") or params.get("url")
            if url:
                url_player.play_url_action(url)
        elif action == "copy_url":
            url = params.get("url")
            if url:
                xbmcgui.Window(10000).setProperty("streamninja.clipboard.url", url)
                xbmcgui.Dialog().notification("StreamNinja", "URL copiada al Portapapeles", xbmcgui.NOTIFICATION_INFO, 1500)
        elif action == "open_login":
            url_player.open_login_dialog()
        elif action == "open_settings":
            _settings_menu()
        elif action == "open_settings_native":
            xbmcaddon.Addon("plugin.video.streamninja").openSettings()
            xbmc.executebuiltin("Container.Refresh")
        elif action == "settings_remote_menu":
            _settings_remote_menu()
        elif action == "settings_downloads_menu":
            _settings_downloads_menu()
        elif action == "settings_acestream_menu":
            _settings_acestream_menu()
        elif action == "settings_general_menu":
            _settings_general_menu()
        elif action == "settings_toggle":
            _settings_toggle(params.get("setting_id", ""), params.get("name", ""))
        elif action == "settings_set_enum":
            _settings_set_enum(params.get("setting_id", ""), params.get("name", ""))
        elif action == "settings_input":
            _settings_input(
                params.get("setting_id", ""), params.get("name", ""),
                params.get("input_type", "text"),
                params.get("min_val"), params.get("max_val"), params.get("step"),
            )
        elif action == "info_menu":
            info_addon.info_menu()
        elif action == "show_universo":
            info_addon.show_universo()
        elif action == "info":
            info_addon.info()
        elif action == "advanced_menu":
            advanced_menu()


        elif action == "check_repo_status":
            _check_repo_status()
        elif action == "loiolog_install":
            _loiolog_install()
        elif action == "open_loiolog":
            xbmc.executebuiltin("RunAddon(plugin.program.loiolog)")
        elif action == "flowfav_install":
            _flowfav_install()
        elif action == "ytdlp_menu":
            _ytdlp_menu()
        elif action == "user_message_dialog":
            _user_message_dialog()
        elif action == "show_telemetry_info":
            _show_telemetry_info()
        elif action == "open_flowfav":
            xbmc.executebuiltin(
                "RunAddon(plugin.program.flowfavmanager)")

        # --- Mis Descargas ---
        elif action == "show_downloads":
            _show_downloads()
        elif action == "remove_download":
            import download_manager
            dl_path = params.get("dl_path", "")
            if dl_path:
                download_manager.remove_download(dl_path)
                xbmc.executebuiltin("Container.Refresh")
        elif action == "delete_download_file":
            _delete_download_file(
                params.get("dl_path", ""),
                params.get("title", ""))

        # --- Debrid (nube) ---
        elif action == "debrid_config":
            _debrid_config_menu()
        elif action == "debrid_set_provider":
            _debrid_set_provider()
        elif action == "debrid_authorize_pin":
            _debrid_authorize_pin()
        elif action == "debrid_authorize_key":
            _debrid_authorize_key()
        elif action == "debrid_account":
            _debrid_account()
        elif action == "debrid_deauthorize":
            _debrid_deauthorize()
        elif action == "debrid_toggle_enabled":
            _debrid_toggle_enabled()
        elif action == "debrid_toggle_cached":
            _debrid_toggle_setting("debrid_cached_only")
        elif action == "debrid_toggle_cleanup":
            _debrid_toggle_setting("debrid_auto_cleanup")
        elif action == "debrid_toggle_quality":
            _debrid_toggle_setting("debrid_auto_quality")
        elif action == "debrid_library":
            url_player.debrid_library_menu()
        elif action == "debrid_library_files":
            url_player.debrid_library_files(params.get("id"))
        elif action == "debrid_library_play":
            url_player.debrid_library_play(params.get("id"), params.get("file"))
        elif action == "debrid_library_delete":
            url_player.debrid_library_delete(params.get("id"))
        elif action == "debrid_download":
            url_player.debrid_download(params.get("id"), params.get("title", ""))

        # --- Grabador HLS en directo ---
        elif action == "pvr_record":
            url_player.record_stream_dialog()
        elif action == "pvr_record_stop":
            url_player.stop_recordings()

        elif action == "accessibility_menu":
            _accessibility_menu()
        elif action == "acc_toggle_bold":
            _acc_toggle_bold()
        elif action == "acc_set_color_mode":
            _acc_set_color_mode()
        elif action == "acc_toggle_symbols":
            _acc_toggle_symbols()
        elif action == "noop":
            pass  # item solo informativo, sin acción
        else:
            # Accion desconocida (URL antigua o manipulada): cerrar el directorio,
            # o Kodi se queda con el spinner girando esperando endOfDirectory.
            xbmc.log("[StreamNinja] Accion desconocida: {0}".format(action), xbmc.LOGWARNING)
            h = url_player._get_handle()
            if h >= 0:
                xbmcplugin.endOfDirectory(h, succeeded=False)

    except Exception as e:
        xbmc.log("[StreamNinja] Error in default.py routing: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "StreamNinja", "No se pudo completar la accion.",
            xbmcgui.NOTIFICATION_ERROR, 4000)
        # Si la accion era de directorio, cerrarlo como fallido para no colgar el
        # menu. En RunPlugin el handle es -1 y se omite (no hay directorio que cerrar).
        h = url_player._get_handle()
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)


# --- CONFIGURACIÓN DEBRID (nube: AllDebrid / Real-Debrid / TorBox / Premiumize) ---

def _debrid_reset_instance():
    try:
        import debrid_resolver
        debrid_resolver.reset_resolver()
    except Exception:
        pass


def _debrid_config_menu():
    """Menú de configuración del resolver Debrid: estado, proveedor, vinculación
    de cuenta y opciones de comportamiento."""
    addon = xbmcaddon.Addon()
    h = url_player._get_handle()
    provider = addon.getSetting("debrid_provider") or "AllDebrid"
    enabled = addon.getSetting("debrid_enabled") == "true"

    authorized = False
    user = ""
    supports_pin = True
    try:
        import debrid_resolver
        r = debrid_resolver.get_resolver()
        authorized = r.is_authorized()
        user = r.stored_user()
        supports_pin = r.SUPPORTS_PIN
    except Exception:
        pass

    def _add(label, action, plot="", icon="info.png"):
        # Un color al inicio envuelve el botón entero (acción) -> a blanco.
        # Un color en medio tiñe solo el valor (estado/proveedor) -> se respeta.
        if label.startswith("[COLOR"):
            label = re.sub(r"\[/?COLOR[^\]]*\]", "", label)
        li = xbmcgui.ListItem(label="[COLOR white]{0}[/COLOR]".format(label))
        icon_path = os.path.join(_MEDIA, icon)
        li.setArt({"icon": icon_path, "thumb": icon_path})
        if plot:
            li.setInfo("video", {"plot": plot})
        # action="" -> item solo informativo; "noop" evita que Kodi intente
        # reproducir una ruta vacía (CVideoPlayer::OpenInputStream - error opening []).
        url = url_player._u(action=action) if action else url_player._u(action="noop")
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    if authorized:
        estado = "[COLOR lime]{0}{1}[/COLOR]".format(provider, " · " + user if user else "")
        estado_action = "debrid_account"
        estado_plot = "Cuenta vinculada. Pulsa para ver el estado y el tráfico disponible."
    else:
        estado = "[COLOR gray]Sin vincular[/COLOR]"
        estado_action = "debrid_authorize_pin" if supports_pin else "debrid_authorize_key"
        estado_plot = "No hay cuenta vinculada. Pulsa para vincular tu cuenta {0}.".format(provider)
    _add("Estado: {0}".format(estado), estado_action, estado_plot, icon="adv_usuario.png")

    en_label = "[COLOR lime]ACTIVADA[/COLOR]" if enabled else "[COLOR grey]DESACTIVADA[/COLOR]"
    _add("Resolución Debrid: {0}".format(en_label), "debrid_toggle_enabled",
         "Si está activa, los magnets y enlaces de hosters premium se resuelven "
         "con tu cuenta antes del método normal.",
         icon="url_cloud.png")

    _add("Proveedor: [COLOR deepskyblue]{0}[/COLOR]".format(provider), "debrid_set_provider",
         "Servicio Debrid a usar: AllDebrid, Real-Debrid, TorBox o Premiumize.",
         icon="catalogo.png")

    if not authorized:
        if supports_pin:
            _add("[COLOR limegreen]Vincular cuenta (código PIN)[/COLOR]", "debrid_authorize_pin",
                 "Muestra un código para introducir en la web del proveedor y vincula "
                 "tu cuenta automáticamente.",
                 icon="loiolink.png")
        _add("[COLOR limegreen]Introducir API Key manualmente[/COLOR]", "debrid_authorize_key",
             "Pega la API key de tu cuenta (la encuentras en la web del proveedor).",
             icon="url_config.png")
    else:
        _add("Comprobar cuenta / tráfico", "debrid_account",
             "Consulta el estado de tu cuenta (premium, caducidad).",
             icon="bt_ranking.png")
        _add("[COLOR lightsalmon]Desconectar cuenta[/COLOR]", "debrid_deauthorize",
             "Elimina la cuenta vinculada de este addon.",
             icon="adv_borrar.png")

    cached = addon.getSetting("debrid_cached_only") == "true"
    _add("Solo caché (no esperar descargas): {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if cached else "[COLOR grey]NO[/COLOR]"),
        "debrid_toggle_cached",
        "Si está activo, un magnet que no esté ya en la nube se omite en lugar de "
        "esperar a que se descargue.",
        icon="adv_cache.png")

    cleanup = addon.getSetting("debrid_auto_cleanup") == "true"
    _add("Borrar torrent tras reproducir: {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if cleanup else "[COLOR grey]NO[/COLOR]"),
        "debrid_toggle_cleanup",
        "Borra el torrent de la nube automáticamente al terminar de reproducir.",
        icon="adv_limpieza.png")

    quality = addon.getSetting("debrid_auto_quality") == "true"
    _add("Auto-seleccionar mayor calidad/archivo: {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if quality else "[COLOR grey]NO[/COLOR]"),
        "debrid_toggle_quality",
        "En torrents o carpetas Debrid con múltiples archivos, reproduce "
        "automáticamente el archivo de vídeo más grande (mayor calidad) sin preguntar.",
        icon="adv_hd.png")

    xbmcplugin.endOfDirectory(h)


def _debrid_set_provider():
    opciones = ["AllDebrid", "Real-Debrid", "TorBox", "Premiumize"]
    cur = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
    pre = opciones.index(cur) if cur in opciones else 0
    sel = xbmcgui.Dialog().select("Proveedor Debrid", opciones, preselect=pre)
    if sel < 0:
        return
    xbmcaddon.Addon().setSetting("debrid_provider", opciones[sel])
    _debrid_reset_instance()
    xbmcaddon.Addon().setSetting("debrid_hosts_cache", "")  # invalida hosts del anterior
    xbmc.executebuiltin("Container.Refresh")


def _debrid_authorize_pin():
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_pin()
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error al vincular:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification(
            "Debrid", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")


def _debrid_authorize_key():
    key = xbmcgui.Dialog().input("API Key del proveedor")
    if not key:
        return
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_apikey(key)
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification(
            "Debrid", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")


def _debrid_deauthorize():
    if not xbmcgui.Dialog().yesno("Debrid", "¿Desconectar la cuenta de este addon?"):
        return
    try:
        import debrid_resolver
        debrid_resolver.get_resolver().deauthorize()
    except Exception:
        pass
    _debrid_reset_instance()
    xbmcgui.Dialog().notification(
        "Debrid", "Cuenta desconectada", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def _debrid_account():
    import debrid_resolver
    try:
        info = debrid_resolver.get_resolver().account_info()
    except debrid_resolver.DebridNetworkError as e:
        # Sin conexión / API caída; el str de la excepción es un tecnicismo de
        # transporte ('<urlopen error ...>'); al usuario se le da algo legible.
        xbmc.log("[StreamNinja] cuenta debrid (red): {0}".format(e), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            "Debrid", "No se pudo contactar con el servicio.\nComprueba tu conexión a internet.")
        return
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "No se pudo consultar la cuenta:\n{0}".format(e))
        return
    estado = "Premium" if info.get("premium") else "No premium"
    lineas = [
        "Usuario: {0}".format(info.get("username", "?")),
        "Estado: {0}".format(estado),
    ]
    expiry = info.get("expiry_text") or ""
    if expiry:
        days = info.get("days")
        dtxt = " ({0} días)".format(days) if isinstance(days, int) else ""
        lineas.append("Válida hasta: {0}{1}".format(expiry, dtxt))
    extra = info.get("extra") or ""
    if extra:
        lineas.append(extra)
    xbmcgui.Dialog().ok("Cuenta Debrid", "\n".join(lineas))


def _debrid_toggle_enabled():
    addon = xbmcaddon.Addon()
    if addon.getSetting("debrid_enabled") == "true":
        addon.setSetting("debrid_enabled", "false")
        xbmcgui.Dialog().notification(
            "Debrid", "Resolución DESACTIVADA", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        return
    # Disclaimer de uso responsable la primera vez que se activa
    if addon.getSetting("debrid_disclaimer_seen") != "true":
        if not xbmcgui.Dialog().yesno(
            "Resolver Debrid - Uso responsable",
            "El resolver usa TU cuenta Debrid para reproducir los enlaces y magnets "
            "que TÚ proporcionas.\n\n"
            "Eres responsable del contenido al que accedes y de respetar la ley de tu "
            "país y los términos de tu servicio Debrid.\n\n"
            "¿Activar el Resolver Debrid?",
        ):
            return
        addon.setSetting("debrid_disclaimer_seen", "true")
    addon.setSetting("debrid_enabled", "true")
    xbmcgui.Dialog().notification(
        "Debrid", "Resolución ACTIVADA", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def _debrid_toggle_setting(key):
    """Invierte un ajuste booleano de Debrid (cached_only / auto_cleanup / auto_quality)."""
    addon = xbmcaddon.Addon()
    addon.setSetting(key, "false" if addon.getSetting(key) == "true" else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")


if __name__ == "__main__":
    main()

