﻿# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE para mas detalles.
"""
Resolver de URLs mediante yt-dlp.

Solo funciona en plataformas de escritorio (Windows, Linux, macOS) donde
Python del sistema y yt-dlp estén disponibles vía PATH.
"""
import json
import os
import subprocess
import sys
import threading
import time
import xbmc
import xbmcaddon
import xbmcvfs

_CREATE_NO_WINDOW = 0x08000000
_BUNDLE_MAX_AGE_DAYS = 14  # yt-dlp caduca rápido; refrescar el embebido pasada esta edad
_FALLBACK_EXTRACTOR_KEY = "cnViZW5zZGZhMWxhYmVybnQ="  # Legacy yt-dlp internal key


def is_available():
    """Indica si yt-dlp podría estar disponible en esta plataforma.

    Devuelve False en Android (no hay Python del sistema).
    """
    return not xbmc.getCondVisibility("System.Platform.Android")

def _add_credentials(args, url):
    """Añade usuario y contraseña a yt-dlp si están configurados para esa url."""
    if "atresplayer.com" not in url.lower():
        return args
        
    addon = xbmcaddon.Addon("plugin.video.streamninja")
    user = addon.getSetting("atresplayer_user")
    pwd = addon.getSetting("atresplayer_pass")
    
    if user and pwd:
        args.extend(["--username", user, "--password", pwd])
    return args


def _build_cmd(url, extra_flags=None):
    """Construye el array de comando base para yt-dlp."""
    cmd = ["python", "-m", "yt_dlp", "--dump-json", "--no-download"]
    if extra_flags:
        cmd.extend(extra_flags)
    cmd.append(url)
    return _add_credentials(cmd, url)


def _packages_dir():
    """Carpeta del perfil donde se guarda el yt-dlp embebido (se crea si falta)."""
    prof = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    pkg = os.path.join(prof, "packages")
    # exist_ok=True: resolve()/scan se invocan desde hilos daemon que pueden
    # coincidir en el primer uso (el if previo tenía un TOCTOU).
    os.makedirs(pkg, exist_ok=True)
    return pkg


def ensure_ytdlp():
    """Asegura un yt-dlp embebido en packages/. Lo descarga si no está, o lo refresca
    si la copia existente supera _BUNDLE_MAX_AGE_DAYS (yt-dlp caduca rápido). Permite
    resolver/descargar sin yt-dlp en el Python del usuario. True si queda disponible.
    Si la re-descarga falla, conserva la copia vieja (mejor que nada)."""
    pkg = _packages_dir()
    ytdlp_dir = os.path.join(pkg, "yt_dlp")
    if os.path.isdir(ytdlp_dir):
        try:
            age_days = (time.time() - os.path.getmtime(ytdlp_dir)) / 86400.0
        except OSError:
            age_days = 0
        if age_days <= _BUNDLE_MAX_AGE_DAYS:
            return True
        xbmc.log(
            "[StreamNinja] yt-dlp embebido tiene {0:.0f} días; intentando actualizar".format(age_days),
            xbmc.LOGINFO,
        )
    try:
        import io
        import shutil
        import zipfile
        import requests
        meta = requests.get("https://pypi.org/pypi/yt-dlp/json", timeout=15)
        if meta.status_code != 200:
            return os.path.isdir(ytdlp_dir)
        whl_url = next(
            (u["url"] for u in meta.json().get("urls", [])
             if u["filename"].endswith(".whl") and "py3-none-any" in u["filename"]),
            None,
        )
        if not whl_url:
            return os.path.isdir(ytdlp_dir)
        whl = requests.get(whl_url, timeout=120)
        if whl.status_code != 200:
            return os.path.isdir(ytdlp_dir)
        # Extracción atómica: se vuelca a un directorio temporal y solo cuando está
        # completo se intercambia por yt_dlp/. Extraer in-place y refrescar su mtime
        # dejaba, si el proceso moría a medias, un bundle corrupto que el fast-path
        # de _BUNDLE_MAX_AGE_DAYS daba por bueno durante días (ImportError opacos).
        staging = os.path.join(pkg, "yt_dlp.new")
        if os.path.isdir(staging):
            shutil.rmtree(staging, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(whl.content)) as zf:
            for member in zf.namelist():
                if member.startswith("yt_dlp/"):
                    # Reescribe el prefijo para extraer dentro de yt_dlp.new/
                    rel = "yt_dlp.new/" + member[len("yt_dlp/"):]
                    if member.endswith("/"):
                        os.makedirs(os.path.join(pkg, rel), exist_ok=True)
                        continue
                    target = os.path.join(pkg, rel)
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with zf.open(member) as src, open(target, "wb") as dst:
                        shutil.copyfileobj(src, dst)
        if not os.path.isdir(staging):
            return os.path.isdir(ytdlp_dir)
        if os.path.isdir(ytdlp_dir):
            shutil.rmtree(ytdlp_dir, ignore_errors=True)
        os.replace(staging, ytdlp_dir)
        return os.path.isdir(ytdlp_dir)
    except Exception as exc:
        xbmc.log("[StreamNinja] ensure_ytdlp: {0}".format(exc), xbmc.LOGWARNING)
        try:
            staging = os.path.join(pkg, "yt_dlp.new")
            if os.path.isdir(staging):
                shutil.rmtree(staging, ignore_errors=True)
        except OSError:
            pass
        return os.path.isdir(ytdlp_dir)  # conserva la copia vieja si la había


def _ytdlp_bundle_env():
    """env con el yt-dlp embebido en PYTHONPATH, o None si no se pudo preparar.
    Solo se antepone packages/ cuando el Python del sistema NO tiene yt_dlp, así
    que nunca ensombrece una instalación del sistema que funcione."""
    if not ensure_ytdlp():
        return None
    env = dict(os.environ)
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = _packages_dir() + ((os.pathsep + existing) if existing else "")
    return env


def _exec_ytdlp(cmd, timeout, env=None):
    """Lanza el subproceso. Devuelve (returncode, stdout, stderr) o None si no se
    pudo arrancar (Python ausente, timeout, error de SO)."""
    creation_flags = _CREATE_NO_WINDOW if _is_windows() else 0
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            creationflags=creation_flags, env=env,
        )
    except FileNotFoundError:
        xbmc.log("[StreamNinja] yt-dlp: Python no encontrado en PATH", xbmc.LOGWARNING)
        return None
    except subprocess.TimeoutExpired:
        xbmc.log("[StreamNinja] yt-dlp: timeout ({0}s)".format(timeout), xbmc.LOGWARNING)
        return None
    except OSError as exc:
        xbmc.log("[StreamNinja] yt-dlp: error de SO: {0}".format(exc), xbmc.LOGWARNING)
        return None
    return proc.returncode, proc.stdout or "", proc.stderr or ""


def _is_bot_block(stderr):
    """True si el stderr de yt-dlp indica el bloqueo anti-bot de YouTube."""
    s = (stderr or "").lower()
    return "sign in to confirm" in s or "not a bot" in s


def _run_ytdlp(cmd, timeout):
    """Ejecuta yt-dlp del sistema y devuelve stdout, o None. Si el Python existe
    pero le falta el módulo yt_dlp, descarga una copia embebida (una sola vez) y
    reintenta con PYTHONPATH; así funciona sin yt-dlp instalado en el sistema.
    Si YouTube bloquea por bot, reintenta con --impersonate chrome (curl_cffi)."""
    res = _exec_ytdlp(cmd, timeout)
    if res is None:
        return None
    returncode, stdout, stderr = res

    # Frase exacta del intérprete; evita falsos positivos cuando yt-dlp del sistema
    # falla por un subpaquete (su traceback también menciona rutas 'yt_dlp').
    if returncode != 0 and "no module named 'yt_dlp'" in stderr.lower():
        xbmc.log(
            "[StreamNinja] yt-dlp no está en el Python del sistema; usando copia embebida",
            xbmc.LOGINFO,
        )
        env = _ytdlp_bundle_env()
        if env is not None:
            res = _exec_ytdlp(cmd, timeout, env=env)
            if res is None:
                return None
            returncode, stdout, stderr = res

    # YouTube bloquea por bot; reintentar con impersonation (necesita curl_cffi;
    # si falta, el reintento falla y se cae al aviso de curl_cffi de abajo).
    url = cmd[-1] if cmd else ""
    if (returncode != 0 and _is_bot_block(stderr)
            and ("youtube.com" in url or "youtu.be" in url)):
        xbmc.log(
            "[StreamNinja] yt-dlp: bloqueo de bot de YouTube; reintentando con --impersonate chrome",
            xbmc.LOGINFO,
        )
        res = _exec_ytdlp(cmd[:-1] + ["--impersonate", "chrome", cmd[-1]], timeout)
        if res is not None:
            returncode, stdout, stderr = res

    if returncode != 0:
        stderr = stderr.strip()
        stderr_lower = stderr.lower()
        if "impersonate" in stderr_lower or "curl_cffi" in stderr_lower:
            xbmc.log(
                "[StreamNinja] yt-dlp: falta curl_cffi para impersonation. "
                "Instalar globalmente con: pip install -U \"yt-dlp[default]\"",
                xbmc.LOGERROR,
            )
            try:
                import xbmcgui as _gui
                _gui.Dialog().notification(
                    "StreamNinja",
                    "Falta curl_cffi. Ve a Opciones Avanzadas.",
                    _gui.NOTIFICATION_WARNING, 5000,
                )
            except Exception:
                pass
        else:
            xbmc.log(
                "[StreamNinja] yt-dlp: código {0} — {1}".format(returncode, stderr[:200]),
                xbmc.LOGWARNING,
            )
        return None

    stdout = stdout.strip()
    return stdout if stdout else None


def resolve(url, fmt="best[ext=mp4]/best", timeout=30):
    """Resuelve *url* con yt-dlp y devuelve la URL directa del stream.

    Args:
        url:     URL pública del vídeo (YouTube, Dailymotion, Vimeo, …).
        fmt:     Cadena de formato de yt-dlp.
        timeout: Segundos máximos de espera para el subproceso.

    Returns:
        Cadena con la URL directa del stream, o ``None`` si la
        resolución falla por cualquier motivo.
    """
    if not is_available():
        return None

    cmd = _build_cmd(url, ["--format", fmt, "--no-playlist"])
    stdout = _run_ytdlp(cmd, timeout)
    if not stdout:
        return None

    try:
        info = json.loads(stdout)
    except (json.JSONDecodeError, ValueError):
        xbmc.log("[StreamNinja] yt-dlp: JSON inválido en stdout", xbmc.LOGWARNING)
        return None

    return info.get("url") or None


def resolve_full(url, fmt="best[ext=mp4]/best", timeout=30):
    """Resuelve *url* con yt-dlp y devuelve un dict con la info completa.

    Útil para plataformas que necesitan cabeceras HTTP o info del protocolo
    (p.ej. A3player que usa HLS con User-Agent obligatorio).

    Returns:
        Dict con claves ``url``, ``headers`` (dict), ``protocol`` (str),
        ``ext`` (str), o ``None`` si la resolución falla.
    """
    if not is_available():
        return None

    cmd = _build_cmd(url, ["--format", fmt, "--no-playlist"])
    stdout = _run_ytdlp(cmd, timeout)
    if not stdout:
        return None

    try:
        info = json.loads(stdout)
    except (json.JSONDecodeError, ValueError):
        return None

    stream_url = info.get("url")
    if not stream_url:
        return None

    return {
        "url": stream_url,
        "headers": info.get("http_headers") or {},
        "protocol": info.get("protocol") or "",
        "ext": info.get("ext") or "",
    }


_inmemory_lock = threading.Lock()
_inmemory_path_added = False
_inmemory_worker = None


def resolve_in_memory(url, fmt="best[ext=mp4]/best", timeout=30):
    """Resuelve *url* importando yt-dlp dentro del propio Python de Kodi.

    Pensado para Android, donde no hay Python del sistema para el subproceso. Devuelve
    el mismo dict que resolve_full ({url, headers, protocol, ext}) o None.

    Limitaciones reales:
      - Requiere Python >= 3.10 (el wheel de yt-dlp lo exige; Kodi 19 trae 3.8).
      - Sin curl_cffi no esquiva el bloqueo anti-bot de YouTube (usar la app/navegador).
      - extract_info es bloqueante: se ejecuta en un hilo con timeout y, si se excede,
        se abandona (un hilo de Python no se puede matar) devolviendo None.
    """
    if sys.version_info < (3, 10):
        xbmc.log("[StreamNinja] yt-dlp en memoria requiere Python 3.10+ (Kodi 20+)",
                 xbmc.LOGINFO)
        return None

    global _inmemory_path_added, _inmemory_worker
    box = {}
    with _inmemory_lock:
        # Un extract_info que se pasó del timeout sigue vivo (un hilo de Python no
        # se puede matar). Si llega otra resolución mientras tanto, se omite en vez
        # de apilar hilos/conexiones que sobreviven a la invocación del addon.
        prev = _inmemory_worker
        if prev is not None and prev.is_alive():
            xbmc.log("[StreamNinja] yt-dlp en memoria: ya hay una resolución en curso; se omite",
                     xbmc.LOGINFO)
            return None
        if not ensure_ytdlp():
            return None
        pkg = _packages_dir()
        if not _inmemory_path_added:
            if pkg not in sys.path:
                sys.path.insert(0, pkg)
            _inmemory_path_added = True
        try:
            from yt_dlp import YoutubeDL
        except Exception as exc:  # import pesado de terceros: si falla, no rompemos nada
            xbmc.log("[StreamNinja] yt-dlp en memoria no importable: {0}".format(exc),
                     xbmc.LOGWARNING)
            return None

        def _work():
            try:
                # socket_timeout acota cada operación de red de yt-dlp para que el
                # hilo termine de verdad ante una página colgada, en vez de seguir
                # corriendo indefinidamente tras devolver None nosotros por el join.
                opts = {"quiet": True, "no_warnings": True, "noplaylist": True,
                        "format": fmt, "socket_timeout": timeout}
                with YoutubeDL(opts) as ydl:
                    box["info"] = ydl.extract_info(url, download=False)
            except Exception as exc:  # lib de terceros en hilo: capturar todo y loguear
                box["error"] = exc

        t = threading.Thread(target=_work, daemon=True)
        # Registrar bajo el MISMO lock que el check; comprobar-y-reservar es atómico,
        # así dos llamadas casi simultáneas no arrancan dos workers a la vez.
        _inmemory_worker = t

    t.start()
    t.join(timeout)
    if t.is_alive():
        xbmc.log("[StreamNinja] yt-dlp en memoria: timeout ({0}s)".format(timeout),
                 xbmc.LOGWARNING)
        return None
    if "error" in box:
        xbmc.log("[StreamNinja] yt-dlp en memoria: {0}".format(box["error"]),
                 xbmc.LOGWARNING)
        return None

    info = box.get("info")
    if not info:
        return None
    if "entries" in info:  # playlist: tomar la primera entrada reproducible
        entries = [e for e in (info.get("entries") or []) if e]
        if not entries:
            return None
        info = entries[0]

    stream_url = info.get("url")
    if not stream_url:
        return None
    return {
        "url": stream_url,
        "headers": info.get("http_headers") or {},
        "protocol": info.get("protocol") or "",
        "ext": info.get("ext") or "",
    }

def scan_videos(url, timeout=90):
    """Extrae la lista de vídeos de *url* vía yt-dlp.

    Ejecuta yt-dlp con ``--dump-json`` y parsea la salida, que contiene
    una línea JSON por cada vídeo detectado.

    Args:
        url:     Página o playlist a escanear.
        timeout: Segundos máximos de espera para el subproceso.

    Returns:
        Lista de dicts con claves ``title``, ``url``, ``duration``
        (segundos o None), ``filesize`` (bytes o None) y ``ext``.
        Lista vacía si yt-dlp no está disponible, falla o no hay vídeos.
    """
    if not is_available():
        return []

    cmd = _build_cmd(url, ["--flat-playlist"])
    stdout = _run_ytdlp(cmd, timeout)
    if not stdout:
        return []

    results = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            info = json.loads(line)
        except (json.JSONDecodeError, ValueError):
            continue
        video_url = info.get("url") or info.get("webpage_url") or ""
        if not video_url:
            continue
        results.append({
            "title": info.get("title") or video_url,
            "url": video_url,
            "duration": info.get("duration"),
            "filesize": info.get("filesize") or info.get("filesize_approx"),
            "ext": info.get("ext") or "",
        })
    return results


def _is_windows():
    return xbmc.getCondVisibility("System.Platform.Windows")
