# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE para mas detalles.
#
# ESTREAMNINJA EXPERIMENTAL:
# EstreamNinja es una versión experimental donde se prueban funcionalidades que, 
# eventualmente, podrían llegar a StreamNinja. Destaca por estar desarrollada
# completamente en español.
# 
# Esta versión no está pensada para ser utilizada por el público general ni por 
# otros desarrolladores: el código carece de los comentarios adecuados, no está pulido
# y contiene elementos muertos o descartables de uso exclusivo para pruebas.
"""
Reproductor de URLs Externas para StreamNinja

Permite al usuario pegar una URL de vídeo y reproducirla en Kodi.
--
Inicia un mini servidor en la red local que sirve una pagina web
donde el usuario puede pegar una URL. 
Al enviar, Kodi lo recibe y actua.

Incluye controles de reproduccion y estado en tiempo real
mediante JSON-RPC de Kodi.

Idea original de RubenSDFA1laberot:
La implementación de un servidor HTTP local efímero que se levanta bajo demanda
para enviar URLs o texto a Kodi y se cierra automáticamente al terminar, sin dejar puertos abiertos ni obligar
al usuario a activar el control HTTP en los ajustes del sistema Kodi.

Si decides utilizar este código en tus propios desarrollos o te inspiras en esta idea original, 
es de agradecer que menciones este proyecto.

Detección inteligente:
  - Dailymotion (dailymotion.com / dai.ly)   -> dm_gujal
  - YouTube     (youtube.com / youtu.be)      -> plugin.video.youtube
  - Streams     (.m3u8 / .mp4 / .mpd / etc.)  -> reproducción directa
  - Torrents    (magnet: / .torrent)           -> plugin.video.elementum
  - AceStream   (acestream://)                -> script.module.horus
  - Otras webs                                -> SendToKodi / yt-dlp
"""
# noinspection PyUnresolvedReferences
import sys
import os
import hashlib
import json
import time
import re
import socket
import subprocess
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import threading
import ytdlp_resolver


_ADDON_ID = "plugin.video.streamninja"
_MEDIA = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")
_profile_path = None
# _json_lock serializa la I/O de fichero (load/save atómicos); _store_lock
# serializa la operación lógica completa leer-modificar-guardar de historial y
# marcadores, para que dos hilos daemon no se pisen y pierdan una entrada.
# Orden de adquisición: _store_lock (externo) -> _json_lock (interno). Nunca al
# revés. El enriquecimiento de red va SIEMPRE fuera de _store_lock.
_json_lock = threading.Lock()
_store_lock = threading.Lock()

# yt-dlp siempre adjunta estos headers de navegador; los CDN suelen rechazarlos
# o son redundantes para Kodi. Se filtran salvo en enlaces directos del usuario.
_GENERIC_HEADERS = {
    "user-agent", "accept", "accept-language", "accept-encoding",
    "sec-fetch-dest", "sec-fetch-mode", "sec-fetch-site",
    "sec-ch-ua", "sec-ch-ua-mobile", "sec-ch-ua-platform",
}
# Debe coincidir con _MAX_HISTORY de url_remote.py; ambos procesos recortan el
# MISMO url_history.json, y un valor distinto haría oscilar su longitud.
MAX_HISTORY = 50
MAX_BOOKMARKS = 50
MAX_SCAN_HISTORY = 20
_DEBRID_CACHE_TTL = 600   # 10 min: los enlaces Debrid caducan; TTL conservador
_DEBRID_CACHE_MAX = 20
_SCAN_CACHE_TTL = 600     # 10 min: resultados de escaneo web en caché
_SCAN_CACHE_MAX = 15

_STREAM_EXTENSIONS = {
    ".m3u8", ".mp4", ".mkv", ".avi", ".ts", ".flv",
    ".mov", ".wmv", ".webm", ".mpd", ".m3u",
}

# El grupo captura el content ID; el sufijo opcional (?:[?&].*)? tolera un
# "?params" no estándar (la wiki oficial dice que el esquema no lo lleva, pero
# así un enlace de fuente rara con cola de query reproduce igual en vez de fallar).
_ACESTREAM_RE = re.compile(r"acestream://([0-9a-fA-F]{40})(?:[?&].*)?", re.IGNORECASE)
_ACE_HASH_RE = re.compile(r"[0-9a-fA-F]{40}")


def _ace_engine_alive(host, port, timeout=1):
    """True si el motor AceStream responde en host:port. Sin motor falla
    por conexión rechazada o timeout corto; evita el cuelgue de 30s de Kodi al
    intentar reproducir directamente cuando no hay nada escuchando."""
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True
    except (OSError, ValueError):
        return False


def _clip_via_cmd(cmd):
    try:
        out = subprocess.run(
            cmd, capture_output=True, encoding="utf-8",
            errors="replace", timeout=2,
        )
        return out.stdout.strip() if out.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def _get_system_clipboard_text():
    """Lee el portapapeles del SO, o '' si no se puede (otra plataforma, sin
    xclip/xsel, portapapeles bloqueado). En ese caso el botón que lo usa no
    aparece, sin error."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            import ctypes.wintypes
            CF_UNICODETEXT = 13
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            user32.GetClipboardData.restype = ctypes.c_void_p
            user32.GetClipboardData.argtypes = [ctypes.wintypes.UINT]
            kernel32.GlobalLock.restype = ctypes.c_void_p
            kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            if not user32.OpenClipboard(None):
                return ""
            try:
                handle = user32.GetClipboardData(CF_UNICODETEXT)
                if not handle:
                    return ""
                ptr = kernel32.GlobalLock(handle)
                if not ptr:
                    return ""
                try:
                    return ctypes.wstring_at(ptr).strip()
                finally:
                    kernel32.GlobalUnlock(handle)
            finally:
                user32.CloseClipboard()
        except Exception:
            return ""
    if sys.platform == "darwin":
        return _clip_via_cmd(["pbpaste"])
    # Linux/Unix. En Android no hay xclip/xsel ni subprocess fiable.
    if xbmc.getCondVisibility("System.Platform.Android"):
        return ""
    return (_clip_via_cmd(["xclip", "-selection", "clipboard", "-o"])
            or _clip_via_cmd(["xsel", "-b", "-o"]))


_PLAYABLE_PREFIXES = ("http://", "https://", "magnet:", "acestream://")


def _looks_like_playable_url(text):
    """True si text parece reproducible: esquema soportado o hash AceStream
    desnudo (40 hex). Acota el tamaño: una URL/magnet real no supera unos pocos
    KB, y así un portapapeles enorme no construye una plugin URL desmesurada."""
    if not text or len(text) > 8192:
        return False
    return (text.lower().startswith(_PLAYABLE_PREFIXES)
            or bool(_ACE_HASH_RE.fullmatch(text)))


def _get_profile():
    global _profile_path
    if _profile_path is None:
        _profile_path = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile")
        )
        os.makedirs(_profile_path, exist_ok=True)
    return _profile_path


def _history_path():
    return os.path.join(_get_profile(), "url_history.json")


def _bookmarks_path():
    return os.path.join(_get_profile(), "url_bookmarks.json")


def _scan_history_path():
    return os.path.join(_get_profile(), "scan_history.json")


def _get_scan_history():
    return _load_json(_scan_history_path())


def _add_to_scan_history(raw_input, scan_type):
    raw_input = raw_input.strip()
    if not raw_input:
        return
    entries = _load_json(_scan_history_path())
    entries = [e for e in entries if e.get('input') != raw_input]
    if scan_type == 'telegram':
        name = raw_input.lstrip('@')
        for prefix in ('https://t.me/', 'http://t.me/', 't.me/'):
            if name.lower().startswith(prefix):
                name = name[len(prefix):]
                break
        name = name.split('/')[0].split('?')[0].strip()
        label = '@' + name if name else raw_input
    else:
        label = raw_input
        for prefix in ('https://www.', 'http://www.', 'https://', 'http://'):
            if label.lower().startswith(prefix):
                label = label[len(prefix):]
                break
        label = label[:80]
    entries.insert(0, {
        'input': raw_input,
        'label': label,
        'type': scan_type,
        'date': time.strftime('%d/%m/%Y %H:%M'),
        'timestamp': int(time.time()),
    })
    _save_json(_scan_history_path(), entries[:MAX_SCAN_HISTORY])


def _remove_from_scan_history(raw_input):
    entries = _load_json(_scan_history_path())
    _save_json(_scan_history_path(), [e for e in entries if e.get('input') != raw_input])


def _clear_scan_history():
    _save_json(_scan_history_path(), [])


def _get_setting_int(setting_id, default=0, max_val=None):
    """Lee un ajuste nativo de Kodi como entero con validacion.

    Los ajustes de tipo 'enum' en settings.xml devuelven el indice
    seleccionado como cadena (ej. "0", "2"). Esta funcion convierte
    a entero de forma segura, aplicando el valor por defecto si la
    cadena esta vacia, corrupta o fuera de rango.
    """
    try:
        val = int(xbmcaddon.Addon().getSetting(setting_id))
    except (ValueError, TypeError):
        return default
    if val < 0 or (max_val is not None and val > max_val):
        return default
    return val


def _load_json(path):
    with _json_lock:
        # Un .tmp aquí es huérfano de una escritura que no llegó a os.replace:
        # bajo el mismo lock no hay ninguna en curso, así que es seguro borrarlo.
        tmp = path + ".tmp"
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []


def _save_json(path, data):
    # Escritura atómica: tmp en el mismo directorio + os.replace (rename atómico
    # en el mismo volumen, garantizado en Windows). fsync best-effort para
    # durabilidad ante corte de luz; si el FS no lo soporta, igual se hace replace.
    # Un fallo a mitad deja intacto el JSON previo en vez de truncarlo.
    with _json_lock:
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass
            os.replace(tmp, path)
        except OSError as exc:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass
            xbmc.log("[StreamNinja] Error guardando {0}: {1}".format(path, exc),
                     xbmc.LOGWARNING)


def _load_list(path):
    """_load_json pero garantizando una lista. Historial y marcadores siempre
    son listas; un fichero manipulado a objeto JSON no debe reventar el bucle
    de los consumidores (mismo criterio que _load_history en url_remote)."""
    data = _load_json(path)
    return data if isinstance(data, list) else []


def parse_url_with_headers(raw_url):
    """Separa URL y headers en formato pipe.

    Entrada: "http://example.com/video.m3u8|User-Agent=xxx&Referer=yyy"
    Salida:  ("http://example.com/video.m3u8", {"User-Agent": "xxx", ...})
    """
    if not raw_url:
        return "", {}
    raw_url = raw_url.strip()
    if "|" not in raw_url:
        return raw_url, {}

    parts = raw_url.split("|", 1)
    url = parts[0].strip()
    headers_str = parts[1].strip()
    if not headers_str:
        return url, {}

    headers = {}
    for pair in headers_str.split("&"):
        if "=" in pair:
            key, value = pair.split("=", 1)
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] in ('"', "'") and value[-1] == value[0]:
                value = value[1:-1]
            if key:
                headers[key] = urllib.parse.unquote(value)
    return url, headers


def is_direct_stream(url):
    """Determina si la URL apunta a un stream reproducible directamente."""
    try:
        parsed = urllib.parse.urlparse(url)
        _, ext = os.path.splitext(parsed.path.lower())
        return ext in _STREAM_EXTENSIONS
    except Exception:
        return False


def build_kodi_url(url, headers=None):
    """Reconstruye URL con headers en formato pipe de Kodi."""
    if not headers:
        return url
    parts = ["{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in headers.items()]
    return url + "|" + "&".join(parts)


def detect_dailymotion_id(url):
    """Extrae el ID de un vídeo de Dailymotion o devuelve None."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]

        if host.endswith("dailymotion.com"):
            match = re.match(r"/video/([a-zA-Z0-9]+)", parsed.path)
            if match:
                return match.group(1)
            match = re.match(r"/embed/video/([a-zA-Z0-9]+)", parsed.path)
            if match:
                return match.group(1)
        elif host == "dai.ly":
            vid = parsed.path.strip("/")
            if vid:
                return vid.split("_")[0].split("?")[0]
    except Exception:
        pass
    return None


def detect_youtube_id(url):
    """Extrae el ID de un vídeo de YouTube o devuelve None."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]

        if host in ("youtube.com", "m.youtube.com"):
            if "/watch" in parsed.path:
                params = urllib.parse.parse_qs(parsed.query)
                vid_list = params.get("v", [])
                if vid_list:
                    return vid_list[0]
            elif "/shorts/" in parsed.path:
                match = re.match(r"/shorts/([a-zA-Z0-9_-]+)", parsed.path)
                if match:
                    return match.group(1)
            elif "/live/" in parsed.path:
                match = re.match(r"/live/([a-zA-Z0-9_-]+)", parsed.path)
                if match:
                    return match.group(1)
        elif host == "youtu.be":
            vid = parsed.path.strip("/")
            if vid:
                return vid
    except Exception:
        pass
    return None


def detect_url_type(raw_url):
    """Clasifica una URL y devuelve (tipo, id_o_url).
    Tipos: 'dailymotion', 'youtube', 'rtve', 'atresplayer', 'torrent',
           'acestream', 'direct_stream', 'web_page'
    """
    url, _ = parse_url_with_headers(raw_url)

    if url.startswith("plugin://"):
        try:
            parsed = urllib.parse.urlparse(url)
            params = urllib.parse.parse_qs(parsed.query)
            if "url" in params:
                extracted = params["url"][0]
                # Resolución de IDs en crudo para catálogos y reproductores integrados
                if "action" in params and params["action"][0] in ["play_video", "play_dm", "dm_gujal_search", "play_media"]:
                    if not extracted.startswith("http") and not "://" in extracted:
                        if len(extracted) == 24 and all(c in "0123456789abcdefABCDEF" for c in extracted):
                            extracted = "https://www.atresplayer.com/video/" + extracted
                        else:
                            extracted = "https://www.dailymotion.com/video/" + extracted
                
                if extracted.startswith("http") or "://" in extracted:
                    url, _ = parse_url_with_headers(extracted)
                else:
                    return "internal_query", extracted
        except Exception:
            pass

    # Magnet links y ficheros .torrent
    if url.startswith("magnet:"):
        return "torrent", url
    try:
        parsed_path = urllib.parse.urlparse(url).path.lower()
        if parsed_path.endswith(".torrent"):
            return "torrent", url
    except Exception:
        pass

    # AceStream. Acepta el esquema acestream:// (con cola ?params opcional) y el
    # content ID desnudo (40 hex). Devolvemos siempre la forma canónica
    # acestream://<hex minúscula>: el reproductor hace replace("acestream://")
    # case-sensitive y necesita el id sin esquema en mayúsculas ni cola de query.
    ace_match = _ACESTREAM_RE.fullmatch(url)
    if ace_match:
        return "acestream", "acestream://" + ace_match.group(1).lower()
    if _ACE_HASH_RE.fullmatch(url):
        return "acestream", "acestream://" + url.lower()

    dm_id = detect_dailymotion_id(url)
    if dm_id:
        return "dailymotion", dm_id

    yt_id = detect_youtube_id(url)
    if yt_id:
        return "youtube", yt_id

    # RTVE Play
    rtve_match = re.match(
        r"https?://(?:www\.)?rtve\.es/(?:play/videos/.+/|v/)(\d+)/?", url)
    if not rtve_match:
        rtve_match = re.match(r"https?://ztnr\.rtve\.es/ztnr/(\d+)\.mpd", url)
    if rtve_match:
        return "rtve", rtve_match.group(1)

    # Atresplayer
    if re.match(r"https?://(?:www\.)?atresplayer\.com/.+", url):
        return "atresplayer", url

    # Mediaset (Telecinco, Cuatro, Mitele, Mediaset Infinity)
    if re.match(r"https?://(?:www\.)?(?:mitele\.es|mediasetinfinity\.es|telecinco\.es|cuatro\.com)/.+", url):
        return "mediaset", url

    # Enlaces internos de Kodi
    if url.startswith("plugin://"):
        return "kodi_plugin", url

    if is_direct_stream(url):
        return "direct_stream", raw_url

    return "web_page", url

_YT_RE = re.compile(
    r"(?:youtube\.com/watch\?.*?v=|youtu\.be/|youtube\.com/shorts/)"
    r"([A-Za-z0-9_-]{11})"
)
_DM_RE = re.compile(
    r"(?:dailymotion\.com/video/|dai\.ly/)([A-Za-z0-9]+)"
)
_VIMEO_RE = re.compile(r"vimeo\.com/(\d+)")
_RTVE_RE = re.compile(
    r"rtve\.es/(?:play/videos/.+/|v/)(\d+)"
)
_RTVE_MPD_RE = re.compile(r"ztnr\.rtve\.es/ztnr/(\d+)\.mpd")
_ATRES_RE = re.compile(
    r"atresplayer\.com/.+?(?:_([a-fA-F0-9]{20,30})/?|/episode/([a-fA-F0-9]{20,30}))"
)
_OG_RE = re.compile(
    r'<meta[^>]+(?:property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']'
    r'|content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\'])',
    re.IGNORECASE,
)
_LEGACY_BIN_RE = re.compile(r"^cnViZW5zZGZhMWxhYmVybnQ=://[a-f0-9]+$")  # Watermark
_THUMB_TIMEOUT = 3

# --- Twitch/Vimeo -> plugin:// del addon nativo (solo si está instalado) ---
_TW_VOD_RE = re.compile(
    r"(?:https?://)?(?:www\.|m\.)?twitch\.tv/videos/(\d+)", re.I)
_TW_CLIP_DOMAIN_RE = re.compile(
    r"(?:https?://)?clips\.twitch\.tv/([A-Za-z0-9_-]+)", re.I)
_TW_CLIP_PATH_RE = re.compile(
    r"(?:https?://)?(?:www\.|m\.)?twitch\.tv/[^/]+/clip/([A-Za-z0-9_-]+)", re.I)
_TW_LIVE_RE = re.compile(
    r"(?:https?://)?(?:www\.|m\.)?twitch\.tv/([a-zA-Z0-9_]{3,25})/?(?:\?[^/]*)?$", re.I)
# Prefijos de twitch.tv que no son canales; tratarlos como canal daría plugin:// inválido.
_TW_RESERVED = frozenset({
    "videos", "directory", "p", "search", "settings", "subscriptions",
    "wallet", "jobs", "turbo", "prime", "login", "signup", "logout",
    "downloads", "creatorcamp", "broadcast",
})
_VIMEO_PLAYER_RE = re.compile(
    r"(?:https?://)?player\.vimeo\.com/video/(\d+)(?:[?/]h(?:ash)?=([A-Za-z0-9]+))?", re.I)
_VIMEO_PAGE_RE = re.compile(
    r"(?:https?://)?(?:www\.)?vimeo\.com/(\d+)(?:/([A-Za-z0-9]+))?", re.I)


def _resolve_known_plugin(url):
    """plugin:// del addon nativo de Twitch/Vimeo si está instalado y la URL encaja;
    si no, None. No cambia el comportamiento actual: solo añade una ruta directa
    (mejor calidad/auth, y funciona en Android sin yt-dlp) cuando el addon existe.
    Esquemas tomados de plugin.video.twitch / plugin.video.vimeo."""
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.twitch)"):
        m = _TW_VOD_RE.search(url)
        if m:
            return "plugin://plugin.video.twitch/?mode=play&video_id=" + m.group(1)
        m = _TW_CLIP_DOMAIN_RE.search(url) or _TW_CLIP_PATH_RE.search(url)
        if m:
            return "plugin://plugin.video.twitch/?mode=play&slug=" + m.group(1)
        m = _TW_LIVE_RE.search(url)
        if m and m.group(1).lower() not in _TW_RESERVED:
            return "plugin://plugin.video.twitch/?mode=play&channel_name=" + m.group(1)
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.vimeo)"):
        for rgx in (_VIMEO_PLAYER_RE, _VIMEO_PAGE_RE):
            m = rgx.search(url)
            if m:
                suffix = (":" + m.group(2)) if m.group(2) else ""
                return ("plugin://plugin.video.vimeo/play/?video_id="
                        + m.group(1) + suffix)
    return None


def _auto_thumb(url):
    """Devuelve la URL de miniatura para la URL dada, o cadena vacia.

    Soporta YouTube, Dailymotion y RTVE (sin HTTP), Vimeo (oEmbed)
    y webs genericas (og:image). En caso de error devuelve cadena vacia.
    """
    if not url:
        return ""
    # YouTube (sin peticion HTTP)
    m = _YT_RE.search(url)
    if m:
        return "https://img.youtube.com/vi/{0}/hqdefault.jpg".format(m.group(1))
    # Dailymotion (sin peticion HTTP)
    m = _DM_RE.search(url)
    if m:
        return "https://www.dailymotion.com/thumbnail/video/{0}".format(m.group(1))
    # RTVE; CDN de thumbnails publico (sin peticion extra)
    m = _RTVE_RE.search(url)
    if not m:
        m = _RTVE_MPD_RE.search(url)
    if m:
        return "https://img2.rtve.es/v/{0}/?w=480".format(m.group(1))
    # Vimeo; oEmbed API (sin autenticacion)
    m = _VIMEO_RE.search(url)
    if m:
        return _vimeo_thumb(url)
    # Atresplayer y webs genericas; intentar og:image
    if url.startswith("http"):
        return _og_thumb(url)
    return ""


def _vimeo_thumb(url):
    """Obtiene miniatura de Vimeo via oEmbed."""
    try:
        import requests
        r = requests.get(
            "https://vimeo.com/api/oembed.json",
            params={"url": url, "width": 480},
            timeout=_THUMB_TIMEOUT,
        )
        if r.status_code == 200:
            return r.json().get("thumbnail_url", "")
    except Exception:
        pass
    return ""


def _og_thumb(url):
    """Extrae la meta tag og:image del HTML de una pagina web."""
    try:
        import requests
        r = requests.get(
            url,
            timeout=_THUMB_TIMEOUT,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
            stream=True,
        )
        try:
            if r.status_code == 200:
                chunk = ""
                for c in r.iter_content(chunk_size=8192, decode_unicode=True):
                    if isinstance(c, bytes):
                        c = c.decode("utf-8", errors="ignore")
                    chunk += c
                    if len(chunk) > 32768:
                        break
                
                m = _OG_RE.search(chunk)
                if m:
                    return m.group(1) or m.group(2) or ""
        finally:
            r.close()
    except Exception:
        pass
    return ""


def _auto_label(url):
    """Genera un titulo legible para la URL dada.

    YouTube/DM/Vimeo: titulo real via oEmbed (sin autenticacion).
    RTVE: titulo real via API publica.
    Atresplayer: path limpio sin hashes.
    Otras URLs: nombre derivado del path.
    """
    if not url:
        return ""
    try:
        import requests
        # YouTube
        m = _YT_RE.search(url)
        if m:
            r = requests.get(
                "https://www.youtube.com/oembed",
                params={"url": url, "format": "json"},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # Dailymotion
        m = _DM_RE.search(url)
        if m:
            r = requests.get(
                "https://www.dailymotion.com/services/oembed",
                params={"url": url, "format": "json"},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # Vimeo
        m = _VIMEO_RE.search(url)
        if m:
            r = requests.get(
                "https://vimeo.com/api/oembed.json",
                params={"url": url},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # RTVE; API publica de metadatos
        m = _RTVE_RE.search(url)
        if not m:
            m = _RTVE_MPD_RE.search(url)
        if m:
            rtve_id = m.group(1)
            try:
                r = requests.get(
                    "https://www.rtve.es/api/videos/{0}.json".format(rtve_id),
                    timeout=3,
                    headers={"User-Agent": "Mozilla/5.0"},
                )
                if r.status_code == 200:
                    data = r.json()
                    page = data.get("page", {})
                    items = page.get("items", [])
                    if items:
                        title = items[0].get("longTitle") or items[0].get("title", "")
                        if title:
                            return title
            except Exception:
                pass
            return "RTVE {0}".format(rtve_id)
    except Exception:
        pass
    # Fallback: limpiar path de la URL
    try:
        parsed = urllib.parse.urlparse(url)
        path = parsed.path.rstrip("/").rsplit("/", 1)[-1]
        if "." in path:
            path = path.rsplit(".", 1)[0]
        name = path.replace("-", " ").replace("_", " ")
        # Limpiar hashes hexadecimales de Atresplayer (20-30 chars)
        name = re.sub(r"\s+[a-fA-F0-9]{20,30}$", "", name)
        return name.strip()[:80] if name.strip() else ""
    except Exception:
        return ""


def _add_to_history(raw_url, label=None, thumb=None):
    """Inserta la entrada al instante; la miniatura/título que falten se
    obtienen por red en un hilo de fondo (la UI nunca se bloquea)."""
    need_thumb = not thumb
    need_label = not label or label == raw_url
    with _store_lock:
        history = _load_list(_history_path())
        # Reutilizar thumb/label de una entrada previa evita volver a la red.
        for h in history:
            if h.get("url") == raw_url:
                if need_thumb and h.get("thumb"):
                    thumb, need_thumb = h["thumb"], False
                if need_label and h.get("label") and h["label"] != raw_url:
                    label, need_label = h["label"], False
                break
        history = [h for h in history if h.get("url") != raw_url]
        entry = {
            "url": raw_url,
            "label": label or raw_url,
            "date": time.strftime("%d/%m/%Y %H:%M"),
            "timestamp": int(time.time()),
        }
        if thumb:
            entry["thumb"] = thumb
        history.insert(0, entry)
        _save_json(_history_path(), history[:MAX_HISTORY])
    if need_thumb or need_label:
        threading.Thread(
            target=_enrich_history_entry,
            args=(raw_url, need_thumb, need_label),
            daemon=True,
        ).start()


def _enrich_history_entry(url, need_thumb=True, need_label=True):
    """Completa thumb/label por red y los aplica a la entrada si sigue ahí.
    No toca disco si no obtiene nada. Idempotente."""
    try:
        thumb = _auto_thumb(url) if need_thumb else ""
        label = ""
        if need_label:
            fetched = _auto_label(url)
            if fetched and fetched != url:
                label = fetched
        if not thumb and not label:
            return
        with _store_lock:
            history = _load_list(_history_path())
            changed = False
            for h in history:
                if h.get("url") == url:
                    if thumb and not h.get("thumb"):
                        h["thumb"] = thumb
                        changed = True
                    if label and (not h.get("label") or h["label"] == url):
                        h["label"] = label
                        changed = True
                    break
            if changed:
                _save_json(_history_path(), history)
    except Exception as exc:
        # Hilo daemon: un fallo no debe morir mudo (sec. logging).
        xbmc.log("[StreamNinja] enrich history: {0}".format(exc), xbmc.LOGWARNING)


def _get_history():
    return _load_list(_history_path())


def _clear_history():
    with _store_lock:
        _save_json(_history_path(), [])


def _remove_from_history(url):
    with _store_lock:
        history = _load_list(_history_path())
        _save_json(_history_path(), [h for h in history if h.get("url") != url])


def _get_bookmarks():
    return _load_list(_bookmarks_path())


def _add_bookmark(name, url):
    """Guarda el marcador al instante; la miniatura se obtiene en segundo
    plano para no congelar la UI con una petición HTTP síncrona."""
    with _store_lock:
        bookmarks = _load_list(_bookmarks_path())
        if any(b.get("url") == url for b in bookmarks):
            return False
        bookmarks.append({
            "name": name,
            "url": url,
            "date": time.strftime("%d/%m/%Y %H:%M"),
        })
        # Al llegar al tope conservamos los MÁS NUEVOS; recortar por el principio
        # descartaría justo el que el usuario acaba de guardar (devolvíamos True
        # sin haberlo guardado).
        _save_json(_bookmarks_path(), bookmarks[-MAX_BOOKMARKS:])
    threading.Thread(
        target=_enrich_bookmark_thumb, args=(url,), daemon=True,
    ).start()
    return True


def _enrich_bookmark_thumb(url):
    """Obtiene la miniatura por red y la fija si el marcador sigue sin ella.
    No toca disco si _auto_thumb no devuelve nada."""
    try:
        thumb = _auto_thumb(url)
        if not thumb:
            return
        with _store_lock:
            bookmarks = _load_list(_bookmarks_path())
            changed = False
            for b in bookmarks:
                if b.get("url") == url and not b.get("thumb"):
                    b["thumb"] = thumb
                    changed = True
                    break
            if changed:
                _save_json(_bookmarks_path(), bookmarks)
    except Exception as exc:
        # Hilo daemon: un fallo no debe morir mudo (sec. logging).
        xbmc.log("[StreamNinja] enrich bookmark: {0}".format(exc), xbmc.LOGWARNING)


def _remove_bookmark(url):
    with _store_lock:
        bookmarks = _load_list(_bookmarks_path())
        new_bookmarks = [b for b in bookmarks if b.get("url") != url]
        _save_json(_bookmarks_path(), new_bookmarks)
    return len(bookmarks) != len(new_bookmarks)


def _rename_bookmark(url, new_name):
    with _store_lock:
        bookmarks = _load_list(_bookmarks_path())
        changed = False
        for b in bookmarks:
            if b.get("url") == url:
                b["name"] = new_name
                changed = True
                break
        if changed:
            _save_json(_bookmarks_path(), bookmarks)
    return changed


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _get_handle():
    """Obtiene el handle del plugin de forma segura."""
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def open_login_dialog():
    """Lanzador cifrado para la gestion de contraseñas de las plataformas."""
    import remote_loader
    remote_loader.load_all_masters()
    
    for i in range(5, 0, -1):
        mod_name = 'remote_login_' + str(i)
        if mod_name in sys.modules and hasattr(sys.modules[mod_name], 'open_login_dialog'):
            sys.modules[mod_name].open_login_dialog()
            return
            



def open_url_dialog():
    """Menú principal de Abrir URL."""
    h = _get_handle()

    li = xbmcgui.ListItem(
        label="[COLOR white][B]Pegar enlace de vídeo[/B][/COLOR]"
    )
    li.setArt({"icon": os.path.join(_MEDIA, "url_clipboard.png")})
    li.setInfo("video", {
        "plot": (
            "Pega el enlace de un vídeo para reproducirlo.\n\n"
            "URLs soportadas:\n"
            "  • Dailymotion: dailymotion.com/video/xxx\n"
            "  • YouTube: youtube.com/watch?v=xxx\n"
            "  • Torrent / Magnet: .torrent, magnet:?\n"
            "  • AceStream: acestream:// o ID de contenido (hash)\n"
            "  • Stream directo: .m3u8, .m3u, .mp4, .mkv, .mpd, .avi, .ts, .flv, .mov, .wmv, .webm\n"
            "  • Con headers: URL|User-Agent=xxx&Referer=yyy\n"
            "  • Otras webs: resolución automática"
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_input"), listitem=li, isFolder=False
    )

    # Pegar URL del sistema; solo si el portapapeles del SO trae algo reproducible.
    # Primera línea no vacía (no split() por espacios; rompería un magnet con dn=).
    sys_clip = next(
        (ln.strip() for ln in _get_system_clipboard_text().splitlines() if ln.strip()),
        "",
    )
    if _looks_like_playable_url(sys_clip):
        clip_display = sys_clip[:70] + "..." if len(sys_clip) > 70 else sys_clip
        li = xbmcgui.ListItem(
            label="[COLOR white][B]Pegar enlace del sistema[/B][/COLOR]"
        )
        li.setArt({"icon": os.path.join(_MEDIA, "url_paste.png")})
        li.setInfo("video", {
            "plot": (
                "Enlace detectado en el portapapeles del sistema:\n{0}\n\n"
                "Pulsa para reproducirlo directamente sin escribir."
            ).format(clip_display),
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_play", url=sys_clip),
            listitem=li, isFolder=False,
        )

    try:
        win = xbmcgui.Window(10000)
        clipboard_url = win.getProperty("streamninja.clipboard.url").strip()
    except Exception:
        clipboard_url = ""
    if clipboard_url:
        url_display = clipboard_url[:70] + "..." if len(clipboard_url) > 70 else clipboard_url
        li = xbmcgui.ListItem(
            label="[COLOR white][B]Reproducir enlace copiado[/B][/COLOR]"
        )
        li.setArt({"icon": os.path.join(_MEDIA, "url_paste.png")})
        li.setInfo("video", {
            "plot": (
                "Enlace en memoria:\n{0}\n\n"
                "Pulsa para reproducirlo directamente "
                "sin necesidad de escribir."
            ).format(url_display),
        })
        li.addContextMenuItems([
            ("Borrar de memoria (quitar botón)", "RunPlugin({0})".format(_u(action="url_clipboard_clear")))
        ])
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_play_clipboard"),
            listitem=li, isFolder=False
        )

    li = xbmcgui.ListItem(
        label="[COLOR white][B]Enviar desde móvil o PC[/B][/COLOR]"
    )
    li.setArt({"icon": os.path.join(_MEDIA, "url_remote.png")})
    li.setInfo("video", {
        "plot": (
            "Abre un servidor temporal en la red local.\n\n"
            "Desde el navegador de tu móvil o PC, "
            "podrás enviar enlaces sin necesidad de escribirlos "
            "con el mando.\n\n"
            "Ideal para dispositivos sin teclado."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_remote"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(
        label="[COLOR white][B]Escanear web o Telegram[/B][/COLOR]"
    )
    li.setArt({"icon": os.path.join(_MEDIA, "url_scan.png")})
    li.setInfo("video", {
        "plot": (
            "Pega la dirección de cualquier web o canal público de Telegram "
            "(@canal, t.me/canal) y el addon detectará todos los vídeos "
            "disponibles.\n\n"
            "Muestra título, duración y tamaño de cada uno.\n\n"
            "En PC usa yt-dlp (más completo).\n"
            "En Android usa análisis HTML."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_scan"), listitem=li, isFolder=False
    )

    # Mi nube Debrid (solo si hay proveedor vinculado y activado)
    if _debrid_active():
        provider = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
        li = xbmcgui.ListItem(label="[COLOR white][B]Mi nube {0}[/B][/COLOR]".format(provider))
        li.setArt({"icon": os.path.join(_MEDIA, "url_cloud.png")})
        li.setInfo("video", {
            "plot": (
                "Vídeos que tienes en tu cuenta {0}.\n\n"
                "Reproduce o borra el contenido de tu nube."
            ).format(provider),
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="debrid_library"), listitem=li, isFolder=True
        )

    history = _get_history()
    if history:
        li = xbmcgui.ListItem(
            label="[COLOR white][B]Historial de vídeos ({0})[/B][/COLOR]".format(len(history))
        )
        li.setArt({"icon": os.path.join(_MEDIA, "url_history.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_history"), listitem=li, isFolder=True
        )

    scan_history = _get_scan_history()
    if scan_history:
        li = xbmcgui.ListItem(
            label="[COLOR white][B]Historial de escaneos ({0})[/B][/COLOR]".format(
                len(scan_history)
            )
        )
        li.setArt({"icon": os.path.join(_MEDIA, "scan_history.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="scan_history"), listitem=li, isFolder=True
        )

    bookmarks = _get_bookmarks()
    if bookmarks:
        li = xbmcgui.ListItem(
            label="[COLOR white][B]Favoritos ({0})[/B][/COLOR]".format(len(bookmarks))
        )
        li.setArt({"icon": os.path.join(_MEDIA, "url_bookmarks.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_bookmarks"), listitem=li, isFolder=True
        )

    li = xbmcgui.ListItem(
        label="[COLOR white][B]Grabar stream en directo[/B][/COLOR]"
    )
    li.setArt({"icon": os.path.join(_MEDIA, "mis_grabaciones.png")})
    li.setInfo("video", {
        "plot": (
            "Graba a disco un stream HLS en directo (.m3u8): TV, eventos, etc.\n\n"
            "Con FFmpeg disponible puede comprimir a MP4; si no, guarda en TS.\n"
            "La carpeta de destino se pide la primera vez."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="pvr_record"), listitem=li, isFolder=False
    )

    rec_active = xbmcgui.Window(10000).getProperty("streamninja_active_recordings")
    if rec_active:
        li = xbmcgui.ListItem(
            label="[COLOR white][B]Detener grabaciones en curso[/B][/COLOR]"
        )
        li.setArt({"icon": os.path.join(_MEDIA, "mis_grabaciones.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="pvr_record_stop"), listitem=li, isFolder=False
        )

    # Mis Descargas
    li = xbmcgui.ListItem(
        label="[COLOR white][B]Mis Descargas[/B][/COLOR]"
    )
    li.setArt({"icon": os.path.join(_MEDIA, "descargas.png")})
    li.setInfo("video", {
        "plot": (
            "Gestiona tus videos descargados localmente.\n"
            "Reproduce sin conexion o elimina archivos.\n\n"
            "Aviso Legal:\n"
            "La funcionalidad de descarga se proporciona como\n"
            "una herramienta técnica neutral.\n"
            "Todo contenido descargado es de su entera y\n"
            "exclusiva responsabilidad legal.\n"
            "StreamNinja no permite descargar vídeos con DRM."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="show_downloads"),
        listitem=li, isFolder=True,
    )

    li = xbmcgui.ListItem(label="[COLOR white][B]Ajustes[/B][/COLOR]")
    li.setArt({"icon": os.path.join(_MEDIA, "opciones.png")})
    li.setInfo("video", {
        "plot": (
            "Accede a la configuración general del addon y utilidades adicionales "
            "(Debrid, Login, Mantenimiento, Accesibilidad, etc)."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="open_settings"), listitem=li, isFolder=True
    )

    li = xbmcgui.ListItem(label="[COLOR white][B]Información[/B][/COLOR]")
    li.setArt({"icon": os.path.join(_MEDIA, "info.png")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="info_menu"), listitem=li, isFolder=True)

    # cacheToDisc=False: el menú depende de estado mutable (negrita, historial,
    # portapapeles, grabaciones); debe re-renderizarse siempre, también al volver atrás.
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


_resolveurl_mod = None
_resolveurl_tried = False


def _get_resolveurl():
    """Devuelve el módulo resolveurl si está instalado (Kodi lo pone en sys.path
    al declararlo en addon.xml), o None. Cachea el resultado; no reintenta tras un
    fallo. El import es pesado (carga cientos de plugins), por eso se hace una vez."""
    global _resolveurl_mod, _resolveurl_tried
    if _resolveurl_tried:
        return _resolveurl_mod
    _resolveurl_tried = True
    if not xbmc.getCondVisibility("System.HasAddon(script.module.resolveurl)"):
        return None
    try:
        import resolveurl
        _resolveurl_mod = resolveurl
    except Exception as e:
        xbmc.log("[StreamNinja] No se pudo cargar ResolveURL: {0}".format(e), xbmc.LOGWARNING)
    return _resolveurl_mod


def _resolveurl_resolve(url):
    """Resuelve url con ResolveURL si reconoce el dominio. None si no es soportado,
    falla, o delega en otro addon. valid_url() es regex local (sin red)."""
    mod = _get_resolveurl()
    if not mod:
        return None
    try:
        hmf = mod.HostedMediaFile(url)
        if not hmf.valid_url():
            return None
        xbmcgui.Dialog().notification(
            "StreamNinja", "Resolviendo con ResolveURL...",
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        stream = hmf.resolve()
    except Exception as e:
        xbmc.log("[StreamNinja] ResolveURL error: {0}".format(e), xbmc.LOGWARNING)
        return None
    if not (isinstance(stream, str) and stream):
        return None
    # Algunos resolvers (youtube, vimeo...) devuelven plugin://otro.addon; esa
    # delegación la maneja mejor el yt-dlp propio, así que caemos al siguiente método.
    if stream.startswith("plugin://"):
        return None
    return stream


def _scrape_hosters(html):
    """Detecta en el HTML enlaces a hosters soportados por ResolveURL y los devuelve
    en el formato del escáner. [] si ResolveURL no está o no hay HTML."""
    mod = _get_resolveurl()
    if not mod or not html:
        return []
    try:
        # El regex propio de ResolveURL solo mira href=; los hosters embebidos van
        # casi siempre en <iframe src=...>. Capturamos href y src (valid_url filtra).
        links = mod.scrape_supported(html, regex=r'''(?:href|src)\s*=\s*['"]([^'"]+)''')
    except Exception as e:
        xbmc.log("[StreamNinja] scrape_supported error: {0}".format(e), xbmc.LOGWARNING)
        return []
    out = []
    for link in links:
        host = urllib.parse.urlparse(link).hostname or "enlace"
        out.append({"title": "Hoster: {0}".format(host), "url": link, "filesize": None, "ext": ""})
    return out


# --- DEBRID (RESOLVER DE NUBE: AllDebrid / Real-Debrid / TorBox / Premiumize) ---

def _debrid_cache_path():
    return os.path.join(_get_profile(), "debrid_resolve_cache.json")


def _debrid_cache_key(provider, url):
    return hashlib.sha1("{0}|{1}".format(provider, url).encode("utf-8")).hexdigest()


def _debrid_cache_get(provider, url):
    data = _load_json(_debrid_cache_path())
    if not isinstance(data, dict):
        return None
    entry = data.get(_debrid_cache_key(provider, url))
    if entry and (time.time() - entry.get("ts", 0)) < _DEBRID_CACHE_TTL:
        return entry.get("stream")
    return None


def _debrid_cache_put(provider, url, stream):
    data = _load_json(_debrid_cache_path())
    if not isinstance(data, dict):
        data = {}
    data[_debrid_cache_key(provider, url)] = {"stream": stream, "ts": int(time.time())}
    if len(data) > _DEBRID_CACHE_MAX:
        recientes = sorted(
            data.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True
        )[:_DEBRID_CACHE_MAX]
        data = dict(recientes)
    _save_json(_debrid_cache_path(), data)


def _scan_cache_path():
    return os.path.join(_get_profile(), "scan_results_cache.json")


def _scan_cache_get(url):
    data = _load_json(_scan_cache_path())
    if not isinstance(data, dict):
        return None
    key = hashlib.sha1(url.encode("utf-8")).hexdigest()
    entry = data.get(key)
    if entry and (time.time() - entry.get("ts", 0)) < _SCAN_CACHE_TTL:
        return entry.get("videos")
    return None


def _scan_cache_put(url, videos):
    data = _load_json(_scan_cache_path())
    if not isinstance(data, dict):
        data = {}
    key = hashlib.sha1(url.encode("utf-8")).hexdigest()
    data[key] = {"videos": videos, "ts": int(time.time())}
    if len(data) > _SCAN_CACHE_MAX:
        data = dict(
            sorted(data.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)
            [:_SCAN_CACHE_MAX]
        )
    _save_json(_scan_cache_path(), data)


_DEBRID_PREFIX = {
    "AllDebrid": "alldebrid", "Real-Debrid": "realdebrid",
    "TorBox": "torbox", "Premiumize": "premiumize",
}


def _debrid_active():
    """True si hay un proveedor Debrid activado y con cuenta vinculada. Lee los
    ajustes directamente (misma lógica que debrid_resolver.is_authorized: token +
    <prefix>_authorized) para NO importar el módulo de 1285 líneas en cada render
    del menú; el import real se hace en _get_debrid() solo cuando se usa."""
    try:
        addon = xbmcaddon.Addon()
        if addon.getSetting("debrid_enabled") != "true":
            return False
        prefix = _DEBRID_PREFIX.get(
            addon.getSetting("debrid_provider") or "AllDebrid", "alldebrid")
        return (bool(addon.getSetting(prefix + "_token"))
                and addon.getSetting(prefix + "_authorized") == "true")
    except Exception:
        return False


def _get_debrid():
    """Instancia del resolver Debrid. Import defensivo: si fallara, el addon
    sigue funcionando como si Debrid no existiera."""
    try:
        import debrid_resolver
        return debrid_resolver.get_resolver()
    except Exception as e:
        xbmc.log("[StreamNinja] Debrid no disponible: {0}".format(e), xbmc.LOGWARNING)
        return None


def _play_resolved_stream(stream_url, headers=None, protocol="", strip_generic_headers=True):
    """Reproduce una URL resuelta, configurando inputstream y headers.

    Args:
        stream_url: URL directa del stream.
        headers:    Dict de cabeceras HTTP de yt-dlp (opcional).
        protocol:   Protocolo reportado por yt-dlp (opcional).
        strip_generic_headers: si es True (resolutores automáticos) descarta
            los headers genéricos de navegador; si es False (enlace directo
            escrito por el usuario) los conserva tal cual, para no romper un
            User-Agent manual que el CDN exige (evita el 403).
    """
    li = xbmcgui.ListItem(path=stream_url)

    # Extraer solo el path real (ignorar query ?...)
    clean_path = urllib.parse.urlparse(stream_url).path.lower()

    meaningful_headers = {}
    if headers:
        if strip_generic_headers:
            meaningful_headers = {
                k: v for k, v in headers.items()
                if k.lower() not in _GENERIC_HEADERS
            }
        else:
            meaningful_headers = dict(headers)

    # Codificar headers para setProperty (formato key=value&key2=value2)
    header_str = ""
    if meaningful_headers:
        header_str = "&".join(
            "{0}={1}".format(k, urllib.parse.quote(str(v), safe=""))
            for k, v in meaningful_headers.items()
        )

    is_mpd = clean_path.endswith(".mpd") or "mpd" in protocol
    is_m3u8 = clean_path.endswith(".m3u8") or "m3u8" in protocol

    if is_mpd:
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setMimeType("application/dash+xml")
        if header_str:
            li.setProperty("inputstream.adaptive.manifest_headers", header_str)
            li.setProperty("inputstream.adaptive.stream_headers", header_str)
    elif is_m3u8:
        li.setMimeType("application/x-mpegURL")
        # ISA reproduce HLS mejor que el demuxer interno (selección de pistas y
        # bitrate adaptativo). Lo forzamos si hay headers que inyectar o si el
        # addon está instalado, aunque el enlace sea público y sin cabeceras.
        if header_str or xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
            li.setProperty("inputstream", "inputstream.adaptive")
            if header_str:
                li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                li.setProperty("inputstream.adaptive.stream_headers", header_str)
    elif header_str:
        # Para mp4/otros formatos directos, usar pipe (aun soportado)
        stream_url = "{0}|{1}".format(stream_url, header_str)
        li = xbmcgui.ListItem(path=stream_url)

    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    xbmc.Player().play(stream_url, li)
    

def play_acestream(content_id=None, ace_url=None, infohash=None, title="", icon="", plot=""):
    """Reproduce AceStream como hacía Horus: un content id, un infohash o una url
    (magnet/.torrent) van SIEMPRE al motor AceStream (no a Elementum). Precedencia
    id > infohash > url. Es el punto de entrada público equivalente al de Horus, para que
    cualquier addon pueda llamar a StreamNinja con el mismo patrón
    (plugin://plugin.video.streamninja/?action=acestream&id=...). Si el motor nativo no
    está disponible cae a Horus/motor local/diálogo: así coexiste con Horus."""
    addon = xbmcaddon.Addon()

    # Normalizar y validar (Horus valida [0-9a-f]{40}; no construimos peticiones al motor
    # con entrada sin sanear). content_id tolera venir como 'acestream://<hash>'.
    content_id = (content_id or "").strip()
    if content_id:
        m = _ACESTREAM_RE.fullmatch(content_id)
        content_id = (m.group(1) if m else content_id).lower()
        if not re.fullmatch(r"[0-9a-f]{40}", content_id):
            content_id = ""
    infohash = (infohash or "").strip().lower()
    if infohash and not re.fullmatch(r"[0-9a-f]{40}", infohash):
        infohash = ""
    ace_url = (ace_url or "").strip()

    # Un caller podría mandar el AceStream por url= en vez de id=: si la url es en realidad
    # un acestream://<hash>, trátalo como content id (si no, iría por error a la ruta torrent).
    if ace_url and not content_id:
        m = _ACESTREAM_RE.fullmatch(ace_url)
        if m:
            content_id = m.group(1).lower()
            ace_url = ""

    if not (content_id or infohash or ace_url):
        xbmcgui.Dialog().ok("StreamNinja", "Enlace AceStream no válido.")
        return

    # Reproductor externo en Android (solo aplica a content id, igual que Horus).
    if (content_id and xbmc.getCondVisibility("System.Platform.Android")
            and addon.getSetting("acestream_android_external") == "true"):
        intent = ('StartAndroidActivity("","org.acestream.action.start_content","",'
                  '"acestream:?content_id={0}")'.format(content_id))
        xbmc.log("[StreamNinja] AceStream app externa: {0}".format(intent), xbmc.LOGINFO)
        xbmc.executebuiltin(intent)
        return

    # Motor nativo local. NO instala ni arranca nada; requiere el motor escuchando.
    if addon.getSetting("acestream_enabled") != "false":
        try:
            import acestream_player
            if content_id:
                handled = acestream_player.play(content_id, title=title, icon=icon, plot=plot)
            else:
                # Precedencia infohash > url.
                torrent_value = ("magnet:?xt=urn:btih:" + infohash) if infohash else ace_url
                handled = acestream_player.play_torrent(torrent_value, title=title, icon=icon, plot=plot)
            if handled:
                return
        except Exception as e:
            xbmc.log("[StreamNinja/url_player] acestream nativo: {0}".format(e), xbmc.LOGWARNING)

    _acestream_fallback(content_id, infohash, ace_url, title)


def _acestream_fallback(content_id, infohash, ace_url, title=""):
    """Respaldo cuando el motor nativo no está disponible: Horus -> motor local
    directo -> diálogo. A Horus se le llama por su plugin:// (coexisten, sin colisión)."""
    if xbmc.getCondVisibility("System.HasAddon(script.module.horus)"):
        xbmcgui.Dialog().notification(
            "StreamNinja", "Abriendo AceStream con Horus...",
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        if content_id:
            q = {"action": "play", "id": content_id}
        elif infohash:
            q = {"action": "play", "infohash": infohash}
        else:
            q = {"action": "play", "url": ace_url}
        horus_url = "plugin://script.module.horus/?" + urllib.parse.urlencode(q)
        xbmc.executebuiltin('PlayMedia("{0}")'.format(horus_url))
        return

    addon = xbmcaddon.Addon()
    host = addon.getSetting("acestream_ip") or "127.0.0.1"
    port = addon.getSetting("acestream_port") or "6878"

    if (content_id or infohash) and _ace_engine_alive(host, port):
        # Sin Horus pero el motor local escucha; stream MPEG-TS directo.
        xbmcgui.Dialog().notification(
            "StreamNinja", "Abriendo AceStream con el motor local...",
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        selector = "id={0}".format(content_id) if content_id else "infohash={0}".format(infohash)
        target = "http://{0}:{1}/ace/getstream?{2}".format(host, port, selector)
        name = title or "AceStream"
        li = xbmcgui.ListItem(label=name, path=target)
        li.setContentLookup(False)
        li.setInfo("video", {"title": name})
        xbmc.Player().play(target, li)
        return

    xbmcgui.Dialog().ok(
        "StreamNinja",
        "Para reproducir enlaces AceStream necesitas el motor "
        "AceStream escuchando ({0}:{1}), o el addon Horus (script.module.horus).\n\n"
        "Arranca el motor AceStream o instala Horus.".format(host, port),
    )


def _resolve_and_play(raw_url):
    """Detecta tipo de URL y reproduce con el método adecuado."""
    url_type, value = detect_url_type(raw_url)

    # Resolver Debrid: solo intercepta magnets y páginas/hosters desconocidos.
    # Los tipos con resolver propio (dailymotion, youtube, rtve...) no pasan por aquí.
    if url_type in ("torrent", "web_page") and _debrid_active():
        provider = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
        stream = _debrid_cache_get(provider, value)
        if not stream:
            try:
                stream = _get_debrid().resolve(value)
            except Exception as e:
                xbmc.log("[StreamNinja/Debrid] {0}".format(e), xbmc.LOGWARNING)
                stream = None
            if stream:
                _debrid_cache_put(provider, value, stream)
        if stream:
            _play_resolved_stream(stream)
            return

    if url_type == "internal_query":
        xbmcgui.Dialog().ok(
            "StreamNinja \n(Enlace No Compatible)", 
            "El elemento seleccionado no es una URL de vídeo válida.\n\n"
            "Esto suele ocurrir si intentas abrir una carpeta o un resultado de búsqueda en lugar de un enlace web real."
        )
        return

    if url_type == "dailymotion":
        xbmcgui.Dialog().notification(
            "StreamNinja", "Dailymotion: " + value,
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        played = False
        is_win = xbmc.getCondVisibility("System.Platform.Windows")

        # Leer configuracion del usuario desde ajustes nativos de Kodi
        dm_level = _get_setting_int("dm_safe_level", default=0, max_val=3)

        # Orden en Windows (a petición del usuario): 1) script con el Python del sistema
        # (sin yt-dlp, esquiva el bloqueo), 2) yt-dlp como fallback, 3) resolutor interno
        # (dm_gujal/directo según dm_safe_level), 4) navegador.
        # Método 0: script del sistema, solo Windows. Devuelve HLS sin headers, así que
        # se reproduce con _play_resolved_stream igual que cualquier m3u8.
        if is_win:
            try:
                import dm_resolver
                _syspy = dm_resolver._dm_play_syspy(value)
                if _syspy and _syspy.get("url"):
                    _play_resolved_stream(_syspy["url"], protocol="m3u8")
                    played = True
            except Exception as e:
                xbmc.log("[StreamNinja/url_player] DM syspy: " + str(e), xbmc.LOGWARNING)

        # yt-dlp: primario en escritorio no-Windows con dm_level 0/3 (comportamiento
        # previo); en Windows actúa como fallback del script (de ahí el 'is_win').
        is_desktop = xbmc.getCondVisibility(
            "System.Platform.Windows | System.Platform.Linux | "
            "System.Platform.OSX"
        )
        use_ytdlp_first = is_win or (dm_level == 3) or (is_desktop and dm_level == 0)

        # Método 1: yt-dlp
        if not played and use_ytdlp_first and ytdlp_resolver.is_available():
            dm_url = "https://www.dailymotion.com/video/" + value
            info = ytdlp_resolver.resolve_full(dm_url)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                played = True

        # Método 2: resolver interno del addon
        if not played:
            try:
                import dm_resolver
                if is_win:
                    result = dm_resolver._dm_play(value, dm_level=dm_level, try_syspy=False)
                else:
                    result = dm_resolver._dm_play_android(
                        value, dm_level=dm_level)
                if result and result.get('url'):
                    stream_url = result['url']
                    
                    # Codificar headers para que Kodi los incluya en las peticiones al CDN
                    headers_dict = result.get('headers')
                    header_str = ""
                    if headers_dict:
                        header_str = "&".join(
                            "{0}={1}".format(k, urllib.parse.quote(str(v), safe=""))
                            for k, v in headers_dict.items()
                        )
                        
                    mime_type = result.get('mime', '')
                    is_hls = 'mpegURL' in mime_type
                    
                    if not is_hls and header_str:
                        stream_url = "{0}|{1}".format(stream_url, header_str)

                    li = xbmcgui.ListItem(path=stream_url)
                    if mime_type:
                        li.setMimeType(mime_type)
                        
                    if is_hls and header_str:
                        # inputstream.adaptive necesita los headers en sus properties
                        li.setProperty("inputstream", "inputstream.adaptive")
                        li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                        li.setProperty("inputstream.adaptive.stream_headers", header_str)
                        
                    li.setContentLookup(False)
                    subs = result.get('subs')
                    if subs and isinstance(subs, list):
                        li.setSubtitles(subs)
                    li.setProperty("IsPlayable", "true")
                    xbmc.Player().play(stream_url, li)
                    played = True
            except Exception as e:
                xbmc.log(
                    "[StreamNinja/url_player] _dm_play error: " + str(e),
                    xbmc.LOGWARNING,
                )

        # Método 3: navegador como último recurso
        if not played:
            dm_web = "https://www.dailymotion.com/video/" + value
            is_android = xbmc.getCondVisibility("System.Platform.Android")
            if is_android:
                opts = ["Abrir en el navegador", "Abrir en app externa"]
                sel = xbmcgui.Dialog().select("No se pudo resolver", opts)
                if sel < 0: return
                if sel == 0:
                    import webbrowser
                    webbrowser.open(dm_web)
                else:
                    xbmc.executebuiltin(
                        'StartAndroidActivity("",'
                        '"android.intent.action.VIEW","",'
                        '"{0}")'.format(dm_web))
            else:
                if xbmcgui.Dialog().yesno(
                    "StreamNinja",
                    "No se pudo resolver el vídeo de Dailymotion.\n\n"
                    "Si el problema persiste, ve a Opciones Avanzadas\n"
                    "y revisa Mantenimiento PC (yt-dlp).\n\n"
                    "¿Abrir en el navegador?"):
                    import webbrowser
                    webbrowser.open(dm_web)

    elif url_type == "youtube":
        yt_web = "https://www.youtube.com/watch?v=" + value
        is_android = xbmc.getCondVisibility("System.Platform.Android")

        opts = []
        actions = []

        # Addon YouTube (no pide API key para reproducir)
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            opts.append("Reproducir aquí")
            actions.append("addon")
        # yt-dlp (PC)
        if ytdlp_resolver.is_available():
            opts.append("Reproducir con yt-dlp")
            actions.append("ytdlp")
        # App YouTube nativa (solo Android)
        if is_android:
            opts.append("Abrir en la app YouTube")
            actions.append("yt_app")
        # Navegador (siempre)
        opts.append("Abrir en el navegador")
        actions.append("browser")

        # Si solo hay una opción, ejecutar directamente
        if len(opts) == 1:
            sel = 0
        else:
            sel = xbmcgui.Dialog().select("YouTube", opts)
        if sel < 0:
            return

        act = actions[sel]
        if act == "ytdlp":
            xbmcgui.Dialog().notification(
                "StreamNinja", "Resolviendo con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_full(yt_web)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
            else:
                xbmcgui.Dialog().ok(
                    "StreamNinja",
                    "yt-dlp no pudo resolver el vídeo.\n\n"
                    "Comprueba que tienes yt-dlp instalado correctamente\n"
                    "en Opciones Avanzadas > Mantenimiento PC (yt-dlp).")
        elif act == "addon":
            xbmc.executebuiltin(
                'PlayMedia("plugin://plugin.video.youtube/play/?video_id={0}")'.format(value))
        elif act == "yt_app":
            xbmc.executebuiltin(
                'StartAndroidActivity(com.google.android.youtube,'
                '"android.intent.action.VIEW","",'
                '"{0}")'.format(yt_web))
        elif act == "browser":
            import webbrowser
            webbrowser.open(yt_web)

    elif url_type == "kodi_plugin":
        xbmcgui.Dialog().notification(
            "StreamNinja", "Abriendo enlace interno...",
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        xbmc.executebuiltin('PlayMedia("{0}")'.format(value))


    elif url_type == "direct_stream":
        xbmcgui.Dialog().notification(
            "StreamNinja", "Reproduciendo vídeo...",
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        # El enlace lo ha tecleado el usuario; conservamos sus headers
        # (User-Agent, Referer...) intactos para no provocar un 403 en el CDN.
        url, headers = parse_url_with_headers(raw_url)
        _play_resolved_stream(url, headers=headers, strip_generic_headers=False)

    elif url_type == "torrent":
        has_elementum = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.elementum)"
        )
        if has_elementum:
            xbmcgui.Dialog().notification(
                "StreamNinja", "Abriendo torrent en Elementum...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            elem_url = (
                "plugin://plugin.video.elementum/play?"
                + urllib.parse.urlencode({"uri": value})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(elem_url))
        else:
            # Sin Elementum (y Debrid no resolvió arriba): intentar el motor AceStream
            # local si está activado y vivo. Aditivo: cualquier fallo cae al diálogo.
            if xbmcaddon.Addon().getSetting("acestream_enabled") != "false":
                try:
                    import acestream_player
                    if acestream_player.play_torrent(value):
                        return
                except Exception as e:
                    xbmc.log("[StreamNinja/url_player] acestream torrent: {0}".format(e),
                             xbmc.LOGWARNING)
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "Para reproducir torrents necesitas instalar "
                "el addon Elementum.\n\n"
                "Descargalo desde su repositorio oficial en GitHub.",
            )

    elif url_type == "acestream":
        # value llega canonicalizado como 'acestream://<hex>'. La lógica nativa + cadena
        # de fallback vive en play_acestream (compartida con la acción pública 'acestream').
        play_acestream(content_id=value.replace("acestream://", ""))

    elif url_type == "rtve":
        xbmcgui.Dialog().notification(
            "StreamNinja", "Reproduciendo vídeo...",
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        try:
            stream_url = "https://ztnr.rtve.es/ztnr/{0}.mpd".format(value)
            # Obtener token Widevine
            license_url = ""
            try:
                import requests
                r = requests.get(
                    "https://www.rtve.es/api/token/{0}".format(value),
                    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
                    timeout=5,
                )
                if r.status_code == 200:
                    token_data = r.json()
                    license_url = token_data.get("widevineURL", "")
            except Exception:
                pass

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Referer": "https://www.rtve.es/",
                "Origin": "https://www.rtve.es",
            }
            headers_string = "&".join(
                ["{0}={1}".format(k, urllib.parse.quote(v)) for k, v in headers.items()])

            li = xbmcgui.ListItem(path=stream_url)
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "mpd")
            li.setProperty("inputstream.adaptive.manifest_headers", headers_string)
            li.setProperty("inputstream.adaptive.stream_headers", headers_string)
            if license_url:
                li.setProperty("inputstream.adaptive.license_type",
                               "com.widevine.alpha")
                li.setProperty("inputstream.adaptive.license_key", license_url)
            li.setMimeType("application/dash+xml")
            li.setContentLookup(False)
            xbmc.Player().play(stream_url, li)
        except Exception as e:
            xbmc.log(
                "[StreamNinja/url_player] RTVE error: " + str(e),
                xbmc.LOGWARNING,
            )
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "Error al reproducir:\n{0}".format(str(e)),
            )

    elif url_type == "mediaset":
        # 0. Intentar resolver nativamente primero mediante el módulo extraído via Carga Remota
        try:
            import remote_loader
            mset_resolver = remote_loader.load_module('mset_resolver')
            if mset_resolver:
                xbmc.log("[StreamNinja] Trying remote MSET for: {0}".format(value), xbmc.LOGINFO)
                xbmcgui.Dialog().notification("StreamNinja", "Resolviendo vídeo de Mediaset...", xbmcgui.NOTIFICATION_INFO, 2000)
                native_result = mset_resolver.MR.resolve_m(value)
                if native_result and native_result.get("url"):
                    stream_url = native_result["url"]
                    title = native_result.get("title", "Mediaset")
                    thumb = native_result.get("thumbnail", "")
                    xbmc.log("[StreamNinja] Native MSET success: {0}".format(title), xbmc.LOGINFO)
                    
                    # Crear ListItem con metadatos completos
                    li = xbmcgui.ListItem(label=title, path=stream_url)
                    li.setProperty("IsPlayable", "true")
                    if thumb:
                        li.setArt({"thumb": thumb, "icon": thumb, "fanart": thumb})
                    info_tag = li.getVideoInfoTag()
                    info_tag.setTitle(title)
                    info_tag.setMediaType("video")
                    xbmc.Player().play(stream_url, li)
                    # Actualizar historial con nombre y carátula reales
                    threading.Thread(
                        target=_add_to_history,
                        args=(value,),
                        kwargs={"label": title, "thumb": thumb},
                        daemon=True,
                    ).start()
                    return True
        except Exception as e:
            xbmc.log("[StreamNinja] Native MSET failed: {0}".format(e), xbmc.LOGERROR)

        is_android = xbmc.getCondVisibility("System.Platform.Android")
        opts = []
        actions = []

        # 1. Navegador o App Nativa Mitele
        if is_android:
            opts.append("Abrir en la app Mitele / Infinity")
            actions.append("app_externa")
        else:
            opts.append("Abrir en el navegador web")
            actions.append("browser")

        sel = xbmcgui.Dialog().select("Mediaset (Protegido por DRM)", opts)
        if sel < 0: return

        act = actions[sel]
        if act == "app_externa":
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","","{0}")'.format(value))
        elif act == "browser":
            import webbrowser
            webbrowser.open(value)

    elif url_type == "atresplayer":
        # 1. Resolver nativo via Carga Remota (Remote Payload)
        try:
            import remote_loader
            a3_resolver = remote_loader.load_module('a3_resolver')
            if a3_resolver:
                xbmcgui.Dialog().notification(
                    "StreamNinja", "Resolviendo vídeo nativo...",
                    xbmcgui.NOTIFICATION_INFO, 2000,
                )
                result = a3_resolver.resolve_a(value)
                if result and result.get("url"):
                    stream_url = result["url"]
                    headers_dict = result.get("headers", {})
                    
                    header_str = ""
                    if headers_dict:
                        header_str = "&".join(
                            "{0}={1}".format(k, urllib.parse.quote(str(v), safe=""))
                            for k, v in headers_dict.items()
                        )
                    
                    kodi_url = stream_url
                    if header_str:
                        kodi_url = "{0}|{1}".format(stream_url, header_str)

                    li = xbmcgui.ListItem(path=kodi_url)
                    if ".mpd" in stream_url.lower():
                        li.setProperty("inputstream", "inputstream.adaptive")
                        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
                        li.setMimeType("application/dash+xml")
                    elif ".m3u8" in stream_url.lower() or "mpegurl" in stream_url.lower():
                        li.setMimeType("application/x-mpegURL")
                        li.setProperty("inputstream", "inputstream.adaptive")
                    
                    if header_str:
                        li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                        li.setProperty("inputstream.adaptive.stream_headers", header_str)

                    li.setProperty("IsPlayable", "true")
                    li.setContentLookup(False)
                    xbmc.Player().play(kodi_url, li)
                    return
        except Exception as e:
            xbmc.log(
                "[StreamNinja/url_player] atresplayer nativo error: " + str(e),
                xbmc.LOGWARNING,
            )

        # 2. Fallback secundario: yt-dlp
        if ytdlp_resolver.is_available():
            xbmcgui.Dialog().notification(
                "StreamNinja", "Resolviendo secundario con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_full(value)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                return
        elif xbmc.getCondVisibility("System.Platform.Android"):
            # Android: yt-dlp en memoria (Kodi 20+). Sirve para contenido libre;
            # el premium con login lo resuelve antes el resolver nativo a3.
            xbmcgui.Dialog().notification(
                "StreamNinja", "Resolviendo secundario con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_in_memory(value)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                return

        # 3. Fallback: navegador/app
        is_android = xbmc.getCondVisibility("System.Platform.Android")
        if is_android:
            opts = ["Abrir en el navegador", "Abrir en app externa"]
            sel = xbmcgui.Dialog().select(
                "No se pudo reproducir (puede requerir login)", opts)
            if sel < 0: return
            if sel == 1:
                xbmc.executebuiltin(
                    'StartAndroidActivity("",'
                    '"android.intent.action.VIEW","",'
                    '"{0}")'.format(value))
            else:
                import webbrowser
                webbrowser.open(value)
        else:
            msg = ("No se pudo reproducir este contenido.\n\n"
                   "Es posible que requiera login o sea premium.\n\n"
                   "¿Abrir en el navegador?")
            if not ytdlp_resolver.is_available():
                msg = ("Se necesita yt-dlp para este contenido.\n\n"
                       "Configúralo en Opciones Avanzadas >\n"
                       "Mantenimiento PC (yt-dlp).\n\n"
                       "¿Abrir en el navegador?")
            if xbmcgui.Dialog().yesno("StreamNinja", msg):
                import webbrowser
                webbrowser.open(value)

    elif url_type == "web_page":
        # Twitch/Vimeo con su addon nativo instalado; plugin:// directo (antes que
        # nada). Si no hay addon nativo, _resolve_known_plugin devuelve None y sigue
        # el flujo normal de abajo, que ya cubre estos sitios vía yt-dlp/SendToKodi.
        native_plugin = _resolve_known_plugin(value)
        if native_plugin:
            xbmcgui.Dialog().notification(
                "StreamNinja", "Abriendo con addon nativo...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(native_plugin))
            return

        # 0. ResolveURL: hosters (streamtape, dood, mixdrop...) que yt-dlp no maneja
        # bien. valid_url() es regex local; si no reconoce el dominio devuelve None
        # al instante y se sigue con yt-dlp.
        ru_stream = _resolveurl_resolve(value)
        if ru_stream:
            li = xbmcgui.ListItem(path=ru_stream)
            _low = ru_stream.split("|", 1)[0].lower()
            if ".m3u8" in _low:
                li.setMimeType("application/x-mpegURL")
            elif ".mpd" in _low:
                li.setProperty("inputstream", "inputstream.adaptive")
                li.setProperty("inputstream.adaptive.manifest_type", "mpd")
            li.setProperty("IsPlayable", "true")
            li.setContentLookup(False)
            xbmc.Player().play(ru_stream, li)
            return

        # 1. yt-dlp (soporta cientos de webs de forma nativa)
        if ytdlp_resolver.is_available():
            xbmcgui.Dialog().notification(
                "StreamNinja", "Resolviendo con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_full(value)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                return
        elif xbmc.getCondVisibility("System.Platform.Android"):
            # Android: sin Python para el subproceso. yt-dlp en memoria (Kodi 20+).
            xbmcgui.Dialog().notification(
                "StreamNinja", "Resolviendo con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_in_memory(value)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                return

        # 2. SendToKodi
        # Agradecimientos especiales a SendToKodi por su trabajo y servir de inspiración.
        has_stk = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.sendtokodi)"
        )
        if has_stk:
            xbmcgui.Dialog().notification(
                "StreamNinja", "Resolviendo con SendToKodi...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            stk_url = (
                "plugin://plugin.video.sendtokodi/?"
                + urllib.parse.urlencode({"url": value})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(stk_url))
            return

        # 3. YouTube addon (último recurso)
        has_yt = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.youtube)"
        )
        if has_yt:
            xbmcgui.Dialog().notification(
                "StreamNinja", "Intentando resolver...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            yt_url = (
                "plugin://plugin.video.youtube/uri2addon/?uri="
                + urllib.parse.quote(value)
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(yt_url))
        else:
            # 4. Abrir en navegador / app nativa
            is_android = xbmc.getCondVisibility("System.Platform.Android")
            if is_android:
                opts = ["Abrir en el navegador", "Abrir en app externa"]
                sel = xbmcgui.Dialog().select("No se puede resolver aquí", opts)
                if sel < 0:
                    return
                if sel == 1:
                    xbmc.executebuiltin(
                        'StartAndroidActivity("",'
                        '"android.intent.action.VIEW","",'
                        '"{0}")'.format(value))
                else:
                    import webbrowser
                    webbrowser.open(value)
            else:
                msg = ("No se pudo resolver esta URL.\n\n"
                       "¿Abrir en el navegador?")
                if not ytdlp_resolver.is_available():
                    msg = ("No se pudo resolver esta URL.\n\n"
                           "Puedes configurar yt-dlp en Opciones\n"
                           "Avanzadas > Mantenimiento PC (yt-dlp).\n\n"
                           "¿Abrir en el navegador?")
                if xbmcgui.Dialog().yesno("StreamNinja", msg):
                    import webbrowser
                    webbrowser.open(value)


def play_clipboard():
    """Reproduce directamente la URL del portapapeles de la sesión."""
    try:
        win = xbmcgui.Window(10000)
        raw = win.getProperty("streamninja.clipboard.url").strip()
    except Exception:
        raw = ""

    if not raw:
        xbmcgui.Dialog().notification(
            "StreamNinja", "No hay URL copiada en memoria",
            xbmcgui.NOTIFICATION_WARNING, 2000
        )
        return

    threading.Thread(target=_add_to_history, args=(raw,), daemon=True).start()
    
    # Consumir el portapapeles para que desaparezca el botón
    win.clearProperty("streamninja.clipboard.url")

    
    _resolve_and_play(raw)


def _find_system_python(require_ytdlp=True):
    """Busca el ejecutable de Python del sistema (no el de Kodi).

    Devuelve la ruta absoluta del ejecutable o None.
    En Windows se prioriza 'python' porque 'python3' suele ser
    el stub de Microsoft Store que no tiene yt-dlp instalado.
    Con require_ytdlp=True verifica además que yt_dlp sea importable; con False
    basta con que sea un Python 3 real (para usarlo con el yt-dlp embebido).
    """
    import subprocess
    import shutil

    is_win = xbmc.getCondVisibility("System.Platform.Windows")
    candidates = ("python", "python3") if is_win else ("python3", "python")

    creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if is_win else 0

    for cmd in candidates:
        abs_path = shutil.which(cmd)
        if not abs_path:
            continue

        # Descartar el stub de Microsoft Store (no tiene paquetes)
        if "WindowsApps" in abs_path:
            continue

        try:
            # 1. Verificar que es Python 3 real
            proc = subprocess.run(
                [abs_path, "--version"],
                capture_output=True, text=True, timeout=5,
                creationflags=creation_flags,
            )
            if proc.returncode != 0 or "Python 3" not in (proc.stdout + proc.stderr):
                continue

            # 2. Verificar que yt_dlp es importable desde ese Python
            if require_ytdlp:
                proc2 = subprocess.run(
                    [abs_path, "-c", "import yt_dlp"],
                    capture_output=True, text=True, timeout=10,
                    creationflags=creation_flags,
                )
                if proc2.returncode != 0:
                    continue

            return abs_path
        except Exception:
            continue
    return None




def _get_download_dest(title, ext=".mp4"):
    """Solicita al usuario la carpeta de destino y devuelve la ruta final.

    Si hay una ruta configurada en los ajustes nativos de Kodi, se usa
    como punto de partida del selector. Devuelve cadena vacia si el
    usuario cancela.
    """
    saved_path = xbmcaddon.Addon().getSetting("download_path") or ""

    dest_dir = xbmcgui.Dialog().browse(
        3, "Selecciona donde guardar", "video",
        "", False, False, saved_path,
    )
    if not dest_dir:
        return ""

    safe_title = "".join(c for c in title if c.isalnum() or c in " -_").strip()
    if not safe_title:
        safe_title = "streamninja_download_{0}".format(int(time.time()))
    if len(safe_title) > 120:
        safe_title = safe_title[:120].rstrip()

    return os.path.join(dest_dir, "{0}{1}".format(safe_title, ext))


def _download_direct_url(url, dest, title, headers=None):
    """Descarga un archivo por HTTP con barra de progreso.

    Funciona con cualquier URL directa (MP4, MKV, etc.) sin
    depender de headers especificos de ninguna plataforma.
    """
    import requests
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando", "Conectando: {0}".format(title))
    tmp = dest + ".tmp"
    try:
        req_headers = headers or {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0.0.0 Safari/537.36",
        }
        with requests.get(url, headers=req_headers, stream=True, timeout=30) as r:
            if r.status_code >= 400:
                raise Exception(
                    "El servidor respondio con codigo {0}".format(r.status_code))
            total = int(r.headers.get("content-length", 0))
            done = 0
            with open(tmp, "wb") as f:
                for chunk in r.iter_content(chunk_size=256 * 1024):
                    if dp.iscanceled():
                        break
                    f.write(chunk)
                    done += len(chunk)
                    if total > 0:
                        pct = int(done * 100 / total)
                        mb_done = done / (1024 * 1024)
                        mb_total = total / (1024 * 1024)
                        dp.update(pct, "{0:.1f} MB / {1:.1f} MB".format(
                            mb_done, mb_total))

        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp, dest)
            try:
                import download_manager
                download_manager.log_download(title, dest, "MP4")
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                "StreamNinja", "Descarga completada:\n{0}".format(dest))
        elif os.path.exists(tmp):
            os.remove(tmp)
    except Exception as exc:
        try:
            dp.close()
        except Exception:
            pass
        if os.path.exists(tmp):
            os.remove(tmp)
        xbmc.log("[StreamNinja/url_player] Error en descarga directa: {0}".format(
            exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("StreamNinja", "Error en la descarga:\n{0}".format(
            str(exc)[:200]))


def _resolve_hls_master(m3u8_text, base_url):
    """Si el texto es un master playlist HLS, devuelve la URL absoluta de la
    variante de mayor BANDWIDTH; si ya es un media playlist, devuelve None.

    Función pura (sin red). Para descarga a disco se elige siempre la calidad
    más alta. El grabador PVR usa su propia selección con límite de bitrate.
    """
    if "#EXT-X-STREAM-INF" not in m3u8_text:
        return None
    lines = m3u8_text.splitlines()
    best_bw = -1
    best_url = None
    for i, line in enumerate(lines):
        if not line.startswith("#EXT-X-STREAM-INF"):
            continue
        m = re.search(r"BANDWIDTH=(\d+)", line)
        bw = int(m.group(1)) if m else 0
        for j in range(i + 1, len(lines)):
            candidate = lines[j].strip()
            if candidate and not candidate.startswith("#"):
                if bw > best_bw:
                    best_bw = bw
                    best_url = urllib.parse.urljoin(base_url, candidate)
                break
    return best_url


def _download_hls_stream(playlist_url, dest, title, headers=None):
    """Descarga un stream HLS concatenando sus segmentos .ts.

    Esta version acepta
    headers arbitrarios en vez de usar los de Dailymotion.
    """
    import requests
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando HLS", "Obteniendo segmentos...")
    req_headers = headers or {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/120.0.0.0 Safari/537.36",
    }
    clean_url = playlist_url.split("|")[0] if "|" in playlist_url else playlist_url
    tmp = dest + ".tmp"
    try:
        with requests.get(clean_url, headers=req_headers, timeout=15) as r:
            if r.status_code >= 400:
                raise Exception(
                    "El servidor respondio con codigo {0}".format(r.status_code))
            m3u8_text = r.text

        # Si es un master playlist, resolver la variante de mayor calidad y
        # recargar su media playlist. Los segmentos relativos resuelven contra
        # la URL de la variante, no contra la del master.
        variant_url = _resolve_hls_master(m3u8_text, clean_url)
        if variant_url:
            clean_url = variant_url
            with requests.get(clean_url, headers=req_headers, timeout=15) as r:
                if r.status_code >= 400:
                    raise Exception(
                        "El servidor respondio con codigo {0}".format(r.status_code))
                m3u8_text = r.text

        # Sin #EXT-X-ENDLIST suele ser una emision en directo; solo se podra
        # capturar el fragmento disponible ahora. Se avisa pero se permite
        # continuar, para no romper un VOD mal etiquetado (sin ENDLIST) que
        # antes se descargaba igualmente.
        if "#EXT-X-ENDLIST" not in m3u8_text:
            dp.close()
            if not xbmcgui.Dialog().yesno(
                    "StreamNinja",
                    "Parece una emision en directo.\n\n"
                    "Para una captura completa usa la grabacion\n"
                    "en directo (PVR). Si continuas, solo se\n"
                    "guardara el fragmento disponible ahora.\n\n"
                    "¿Continuar igualmente?"):
                return
            dp = xbmcgui.DialogProgress()
            dp.create("Descargando HLS", "Obteniendo segmentos...")

        if "?" in clean_url:
            params = "?" + clean_url.split("?")[1]
        else:
            params = ""

        segments = [
            ln for ln in m3u8_text.splitlines()
            if ln and not ln.startswith("#")
        ]
        if not segments:
            dp.close()
            xbmcgui.Dialog().ok(
                "StreamNinja", "La lista de reproduccion esta vacia.")
            return

        with open(tmp, "wb") as f_out:
            for idx, seg_name in enumerate(segments):
                if dp.iscanceled():
                    break

                if seg_name.startswith("http"):
                    seg_url = seg_name
                else:
                    seg_url = urllib.parse.urljoin(clean_url, seg_name)
                    # Añadir parametros de la playlist si el segmento no tiene propios
                    if params and "?" not in seg_url:
                        seg_url += params

                success = False
                for _attempt in range(3):
                    try:
                        with requests.get(seg_url, headers=req_headers, timeout=12) as seg_r:
                            seg_r.raise_for_status()
                            seg_data = seg_r.content
                        f_out.write(seg_data)
                        success = True
                        break
                    except Exception:
                        continue

                if not success:
                    raise Exception(
                        "Fallo en segmento {0}/{1}".format(idx + 1, len(segments)))

                pct = int((idx + 1) * 100 / len(segments))
                dp.update(pct, "Segmento {0}/{1} - {2}".format(
                    idx + 1, len(segments), title))

        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp, dest)
            try:
                import download_manager
                download_manager.log_download(title, dest, "HLS")
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                "StreamNinja", "Descarga HLS completada:\n{0}".format(dest))
        elif os.path.exists(tmp):
            os.remove(tmp)
    except Exception as exc:
        try:
            dp.close()
        except Exception:
            pass
        if os.path.exists(tmp):
            os.remove(tmp)
        xbmc.log("[StreamNinja/url_player] Error HLS download: {0}".format(
            exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            "StreamNinja", "Error en descarga HLS:\n{0}".format(str(exc)[:200]))


def _download_via_ytdlp(url, dest, title):
    """Descarga cualquier URL soportada por yt-dlp a disco.

    Genera un script auxiliar que ejecuta yt-dlp como libreria para
    evitar conflictos con el Python interno de Kodi.  Solo disponible
    en plataformas de escritorio con Python >= 3.10 en el PATH.
    """
    import subprocess

    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "Las descargas con yt-dlp no estan\n"
            "disponibles en dispositivos Android.\n\n"
            "Usa un PC con Python 3.10+ instalado.")
        return

    dp = xbmcgui.DialogProgress()
    dp.create("Descarga con yt-dlp", "Preparando...")

    try:
        # Buscar Python del sistema. Si tiene yt-dlp se usa tal cual; si no, se
        # busca cualquier Python 3 y se le añade el yt-dlp embebido vía PYTHONPATH.
        dp.update(2, "Buscando Python del sistema...")
        env = None
        py_cmd = _find_system_python()  # Python del sistema CON yt_dlp
        if not py_cmd:
            # Sin yt-dlp en el sistema; cualquier Python 3 + yt-dlp embebido.
            py_cmd = _find_system_python(require_ytdlp=False)
            if not py_cmd:
                dp.close()
                xbmcgui.Dialog().ok(
                    "StreamNinja",
                    "Se necesita Python 3 en el sistema.\n\n"
                    "Descargalo de python.org e instalalo\n"
                    "marcando 'Add to PATH'.\n\n"
                    "Despues reinicia Kodi.")
                return
            dp.update(4, "Preparando yt-dlp embebido...")
            env = ytdlp_resolver._ytdlp_bundle_env()  # descarga el wheel + PYTHONPATH
            if env is None:
                dp.close()
                xbmcgui.Dialog().ok(
                    "StreamNinja",
                    "No se pudo preparar el yt-dlp embebido.\n\n"
                    "Suele ser un problema de conexion al descargarlo.\n"
                    "Comprueba tu red e intentalo de nuevo.")
                return

        # Asegurar extension .mp4
        if not dest.endswith(".mp4"):
            dest = os.path.splitext(dest)[0] + ".mp4"

        # Ficheros temporales en el perfil del addon
        tmp_dir = _get_profile()
        progress_file = os.path.join(tmp_dir, "_dl_progress.json")
        if os.path.exists(progress_file):
            os.remove(progress_file)

        helper_path = os.path.join(tmp_dir, "_dl_helper.py")
        script = (
            "import json\n"
            "import yt_dlp\n"
            "\n"
            "progress_file = {pf!r}\n"
            "\n"
            "def hook(d):\n"
            "    info = {{\"status\": d.get(\"status\", \"\"), "
            "\"percent\": 0, \"text\": \"\"}}\n"
            "    if d[\"status\"] == \"downloading\":\n"
            "        total = d.get(\"total_bytes\") or "
            "d.get(\"total_bytes_estimate\") or 0\n"
            "        done = d.get(\"downloaded_bytes\", 0)\n"
            "        speed = d.get(\"speed\") or 0\n"
            "        if total > 0:\n"
            "            info[\"percent\"] = int(done * 100 / total)\n"
            "            mb_d = done / (1024*1024)\n"
            "            mb_t = total / (1024*1024)\n"
            "            sp = speed / (1024*1024) if speed else 0\n"
            "            info[\"text\"] = "
            "f\"{{mb_d:.1f}}MB / {{mb_t:.1f}}MB ({{sp:.1f}} MB/s)\"\n"
            "        elif done > 0:\n"
            "            info[\"percent\"] = 50\n"
            "            info[\"text\"] = "
            "f\"Descargando: {{done/(1024*1024):.1f}}MB\"\n"
            "    elif d[\"status\"] == \"finished\":\n"
            "        info[\"percent\"] = 95\n"
            "        info[\"text\"] = \"Finalizando...\"\n"
            "    with open(progress_file, \"w\") as f:\n"
            "        json.dump(info, f)\n"
            "\n"
            "opts = {{\n"
            "    \"format\": \"best[ext=mp4]/best\",\n"
            "    \"outtmpl\": {dest!r},\n"
            "    \"quiet\": True,\n"
            "    \"no_warnings\": True,\n"
            "    \"progress_hooks\": [hook],\n"
            "    \"noprogress\": True,\n"
            "}}\n"
            "try:\n"
            "    ydl = yt_dlp.YoutubeDL(opts)\n"
            "    ydl.download([{url!r}])\n"
            "    with open(progress_file, \"w\") as f:\n"
            "        json.dump({{\"status\": \"done\", \"percent\": 100, "
            "\"text\": \"Completado\"}}, f)\n"
            "except Exception as e:\n"
            "    with open(progress_file, \"w\") as f:\n"
            "        json.dump({{\"status\": \"error\", \"percent\": 0, "
            "\"text\": str(e)[:300]}}, f)\n"
        ).format(pf=progress_file, dest=dest, url=url)

        with open(helper_path, "w", encoding="utf-8") as f:
            f.write(script)

        # Ejecutar descarga
        dp.update(10, "Iniciando descarga...")
        no_win = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        proc = subprocess.Popen(
            [py_cmd, helper_path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=no_win, env=env,
        )

        # Polling
        cancelled = False
        while proc.poll() is None:
            if dp.iscanceled():
                cancelled = True
                proc.kill()
                break
            if os.path.exists(progress_file):
                try:
                    with open(progress_file, "r") as f:
                        info = json.loads(f.read())
                    dp.update(
                        info.get("percent", 0),
                        info.get("text", "Descargando..."))
                except Exception:
                    pass
            time.sleep(0.5)

        dp.close()

        # Limpieza
        for tmp in [helper_path, progress_file]:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except Exception:
                    pass

        if cancelled:
            for ext in ["", ".part"]:
                p = dest + ext
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except Exception:
                        pass
            return

        if proc.returncode == 0 and os.path.exists(dest):
            try:
                import download_manager
                download_manager.log_download(title, dest, "YT-DLP")
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                "StreamNinja", "Descarga completada:\n{0}".format(dest))
        else:
            stderr = ""
            try:
                stderr = proc.stderr.read().decode(
                    "utf-8", errors="replace")[:200]
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "Error en la descarga:\n{0}".format(stderr or "Desconocido"))

    except Exception as exc:
        try:
            dp.close()
        except Exception:
            pass
        xbmc.log("[StreamNinja/url_player] Error yt-dlp download: {0}".format(
            exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            "StreamNinja", "Error al preparar la descarga:\n{0}".format(
                str(exc)[:200]))


def _resolve_and_download(raw_url):
    """Clasifica la URL y lanza la descarga adecuada."""
    url_type, value = detect_url_type(raw_url)

    if url_type == "dailymotion":
        label = _auto_label(raw_url) or value
        dm_url = "https://www.dailymotion.com/video/" + value

        # Leer modo de descarga desde ajustes nativos de Kodi
        dl_mode = _get_setting_int("dl_mode", default=0, max_val=4)

        ytdlp_ok = ytdlp_resolver.is_available()

        # Si el usuario forzó yt-dlp y no lo tiene
        if dl_mode in (3, 4) and not ytdlp_ok:
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "El modo elegido (YT-DLP/ULTRA) requiere yt-dlp.\n\n"
                "Solo esta disponible en PC con Python 3.10+.")
            return

        # Si el modo es el por defecto (0) pero YT-DLP no esta
        # instalado, adaptar segun plataforma en vez de mostrar error seco.
        if dl_mode == 0 and not ytdlp_ok:
            is_android = xbmc.getCondVisibility("System.Platform.Android")
            if is_android:
                # Android/FireTV: yt-dlp no se puede instalar, fallback
                # directo a la API sin molestar al usuario.
                xbmcgui.Dialog().notification(
                    "StreamNinja", "Resolviendo origen multimedia...",
                    xbmcgui.NOTIFICATION_INFO, 2000,
                )
                dl_mode = 2
            else:
                # Escritorio (Linux/Mac/Win) sin yt-dlp; informar al usuario
                # de que existe una opcion mejor y dejarle elegir.
                choice = xbmcgui.Dialog().yesno(
                    "StreamNinja",
                    "yt-dlp no esta instalado en este equipo.\n\n"
                    "Con yt-dlp las descargas son de mejor calidad\n"
                    "y mas fiables.\n\n"
                    "Puedes instalarlo desde Opciones Avanzadas >\n"
                    "Mantenimiento PC (yt-dlp).\n\n"
                    "Descargar ahora con la API interna?",
                    yeslabel="Descargar ahora",
                    nolabel="Cancelar",
                )
                if choice:
                    dl_mode = 2
                else:
                    return

        if dl_mode in (0, 3, 4):
            dest = _get_download_dest(label)
            if dest:
                _download_via_ytdlp(dm_url, dest, label)

        # Modo 1 (SAFE MODE): resolver MP4 directo vía API interna
        elif dl_mode == 1:
            try:
                import dm_resolver
                result = dm_resolver._dm_play_direct(value)
                if result and result.get("url") and result.get("mime") == "video/mp4":
                    dest = _get_download_dest(label)
                    if dest:
                        _download_direct_url(
                            result["url"], dest, label,
                            headers=result.get("headers"),
                        )
                else:
                    xbmcgui.Dialog().ok(
                        "StreamNinja",
                        "No hay enlaces MP4 directos disponibles.\n\n"
                        "Elige otro modo en Opciones Avanzadas."
                    )
            except Exception as exc:
                xbmc.log(
                    "[StreamNinja] dl_mode 1 error: {0}".format(exc),
                    xbmc.LOGWARNING)
                xbmcgui.Dialog().ok(
                    "StreamNinja",
                    "Error al resolver MP4 directo.\n{0}".format(
                        str(exc)[:200]))

        # Modo 2 (HLS/Smart Fallback): resolver lo mejor disponible vía API interna
        elif dl_mode == 2:
            try:
                import dm_resolver
                result = dm_resolver._dm_play_direct(value)
                if result and result.get("url"):
                    stream_url = result["url"]
                    mime = result.get("mime", "")
                    if "mpegURL" in mime:
                        dest = _get_download_dest(label, ext=".ts")
                        if dest:
                            if xbmcgui.Dialog().yesno(
                                "Descarga Segmentada",
                                "La API solo ofrece stream dinamico (HLS).\n"
                                "La descarga unira los segmentos "
                                "de forma progresiva, puede tardar mas "
                                "que un MP4 directo.\n\nContinuar?",
                            ):
                                _download_hls_stream(
                                    stream_url, dest, label,
                                    headers=result.get("headers"),
                                )
                    else:
                        dest = _get_download_dest(label)
                        if dest:
                            _download_direct_url(
                                stream_url, dest, label,
                                headers=result.get("headers"),
                            )
                else:
                    xbmcgui.Dialog().ok(
                        "StreamNinja",
                        "No se pudo resolver el contenido para descarga.\n\n"
                        "Prueba yt-dlp en PC o elige otro contenido.")
            except Exception as exc:
                xbmc.log(
                    "[StreamNinja] dl_mode 2 error: {0}".format(exc),
                    xbmc.LOGWARNING)
                xbmcgui.Dialog().ok(
                    "StreamNinja",
                    "Error al resolver contenido.\n{0}".format(
                        str(exc)[:200]))

    elif url_type in ("youtube", "web_page"):
        if not ytdlp_resolver.is_available():
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "La descarga de este contenido requiere yt-dlp.\n\n"
                "Solo esta disponible en PC (Windows/Linux/Mac)\n"
                "con Python 3.10+ instalado.")
            return
        label = _auto_label(raw_url) or "video"
        dest = _get_download_dest(label)
        if not dest:
            return
        _download_via_ytdlp(raw_url, dest, label)

    elif url_type == "direct_stream":
        url, headers = parse_url_with_headers(raw_url)
        label = _auto_label(raw_url) or "stream"

        clean_path = urllib.parse.urlparse(url).path.lower()
        if clean_path.endswith(".m3u8"):
            dest = _get_download_dest(label, ext=".ts")
            if not dest:
                return
            if not xbmcgui.Dialog().yesno(
                    "Descarga HLS",
                    "Este stream se descargara por segmentos.\n"
                    "El proceso puede ser lento. Continuar?"):
                return
            _download_hls_stream(url, dest, label, headers=headers or None)
        else:
            ext = os.path.splitext(clean_path)[1] or ".mp4"
            dest = _get_download_dest(label, ext=ext)
            if not dest:
                return
            h = headers if headers else None
            _download_direct_url(url, dest, label, headers=h)

    elif url_type == "rtve":
        if not ytdlp_resolver.is_available():
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "La descarga de RTVE requiere yt-dlp.\n\n"
                "Solo esta disponible en PC.")
            return
        label = _auto_label(raw_url) or "rtve"
        dest = _get_download_dest(label)
        if not dest:
            return
        _download_via_ytdlp(raw_url, dest, label)

    elif url_type == "torrent":
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "Para descargar torrents nativamente necesitas instalar "
                "el addon Elementum.")
            return

        xbmcgui.Dialog().notification(
            "StreamNinja", "Añadiendo a las descargas de Elementum...",
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        
        elem_url = (
            "plugin://plugin.video.elementum/download?"
            + urllib.parse.urlencode({"uri": value})
        )
        xbmc.executebuiltin('RunPlugin("{0}")'.format(elem_url))

    else:
        if not ytdlp_resolver.is_available():
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "La descarga de este contenido requiere yt-dlp.\n\n"
                "Solo esta disponible en PC (Windows/Linux/Mac)\n"
                "con Python 3.10+ instalado.")
            return
        label = _auto_label(raw_url) or "video"
        dest = _get_download_dest(label)
        if not dest:
            return
        _download_via_ytdlp(raw_url, dest, label)


def url_input():
    """Teclado para pegar un enlace y reproducirlo."""
    kb = xbmc.Keyboard("", "Pegar dirección o enlace de vídeo (YouTube, Dailymotion...)")
    kb.doModal()
    if not kb.isConfirmed():
        return

    raw = kb.getText().strip()
    if not raw:
        return

    if _ACE_HASH_RE.fullmatch(raw):
        raw = "acestream://" + raw.lower()

    valid_schemes = ("http://", "https://", "rtmp://", "rtsp://",
                     "magnet:?", "acestream://")
    if not raw.lower().startswith(valid_schemes):
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "La URL no parece válida.\n\n"
            "Esquemas soportados: http, https, rtmp, rtsp, magnet, acestream",
        )
        return

    threading.Thread(target=_add_to_history, args=(raw,), daemon=True).start()

    url_type, _ = detect_url_type(raw)
    type_labels = {
        "dailymotion": "Dailymotion",
        "youtube": "YouTube",
        "rtve": "RTVE",
        "atresplayer": "Atresplayer",
        "mediaset": "Mediaset",
        "torrent": "Torrent",
        "acestream": "AceStream",
        "direct_stream": "Stream directo",
        "web_page": "Página web",
    }
    detected = type_labels.get(url_type, "Desconocido")
    url_display = raw[:50] + "..." if len(raw) > 50 else raw

    opts = [
        "Reproducir ahora ({0})".format(detected),
        "Guardar como favorito y reproducir",
        "Solo guardar como favorito",
    ]
    _NOT_DOWNLOADABLE = {"acestream", "kodi_plugin", "internal_query"}
    if url_type not in _NOT_DOWNLOADABLE:
        opts.append("Descargar ({0})".format(detected))

    sel = xbmcgui.Dialog().select(url_display, opts)

    if sel == 0:
        _resolve_and_play(raw)
    elif sel == 1:
        name_kb = xbmc.Keyboard("", "Nombre para el favorito")
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            _add_bookmark(name_kb.getText().strip(), raw)
        _resolve_and_play(raw)
    elif sel == 2:
        name_kb = xbmc.Keyboard("", "Nombre para el favorito")
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            if _add_bookmark(name_kb.getText().strip(), raw):
                xbmcgui.Dialog().notification(
                    "StreamNinja", "Favorito guardado",
                    xbmcgui.NOTIFICATION_INFO,
                )
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().notification(
                    "StreamNinja", "Ya existe este favorito",
                    xbmcgui.NOTIFICATION_INFO,
                )
    elif sel == 3:
        _resolve_and_download(raw)


def _action_art(icon_file, _cinema=False):
    """Arte para items de accion (borrar, atajos)."""
    icon = os.path.join(_MEDIA, icon_file)
    return {"icon": icon}


def url_history_menu():
    """Historial de URLs reproducidas."""
    h = _get_handle()
    history = _get_history()

    if not history:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No hay URLs en el historial[/COLOR]"
        )
        li.setArt({"icon": os.path.join(_MEDIA, "info.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    li = xbmcgui.ListItem(
        label="[COLOR red][B]Borrar todo el historial de URLs[/B][/COLOR]"
    )
    li.setArt(_action_art("adv_limpieza.png", False))
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_history_clear"), listitem=li, isFolder=False
    )

    for entry in history:
        raw_url = entry.get("url", "")
        label = entry.get("label", raw_url)
        date = entry.get("date", "")

        display = label[:80] + "..." if len(label) > 80 else label
        thumb = entry.get("thumb", "")
        plot = "URL: {0}\n\nFecha: {1}".format(raw_url, date)
        li = xbmcgui.ListItem(label=display)
        li.setArt({
            "icon": thumb or "DefaultVideo.png",
            "thumb": thumb or "",
        })
        li.setInfo("video", {"plot": plot})

        cm = [
            (
                "Guardar como favorito",
                "RunPlugin({0})".format(
                    _u(action="url_bookmark_save_from_history", url=raw_url)
                ),
            ),
            (
                "Eliminar del historial",
                "RunPlugin({0})".format(
                    _u(action="url_history_remove", url=raw_url)
                ),
            ),
        ]
        
        url_type, _ = detect_url_type(raw_url)
        _NOT_DOWNLOADABLE = {"acestream", "kodi_plugin", "internal_query"}
        if url_type not in _NOT_DOWNLOADABLE:
            cm.insert(0, (
                "Descargar",
                "RunPlugin({0})".format(_u(action="url_download", url=raw_url))
            ))
            
        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=raw_url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def scan_history_menu():
    """Historial de webs y canales de Telegram escaneados."""
    h = _get_handle()
    history = _get_scan_history()

    if not history:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No hay escaneos en el historial[/COLOR]"
        )
        li.setArt({"icon": os.path.join(_MEDIA, "info.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    li = xbmcgui.ListItem(
        label="[COLOR red][B]Borrar todo el historial de escaneos[/B][/COLOR]"
    )
    li.setArt({"icon": os.path.join(_MEDIA, "adv_limpieza.png")})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="scan_history_clear"), listitem=li, isFolder=False
    )

    for entry in history:
        raw_input = entry.get("input", "")
        label = entry.get("label", raw_input)
        scan_type = entry.get("type", "web")
        date = entry.get("date", "")

        display = "{0}: {1}".format(scan_type, label)
        li = xbmcgui.ListItem(label=display)
        icon = "url_scan.png" if scan_type == "web" else "url_remote.png"
        li.setArt({"icon": os.path.join(_MEDIA, icon)})
        li.setInfo("video", {"plot": "{0}\n\nEscaneado: {1}".format(raw_input, date)})
        cm = [
            (
                "Eliminar del historial",
                "RunPlugin({0})".format(
                    _u(action="scan_history_remove", url=raw_input)
                ),
            ),
        ]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="scan_url", url=raw_input),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def url_bookmarks_menu():
    """Favoritos de URLs guardados."""
    h = _get_handle()
    bookmarks = _get_bookmarks()

    # Flow FavManager; acceso directo al gestor avanzado de favoritos
    try:
        xbmcaddon.Addon("plugin.program.flowfavmanager")
        li_flow = xbmcgui.ListItem(
            label="[COLOR violet][B]Flow FavManager[/B][/COLOR]"
        )
        li_flow.setArt(_action_art("shortcut_addon.png", False))
        li_flow.setInfo("video", {
            "plot": "Abre la utilidad avanzada para organizar "
                    "y gestionar estos favoritos."
        })
        xbmcplugin.addDirectoryItem(
            handle=h,
            url="plugin://plugin.program.flowfavmanager/",
            listitem=li_flow, isFolder=False,
        )
    except Exception:
        li_flow = xbmcgui.ListItem(
            label="[COLOR gray]Flow FavManager (No instalado)[/COLOR]"
        )
        li_flow.setArt(_action_art("shortcut_addon.png", False))
        li_flow.setInfo("video", {
            "plot": "Gestor avanzado de favoritos. "
                    "Pulsa para instalar desde GitHub."
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="flowfav_install"),
            listitem=li_flow, isFolder=False,
        )

    if not bookmarks:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No hay favoritos guardados[/COLOR]"
        )
        li.setArt({"icon": os.path.join(_MEDIA, "info.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    for bm in bookmarks:
        url = bm.get("url", "")
        name = bm.get("name", url)
        date = bm.get("date", "")

        li = xbmcgui.ListItem(label=name)
        thumb = bm.get("thumb", "")
        plot = "URL: {0}\n\nGuardado: {1}".format(url, date)
        li.setArt({
            "icon": thumb or "DefaultVideo.png",
            "thumb": thumb or "",
        })
        li.setInfo("video", {"plot": plot})

        cm = [
            (
                "Renombrar",
                "RunPlugin({0})".format(_u(action="url_bookmark_rename", url=url)),
            ),
            (
                "Eliminar favorito",
                "RunPlugin({0})".format(_u(action="url_bookmark_delete", url=url)),
            ),
        ]

        url_type, _ = detect_url_type(url)
        _NOT_DOWNLOADABLE = {"acestream", "kodi_plugin", "internal_query"}
        if url_type not in _NOT_DOWNLOADABLE:
            cm.insert(0, (
                "Descargar",
                "RunPlugin({0})".format(_u(action="url_download", url=url))
            ))

        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def bookmark_save_from_history(url):
    if not url:
        return
    kb = xbmc.Keyboard("", "Nombre para el favorito")
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _add_bookmark(kb.getText().strip(), url):
            xbmcgui.Dialog().notification(
                "StreamNinja", "Favorito guardado",
                xbmcgui.NOTIFICATION_INFO
            )
            xbmc.executebuiltin("Container.Refresh")
        else:
            xbmcgui.Dialog().notification(
                "StreamNinja", "Ya existe este favorito",
                xbmcgui.NOTIFICATION_INFO
            )


def bookmark_rename(url):
    if not url:
        return
    bookmarks = _get_bookmarks()
    current_name = ""
    for b in bookmarks:
        if b.get("url") == url:
            current_name = b.get("name", "")
            break

    kb = xbmc.Keyboard(current_name, "Nuevo nombre")
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _rename_bookmark(url, kb.getText().strip()):
            xbmc.executebuiltin("Container.Refresh")


def bookmark_delete(url):
    if not url:
        return
    if _remove_bookmark(url):
        xbmcgui.Dialog().notification(
            "StreamNinja", "Favorito eliminado", xbmcgui.NOTIFICATION_INFO
        )
        xbmc.executebuiltin("Container.Refresh")


def history_remove(url):
    if not url:
        return
    _remove_from_history(url)
    xbmc.executebuiltin("Container.Refresh")


def history_clear():
    if xbmcgui.Dialog().yesno("StreamNinja", "¿Borrar todo el historial de URLs?"):
        _clear_history()
        xbmc.executebuiltin("Container.Refresh")


def play_url_action(raw_url):
    """Reproduce una URL registrándola en el historial."""
    if not raw_url:
        return
    threading.Thread(target=_add_to_history, args=(raw_url,), daemon=True).start()
    _resolve_and_play(raw_url)


def api_resolve_action(raw_url):
    """
    API Nativa para que otros Addons usen StreamNinja como resolver silencioso.
    Soporta enlaces directos, Atresplayer, Mediaset, Dailymotion, webs genéricas
    y plataformas compatibles con yt-dlp.
    Devuelve el resultado al Addon original usando setResolvedUrl.
    """
    try:
        handle = int(sys.argv[1])
    except Exception:
        handle = -1

    if handle == -1:
        xbmc.log("[StreamNinja API] Error: handle inválido.", xbmc.LOGERROR)
        return

    if not raw_url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    url_type, value = detect_url_type(raw_url)

    stream_url = ""
    header_str = ""
    mime_type = ""
    is_mpd = False
    is_m3u8 = False

    try:
        if url_type == "direct_stream":
            u, headers = parse_url_with_headers(raw_url)
            stream_url = u
            if headers:
                header_str = "&".join("{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in headers.items())
            if ".mpd" in stream_url.lower():
                is_mpd = True
                mime_type = "application/dash+xml"
            elif ".m3u8" in stream_url.lower() or "mpegurl" in stream_url.lower():
                is_m3u8 = True
                mime_type = "application/x-mpegURL"

        elif url_type == "atresplayer":
            import remote_loader
            a3_res = remote_loader.load_module('a3_resolver')
            result = a3_res.resolve_a(value) if a3_res else None
            if result and result.get("url"):
                stream_url = result["url"]
                headers_dict = result.get("headers", {})
                if headers_dict:
                    header_str = "&".join("{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in headers_dict.items())
                if ".mpd" in stream_url.lower():
                    is_mpd = True
                    mime_type = "application/dash+xml"
                elif ".m3u8" in stream_url.lower() or "mpegurl" in stream_url.lower():
                    is_m3u8 = True
                    mime_type = "application/x-mpegURL"

        elif url_type == "mediaset":
            import remote_loader
            mset_res = remote_loader.load_module('mset_resolver')
            native_result = mset_res.MR.resolve_m(value) if mset_res else None
            if native_result and native_result.get("url"):
                stream_url = native_result["url"]
                if ".mpd" in stream_url.lower():
                    is_mpd = True
                    mime_type = "application/dash+xml"
                else:
                    is_m3u8 = True
                    mime_type = "application/x-mpegURL"

        elif url_type == "dailymotion":
            # yt-dlp primero, luego resolver interno
            dm_full = "https://www.dailymotion.com/video/" + value
            if ytdlp_resolver.is_available():
                info = ytdlp_resolver.resolve_full(dm_full)
                if info and info.get("url"):
                    stream_url = info["url"]
                    h = info.get("headers", {})
                    if h:
                        header_str = "&".join("{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in h.items())
                    proto = info.get("protocol", "")
                    if "m3u8" in proto or ".m3u8" in stream_url.lower():
                        is_m3u8 = True
                        mime_type = "application/x-mpegURL"
            if not stream_url:
                try:
                    import dm_resolver
                    is_win = xbmc.getCondVisibility("System.Platform.Windows")
                    dm_level = _get_setting_int("dm_safe_level", default=0, max_val=3)
                    result = (dm_resolver._dm_play(value, dm_level=dm_level) if is_win
                              else dm_resolver._dm_play_android(value, dm_level=dm_level))
                    if result and result.get("url"):
                        stream_url = result["url"]
                        hd = result.get("headers", {})
                        if hd:
                            header_str = "&".join("{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in hd.items())
                        mt = result.get("mime", "")
                        if "mpegURL" in mt or ".m3u8" in stream_url.lower():
                            is_m3u8 = True
                            mime_type = "application/x-mpegURL"
                except Exception:
                    pass

        elif url_type == "web_page":
            # yt-dlp soporta cientos de webs
            if ytdlp_resolver.is_available():
                info = ytdlp_resolver.resolve_full(value)
                if info and info.get("url"):
                    stream_url = info["url"]
                    h = info.get("headers", {})
                    if h:
                        header_str = "&".join("{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in h.items())
                    proto = info.get("protocol", "")
                    if "m3u8" in proto or ".m3u8" in stream_url.lower():
                        is_m3u8 = True
                        mime_type = "application/x-mpegURL"
                    elif ".mpd" in stream_url.lower():
                        is_mpd = True
                        mime_type = "application/dash+xml"

        # Construir ListItem y devolver a Kodi
        if stream_url:
            kodi_url = stream_url
            if header_str and not is_m3u8 and not is_mpd:
                kodi_url = "{0}|{1}".format(stream_url, header_str)

            li = xbmcgui.ListItem(path=kodi_url)
            if mime_type:
                li.setMimeType(mime_type)

            if is_mpd:
                li.setProperty("inputstream", "inputstream.adaptive")
                li.setProperty("inputstream.adaptive.manifest_type", "mpd")
                if header_str:
                    li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                    li.setProperty("inputstream.adaptive.stream_headers", header_str)
            elif is_m3u8:
                if header_str:
                    li.setProperty("inputstream", "inputstream.adaptive")
                    li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                    li.setProperty("inputstream.adaptive.stream_headers", header_str)

            li.setProperty("IsPlayable", "true")
            li.setContentLookup(False)
            xbmcplugin.setResolvedUrl(handle, True, li)
            return

        # No se pudo resolver
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

    except Exception as e:
        xbmc.log("[StreamNinja API] Error resolviendo URL: " + str(e), xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def scan_videos_dialog():
    """Escanea una web o un canal público de Telegram y permite reproducir."""
    kb = xbmc.Keyboard("", "URL web, Telegram (@canal), Google Docs/Drive o Pastebin")
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    if not url:
        return
    _run_scan(url)


def _run_scan(url):
    """Ejecuta el escaneo para una URL o canal ya conocido."""
    import telegram_scanner

    # Canales de Telegram: flujo propio (acepta @canal, t.me/canal o nombre desnudo)
    if telegram_scanner.is_telegram(url):
        _scan_telegram_flow(url)
        return

    if not url.startswith(("http://", "https://")):
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "Introduce una URL (http:// o https://) o un canal de "
            "Telegram (@canal, t.me/canal).",
        )
        return

    videos = _scan_cache_get(url)
    from_cache = videos is not None

    if not from_cache:
        pdp = xbmcgui.DialogProgress()
        pdp.create("Escaneando vídeos", "Analizando {0}...".format(url[:60]))
        try:
            videos = _scan_with_best_engine(url)
        except Exception as exc:
            xbmc.log(
                "[StreamNinja] Error escaneando {0}: {1}".format(url[:60], exc),
                xbmc.LOGWARNING,
            )
            videos = []
        finally:
            pdp.close()

        if not videos:
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "No se encontraron vídeos en esta página.\n\n"
                "Prueba con otra URL o pega directamente \n"
                "la URL del vídeo.",
            )
            return

        _add_to_scan_history(url, 'web')
        _scan_cache_put(url, videos)

    import html_scanner

    labels = []
    for v in videos:
        parts = [v.get("title") or v.get("url", "")[:60]]
        dur = v.get("duration")
        if dur:
            parts.append(html_scanner.format_duration(dur))
        size = v.get("filesize")
        if size:
            parts.append(html_scanner.format_size(size))
        ext = v.get("ext", "")
        if ext:
            parts.append(ext.upper())
        labels.append(" — ".join(parts))

    title = "Vídeos encontrados ({0}){1}".format(
        len(videos), " — caché" if from_cache else ""
    )
    sel = xbmcgui.Dialog().select(title, labels)
    if sel < 0:
        return

    chosen = videos[sel]
    chosen_url = chosen.get("url", "")
    if chosen_url:
        _add_to_history(chosen_url, label=chosen.get("title"))
        _resolve_and_play(chosen_url)


def _scan_with_best_engine(url):
    """yt-dlp (PC, más completo) o html_scanner para los vídeos; además ResolveURL
    detecta hosters embebidos (streamtape, dood...) que ninguno de los dos reconoce."""
    import html_scanner
    results = []
    if ytdlp_resolver.is_available():
        results = ytdlp_resolver.scan_videos(url)   # [] si falla, nunca lanza

    mod = _get_resolveurl()
    # El HTML solo hace falta para el fallback html_scanner o para scrape de hosters.
    # Si yt-dlp ya resolvió y ResolveURL no está, no se descarga.
    html = ""
    if not results or mod:
        html = html_scanner._download_html(url, html_scanner._DOWNLOAD_TIMEOUT)
    if not results:
        results = html_scanner.scan_page(url, html_content=html)
    if mod and html:
        seen = {r.get("url") for r in results}
        for h in _scrape_hosters(html):
            if h["url"] not in seen:
                seen.add(h["url"])
                results.append(h)
    return results


def _scan_telegram_flow(channel):
    """Escanea un canal público de Telegram con paginación incremental.
    Empieza por las últimas entradas y permite cargar más antiguas a demanda.
    El label de cada enlace es el texto del mensaje (contexto, no solo la URL)."""
    import telegram_scanner
    import html_scanner

    if telegram_scanner.is_private_invite(channel):
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "Es un enlace de invitación a un canal o grupo PRIVADO de Telegram.\n\n"
            "Solo se pueden escanear canales públicos (t.me/nombre).",
        )
        return

    videos = []
    seen = set()
    cursor = None
    first = True

    while True:
        pdp = xbmcgui.DialogProgress()
        pdp.create(
            "Escaneando Telegram",
            "Leyendo las últimas entradas..." if first else "Cargando más antiguas...",
        )
        try:
            batch, cursor = telegram_scanner.scan_channel_paged(channel, before_id=cursor)
        except Exception as exc:
            xbmc.log(
                "[StreamNinja] Error escaneando Telegram {0}: {1}".format(channel[:40], exc),
                xbmc.LOGWARNING,
            )
            batch, cursor = [], None
        finally:
            pdp.close()

        added = 0
        for v in batch:
            u = v.get("url", "")
            if u and u not in seen:
                seen.add(u)
                videos.append(v)
                added += 1

        if not videos:
            # Cubre canal inexistente/vacío y también fallo de red.
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "No se pudieron obtener enlaces de vídeo del canal.\n\n"
                "Verifica que el nombre es correcto y el canal es público "
                "(t.me/nombre), que comparte vídeos y que tienes conexión.",
            )
            return

        if first:
            _add_to_scan_history(channel, 'telegram')
        elif added == 0:
            xbmcgui.Dialog().notification(
                "Telegram", "Sin enlaces nuevos en las entradas anteriores",
                xbmcgui.NOTIFICATION_INFO, 2500,
            )
        first = False

        options = []
        for v in videos:
            parts = [v.get("title") or v.get("url", "")[:60]]
            dur = v.get("duration")
            if dur:
                parts.append(html_scanner.format_duration(dur))
            size = v.get("filesize")
            if size:
                parts.append(html_scanner.format_size(size))
            ext = v.get("ext", "")
            if ext:
                parts.append(ext.upper())
            options.append(" — ".join(parts))

        more_idx = -1
        if cursor:
            more_idx = len(options)
            options.append("[COLOR cyan]⬇ Cargar más antiguos[/COLOR]")

        sel = xbmcgui.Dialog().select(
            "Telegram: {0} enlaces".format(len(videos)), options
        )
        if sel < 0:
            return
        if sel == more_idx:
            continue  # paginar hacia atrás y reabrir la lista acumulada
        chosen = videos[sel]
        chosen_url = chosen.get("url", "")
        if chosen_url:
            _add_to_history(chosen_url, label=chosen.get("title"))
            _resolve_and_play(chosen_url)
        return


# --- BIBLIOTECA DE LA NUBE DEBRID ---

def debrid_library_menu():
    h = _get_handle()
    resolver = _get_debrid()
    if resolver is None:
        xbmcplugin.endOfDirectory(h)
        return
    # list_library() es una llamada de red; sin feedback Kodi solo muestra el
    # spinner y el usuario puede creer que está colgado.
    dp = xbmcgui.DialogProgress()
    dp.create("Mi nube Debrid", "Cargando tu biblioteca...")
    try:
        items = resolver.list_library()
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] biblioteca: {0}".format(e), xbmc.LOGWARNING)
        items = None
    finally:
        dp.close()
    if items is None:
        xbmcgui.Dialog().notification(
            "Debrid", "No se pudo cargar tu nube", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(h)
        return

    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]Tu nube está vacía[/COLOR]")
        li.setArt({"icon": os.path.join(_MEDIA, "url_cloud.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for it in items:
        size_gb = (it.get("size", 0) or 0) / 1e9
        ready = it.get("ready")
        if ready:
            label = "{0}  [COLOR grey]({1:.2f} GB)[/COLOR]".format(
                it.get("filename", "?"), size_gb)
        else:
            label = "[COLOR grey]{0} ({1})[/COLOR]".format(
                it.get("filename", "?"), it.get("status", "procesando"))
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultVideo.png"})
        item_id = it.get("id")
        if ready:
            li.setProperty("IsPlayable", "false")
            li.addContextMenuItems([
                ("Ver archivos",
                 "Container.Update({0})".format(_u(action="debrid_library_files", id=item_id))),
                ("Descargar a disco",
                 "RunPlugin({0})".format(_u(action="debrid_download", id=item_id, title=it.get("filename", "")))),
                ("Borrar de la nube",
                 "RunPlugin({0})".format(_u(action="debrid_library_delete", id=item_id))),
            ])
            url = _u(action="debrid_library_play", id=item_id)
        else:
            url = ""
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def debrid_library_files(item_id):
    h = _get_handle()
    resolver = _get_debrid()
    if resolver is None or not item_id:
        xbmcplugin.endOfDirectory(h)
        return
    try:
        files = resolver.library_files(item_id)
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] archivos: {0}".format(e), xbmc.LOGWARNING)
        files = []
    for idx, f in enumerate(files):
        size_gb = (f.get("size", 0) or 0) / 1e9
        li = xbmcgui.ListItem(
            label="{0}  [COLOR grey]({1:.2f} GB)[/COLOR]".format(f.get("name", "?"), size_gb))
        li.setArt({"icon": "DefaultVideo.png"})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="debrid_library_play", id=item_id, file=idx),
            listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def debrid_library_play(item_id, file_index=None):
    resolver = _get_debrid()
    if resolver is None or not item_id:
        return
    try:
        if file_index is None:
            stream = resolver.resolve_library_item(item_id)
        else:
            stream = resolver.resolve_library_file(item_id, int(file_index))
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] reproducir nube: {0}".format(e), xbmc.LOGWARNING)
        stream = None
    if stream:
        _play_resolved_stream(stream)
    else:
        xbmcgui.Dialog().notification(
            "Debrid", "No se pudo reproducir", xbmcgui.NOTIFICATION_WARNING, 3000)


def debrid_library_delete(item_id):
    if not item_id:
        return
    if not xbmcgui.Dialog().yesno("Debrid", "¿Borrar este elemento de tu nube?"):
        return
    resolver = _get_debrid()
    if resolver is None:
        return
    try:
        resolver.delete_library_item(item_id)
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] borrar nube: {0}".format(e), xbmc.LOGWARNING)
    xbmc.executebuiltin("Container.Refresh")


def debrid_download(item_id, title=""):
    resolver = _get_debrid()
    if resolver is None or not item_id:
        return
    try:
        stream = resolver.resolve_library_item(item_id)
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] descargar nube: {0}".format(e), xbmc.LOGWARNING)
        stream = None
    if not stream:
        xbmcgui.Dialog().notification(
            "Debrid", "No se pudo resolver para descargar",
            xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    title = title or "video"
    ext = os.path.splitext(urllib.parse.urlparse(stream).path)[1].lower()
    if ext not in _STREAM_EXTENSIONS:
        ext = ".mp4"
    dest = _get_download_dest(title, ext)
    if not dest:
        return
    _download_direct_url(stream, dest, title)


# --- GRABADOR DE STREAMS HLS EN DIRECTO ---

def record_stream_dialog():
    """Pide una dirección de vídeo HLS en directo y la graba a disco con el grabador PVR."""
    import pvr_recorder_manager
    kb = xbmc.Keyboard("", "Dirección del vídeo en directo (.m3u8) a grabar")
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    if not url:
        return
    name_kb = xbmc.Keyboard("Grabacion", "Nombre de la grabación")
    name_kb.doModal()
    name = name_kb.getText().strip() if name_kb.isConfirmed() else ""
    pvr_recorder_manager.start_recording_ui(url, name or "Grabacion")


def stop_recordings():
    import pvr_recorder_manager
    pvr_recorder_manager.stop_all_recordings()
