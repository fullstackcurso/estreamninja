﻿# -*- coding: utf-8 -*-
# StreamNinja
# Creado por RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE para mas detalles.
#
# ESTREAMNINJA EXPERIMENTAL:
# EstreamNinja es una versión experimental donde se prueban funcionalidades que, 
# eventualmente, podrían llegar a StreamNinja. Destaca por estar desarrollada
# completamente en español.
# 
# Esta versión no está pensada para ser utilizada por el público general ni por 
# otros desarrolladores: el código carece de los comentarios adecuados, no está pulido
# y contiene elementos muertos o descartables de uso exclusivo para pruebas.
"""
Servidor HTTP local para recibir URLs o texto desde movil o PC.

Inicia un mini servidor en la red local que sirve una pagina web
donde el usuario puede pegar una URL o escribir texto. Al enviar,
Kodi lo recibe y actua (reproduce la URL o usa el texto).

Incluye controles de reproduccion y estado en tiempo real
mediante JSON-RPC de Kodi.

Idea original de RubenSDFA1laberot:
La implementación de un servidor HTTP local efímero que se levanta bajo demanda
para enviar URLs o texto a Kodi y se cierra automáticamente al terminar, sin dejar puertos abiertos ni obligar
al usuario a activar el control HTTP en los ajustes del sistema Kodi.

Si este proyecto te ha gustado, puedes darle una estrella en GitHub.
Si decides utilizar este código en tus propios desarrollos o te inspiras en esta idea original, 
te agradecemos que menciones este proyecto original.

Visita el github https://github.com/fullstackcurso/streamninja para ver el código del addon completo, colaborar o usar la API.
"""
import errno
import ipaddress
import json
import os
import re
import secrets
import socket
import threading
import time as _time
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.error import URLError
from urllib.request import urlopen, Request, build_opener, HTTPRedirectHandler
from urllib.parse import quote, urlparse, parse_qs
try:
    from http.server import ThreadingHTTPServer
except ImportError:
    # Python < 3.7 fallback
    from socketserver import ThreadingMixIn
    class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
        daemon_threads = True

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_PORT_RANGE = 10
_PORT_DEFAULT = 8089
_TIMEOUT_SECONDS = 300  # 5 minutos
# Relay por Internet vía ntfy.sh (pub/sub público). Opt-in: solo si el usuario
# elige "Internet" en los ajustes. El topic actúa como secreto compartido.
_NTFY_DEFAULT_SERVER = "https://ntfy.sh"
_NTFY_TOPIC_PREFIX = "StreamNinja-"
_NTFY_READ_TIMEOUT = 45         # 1.5x el keepalive de ntfy.sh (~30s): detecta conexión muerta
_NTFY_RECONNECT_DELAY = 3       # backoff entre reconexiones si cae el stream
_VALID_URL_SCHEMES = ("http://", "https://", "magnet:", "acestream://")
_PACKET_VERIFY_ID = 0x727562656e73646661316c616265726e74  # native check


def _get_port_start():
    """Lee el puerto base de los ajustes del addon."""
    try:
        val = xbmcaddon.Addon().getSetting('remote_port')
        if val:
            port = int(val)
            if 1024 <= port <= 65535:
                return port
    except (ValueError, RuntimeError):
        pass
    return _PORT_DEFAULT


def _get_bind_ip():
    """IP de escucha del servidor según ajustes. Vacío = todas las interfaces.

    Solo IPv4: el servidor HTTP usa sockets AF_INET, así que una IPv6 ni siquiera
    podría enlazarse. Un valor mal formado se ignora (se escucha en todas las
    interfaces) y se avisa en el log para no degradar la seguridad en silencio.
    """
    try:
        val = (xbmcaddon.Addon().getSetting('remote_ip') or '').strip()
    except (AttributeError, RuntimeError):
        return ''
    if not val:
        return ''
    try:
        if ipaddress.ip_address(val).version == 4:
            return val
    except ValueError:
        pass
    xbmc.log(
        "[StreamNinja/remote] remote_ip no valida ('{0}'): se ignora, el servidor "
        "escuchara en todas las interfaces".format(val),
        xbmc.LOGWARNING,
    )
    return ''

_POLL_INTERVAL_MS = 500


def _get_local_ip():
    """Obtiene la IP local del dispositivo en la red."""
    try:
        ip = xbmc.getIPAddress()
        if ip and ip != "127.0.0.1" and not ip.startswith("0."):
            return ip
    except Exception:
        pass

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.settimeout(0)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            if ip and ip != "127.0.0.1":
                return ip
        finally:
            s.close()
    except Exception:
        pass

    return None


# Historial sincronizado

# Debe coincidir con MAX_HISTORY de url_player.py (mismo url_history.json).
_MAX_HISTORY = 50
_history_lock = threading.Lock()
_sse_connections = 0
_sse_lock = threading.Lock()
_MAX_SSE = 5

# --- Estado del mando por eventos en vez de polling fijo ---
# Un xbmc.Monitor bumpea _status_version en cada evento de reproducción; las
# conexiones SSE esperan en la Condition y empujan al instante (vs sleep de 2s).
_SSE_HEARTBEAT = 1.5       # tope de espera: refresca la barra de progreso
_SSE_MIN_INTERVAL = 0.25   # floor anti-ráfaga: caps la frecuencia de push/RPC
_status_version = 0
_status_cv = threading.Condition()
_remote_monitor = None
_monitor_lock = threading.Lock()


def _bump_status(reason=""):
    """Incrementa la versión de estado y despierta a las conexiones SSE vivas.
    Lo llama el Monitor en cada evento de Kodi (y es invocable desde tests)."""
    global _status_version
    with _status_cv:
        _status_version += 1
        _status_cv.notify_all()
    if reason:
        xbmc.log("[StreamNinja/remote] mando: bump por {0}".format(reason),
                 xbmc.LOGDEBUG)


class _RemoteMonitor(xbmc.Monitor):
    """Traduce eventos de reproducción de Kodi en despertares del SSE."""

    def onNotification(self, sender, method, data):
        if method.startswith("Player.") or method == "Application.OnVolumeChanged":
            _bump_status(method)


def _ensure_monitor():
    """Crea (una vez) el Monitor que alimenta el SSE por eventos. Defensivo: si
    falla la creación, devuelve None y el bucle SSE sigue solo con el heartbeat
    (= comportamiento sin eventos). Singleton: vive lo que el invoker del plugin."""
    global _remote_monitor
    if _remote_monitor is not None:
        return _remote_monitor
    with _monitor_lock:
        if _remote_monitor is None:
            try:
                _remote_monitor = _RemoteMonitor()
            except Exception as exc:
                xbmc.log("[StreamNinja/remote] Monitor no disponible: {0}".format(exc),
                         xbmc.LOGWARNING)
    return _remote_monitor

# Preview / oEmbed
_YOUTUBE_OEMBED = "https://www.youtube.com/oembed?url={url}&format=json"
_preview_cache = {}
_preview_lock = threading.Lock()
_PREVIEW_CACHE_MAX = 20


def _history_path():
    """Devuelve la ruta absoluta del archivo de historial."""
    try:
        profile = xbmcaddon.Addon().getAddonInfo("profile")
        folder = xbmcvfs.translatePath(profile)
        # exist_ok=True: el servidor HTTP atiende cada petición en su propio hilo;
        # dos handlers podrían pasar el isdir() a la vez en el primer uso y chocar.
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, "url_history.json")
    except Exception:
        return None


def _load_history():
    """Carga el historial desde disco. Devuelve lista de dicts."""
    path = _history_path()
    if not path or not os.path.isfile(path):
        return []
    try:
        with _history_lock:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_history(entries):
    """Guarda el historial en disco de forma atómica.

    El servicio remoto y la invocación del plugin escriben el MISMO
    url_history.json desde procesos distintos: sin escritura atómica un lector
    podría ver el archivo a medio escribir. Escribimos a un .tmp con nombre
    único por proceso (PID) y hacemos os.replace, que es atómico a nivel de FS;
    el sufijo con PID evita colisionar con el .tmp de nombre fijo del plugin.
    """
    path = _history_path()
    if not path:
        return
    tmp = "{0}.{1}.tmp".format(path, os.getpid())
    try:
        with _history_lock:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(entries[:_MAX_HISTORY], fh, ensure_ascii=False)
            os.replace(tmp, path)
    except OSError:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass


def _detect_platform(url):
    """Devuelve la plataforma oEmbed de la URL, o None."""
    if re.search(r'youtu\.?be|youtube', url, re.I):
        return "youtube"
    if re.search(r'dailymotion\.com|dai\.ly', url, re.I):
        return "dailymotion"
    if re.search(r'vimeo\.com', url, re.I):
        return "vimeo"
    return None


def _is_public_url(url):
    """True solo si el host resuelve a IP(s) públicas. Cierra el SSRF del /preview:
    un cliente del servidor LAN no puede hacer que Kodi sondee IPs internas."""
    try:
        host = urlparse(url).hostname
        if not host:
            return False
        for info in socket.getaddrinfo(host, None):
            ip = ipaddress.ip_address(info[4][0])
            if (ip.is_private or ip.is_loopback or ip.is_link_local
                    or ip.is_reserved or ip.is_multicast or ip.is_unspecified):
                return False
        return True
    except Exception:
        return False


class _NoPrivateRedirect(HTTPRedirectHandler):
    """Revalida cada salto de redirect: un 3xx no puede apuntar a una IP interna
    (cierra el SSRF por redirect)."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not _is_public_url(newurl):
            raise URLError("redirect a destino no permitido")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_safe_opener = build_opener(_NoPrivateRedirect())


def _fetch_og_meta(url):
    """Descarga los primeros 50KB de HTML y extrae Open Graph meta tags.
    Solo URLs con host público (anti-SSRF) y sin redirects a IPs internas."""
    if not _is_public_url(url):
        return None
    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; Kodi)"})
        with _safe_opener.open(req, timeout=4) as resp:
            html = resp.read(51200).decode("utf-8", errors="ignore")
        # Patron flexible; soporta content antes o despues de property
        og_title = re.search(
            r'<meta\s+[^>]*?(?:property|name)=["\']og:title["\'][^>]*?content=["\']([^"\']+)',
            html, re.I
        ) or re.search(
            r'<meta\s+[^>]*?content=["\']([^"\']+)["\'][^>]*?(?:property|name)=["\']og:title["\']',
            html, re.I
        )
        og_image = re.search(
            r'<meta\s+[^>]*?(?:property|name)=["\']og:image["\'][^>]*?content=["\']([^"\']+)',
            html, re.I
        ) or re.search(
            r'<meta\s+[^>]*?content=["\']([^"\']+)["\'][^>]*?(?:property|name)=["\']og:image["\']',
            html, re.I
        )
        og_site = re.search(
            r'<meta\s+[^>]*?(?:property|name)=["\']og:site_name["\'][^>]*?content=["\']([^"\']+)',
            html, re.I
        ) or re.search(
            r'<meta\s+[^>]*?content=["\']([^"\']+)["\'][^>]*?(?:property|name)=["\']og:site_name["\']',
            html, re.I
        )
        # Fallback al <title> si no hay og:title
        if not og_title:
            og_title = re.search(r'<title[^>]*>([^<]+)</title>', html, re.I)
        title = og_title.group(1).strip() if og_title else ""
        thumb = og_image.group(1).strip() if og_image else ""
        site = og_site.group(1).strip() if og_site else ""
        if not title and not thumb:
            return None
        return {
            "title": title,
            "thumbnail": thumb,
            "author": "",
            "provider": site,
            "duration": None,
        }
    except Exception:
        return None


def _fetch_preview(url):
    """Obtiene metadatos de preview: oEmbed (YouTube) o Open Graph (resto)."""
    with _preview_lock:
        if url in _preview_cache:
            return _preview_cache[url]

    result = None

    # Intentar oEmbed para YouTube (mas rapido y fiable)
    platform = _detect_platform(url)
    if platform == "youtube":
        endpoint = _YOUTUBE_OEMBED.format(url=quote(url, safe=""))
        try:
            req = Request(endpoint, headers={"User-Agent": "Kodi/StreamNinja"})
            with urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            result = {
                "title": data.get("title", ""),
                "thumbnail": data.get("thumbnail_url", ""),
                "author": data.get("author_name", ""),
                "provider": data.get("provider_name", platform),
                "duration": data.get("duration"),
            }
        except Exception:
            pass

    # Fallback universal: Open Graph meta tags
    if not result and url.startswith(("http://", "https://")):
        result = _fetch_og_meta(url)

    if result:
        with _preview_lock:
            if len(_preview_cache) >= _PREVIEW_CACHE_MAX:
                _preview_cache.pop(next(iter(_preview_cache)))
            _preview_cache[url] = result

    return result


def _scan_videos_hybrid(url):
    """Escanea vídeos con el mejor motor disponible.

    Delega a url_player._scan_with_best_engine para evitar duplicación.
    """
    import url_player
    return url_player._scan_with_best_engine(url)


def _kodi_rpc(method, params=None):
    """Ejecuta un comando JSON-RPC de Kodi y devuelve el resultado."""
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params:
        request["params"] = params
    try:
        raw = xbmc.executeJSONRPC(json.dumps(request))
        return json.loads(raw).get("result")
    except Exception:
        return None


def _get_player_status():
    """Obtiene el estado actual del reproductor de Kodi."""
    players = _kodi_rpc("Player.GetActivePlayers")
    if not players:
        return {"playing": False}

    pid = players[0].get("playerid", 0)

    item = _kodi_rpc("Player.GetItem", {"playerid": pid, "properties": ["title"]})
    title = ""
    if item and item.get("item"):
        title = item["item"].get("title") or item["item"].get("label", "")

    props = _kodi_rpc("Player.GetProperties", {
        "playerid": pid,
        "properties": ["speed", "time", "totaltime"]
    })

    speed = 0
    time_str = ""
    total_str = ""
    seconds = 0
    totalseconds = 0
    if props:
        speed = props.get("speed", 0)
        t = props.get("time", {})
        tt = props.get("totaltime", {})
        time_str = "{0:02d}:{1:02d}:{2:02d}".format(
            t.get("hours", 0), t.get("minutes", 0), t.get("seconds", 0)
        )
        total_str = "{0:02d}:{1:02d}:{2:02d}".format(
            tt.get("hours", 0), tt.get("minutes", 0), tt.get("seconds", 0)
        )
        seconds = t.get("hours", 0) * 3600 + t.get("minutes", 0) * 60 + t.get("seconds", 0)
        totalseconds = tt.get("hours", 0) * 3600 + tt.get("minutes", 0) * 60 + tt.get("seconds", 0)

    vol_result = _kodi_rpc("Application.GetProperties", {"properties": ["volume", "muted"]})
    volume = 100
    muted = False
    if vol_result:
        volume = vol_result.get("volume", 100)
        muted = vol_result.get("muted", False)

    percentage = 0
    if totalseconds > 0:
        percentage = round((seconds / totalseconds) * 100, 1)

    status = {
        "playing": True,
        "paused": speed == 0,
        "title": title,
        "time": time_str,
        "totaltime": total_str,
        "seconds": seconds,
        "totalseconds": totalseconds,
        "percentage": percentage,
        "volume": volume,
        "muted": muted,
    }
    status.update(_get_track_status(pid))
    return status


def _norm_stream_value(value, keywords):
    """Valida el valor de setaudio/setsubtitle: una palabra clave permitida
    (next/previous/off/on) o un índice entero >= 0. Devuelve el valor normalizado
    o None si no es válido."""
    if isinstance(value, str) and value in keywords:
        return value
    if isinstance(value, bool):   # bool es subclase de int; no es un índice válido
        return None
    if isinstance(value, int) and value >= 0:
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None


def _track_list(streams):
    """Normaliza la lista de audiostreams/subtitles de Kodi a {index, label}
    para el mando. label prioriza nombre y, si no, idioma o índice."""
    out = []
    for s in streams or []:
        idx = s.get("index", -1)
        label = (s.get("name") or s.get("language")
                 or "Pista {0}".format(idx + 1))
        out.append({"index": idx, "label": label})
    return out


def _get_track_status(pid):
    """Pistas de audio/subtítulos y modos repeat/shuffle. En llamada aparte:
    si falla (player sin soporte), el estado básico no se ve afectado."""
    tracks = _kodi_rpc("Player.GetProperties", {
        "playerid": pid,
        "properties": ["currentaudiostream", "audiostreams",
                       "currentsubtitle", "subtitles", "subtitleenabled",
                       "repeat", "shuffled"],
    }) or {}
    sub_enabled = bool(tracks.get("subtitleenabled", False))
    cur_sub = tracks.get("currentsubtitle") or {}
    return {
        "audiostreams": _track_list(tracks.get("audiostreams")),
        "currentaudio": (tracks.get("currentaudiostream") or {}).get("index", -1),
        "subtitles": _track_list(tracks.get("subtitles")),
        "currentsubtitle": cur_sub.get("index", -1) if sub_enabled else -1,
        "subtitleenabled": sub_enabled,
        "repeat": tracks.get("repeat", "off"),
        "shuffled": bool(tracks.get("shuffled", False)),
    }

def _get_secure():
    """True si el servidor local debe exigir token (ajuste remote_secure)."""
    try:
        return xbmcaddon.Addon().getSetting("remote_secure") == "true"
    except (AttributeError, RuntimeError):
        return False


# Tope de intentos de PIN por sesión de servidor. 8 fallos sobre 10^6 combinaciones
# hacen el brute force inviable; suficiente margen para erratas humanas.
_MAX_PIN_ATTEMPTS = 8


def _get_pin_enabled():
    """True si el emparejamiento por PIN está activo (ajuste remote_pin). Implica
    token, pero el token NO viaja en el QR: se obtiene tras validar el PIN."""
    try:
        return xbmcaddon.Addon().getSetting("remote_pin") == "true"
    except (AttributeError, RuntimeError):
        return False


def _inject_token_script(html, token):
    """Inyecta en el <head> un script que adjunta el token a TODAS las peticiones:
    envuelve fetch (header X-Remote-Token) y EventSource (query ?t=), de modo que la
    página, abierta con ?t=<token>, siga autenticada en sus llamadas posteriores.
    Se concatena (no .format) para no chocar con las llaves del JS."""
    script = (
        "<script>"
        "window.__RT__=" + json.dumps(token) + ";"
        "(function(){"
        "var _f=window.fetch;"
        "window.fetch=function(u,o){o=o||{};"
        "o.headers=Object.assign({},o.headers,{'X-Remote-Token':window.__RT__});"
        "return _f(u,o);};"
        "if(window.EventSource){var _E=window.EventSource;"
        "window.EventSource=function(u,o){"
        "u+=(u.indexOf('?')>=0?'&':'?')+'t='+encodeURIComponent(window.__RT__);"
        "return new _E(u,o);};}"
        "})();"
        "</script>"
    )
    return _insert_in_head(html, script)


def _insert_in_head(html, snippet):
    """Inserta snippet antes de </head> (etiqueta estable); si no existe, tras
    <head ...> (tolera atributos); último recurso, anteponer."""
    if "</head>" in html:
        return html.replace("</head>", snippet + "</head>", 1)
    m = re.search(r"<head[^>]*>", html, re.I)
    if m:
        return html[:m.end()] + snippet + html[m.end():]
    return snippet + html


def _inject_pin_script(html):
    """Modo PIN: el token NO viaja en la URL. Esta capa cliente adjunta el token
    (guardado en sessionStorage) a fetch/EventSource y, si aún no hay token, muestra
    una pantalla para teclear el PIN mostrado en la TV y emparejar vía POST /pair.
    Concatenado (no .format) para no chocar con las llaves del JS."""
    overlay = (
        "<h2>Introduce el PIN</h2>"
        "<p>Aparece en la pantalla de la TV</p>"
        "<input id=\"sn-pin-in\" type=\"tel\" inputmode=\"numeric\" maxlength=\"6\" "
        "autocomplete=\"off\" placeholder=\"------\">"
        "<button id=\"sn-pin-go\">Conectar</button>"
        "<div class=\"err\" id=\"sn-pin-err\"></div>"
    )
    script = (
        "<style>"
        "#sn-pin{position:fixed;inset:0;background:#0d1117;z-index:9999;display:flex;"
        "align-items:center;justify-content:center;flex-direction:column;padding:24px;"
        "text-align:center;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#c9d1d9}"
        "#sn-pin h2{font-size:1.15em;margin:0 0 6px}"
        "#sn-pin p{font-size:.85em;color:#8b949e;margin:0 0 18px}"
        "#sn-pin input{font-size:1.6em;letter-spacing:.3em;text-align:center;width:180px;"
        "padding:10px;border-radius:10px;border:1px solid #30363d;background:#161b22;color:#fff}"
        "#sn-pin button{margin-top:16px;padding:11px 24px;border:0;border-radius:10px;"
        "background:#3fb950;color:#06210f;font-weight:700;font-size:1em;cursor:pointer}"
        "#sn-pin .err{color:#f85149;font-size:.8em;margin-top:12px;min-height:16px}"
        "</style>"
        "<script>"
        "(function(){"
        "var T=sessionStorage.getItem('sn_rt')||'';"
        "window.__RT__=T;"
        "var _f=window.fetch;"
        "window.fetch=function(u,o){o=o||{};"
        "o.headers=Object.assign({},o.headers,{'X-Remote-Token':window.__RT__});"
        "return _f(u,o);};"
        "if(window.EventSource){var _E=window.EventSource;"
        "window.EventSource=function(u,o){"
        "u+=(u.indexOf('?')>=0?'&':'?')+'t='+encodeURIComponent(window.__RT__);"
        "return new _E(u,o);};}"
        "if(T)return;"
        "function build(){"
        "var d=document.createElement('div');d.id='sn-pin';"
        "d.innerHTML='" + overlay + "';"
        "document.body.appendChild(d);"
        "var inp=document.getElementById('sn-pin-in');"
        "var err=document.getElementById('sn-pin-err');"
        "try{inp.focus();}catch(e){}"
        "function go(){"
        "var p=(inp.value||'').trim();"
        "if(!/^[0-9]{4,6}$/.test(p)){err.textContent='PIN de 6 digitos';return;}"
        "_f('/pair',{method:'POST',headers:{'Content-Type':'application/json'},"
        "body:JSON.stringify({pin:p})}).then(function(r){"
        "return r.json().then(function(j){return {s:r.status,j:j};});"
        "}).then(function(o){"
        "if(o.s===200&&o.j.token){sessionStorage.setItem('sn_rt',o.j.token);location.reload();}"
        "else{err.textContent=((o.j&&o.j.error)||'Error')"
        "+((o.j&&o.j.remaining!=null)?(' ('+o.j.remaining+' intentos)'):'');"
        "inp.value='';try{inp.focus();}catch(e){}}"
        "}).catch(function(){err.textContent='Sin conexion';});"
        "}"
        "document.getElementById('sn-pin-go').addEventListener('click',go);"
        "inp.addEventListener('keydown',function(e){if(e.key==='Enter')go();});"
        "}"
        "if(document.readyState==='loading')"
        "document.addEventListener('DOMContentLoaded',build);else build();"
        "})();"
        "</script>"
    )
    return _insert_in_head(html, script)


class _RemoteHandler(BaseHTTPRequestHandler):
    """Maneja peticiones GET (pagina, estado) y POST (URL, controles)."""

    # Timeout de socket por operacion; un cliente que abre la conexion y no
    # completa el body (lento o malicioso) liberaria el hilo en 15s en vez de
    # colgarlo. Holgado frente a la cadencia del SSE (~1.75s por evento).
    timeout = 15

    def log_message(self, fmt, *args):
        """Redirige logs del servidor HTTP al log de Kodi, redactando el token de
        seguridad (?t=) y a nivel DEBUG para no inundar ni filtrar el log."""
        try:
            msg = (fmt % args).replace("\x00", "")
            msg = re.sub(r"([?&]t=)[^ &\"]+", r"\1***", msg)
            xbmc.log("[StreamNinja/remote] {0}".format(msg), xbmc.LOGDEBUG)
        except Exception:
            pass

    def _check_token(self):
        """En modo seguro exige el token (header X-Remote-Token o query ?t=).
        En modo PIN, la página y /pair son accesibles sin token (el token se
        obtiene tras validar el PIN); el resto exige token. En modo normal pasa."""
        srv = self.server
        if not getattr(srv, "_auth", False):
            return True
        if getattr(srv, "pin_required", False):
            route = self.path.split("?")[0]
            if route in ("/", "", "/pair"):
                return True
        t = self.headers.get("X-Remote-Token", "").strip()
        if not t:
            t = parse_qs(urlparse(self.path).query).get("t", [""])[0]
        if not t:
            return False
        return secrets.compare_digest(t, srv.token)

    def _reject_unauthorized(self):
        body = b'{"error":"No autorizado"}'
        self.send_response(403)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _dispatch_error(self, exc):
        """Una excepción no controlada en un handler no debe dejar la petición sin
        respuesta (el cliente vería la conexión cortada). Devuelve 500; si la
        respuesta ya se había iniciado (p.ej. SSE en curso), el envío fallará y
        solo queda registrar."""
        xbmc.log("[StreamNinja/remote] Error en {0}: {1}".format(
            self.path.split("?")[0], exc), xbmc.LOGWARNING)
        try:
            self._json_response(500, {"error": "Error interno del servidor"})
        except Exception:
            pass

    def do_GET(self):
        if not self._check_token():
            self._reject_unauthorized()
            return
        route = self.path.split("?")[0]
        try:
            if route == "/" or route == "":
                self._serve_html()
            elif route == "/status":
                self._serve_status()
            elif route == "/events":
                self._serve_sse()
            elif route == "/history":
                self._serve_history()
            else:
                self.send_response(404)
                self.end_headers()
        except Exception as exc:
            self._dispatch_error(exc)

    def do_POST(self):
        if not self._check_token():
            self._reject_unauthorized()
            return
        route = self.path.split("?")[0]
        try:
            if route == "/send":
                self._handle_send()
            elif route == "/pair":
                self._handle_pair()
            elif route == "/control":
                self._handle_control()
            elif route == "/toggle-keep-alive":
                self._handle_toggle_keep_alive()
            elif route == "/history/clear":
                self._handle_history_clear()
            elif route == "/history/remove":
                self._handle_history_remove()
            elif route == "/preview":
                self._handle_preview()
            elif route == "/scan":
                self._handle_scan()
            elif route == "/scan-telegram":
                self._handle_scan_telegram()
            else:
                self.send_response(404)
                self.end_headers()
        except Exception as exc:
            self._dispatch_error(exc)

    def _serve_html(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        html = self.server.html_page
        if getattr(self.server, "pin_required", False):
            html = _inject_pin_script(html)
        elif getattr(self.server, "secure", False):
            html = _inject_token_script(html, self.server.token)
        self.wfile.write(html.encode("utf-8"))

    def _handle_pair(self):
        """Valida el PIN y, si es correcto, entrega el token de sesión. Tope de
        intentos por servidor para frenar fuerza bruta; comparación en tiempo
        constante. Solo disponible cuando el modo PIN está activo."""
        srv = self.server
        if not getattr(srv, "pin_required", False) or not srv.pin:
            self._json_response(404, {"error": "Emparejamiento no disponible"})
            return
        data = self._read_json_body()
        if data is None:
            return
        received = str(data.get("pin", "")).strip()
        with srv.pin_lock:
            if srv.pin_attempts >= _MAX_PIN_ATTEMPTS:
                self._json_response(
                    429, {"error": "Demasiados intentos. Reinicia el servidor."})
                return
            if received and secrets.compare_digest(srv.pin, received):
                self._json_response(200, {"ok": True, "token": srv.token})
                return
            srv.pin_attempts += 1
            self._json_response(403, {
                "error": "PIN incorrecto",
                "remaining": max(0, _MAX_PIN_ATTEMPTS - srv.pin_attempts),
            })

    def _serve_status(self):
        status = _get_player_status()
        self._json_response(200, status)

    def _handle_send(self):
        data = self._read_json_body()
        if data is None:
            return

        url = data.get("url") or data.get("text") or ""
        if not isinstance(url, str) or not url.strip():
            self._json_response(400, {"error": "Campo vacio o no valido"})
            return
        url = url.strip()

        if self.server.mode == "url":
            # Un hash AceStream de 40 hex pelado (sin esquema) se normaliza a
            # acestream:// para que pase la validación, igual que en los addons hermanos.
            if len(url) == 40 and all(c in "0123456789abcdefABCDEF" for c in url):
                url = "acestream://" + url.lower()
            valid_schemes = ("http://", "https://", "rtmp://", "rtsp://",
                            "magnet:", "acestream://")
            if not url.lower().startswith(valid_schemes):
                self._json_response(400, {"error": "URL no valida. Esquemas soportados: http, magnet, acestream"})
                return

        self.server.received_url = url
        if self.server.keep_alive and self.server.mode == "url":
            msg = "URL recibida. Reproduciendo en Kodi..."
            self._json_response(200, {"ok": True, "message": msg, "keepAlive": True})
            import url_player

            def _play_received():
                # El thread daemon no pasa por el try/except del router de
                # default.py: sin esto, un fallo de reproducción moriría mudo.
                try:
                    url_player.play_url_action(url)
                except Exception as exc:
                    xbmc.log("[StreamNinja/remote] Error reproduciendo URL recibida: {0}".format(exc),
                             xbmc.LOGWARNING)

            threading.Thread(target=_play_received, daemon=True).start()
        else:
            self.server.url_event.set()
            msg = "URL recibida. Reproduciendo en Kodi..." if self.server.mode == "url" else "Texto recibido."
            self._json_response(200, {"ok": True, "message": msg})

    def _handle_control(self):
        data = self._read_json_body()
        if data is None:
            return

        action = data.get("action", "")
        result = False

        if action == "playpause":
            players = _kodi_rpc("Player.GetActivePlayers")
            if players:
                pid = players[0].get("playerid", 0)
                _kodi_rpc("Player.PlayPause", {"playerid": pid})
                result = True

        elif action == "stop":
            players = _kodi_rpc("Player.GetActivePlayers")
            if players:
                pid = players[0].get("playerid", 0)
                _kodi_rpc("Player.Stop", {"playerid": pid})
                result = True

        elif action == "volup":
            vol = _kodi_rpc("Application.GetProperties", {"properties": ["volume"]})
            if vol:
                new_vol = min(100, vol.get("volume", 50) + 5)
                _kodi_rpc("Application.SetVolume", {"volume": new_vol})
                result = True

        elif action == "voldown":
            vol = _kodi_rpc("Application.GetProperties", {"properties": ["volume"]})
            if vol:
                new_vol = max(0, vol.get("volume", 50) - 5)
                _kodi_rpc("Application.SetVolume", {"volume": new_vol})
                result = True

        elif action == "mute":
            _kodi_rpc("Application.SetMute", {"mute": "toggle"})
            result = True

        elif action == "seek":
            value = data.get("value")
            if value is not None:
                try:
                    pct = max(0, min(100, float(value)))
                except (ValueError, TypeError):
                    self._json_response(400, {"error": "Valor de seek no numerico"})
                    return
                players = _kodi_rpc("Player.GetActivePlayers")
                if players:
                    pid = players[0].get("playerid", 0)
                    _kodi_rpc("Player.Seek", {
                        "playerid": pid,
                        "value": {"percentage": pct},
                    })
                    result = True

        elif action in ("previous", "next"):
            players = _kodi_rpc("Player.GetActivePlayers")
            if players:
                pid = players[0].get("playerid", 0)
                _kodi_rpc("Player.GoTo", {"playerid": pid, "to": action})
                result = True

        elif action == "setaudio":
            stream = _norm_stream_value(data.get("value"), ("next", "previous"))
            if stream is None:
                self._json_response(400, {"error": "Valor de audio no valido"})
                return
            players = _kodi_rpc("Player.GetActivePlayers")
            if players:
                pid = players[0].get("playerid", 0)
                _kodi_rpc("Player.SetAudioStream", {"playerid": pid, "stream": stream})
                result = True

        elif action == "setsubtitle":
            sub = _norm_stream_value(data.get("value"), ("off", "on", "next", "previous"))
            if sub is None:
                self._json_response(400, {"error": "Valor de subtitulo no valido"})
                return
            players = _kodi_rpc("Player.GetActivePlayers")
            if players:
                pid = players[0].get("playerid", 0)
                params = {"playerid": pid, "subtitle": sub}
                if sub != "off":
                    params["enable"] = True
                _kodi_rpc("Player.SetSubtitle", params)
                result = True

        elif action == "repeat":
            mode = data.get("value")
            if mode not in ("off", "one", "all"):
                self._json_response(400, {"error": "Modo de repeticion no valido"})
                return
            players = _kodi_rpc("Player.GetActivePlayers")
            if players:
                pid = players[0].get("playerid", 0)
                _kodi_rpc("Player.SetRepeat", {"playerid": pid, "repeat": mode})
                result = True

        elif action == "shuffle":
            on = data.get("value")
            if not isinstance(on, bool):
                self._json_response(400, {"error": "Valor de shuffle no valido"})
                return
            players = _kodi_rpc("Player.GetActivePlayers")
            if players:
                pid = players[0].get("playerid", 0)
                _kodi_rpc("Player.SetShuffle", {"playerid": pid, "shuffle": on})
                result = True

        if result:
            self._json_response(200, {"ok": True})
        else:
            self._json_response(400, {"error": "Accion no reconocida o sin reproductor activo"})

    def _read_json_body(self):
        """Lee y parsea el body JSON. Devuelve dict o None si error."""
        try:
            content_length = int(self.headers.get("Content-Length", 0))
        except (ValueError, TypeError):
            self._json_response(400, {"error": "Content-Length no valido"})
            return None
        # <= 0 también rechaza un Content-Length negativo; rfile.read(-1) leería
        # hasta EOF, saltándose el tope de tamaño.
        if content_length <= 0 or content_length > 4096:
            self._json_response(400, {"error": "Datos no validos"})
            return None

        body = self.rfile.read(content_length)
        try:
            parsed = json.loads(body.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._json_response(400, {"error": "JSON no valido"})
            return None
        if not isinstance(parsed, dict):
            self._json_response(400, {"error": "Se esperaba un objeto JSON"})
            return None
        return parsed

    def _json_response(self, code, obj):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def _handle_toggle_keep_alive(self):
        self.server.keep_alive = not self.server.keep_alive
        self._json_response(200, {
            "ok": True,
            "keepAlive": self.server.keep_alive,
        })

    def _serve_sse(self):
        """Sirve Server-Sent Events con estado del reproductor."""
        global _sse_connections
        with _sse_lock:
            if _sse_connections >= _MAX_SSE:
                self._json_response(429, {"error": "Demasiadas conexiones SSE"})
                return
            _sse_connections += 1
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            _ensure_monitor()   # activa los despertares por evento (defensivo)
            while True:
                # Capturar la versión ANTES de leer/empujar; si llega un evento
                # durante el push o el floor, wait_for lo ve y no se pierde.
                last_seen = _status_version
                status = _get_player_status()
                payload = "data: " + json.dumps(status) + "\n\n"
                self.wfile.write(payload.encode("utf-8"))
                self.wfile.flush()
                _time.sleep(_SSE_MIN_INTERVAL)   # floor anti-ráfaga
                with _status_cv:
                    _status_cv.wait_for(
                        lambda: _status_version != last_seen,
                        timeout=_SSE_HEARTBEAT,
                    )
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            with _sse_lock:
                _sse_connections -= 1

    def _serve_history(self):
        entries = _load_history()
        self._json_response(200, {"history": entries})

    def _handle_history_clear(self):
        # Drenar body sin error de formato (evita doble respuesta)
        try:
            cl = int(self.headers.get("Content-Length", 0))
            if 0 < cl <= 4096:
                self.rfile.read(cl)
        except Exception:
            pass
        _save_history([])
        self._json_response(200, {"ok": True})

    def _handle_history_remove(self):
        data = self._read_json_body()
        if data is None:
            return
        url = data.get("url")
        if not isinstance(url, str) or not url.strip():
            self._json_response(400, {"error": "URL vacia o no valida"})
            return
        url = url.strip()
        entries = _load_history()
        filtered = [e for e in entries
                    if (e if isinstance(e, str) else e.get("url")) != url]
        _save_history(filtered)
        self._json_response(200, {"ok": True})

    def _handle_preview(self):
        """Devuelve metadatos oEmbed o Open Graph de una URL."""
        data = self._read_json_body()
        if data is None:
            return
        url = data.get("url") or ""
        if not isinstance(url, str) or not url.strip():
            self._json_response(400, {"error": "URL vacia o no valida"})
            return
        url = url.strip()
        # Solo permitir esquemas HTTP/HTTPS para evitar peticiones a redes internas
        if not url.startswith(("http://", "https://")):
            self._json_response(400, {"error": "Solo URLs HTTP/HTTPS"})
            return
        if not _is_public_url(url):
            self._json_response(400, {"error": "URL no permitida (host privado/interno)"})
            return
        meta = _fetch_preview(url)
        if meta:
            self._json_response(200, {"ok": True, "preview": meta})
        else:
            platform = _detect_platform(url)
            self._json_response(200, {"ok": True, "preview": None, "platform": platform})

    def _handle_scan(self):
        """Escanea una URL en busca de vídeos y devuelve la lista."""
        data = self._read_json_body()
        if data is None:
            return
        url = data.get("url") or ""
        if not isinstance(url, str) or not url.strip():
            self._json_response(400, {"error": "URL vacia o no valida"})
            return
        url = url.strip()
        if not url.startswith(("http://", "https://")):
            self._json_response(400, {"error": "Solo URLs HTTP/HTTPS"})
            return
        if not _is_public_url(url):
            self._json_response(400, {"error": "URL no permitida (host privado/interno)"})
            return
        try:
            videos = _scan_videos_hybrid(url)
        except Exception as exc:
            xbmc.log(
                "[StreamNinja/remote] Error escaneando {0}: {1}".format(url[:60], exc),
                xbmc.LOGWARNING,
            )
            self._json_response(200, {"ok": True, "videos": [], "count": 0})
            return
        import html_scanner
        formatted = []
        for v in videos[:50]:
            formatted.append({
                "title": v.get("title") or v.get("url", "")[:60],
                "url": v.get("url", ""),
                "duration": html_scanner.format_duration(v.get("duration")),
                "filesize": html_scanner.format_size(v.get("filesize")),
                "ext": v.get("ext", ""),
            })
        self._json_response(200, {
            "ok": True,
            "videos": formatted,
            "count": len(formatted),
        })

    def _handle_scan_telegram(self):
        """Escanea un canal público de Telegram. A diferencia del escaneo web,
        pagina: el cliente reenvía 'before_id' para pedir mensajes más antiguos."""
        data = self._read_json_body()
        if data is None:
            return
        channel = (data.get("url") or data.get("channel") or "").strip()
        if not channel:
            self._json_response(400, {"error": "Escribe un canal: @canal o t.me/canal"})
            return
        import telegram_scanner
        if telegram_scanner.is_private_invite(channel):
            self._json_response(400, {
                "error": "Es un canal o grupo PRIVADO de Telegram; no se puede escanear."})
            return
        before_id = data.get("before_id")
        if before_id is not None:
            # El cursor que emitimos siempre es un ID de mensaje numérico. Si llega
            # otra cosa, ignorarlo; es el único dato del cliente que acaba en la URL
            # saliente de t.me, así que no dejamos colar texto arbitrario.
            before_id = str(before_id)
            if not before_id.isdigit():
                before_id = None
        try:
            videos, cursor = telegram_scanner.scan_channel_paged(
                channel, before_id=before_id)
        except Exception as exc:
            xbmc.log(
                "[StreamNinja/remote] Error escaneando Telegram {0}: {1}".format(
                    channel[:40], exc),
                xbmc.LOGWARNING,
            )
            self._json_response(200, {"ok": True, "videos": [], "count": 0, "before_id": None})
            return
        import html_scanner
        formatted = []
        for v in videos:
            formatted.append({
                "title": v.get("title") or v.get("url", "")[:60],
                "url": v.get("url", ""),
                "duration": html_scanner.format_duration(v.get("duration")),
                "filesize": html_scanner.format_size(v.get("filesize")),
                "ext": v.get("ext", ""),
            })
        self._json_response(200, {
            "ok": True,
            "videos": formatted,
            "count": len(formatted),
            "before_id": cursor,
        })


class _RemoteServer(ThreadingHTTPServer):
    """HTTPServer multihilo con atributos extra para comunicacion entre threads."""

    daemon_threads = True
    allow_reuse_address = True  # Permite re-bind rapido tras cierre del addon

    def __init__(self, address, handler_class, mode="url", secure=False, pin=False):
        global _sse_connections
        # Resetear contador SSE para evitar conexiones fantasma de sesiones anteriores
        with _sse_lock:
            _sse_connections = 0
        self.received_url = None
        self.url_event = threading.Event()
        self.mode = mode
        self.keep_alive = False
        self.secure = secure
        self.pin_required = pin
        # _auth: se exige token si hay modo seguro o PIN (en PIN el token no viaja
        # en la URL, se entrega tras validar el PIN).
        self._auth = secure or pin
        self.token = secrets.token_urlsafe(16) if self._auth else None
        self.pin = "{0:06d}".format(secrets.randbelow(1000000)) if pin else None
        self.pin_attempts = 0
        self.pin_lock = threading.Lock()
        self.html_page = _HTML_URL if mode == "url" else _HTML_TEXT
        ThreadingHTTPServer.__init__(self, address, handler_class)


def _try_start_server(mode="url", secure=False, pin=False):
    """Inicia el servidor en el primer puerto libre del rango.

    Devuelve (server, port). Si la IP configurada no es asignable en este equipo
    devuelve (None, -1) para que el llamador lo distinga de 'puertos ocupados'
    (None, 0): ningún puerto funcionaría, así que falla rápido sin recorrer todos.
    """
    bind_ip = _get_bind_ip()
    port_start = _get_port_start()
    port_end = port_start + _PORT_RANGE
    for port in range(port_start, port_end + 1):
        try:
            server = _RemoteServer((bind_ip, port), _RemoteHandler, mode, secure, pin)
            return server, port
        except OSError as exc:
            if exc.errno == errno.EADDRNOTAVAIL:
                return None, -1
            continue
    return None, 0


def _qr_remote_enabled():
    """Devuelve True si el usuario ha activado el QR en Ajustes > General."""
    try:
        return xbmcaddon.Addon().getSetting("enable_qr_remote") == "true"
    except RuntimeError:
        return False


class _QRServerDialog(xbmcgui.WindowDialog):
    """Ventana modal con código QR para el servidor remoto de StreamNinja.

    Muestra la dirección IP, un código QR escaneable y un temporizador de
    cuenta atrás. El bucle de polling corre en un hilo daemon independiente
    para no bloquear el hilo de la interfaz de Kodi.

    Una vez que se recibe la URL, o el usuario cancela, el hilo de polling
    llama a self.close() y la ventana desaparece. El llamador consulta
    los atributos públicos al volver de doModal() y debe invocar dispose()
    para liberar el PNG temporal.

    Atributos públicos (de solo lectura tras doModal):
        received  -- Texto/URL recibida, o None si se canceló o expiró.
        canceled  -- True si el usuario cerró la ventana manualmente.
        timed_out -- True si se agotó el tiempo sin URL ni cancelación.
    """

    # --- Geometría (1280×720, Kodi escala automáticamente) ---
    _W, _H = 1280, 720
    _PANEL_W, _PANEL_H = 680, 560
    _PANEL_X = (_W - _PANEL_W) // 2   # 300
    _PANEL_Y = (_H - _PANEL_H) // 2   # 80

    # Colores (AARRGGBB)
    _C_TITLE = "0xFFFFFFFF"
    _C_ADDR  = "0xFF58A6FF"   # azul suave, legible sobre fondo oscuro
    _C_DIM   = "0xFF8B949E"

    # Fuentes estándar disponibles en todos los skins de Kodi
    _FONT_H1   = "font20"
    _FONT_BODY = "font16"
    _FONT_SM   = "font14"

    # Acciones de navegación que cierran la ventana.
    # Los identificadores son constantes fijas del protocolo de Kodi.
    _CLOSE_ACTIONS = frozenset([
        xbmcgui.ACTION_PREVIOUS_MENU,   # Escape / tecla Atrás
        xbmcgui.ACTION_NAV_BACK,        # Mando: botón Back
        xbmcgui.ACTION_STOP,            # Mando: botón Stop
    ])

    def __init__(self, server, addr, title, wait_msg, timeout_seconds):
        """Construye la ventana y lanza el hilo de polling.

        Args:
            server:          Instancia de _RemoteServer en ejecución.
            addr:            Dirección completa (ej. ``http://192.168.1.10:8089``).
            title:           Título de la ventana.
            wait_msg:        Texto de estado inicial (ej. "Esperando URL...").
            timeout_seconds: Máximo de segundos antes de auto-cerrar.
        """
        super(_QRServerDialog, self).__init__()

        self._server  = server
        self._addr    = addr
        self._title   = title
        self._wait_msg = wait_msg
        self._timeout = timeout_seconds

        # Estado observable por el llamador tras doModal()
        self.received  = None
        self.canceled  = False
        self.timed_out = False

        self._stop_event = threading.Event()

        # Módulo QR y ruta al PNG temporal. Ambos se inicializan aquí para que
        # dispose() sea seguro incluso si _build_ui() lanza antes de asignarlos.
        self._qrmod   = None
        self._qr_path = None

        self._build_ui()

        # El hilo de polling arranca antes de doModal() para que el contador
        # empiece desde el primer frame visible. Es daemon para no bloquear
        # el proceso si Kodi se cierra de forma abrupta.
        self._poll_thread = threading.Thread(
            target=self._poll_loop,
            daemon=True,
            name="streamninja-qr-poll",
        )
        self._poll_thread.start()

    # --- Construcción de la interfaz ---

    def _build_ui(self):
        """Añade todos los controles a la ventana con coordenadas absolutas."""
        px, py = self._PANEL_X, self._PANEL_Y
        pw, ph = self._PANEL_W, self._PANEL_H

        addon_path = xbmcaddon.Addon().getAddonInfo("path")
        media_dir  = os.path.join(addon_path, "resources", "media")

        # Capa de oscurecimiento sobre el contenido subyacente
        self._bg = xbmcgui.ControlImage(
            0, 0, self._W, self._H,
            os.path.join(media_dir, "transparent.png"),
            aspectRatio=2, colorDiffuse="0xCC000000",
        )
        self.addControl(self._bg)

        # Panel central
        self._panel = xbmcgui.ControlImage(
            px, py, pw, ph,
            os.path.join(media_dir, "white.png"),
            aspectRatio=2, colorDiffuse="0xEE161B22",
        )
        self.addControl(self._panel)

        # --- Título ---
        self._lbl_title = xbmcgui.ControlLabel(
            px, py + 20, pw, 36,
            self._title,
            font=self._FONT_H1,
            textColor=self._C_TITLE,
            alignment=0x00000002,   # XBFONT_CENTER_X
        )
        self.addControl(self._lbl_title)

        # --- Instrucción ---
        self._lbl_instr = xbmcgui.ControlLabel(
            px, py + 68, pw, 28,
            "Abre esta direccion en tu navegador o escanea el QR:",
            font=self._FONT_SM,
            textColor=self._C_DIM,
            alignment=0x00000002,
        )
        self.addControl(self._lbl_instr)

        # --- Dirección IP ---
        self._lbl_addr = xbmcgui.ControlLabel(
            px, py + 100, pw, 36,
            "[B]{0}[/B]".format(self._addr),
            font=self._FONT_BODY,
            textColor=self._C_ADDR,
            alignment=0x00000002,
        )
        self.addControl(self._lbl_addr)

        # --- Imagen QR ---
        # Si segno no está disponible o la generación falla, _qr_path queda
        # en None y la ventana continúa mostrando solo el texto de la IP.
        import qr_generator as _qrmod
        self._qrmod   = _qrmod
        self._qr_path = _qrmod.generate(self._addr)

        qr_size = 256
        qr_x    = px + (pw - qr_size) // 2
        qr_y    = py + 148

        if self._qr_path:
            self._img_qr = xbmcgui.ControlImage(
                qr_x, qr_y, qr_size, qr_size,
                self._qr_path,
                aspectRatio=0,
            )
            self.addControl(self._img_qr)

        # --- Etiqueta bajo el QR ---
        label_y = qr_y + qr_size + 10
        _pin = getattr(self._server, "pin", None)
        scan_text = "Escanea con la camara de tu movil"
        if _pin:
            scan_text = "Escanea y teclea el PIN:  [B]{0}[/B]".format(_pin)
        self._lbl_scan = xbmcgui.ControlLabel(
            px, label_y, pw, 28,
            scan_text,
            font=self._FONT_SM,
            textColor=self._C_DIM,
            alignment=0x00000002,
        )
        self.addControl(self._lbl_scan)

        # --- Estado / cuenta atrás ---
        status_y = label_y + 34
        self._lbl_status = xbmcgui.ControlLabel(
            px, status_y, pw, 28,
            self._wait_msg,
            font=self._FONT_SM,
            textColor=self._C_DIM,
            alignment=0x00000002,
        )
        self.addControl(self._lbl_status)

        # --- Barra de progreso ---
        prog_margin = 60
        self._progress = xbmcgui.ControlProgress(
            px + prog_margin,
            status_y + 36,
            pw - prog_margin * 2,
            12,
        )
        self.addControl(self._progress)
        self._progress.setPercent(0)

    # --- Bucle de polling (hilo daemon) ---

    def _poll_loop(self):
        """Monitoriza el servidor y cierra la ventana cuando corresponde.

        Corre íntegramente en un hilo daemon. setLabel() y setPercent()
        son seguros desde hilos secundarios en las implementaciones de
        Kodi; self.close() también lo es mediante la cola de eventos GUI.
        """
        elapsed = 0.0
        poll_s  = _POLL_INTERVAL_MS / 1000.0

        while not self._stop_event.is_set():
            if self._server.url_event.wait(timeout=poll_s):
                self.received = self._server.received_url
                self.close()
                return

            if self._stop_event.is_set():
                break

            if self._server.keep_alive:
                elapsed = 0.0
                self._lbl_status.setLabel("Servidor fijado — pulsa Atras para cerrar")
                self._progress.setPercent(0)
                continue

            elapsed += poll_s
            if elapsed >= self._timeout:
                self.timed_out = True
                self.close()
                return

            remaining = int(self._timeout - elapsed)
            self._lbl_status.setLabel(
                "{0} ({1}s)".format(self._wait_msg, remaining)
            )
            self._progress.setPercent((elapsed / self._timeout) * 100)

    # --- Eventos de la ventana ---

    def onAction(self, action):
        if action.getId() in self._CLOSE_ACTIONS:
            self.canceled = True
            self._stop_event.set()
            self.close()

    def close(self):
        """Cierra la ventana y señala al hilo de polling que se detenga."""
        self._stop_event.set()
        super(_QRServerDialog, self).close()

    def dispose(self):
        """Libera el PNG temporal del QR.

        Debe invocarse una vez que la ventana ya no es necesaria. Es
        idempotente: llamadas repetidas no producen efectos secundarios.
        """
        if self._qr_path and self._qrmod:
            self._qrmod.cleanup(self._qr_path)
            self._qr_path = None


def _run_server(mode, title, wait_msg):
    """Ciclo comun: inicia servidor, muestra dialogo, espera datos.

    Devuelve el texto/URL recibido o None si se cancelo o expiro.
    Si el ajuste ``enable_qr_remote`` está activo muestra una ventana
    personalizada con código QR; en caso contrario usa DialogProgress.
    """
    bind_ip = _get_bind_ip()
    ip = bind_ip if bind_ip and bind_ip != '0.0.0.0' else _get_local_ip()
    if not ip:
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "No se pudo detectar la IP local.\n\n"
            "Asegurate de estar conectado a una red WiFi o Ethernet."
        )
        return None

    pin = _get_pin_enabled()
    # PIN tiene prioridad sobre el token-en-QR; es la opción más segura.
    secure = _get_secure() and not pin
    server, port = _try_start_server(mode, secure, pin)
    if not server:
        if port == -1:
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "La IP configurada ({0}) no esta disponible en este "
                "dispositivo.\n\nRevisa el ajuste 'IP de escucha del servidor' "
                "o dejalo vacio.".format(bind_ip)
            )
        else:
            port_start = _get_port_start()
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "No se pudo iniciar el servidor.\n\n"
                "Los puertos {0}-{1} estan ocupados.".format(
                    port_start, port_start + _PORT_RANGE
                )
            )
        return None

    # En modo seguro el token viaja en la URL/QR; el primer GET ya autentica y el
    # script inyectado lo propaga al resto de peticiones (fetch + EventSource).
    addr = "http://{0}:{1}".format(ip, port)
    if secure:
        addr += "/?t=" + server.token
    xbmc.log(
        "[StreamNinja/remote] Servidor iniciado en {0} (modo: {1})".format(addr, mode),
        xbmc.LOGINFO,
    )

    http_thread = threading.Thread(target=server.serve_forever, daemon=True)
    http_thread.start()

    if _qr_remote_enabled():
        received, timed_out = _run_server_qr(server, addr, title, wait_msg)
    else:
        received, timed_out = _run_server_text(server, addr, title, wait_msg)

    server.shutdown()
    server.server_close()
    http_thread.join(timeout=3)

    if timed_out:
        xbmcgui.Dialog().notification(
            "StreamNinja", "Tiempo agotado",
            xbmcgui.NOTIFICATION_WARNING, 2000
        )

    return received


def _run_server_qr(server, addr, title, wait_msg):
    """Muestra la ventana con QR y devuelve ``(received, timed_out)``."""
    received = None
    timed_out = False
    dlg = _QRServerDialog(server, addr, title, wait_msg, _TIMEOUT_SECONDS)
    try:
        dlg.doModal()
        received  = dlg.received
        timed_out = dlg.timed_out
    finally:
        dlg.dispose()
    return received, timed_out


def _run_server_text(server, addr, title, wait_msg):
    """Muestra el DialogProgress clásico y devuelve ``(received, timed_out)``."""
    pin_line = ""
    if getattr(server, "pin", None):
        pin_line = "PIN para conectar: [B]{0}[/B]\n\n".format(server.pin)
    pdp = xbmcgui.DialogProgress()
    pdp.create(
        title,
        "Abre esta direccion en tu navegador:\n\n"
        "[B]{0}[/B]\n\n"
        "{1}{2}".format(addr, pin_line, wait_msg)
    )

    received  = None
    elapsed   = 0.0
    timed_out = False

    while elapsed < _TIMEOUT_SECONDS:
        if pdp.iscanceled():
            break

        if server.url_event.wait(timeout=_POLL_INTERVAL_MS / 1000.0):
            received = server.received_url
            break

        if server.keep_alive:
            elapsed = 0.0
            pdp.update(
                0,
                "Abre esta direccion en tu navegador:\n\n"
                "[B]{0}[/B]\n\n"
                "{1}Servidor fijado (pulsa Cancel para cerrar)".format(addr, pin_line)
            )
        else:
            elapsed += _POLL_INTERVAL_MS / 1000.0
            remaining = int(_TIMEOUT_SECONDS - elapsed)
            pdp.update(
                int((elapsed / _TIMEOUT_SECONDS) * 100),
                "Abre esta direccion en tu navegador:\n\n"
                "[B]{0}[/B]\n\n"
                "{1}{2} ({3}s)".format(addr, pin_line, wait_msg, remaining)
            )
    else:
        # El bucle completó todas las iteraciones; tiempo agotado
        timed_out = True

    pdp.close()
    return received, timed_out


# --- RECEPTOR POR INTERNET (relay ntfy) ---

def _get_webremote_mode():
    _LABELS = ["Red local", "Internet"]
    try:
        val = xbmcaddon.Addon().getSetting("webremote_mode") or "0"
        try:
            idx = int(val)
        except ValueError:
            idx = _LABELS.index(val) if val in _LABELS else 0
        return "internet" if idx == 1 else "lan"
    except (AttributeError, RuntimeError):
        return "lan"


def _get_webremote_confirm():
    try:
        return xbmcaddon.Addon().getSetting("webremote_confirm") == "true"
    except (AttributeError, RuntimeError):
        return False


def _get_webremote_server():
    try:
        val = (xbmcaddon.Addon().getSetting("webremote_server") or "").strip().rstrip("/")
        if val.startswith(("http://", "https://")):
            return val
    except (AttributeError, RuntimeError):
        pass
    return _NTFY_DEFAULT_SERVER


def _get_or_create_topic():
    # El topic actúa como secreto; solo quien lo conozca puede enviar a este Kodi.
    try:
        addon = xbmcaddon.Addon()
        topic = addon.getSetting("webremote_topic").strip()
        if not topic:
            topic = _NTFY_TOPIC_PREFIX + secrets.token_hex(8)
            addon.setSetting("webremote_topic", topic)
        return topic
    except (AttributeError, RuntimeError):
        return _NTFY_TOPIC_PREFIX + secrets.token_hex(8)


def _ntfy_stream_thread(server, topic, done_event, holder, stop_event, lock):
    # Conexión de streaming persistente; ntfy mantiene el GET abierto y empuja
    # los mensajes al instante. Un poll repetido agotaría el rate limit anónimo.
    url = "{0}/{1}/json".format(server, topic)
    while not stop_event.is_set():
        try:
            req = Request(url, headers={"User-Agent": "Kodi/StreamNinja"})
            resp = _safe_opener.open(req, timeout=_NTFY_READ_TIMEOUT)
            with lock:
                # stop() pudo dispararse mientras open() bloqueaba; cerramos aquí
                # en vez de entrar al loop y bloquear hasta el timeout de lectura.
                if stop_event.is_set():
                    try:
                        resp.close()
                    except OSError:
                        pass
                    return
                holder["resp"] = resp
            try:
                for raw in resp:
                    if stop_event.is_set():
                        return
                    line = raw.decode("utf-8", errors="ignore").strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except ValueError:
                        continue
                    if not isinstance(obj, dict):
                        continue   # ntfy siempre manda objetos; defensa ante self-hosted/anómalo
                    if obj.get("event") != "message":
                        continue
                    msg = (obj.get("message") or "").strip()
                    if msg:
                        holder["result"] = msg
                        done_event.set()
                        return
            finally:
                with lock:
                    holder["resp"] = None
                try:
                    resp.close()
                except OSError:
                    pass
        except OSError:
            if stop_event.is_set():
                return
        if not stop_event.is_set():
            stop_event.wait(timeout=_NTFY_RECONNECT_DELAY)


class _NtfyAdapter(object):
    """Adaptador para reutilizar _QRServerDialog con el relay ntfy: expone la
    interfaz mínima que la ventana QR espera del servidor local
    (url_event, received_url, keep_alive)."""

    keep_alive = False

    def __init__(self, done_event, holder):
        self.url_event = done_event
        self._holder = holder

    @property
    def received_url(self):
        return self._holder.get("result")


def _run_ntfy(mode, title, wait_msg):
    server = _get_webremote_server()
    topic = _get_or_create_topic()
    sub_url = "{0}/{1}".format(server, topic)

    holder = {"resp": None, "result": None}
    done_event = threading.Event()
    stop_event = threading.Event()
    lock = threading.Lock()
    thread = threading.Thread(
        target=_ntfy_stream_thread,
        args=(server, topic, done_event, holder, stop_event, lock),
        daemon=True,
    )
    thread.start()

    xbmc.log(
        "[StreamNinja/remote] Modo internet escuchando en {0} (modo: {1})".format(sub_url, mode),
        xbmc.LOGINFO,
    )

    received = None
    timed_out = False
    try:
        if _qr_remote_enabled():
            # Reutiliza la ventana QR del servidor local; escanea el QR del topic
            # ntfy y publica desde el móvil sin teclear la dirección.
            dlg = _QRServerDialog(
                _NtfyAdapter(done_event, holder), sub_url, title, wait_msg,
                _TIMEOUT_SECONDS,
            )
            try:
                dlg.doModal()
                received = dlg.received
                timed_out = dlg.timed_out
            finally:
                dlg.dispose()
        else:
            pdp = xbmcgui.DialogProgress()
            pdp.create(
                title,
                "Abre esta direccion en tu movil o PC\ny pulsa Publicar para enviar:\n\n"
                "[B]{0}[/B]\n\n{1}".format(sub_url, wait_msg),
            )
            elapsed = 0.0
            while elapsed < _TIMEOUT_SECONDS:
                if pdp.iscanceled():
                    break
                if done_event.wait(timeout=_POLL_INTERVAL_MS / 1000):
                    received = holder["result"]
                    break
                elapsed += _POLL_INTERVAL_MS / 1000
                remaining = int(_TIMEOUT_SECONDS - elapsed)
                pdp.update(
                    int((elapsed / _TIMEOUT_SECONDS) * 100),
                    "Abre esta direccion en tu movil o PC\ny pulsa Publicar para enviar:\n\n"
                    "[B]{0}[/B]\n\n{1} ({2}s)".format(sub_url, wait_msg, remaining),
                )
            pdp.close()
            timed_out = elapsed >= _TIMEOUT_SECONDS and not received
    finally:
        stop_event.set()
        with lock:
            resp = holder["resp"]
            holder["resp"] = None
        if resp is not None:
            try:
                resp.close()   # desbloquea la lectura del hilo al instante
            except OSError:
                pass
        thread.join(timeout=5)

    if timed_out:
        xbmcgui.Dialog().notification(
            "StreamNinja", "Tiempo agotado", xbmcgui.NOTIFICATION_WARNING, 2000
        )

    return received


def start_remote():
    """Punto de entrada URL: en modo Internet usa el relay ntfy; si no, servidor local."""
    if _get_webremote_mode() == "internet":
        received = _run_ntfy("url", "Enviar URL por internet", "Esperando URL...")
        if received:
            if re.match(r"^[0-9a-fA-F]{40}$", received):
                received = "acestream://" + received.lower()
            if not received.startswith(_VALID_URL_SCHEMES):
                xbmc.log(
                    "[StreamNinja/remote] URL ignorada (esquema invalido): " + received[:80],
                    xbmc.LOGWARNING,
                )
                received = None
    else:
        received = _run_server("url", "Enviar URL desde movil/PC", "Esperando URL...")

    if received:
        if _get_webremote_confirm() and not xbmcgui.Dialog().yesno(
                "StreamNinja", "¿Reproducir la URL recibida?\n\n" + received[:150]):
            return
        xbmcgui.Dialog().notification(
            "StreamNinja", "URL recibida, reproduciendo...",
            xbmcgui.NOTIFICATION_INFO, 2000
        )
        import url_player
        url_player.play_url_action(received)


def receive_text(title="Escribir desde movil/PC"):
    """Punto de entrada texto: en modo Internet usa el relay ntfy; si no, servidor local."""
    if _get_webremote_mode() == "internet":
        received = _run_ntfy("text", title, "Esperando texto...")
    else:
        received = _run_server("text", title, "Esperando texto...")
    if received:
        xbmcgui.Dialog().notification(
            "StreamNinja", "Texto recibido",
            xbmcgui.NOTIFICATION_INFO, 1500
        )
    return received


# HTML embebido (pagina URL)

_HTML_URL = r"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#0d1117">
<meta name="color-scheme" content="dark">
<title>StreamNinja Remote</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  background:#0d1117;color:#c9d1d9;
  min-height:100vh;display:flex;align-items:flex-start;justify-content:center;
  padding:16px;
}
.card{
  background:#161b22;border:1px solid #30363d;border-radius:12px;
  padding:32px 24px;max-width:540px;width:100%;
  box-shadow:0 8px 32px rgba(0,0,0,.4);
}
h1{
  font-size:1.4em;text-align:center;margin-bottom:4px;
  color:#58a6ff;font-weight:600;
}
.sub{
  text-align:center;color:#8b949e;font-size:.85em;margin-bottom:6px;
}
.status-dot{
  display:inline-block;width:8px;height:8px;border-radius:50%;
  background:#484f58;margin-right:6px;vertical-align:middle;
  transition:background .3s;
}
.status-dot.on{background:#3fb950}
.status-bar{
  text-align:center;font-size:.75em;color:#8b949e;margin-bottom:20px;
  min-height:16px;
}
label{
  display:block;font-size:.9em;color:#8b949e;margin-bottom:6px;
}
.badge{
  display:inline-block;font-size:.7em;padding:2px 8px;border-radius:10px;
  margin-left:8px;vertical-align:middle;font-weight:600;
  background:#21262d;color:#8b949e;transition:all .3s;
}
.badge.youtube{background:#2d1117;color:#f85149}
.badge.dailymotion{background:#1a1d2e;color:#58a6ff}
.badge.stream{background:#0d2818;color:#3fb950}
.badge.torrent{background:#2d1f0d;color:#d29922}
.badge.acestream{background:#0d1f2d;color:#39d2e5}
.badge.twitch{background:#24163a;color:#a970ff}
.badge.vimeo{background:#1a2d2e;color:#1ab7ea}
.drop-zone{
  position:relative;
  width:100%;min-height:80px;padding:12px;
  background:#0d1117;color:#c9d1d9;
  border:1px solid #30363d;border-radius:8px;
  font-size:16px;font-family:monospace;
  resize:vertical;outline:none;
  transition:border-color .2s;
}
.drop-zone:focus{border-color:#58a6ff}
.drop-zone::placeholder{color:#484f58}
.drop-zone.dragover{
  border-color:#58a6ff;border-style:dashed;
  background:rgba(88,166,255,.05);
}
.btn-primary{
  display:block;width:100%;padding:14px;margin-top:16px;
  background:#e6edf3;color:#0d1117;
  border:1px solid #d0d7de;border-radius:8px;
  font-size:1em;font-weight:600;cursor:pointer;
  transition:background .15s,border-color .15s;
}
.btn-primary:hover{background:#f0f6fc}
.btn-primary:active{background:#d0d7de;transform:scale(.99)}
.btn-primary:disabled{background:#21262d;color:#484f58;border-color:#21262d;cursor:not-allowed}
.msg{
  margin-top:14px;padding:10px 14px;border-radius:8px;
  font-size:.9em;text-align:center;display:none;
}
.msg.ok{display:flex;align-items:center;justify-content:center;gap:8px;background:#0d2818;color:#3fb950;border:1px solid #238636}
.msg.err{display:block;background:#2d1117;color:#f85149;border:1px solid #da3633}
.check-svg{width:20px;height:20px;flex-shrink:0}
.check-svg circle{stroke:#3fb950;stroke-width:2;fill:none;stroke-dasharray:52;stroke-dashoffset:52;animation:circ .4s ease forwards}
.check-svg path{stroke:#3fb950;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:20;stroke-dashoffset:20;animation:tick .3s .35s ease forwards}
@keyframes circ{to{stroke-dashoffset:0}}
@keyframes tick{to{stroke-dashoffset:0}}

/* --- Controles --- */
.controls{
  display:flex;align-items:center;justify-content:center;gap:6px;flex-wrap:wrap;
  margin-top:18px;padding-top:16px;border-top:1px solid #21262d;
}
.ctrl-btn{
  width:40px;height:40px;border-radius:8px;border:1px solid #30363d;
  background:#0d1117;color:#c9d1d9;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  font-size:1.1em;transition:background .15s,border-color .15s;
}
.ctrl-btn:hover{background:#161b22;border-color:#58a6ff}
.ctrl-btn:active{transform:scale(.93)}
.ctrl-btn svg{width:18px;height:18px;fill:#c9d1d9}
.ctrl-btn.active{border-color:#3fb950}
.ctrl-btn.active svg{fill:#3fb950}
.vol-label{font-size:.7em;color:#8b949e;min-width:32px;text-align:center}
.tracks{margin-top:10px;display:none;flex-direction:column;gap:8px}
.tracks.visible{display:flex}
.track-row{display:flex;align-items:center;gap:8px}
.track-ico{font-size:.66em;font-weight:700;color:#8b949e;min-width:26px;text-align:center}
.track-sel{
  flex:1;min-width:0;background:#0d1117;color:#c9d1d9;border:1px solid #30363d;
  border-radius:8px;padding:7px 8px;font-size:.8em;
}
.track-toggles{display:flex;justify-content:center;gap:6px;margin-top:2px}
.now-playing{
  text-align:center;font-size:.78em;color:#8b949e;margin-top:8px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  max-width:100%;min-height:16px;
}

/* --- Barra de progreso --- */
.progress-container{
  margin-top:8px;padding:0 4px;display:none;
}
.progress-container.visible{display:block}
.progress-times{
  display:flex;justify-content:space-between;
  font-size:.7em;color:#484f58;margin-bottom:4px;font-variant-numeric:tabular-nums;
}
.progress-bar{
  -webkit-appearance:none;appearance:none;width:100%;height:6px;
  background:#21262d;border-radius:3px;outline:none;cursor:pointer;
}
.progress-bar::-webkit-slider-thumb{
  -webkit-appearance:none;appearance:none;
  width:14px;height:14px;border-radius:50%;
  background:#58a6ff;cursor:pointer;
  border:2px solid #0d1117;
  margin-top:-4px;
}
.progress-bar::-moz-range-thumb{
  width:14px;height:14px;border-radius:50%;
  background:#58a6ff;cursor:pointer;
  border:2px solid #0d1117;
}
.progress-bar::-webkit-slider-runnable-track{
  height:6px;border-radius:3px;
}
.progress-bar::-moz-range-track{
  height:6px;border-radius:3px;background:#21262d;
}

/* --- Preview card --- */
.preview-card{
  display:none;margin-top:10px;padding:10px;border-radius:8px;
  background:#0d1117;border:1px solid #30363d;
  gap:10px;align-items:center;
}
.preview-card.visible{display:flex}
.preview-card.loading{display:flex}
.preview-thumb{
  width:100px;min-width:100px;height:56px;border-radius:4px;
  object-fit:cover;background:#21262d;
}
.preview-info{flex:1;overflow:hidden}
.preview-title{
  font-size:.82em;color:#c9d1d9;font-weight:600;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.preview-author{
  font-size:.72em;color:#8b949e;margin-top:2px;
}
.preview-skeleton{
  background:linear-gradient(90deg,#21262d 25%,#30363d 50%,#21262d 75%);
  background-size:400% 100%;animation:shimmer 1.5s infinite;
  border-radius:4px;
}
@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
.preview-skeleton-thumb{width:100px;min-width:100px;height:56px}
.preview-skeleton-text{height:12px;width:70%;margin-bottom:6px}
.preview-skeleton-text2{height:10px;width:45%}

/* --- Historial --- */
.history{margin-top:18px;padding-top:14px;border-top:1px solid #21262d}
.history-header{
  display:flex;align-items:center;justify-content:center;
  position:relative;padding:4px 0;
  cursor:pointer;user-select:none;
}
.history-header span{font-size:.92em;color:#8b949e;display:flex;align-items:center;gap:9px}
.hist-icon{width:22px;height:22px;fill:#6e7681;flex-shrink:0}
.history-header .arrow{
  width:16px;height:16px;fill:#484f58;flex-shrink:0;
  transition:transform .2s;
}
.history-header .arrow.open{transform:rotate(90deg)}
.history-list{
  list-style:none;margin-top:8px;max-height:200px;overflow-y:auto;
}
.history-list.hidden{display:none}
.history-item{
  display:flex;align-items:center;gap:8px;
  padding:8px 10px;margin-bottom:4px;border-radius:6px;
  background:#0d1117;border:1px solid transparent;
  cursor:pointer;transition:border-color .15s;
}
.history-item:hover{border-color:#30363d}
.history-thumb{
  width:60px;height:34px;object-fit:cover;border-radius:3px;
  flex-shrink:0;background:#21262d;
}
.history-info{
  flex:1;min-width:0;display:flex;flex-direction:column;gap:1px;
}
.history-title{
  font-size:.8em;color:#c9d1d9;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.history-date{font-size:.7em;color:#6e7681}
.history-del{
  background:none;border:none;color:#484f58;cursor:pointer;
  font-size:1.05em;line-height:1;padding:3px 6px;border-radius:3px;flex-shrink:0;
  transition:color .15s,background .15s;
}
.history-del:hover{color:#f85149;background:#21262d}
.clear-btn{
  position:absolute;right:0;
  background:none;border:none;cursor:pointer;
  padding:6px;border-radius:4px;line-height:0;
  visibility:hidden;opacity:0;pointer-events:none;
  transition:background .15s,opacity .2s;
}
.clear-btn svg{width:20px;height:20px;fill:#484f58;transition:fill .15s}
.clear-btn:hover{background:#21262d}
.clear-btn:hover svg{fill:#f85149}
#history-section.hist-open .clear-btn{visibility:visible;opacity:1;pointer-events:auto}

.footer{
  text-align:center;color:#484f58;font-size:.75em;margin-top:20px;
}
.keep-alive-btn{
  display:block;margin:8px auto 0;padding:6px 16px;
  background:none;border:1px solid #30363d;border-radius:6px;
  color:#8b949e;font-size:.72em;cursor:pointer;
  transition:all .2s;
}
.keep-alive-btn:hover{border-color:#58a6ff;color:#58a6ff}
.keep-alive-btn.active{border-color:#238636;color:#3fb950;background:#0d2818}

/* --- Tipos compatibles --- */
.compat{margin-top:2px;margin-bottom:4px;text-align:center}
.compat summary{
  display:inline-flex;align-items:center;gap:5px;
  font-size:.75em;color:#8b949e;cursor:pointer;
  list-style:none;user-select:none;
  border:1px solid #30363d;border-radius:20px;
  padding:4px 14px;
  transition:border-color .15s,color .15s;
}
.compat summary:hover{border-color:#444c56;color:#c9d1d9}
.compat summary::-webkit-details-marker{display:none}
.compat-chevron{width:11px;height:11px;fill:currentColor;transition:transform .2s;flex-shrink:0}
details[open].compat .compat-chevron{transform:rotate(180deg)}
.compat-list{
  margin-top:8px;display:flex;flex-wrap:wrap;justify-content:center;
  gap:4px 16px;font-size:.72em;color:#8b949e;
}
.compat-item{display:flex;align-items:center;gap:6px;padding:3px 0}
.compat-item .badge{margin-left:0;font-size:.9em}

/* --- EscaÌner de viÌdeos --- */
.btn-row{display:flex;gap:8px;margin-top:8px}
.btn-ghost{
  flex:1;display:flex;align-items:center;justify-content:center;
  padding:11px 12px;
  background:transparent;border:1px solid #373e47;border-radius:8px;
  color:#c9d1d9;font-size:.9em;font-weight:500;cursor:pointer;
  transition:background .15s,border-color .15s;
}
.btn-ghost:hover{background:#1c2128;border-color:#444c56}
.btn-ghost:active{transform:scale(.98)}
.btn-ghost:disabled{color:#484f58;border-color:#21262d;cursor:not-allowed}
.btn-ghost--tg:hover{border-color:#1e4d6e}
@media(max-width:360px){
  .btn-row{flex-direction:column}
  .btn-ghost{flex:none;width:100%}
}
.tg-hint{font-size:.72em;color:#6e7681;margin-top:6px;display:none}
.scan-more{
  display:block;width:100%;margin-top:8px;padding:9px;
  background:transparent;border:1px solid #373e47;border-radius:8px;
  color:#58a6ff;font-size:.82em;cursor:pointer;
  transition:background .15s,border-color .15s;
}
.scan-more:hover{background:#1c2128;border-color:#444c56}
.scan-more:disabled{color:#484f58;cursor:not-allowed}
.scan-results{margin-top:12px;display:none}
.scan-results.visible{display:block}
.scan-count{font-size:.8em;color:#8b949e;margin-bottom:6px}
.scan-list{list-style:none;max-height:300px;overflow-y:auto}
.scan-item{
  padding:10px 12px;margin-bottom:4px;border-radius:6px;
  background:#0d1117;border:1px solid transparent;
  cursor:pointer;transition:border-color .15s;
}
.scan-item:hover{border-color:#444c56}
.scan-item-title{font-size:.85em;color:#c9d1d9;font-weight:500}
.scan-item-meta{font-size:.72em;color:#8b949e;margin-top:2px}
</style>
</head>
<body>
<div class="card">
  <h1>StreamNinja Remote</h1>
  <p class="sub">Pega una URL para reproducirla en Kodi</p>

  <details class="compat" id="compat-details">
    <summary>
      <svg class="compat-chevron" viewBox="0 0 24 24"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/></svg>
      Enlaces compatibles
    </summary>
    <div class="compat-list">
      <div class="compat-item"><span class="badge youtube">YouTube</span> youtube.com, youtu.be</div>
      <div class="compat-item"><span class="badge dailymotion">Dailymotion</span> dailymotion.com</div>
      <div class="compat-item"><span class="badge twitch">Twitch</span> twitch.tv</div>
      <div class="compat-item"><span class="badge vimeo">Vimeo</span> vimeo.com</div>
      <div class="compat-item"><span class="badge stream">Stream</span> .m3u8, .mp4, .mpd</div>
      <div class="compat-item"><span class="badge torrent">Torrent</span> magnet:, .torrent</div>
      <div class="compat-item"><span class="badge acestream">AceStream</span> acestream://</div>
      <div class="compat-item"><span class="badge">Web</span> cualquier URL</div>
    </div>
  </details>

  <div class="status-bar">
    <span class="status-dot" id="dot"></span>
    <span id="status-text">Conectando...</span>
  </div>

  <label for="url">URL del video <span class="badge" id="badge"></span></label>
  <textarea class="drop-zone" id="url" placeholder="https://youtu.be/dQw4w9WgXcQ&#10;https://ejemplo.com/canal.m3u8&#10;magnet:?xt=urn:btih:...&#10;acestream://abcdef1234..." inputmode="url" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="send" autofocus></textarea>
  <div class="preview-card" id="preview-card">
    <img class="preview-thumb" id="preview-thumb" src="" alt="">
    <div class="preview-info">
      <div class="preview-title" id="preview-title"></div>
      <div class="preview-author" id="preview-author"></div>
    </div>
  </div>
  <button class="btn-primary" id="send" onclick="enviar()">Enviar a Kodi</button>
  <div class="btn-row">
    <button class="btn-ghost" id="scan-btn" onclick="escanear()">Escanear web</button>
    <button class="btn-ghost btn-ghost--tg" id="scan-tg-btn" onclick="escanearTelegram()">Canal Telegram</button>
  </div>
  <div class="tg-hint" id="tg-hint">Solo canales públicos: @canal o t.me/canal</div>
  <div class="msg" id="msg"></div>
  <div class="scan-results" id="scan-results">
    <div class="scan-count" id="scan-count"></div>
    <ul class="scan-list" id="scan-list"></ul>
  </div>

  <div class="controls" id="controls">
    <button class="ctrl-btn" onclick="ctrl('voldown')" title="Vol -">
      <svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3z"/></svg>
    </button>
    <span class="vol-label" id="vol">--</span>
    <button class="ctrl-btn" onclick="ctrl('volup')" title="Vol +">
      <svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0012 7.5v9a4.5 4.5 0 004.5-4.5z"/></svg>
    </button>
    <button class="ctrl-btn" onclick="ctrl('mute')" title="Silenciar" id="mute-btn">
      <svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3z"/></svg>
    </button>
    <div style="width:12px"></div>
    <button class="ctrl-btn" onclick="ctrl('previous')" title="Anterior">
      <svg viewBox="0 0 24 24"><path d="M6 6h2v12H6zm3.5 6 8.5 6V6z"/></svg>
    </button>
    <button class="ctrl-btn" onclick="ctrl('playpause')" title="Play / Pausa" id="pp-btn">
      <svg viewBox="0 0 24 24" id="pp-icon"><polygon points="5,3 19,12 5,21"/></svg>
    </button>
    <button class="ctrl-btn" onclick="ctrl('stop')" title="Stop">
      <svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="1"/></svg>
    </button>
    <button class="ctrl-btn" onclick="ctrl('next')" title="Siguiente">
      <svg viewBox="0 0 24 24"><path d="M16 6h2v12h-2zM6 18l8.5-6L6 6z"/></svg>
    </button>
  </div>
  <div class="now-playing" id="np"></div>
  <div class="progress-container" id="progress-container">
    <div class="progress-times">
      <span id="p-cur">00:00:00</span>
      <span id="p-tot">00:00:00</span>
    </div>
    <input type="range" class="progress-bar" id="progress-bar" min="0" max="100" step="0.1" value="0"
      oninput="this.dataset.seeking='1'" onchange="seekTo(this.value);this.dataset.seeking=''">
  </div>
  <div class="tracks" id="tracks">
    <label class="track-row" id="audio-row" style="display:none">
      <span class="track-ico" title="Audio">AUD</span>
      <select class="track-sel" id="audio-sel" onchange="setTrack('setaudio',this.value)"></select>
    </label>
    <label class="track-row" id="sub-row" style="display:none">
      <span class="track-ico" title="Subtitulos">SUB</span>
      <select class="track-sel" id="sub-sel" onchange="setTrack('setsubtitle',this.value)"></select>
    </label>
    <div class="track-toggles">
      <button class="ctrl-btn" id="rep-btn" onclick="cycleRepeat()" title="Repetir">
        <svg viewBox="0 0 24 24"><path d="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z"/></svg>
      </button>
      <button class="ctrl-btn" id="shuf-btn" onclick="toggleShuffle()" title="Aleatorio">
        <svg viewBox="0 0 24 24"><path d="M10.6 8.4 7.4 5.2 6 6.6l3.2 3.2 1.4-1.4zM3 4v3h3l1.8 1.8 2-2L7 4H3zm14 0v3h-2.2L4 17.8V21h3l10.8-10.8H20v3l4-4-4-4v3z"/></svg>
      </button>
    </div>
  </div>

  <div class="history" id="history-section">
    <div class="history-header" onclick="toggleHistory()">
      <span>
        <svg class="hist-icon" viewBox="0 0 24 24"><path d="M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0 0 13 21a9 9 0 0 0 0-18zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>
        Historial
        <svg class="arrow" id="arrow" viewBox="0 0 24 24"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>
      </span>
      <button class="clear-btn" onclick="event.stopPropagation();clearHistory()" title="Limpiar historial">
        <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
      </button>
    </div>
    <ul class="history-list hidden" id="history-list"></ul>
  </div>

  <p class="footer" id="footer-msg">El servidor se cerrara automaticamente tras recibir la URL.</p>
  <button class="keep-alive-btn" id="keep-alive-btn" onclick="toggleKeepAlive()">Mantener servidor abierto</button>
  <p style="text-align:center;color:#484f58;font-size:.7em;margin-top:8px">Concepto: RubenSDFA1laberot</p>
</div>
<script>
/* --- Deteccion de tipo --- */
var TYPE_MAP=[
  [/youtu\.?be|youtube/i,'YouTube','youtube'],
  [/dailymotion|dai\.ly/i,'Dailymotion','dailymotion'],
  [/twitch\.tv/i,'Twitch','twitch'],
  [/vimeo\.com/i,'Vimeo','vimeo'],
  [/^magnet:\?|\.torrent(\?|$)/i,'Torrent','torrent'],
  [/^acestream:\/\//i,'AceStream','acestream'],
  [/^[0-9a-fA-F]{40}$/,'AceStream','acestream'],
  [/\.m3u8|\.mpd|\.mp4|\.mkv|\.avi|\.ts|\.flv|\.webm|\.mov/i,'Stream','stream']
];
function detectType(u){
  for(var i=0;i<TYPE_MAP.length;i++){
    if(TYPE_MAP[i][0].test(u)) return {label:TYPE_MAP[i][1],cls:TYPE_MAP[i][2]};
  }
  return u?{label:'Web',cls:''}:null;
}
var urlEl=document.getElementById('url');
var badgeEl=document.getElementById('badge');
function updateBadge(){
  var t=detectType(urlEl.value.trim());
  if(t){badgeEl.textContent=t.label;badgeEl.className='badge '+t.cls;}
  else{badgeEl.textContent='';badgeEl.className='badge';}
}
urlEl.addEventListener('input',updateBadge);

/* --- Drag & drop --- */
urlEl.addEventListener('dragover',function(e){
  e.preventDefault();urlEl.classList.add('dragover');
});
urlEl.addEventListener('dragleave',function(){
  urlEl.classList.remove('dragover');
});
urlEl.addEventListener('drop',function(e){
  e.preventDefault();urlEl.classList.remove('dragover');
  var text=e.dataTransfer.getData('text/uri-list')||e.dataTransfer.getData('text/plain')||'';
  if(text){urlEl.value=text.split('\n')[0].trim();updateBadge();}
});

/* --- Auto-paste --- */
(function(){
  var done=false;
  urlEl.addEventListener('focus',function(){
    if(done||urlEl.value.trim()) return;
    done=true;
    if(navigator.clipboard&&navigator.clipboard.readText){
      navigator.clipboard.readText().then(function(t){
        t=t.trim();
        if(t&&(/^(https?:\/\/|magnet:\?|acestream:\/\/)/i.test(t)||/^[0-9a-fA-F]{40}$/.test(t))&&!urlEl.value.trim()){
          urlEl.value=t;updateBadge();
        }
      }).catch(function(){});
    }
  });
})();

/* --- Historial (sincronizado con servidor) --- */
function fetchHistory(){
  fetch('/history').then(function(r){return r.json()}).then(function(d){
    renderHistory(d.history||[]);
  }).catch(function(){renderHistory([]);});
}
function renderHistory(h){
  var list=document.getElementById('history-list');
  var section=document.getElementById('history-section');
  list.innerHTML='';
  if(!h.length){
    section.style.display='none';
    section.classList.remove('hist-open');
    list.classList.add('hidden');
    document.getElementById('arrow').classList.remove('open');
    return;
  }
  section.style.display='';
  h.forEach(function(item){
    var u=typeof item==='string'?item:item.url;
    var label=(item.label&&item.label!==u)?item.label:u;
    var thumb=item.thumb||'';
    var date=item.date||'';
    var li=document.createElement('li');
    li.className='history-item';li.title=u;
    if(thumb){
      var img=document.createElement('img');
      img.src=thumb;img.className='history-thumb';img.loading='lazy';img.alt='';
      img.onerror=function(){this.style.display='none';};
      li.appendChild(img);
    }
    var info=document.createElement('div');
    info.className='history-info';
    var titleEl=document.createElement('span');
    titleEl.className='history-title';
    titleEl.textContent=label.length>70?label.slice(0,67)+'...':label;
    info.appendChild(titleEl);
    if(date){
      var dateEl=document.createElement('span');
      dateEl.className='history-date';dateEl.textContent=date;
      info.appendChild(dateEl);
    }
    li.appendChild(info);
    var del=document.createElement('button');
    del.className='history-del';del.innerHTML='&times;';del.title='Eliminar';
    del.setAttribute('aria-label','Eliminar del historial');
    del.onclick=function(e){
      e.stopPropagation();
      fetch('/history/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:u})})
      .then(function(){fetchHistory();}).catch(function(){});
    };
    li.appendChild(del);
    li.onclick=function(){urlEl.value=u;updateBadge();urlEl.focus();};
    list.appendChild(li);
  });
}
function toggleHistory(){
  var list=document.getElementById('history-list');
  var arrow=document.getElementById('arrow');
  var hidden=list.classList.toggle('hidden');
  arrow.classList.toggle('open',!hidden);
  document.getElementById('history-section').classList.toggle('hist-open',!hidden);
}
function clearHistory(){
  fetch('/history/clear',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})
  .then(function(){fetchHistory();}).catch(function(){});
}
fetchHistory();

/* --- Keep-alive --- */
var keepAlive=false;
function toggleKeepAlive(){
  fetch('/toggle-keep-alive',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})
  .then(function(r){return r.json();})
  .then(function(d){
    keepAlive=d.keepAlive;
    var btn=document.getElementById('keep-alive-btn');
    var footer=document.getElementById('footer-msg');
    if(keepAlive){
      btn.textContent='Servidor fijado (click para cerrar tras envio)';
      btn.classList.add('active');
      footer.textContent='El servidor permanecera abierto. Puedes enviar varias URLs.';
    }else{
      btn.textContent='Mantener servidor abierto';
      btn.classList.remove('active');
      footer.textContent='El servidor se cerrara automaticamente tras recibir la URL.';
    }
  });
}

/* --- Enviar --- */
function checkSVG(){
  return '<svg class="check-svg" viewBox="0 0 24 24">'
    +'<circle cx="12" cy="12" r="10"/>'
    +'<path d="M7 12.5l3 3 7-7"/></svg>';
}
function enviar(){
  var url=urlEl.value.trim();
  var msg=document.getElementById('msg');
  var btn=document.getElementById('send');
  msg.className='msg';msg.style.display='none';
  if(!url){
    msg.className='msg err';msg.textContent='Escribe una URL';msg.style.display='block';
    return;
  }
  if(!/^(https?|rtmp|rtsp):\/\//i.test(url)&&!/^magnet:\?/i.test(url)&&!/^acestream:\/\//i.test(url)&&!/^[0-9a-fA-F]{40}$/.test(url)){
    msg.className='msg err';msg.textContent='Esquemas soportados: http, magnet, acestream';msg.style.display='block';
    return;
  }
  btn.disabled=true;btn.textContent='Enviando...';
  fetch('/send',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:url})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    if(d.ok){
      msg.className='msg ok';
      msg.innerHTML=checkSVG()+'<span>URL enviada a Kodi</span>';
      fetchHistory();
      // La miniatura/titulo del historial se enriquecen en segundo plano: un
      // refresco diferido los muestra sin que el usuario tenga que recargar.
      setTimeout(fetchHistory,3000);
      setTimeout(function(){btn.disabled=false;btn.textContent='Enviar a Kodi';urlEl.value='';updateBadge();msg.className='msg';msg.style.display='none';document.getElementById('preview-card').className='preview-card';},1800);
    }else{
      msg.className='msg err';
      msg.textContent=d.error||'Error desconocido';
      btn.disabled=false;btn.textContent='Enviar a Kodi';
    }
    msg.style.display='';
  })
  .catch(function(){
    msg.className='msg err';
    msg.textContent='Error de conexion con Kodi';
    msg.style.display='block';
    btn.disabled=false;btn.textContent='Enviar a Kodi';
  });
}
urlEl.addEventListener('keydown',function(e){
  if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();enviar()}
});

/* --- Escanear videos --- */
function escanear(){
  var url=urlEl.value.trim();
  var msg=document.getElementById('msg');
  var scanBtn=document.getElementById('scan-btn');
  var scanResults=document.getElementById('scan-results');
  var scanList=document.getElementById('scan-list');
  var scanCount=document.getElementById('scan-count');
  msg.className='msg';msg.style.display='none';
  scanResults.className='scan-results';
  _removeTgMore();
  if(!url){
    msg.className='msg err';msg.textContent='Escribe una URL para escanear';msg.style.display='block';
    return;
  }
  if(!/^https?:\/\//i.test(url)){
    msg.className='msg err';msg.textContent='Solo URLs http:// o https://';msg.style.display='block';
    return;
  }
  scanBtn.disabled=true;scanBtn.textContent='Escaneando...';
  fetch('/scan',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:url})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    scanBtn.disabled=false;scanBtn.textContent='Escanear web';
    if(!d.ok||!d.videos||!d.videos.length){
      msg.className='msg err';msg.textContent='No se encontraron videos en esta pagina';msg.style.display='block';
      return;
    }
    scanCount.textContent=d.count+' video'+(d.count===1?'':'s')+' encontrado'+(d.count===1?'':'s');
    scanList.innerHTML='';
    d.videos.forEach(function(v){
      var li=document.createElement('li');
      li.className='scan-item';
      var title=document.createElement('div');
      title.className='scan-item-title';
      title.textContent=v.title||v.url;
      li.appendChild(title);
      var meta=[];
      if(v.duration) meta.push(v.duration);
      if(v.filesize) meta.push(v.filesize);
      if(v.ext) meta.push(v.ext.toUpperCase());
      if(meta.length){
        var metaEl=document.createElement('div');
        metaEl.className='scan-item-meta';
        metaEl.textContent=meta.join(' \— ');
        li.appendChild(metaEl);
      }
      li.onclick=function(){sendVideo(v.url,v.title)};
      scanList.appendChild(li);
    });
    scanResults.className='scan-results visible';
  })
  .catch(function(){
    scanBtn.disabled=false;scanBtn.textContent='Escanear web';
    msg.className='msg err';msg.textContent='Error de conexion al escanear';msg.style.display='block';
  });
}
function sendVideo(videoUrl,title){
  var msg=document.getElementById('msg');
  fetch('/send',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:videoUrl})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    if(d.ok){
      msg.className='msg ok';
      msg.innerHTML=checkSVG()+'<span></span>';
      msg.querySelector('span').textContent=(title||'Video')+' enviado a Kodi';
      msg.style.display='';
      fetchHistory();
    }
  })
  .catch(function(){});
}

/* --- Escaner Telegram (paginado: supera al escaneo simple de los hermanos) --- */
var _tgChannel=null,_tgCursor=null,_tgSeen=null;
function escanearTelegram(){
  var channel=urlEl.value.trim();
  var msg=document.getElementById('msg');
  document.getElementById('tg-hint').style.display='block';
  msg.className='msg';msg.style.display='none';
  document.getElementById('scan-results').className='scan-results';
  _removeTgMore();
  if(!channel){
    msg.className='msg err';msg.textContent='Escribe @canal o t.me/canal';msg.style.display='block';
    return;
  }
  _tgChannel=channel;_tgCursor=null;_tgSeen=new Set();
  document.getElementById('scan-list').innerHTML='';
  _tgFetch(false);
}
function loadMoreTelegram(){_tgFetch(true);}
function _tgFetch(append){
  var msg=document.getElementById('msg');
  var tgBtn=document.getElementById('scan-tg-btn');
  var more=document.getElementById('tg-more');
  tgBtn.disabled=true;tgBtn.textContent='Escaneando...';
  if(more){more.disabled=true;more.textContent='Cargando...';}
  var body={url:_tgChannel};
  if(append&&_tgCursor) body.before_id=_tgCursor;
  fetch('/scan-telegram',{
    method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)
  })
  .then(function(r){return r.json()})
  .then(function(d){
    tgBtn.disabled=false;tgBtn.textContent='Canal Telegram';
    _removeTgMore();
    var list=document.getElementById('scan-list');
    if(d&&d.ok&&d.videos){
      d.videos.forEach(function(v){
        var u=v.url||'';
        if(!u||_tgSeen.has(u)) return;
        _tgSeen.add(u);list.appendChild(_tgItem(v));
      });
    }
    var total=_tgSeen?_tgSeen.size:0;
    if(!total){
      msg.className='msg err';
      msg.textContent='No se encontraron contenidos. Comprueba que el canal es publico.';
      msg.style.display='block';
      return;
    }
    document.getElementById('scan-count').textContent=total+' elemento'+(total===1?'':'s')+' en Telegram';
    document.getElementById('scan-results').className='scan-results visible';
    _tgCursor=(d&&d.before_id)||null;
    if(_tgCursor) _addTgMore();
  })
  .catch(function(){
    tgBtn.disabled=false;tgBtn.textContent='Canal Telegram';
    var m=document.getElementById('tg-more');
    if(m){m.disabled=false;m.textContent='Cargar mas antiguos';}
    msg.className='msg err';msg.textContent='Error de conexion al escanear Telegram';msg.style.display='block';
  });
}
function _tgItem(v){
  var li=document.createElement('li');li.className='scan-item';
  var title=document.createElement('div');
  title.className='scan-item-title';title.textContent=v.title||v.url;
  li.appendChild(title);
  var meta=[];
  if(v.duration) meta.push(v.duration);
  if(v.filesize) meta.push(v.filesize);
  if(v.ext) meta.push(v.ext.toUpperCase());
  if(meta.length){
    var m=document.createElement('div');
    m.className='scan-item-meta';m.textContent=meta.join(' — ');
    li.appendChild(m);
  }
  li.onclick=function(){sendVideo(v.url,v.title)};
  return li;
}
function _addTgMore(){
  if(document.getElementById('tg-more')) return;
  var btn=document.createElement('button');
  btn.id='tg-more';btn.className='scan-more';btn.textContent='Cargar mas antiguos';
  btn.onclick=loadMoreTelegram;
  document.getElementById('scan-results').appendChild(btn);
}
function _removeTgMore(){
  var b=document.getElementById('tg-more');
  if(b&&b.parentNode) b.parentNode.removeChild(b);
}

/* --- Controles remotos --- */
function ctrl(action){
  fetch('/control',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:action})
  }).catch(function(){});
  setTimeout(pollStatus,300);
}
function ctrlVal(action,value){
  fetch('/control',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:action,value:value})
  }).then(function(){setTimeout(pollStatus,300);}).catch(function(){});
}
function setTrack(action,value){
  var v=/^-?\d+$/.test(value)?parseInt(value,10):value;
  ctrlVal(action,v);
}
function cycleRepeat(){
  var nxt={off:'all',all:'one',one:'off'};
  ctrlVal('repeat',nxt[(_st&&_st.repeat)||'off']||'all');
}
function toggleShuffle(){
  ctrlVal('shuffle',!(_st&&_st.shuffled));
}

/* --- Preview oEmbed --- */
var _previewTimer=null;
var _previewAbort=null;
function requestPreview(url){
  var card=document.getElementById('preview-card');
  var thumb=document.getElementById('preview-thumb');
  var ptitle=document.getElementById('preview-title');
  var pauthor=document.getElementById('preview-author');
  if(!url||url.length<10){
    card.className='preview-card';return;
  }
  // Skeleton loader
  card.className='preview-card loading visible';
  thumb.src='';thumb.className='preview-thumb preview-skeleton preview-skeleton-thumb';
  ptitle.textContent='';ptitle.className='preview-title preview-skeleton preview-skeleton-text';
  ptitle.innerHTML=' ';
  pauthor.textContent='';pauthor.className='preview-author preview-skeleton preview-skeleton-text2';
  pauthor.innerHTML=' ';
  // Abort previous
  if(_previewAbort)try{_previewAbort.abort();}catch(e){}
  _previewAbort=new AbortController();
  fetch('/preview',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:url}),signal:_previewAbort.signal
  }).then(function(r){return r.json()}).then(function(d){
    if(d.ok&&d.preview){
      thumb.src=d.preview.thumbnail||'';
      thumb.className='preview-thumb';
      ptitle.textContent=d.preview.title||'';
      ptitle.className='preview-title';
      pauthor.textContent=d.preview.author?(d.preview.author+' • '+d.preview.provider):(d.preview.provider||'');
      pauthor.className='preview-author';
      card.className='preview-card visible';
    }else{
      card.className='preview-card';
    }
  }).catch(function(){
    card.className='preview-card';
  });
}
function debouncePreview(){
  clearTimeout(_previewTimer);
  _previewTimer=setTimeout(function(){
    var url=document.getElementById('url').value.trim();
    if(/^https?:\/\//i.test(url)) requestPreview(url);
    else document.getElementById('preview-card').className='preview-card';
  },400);
}
urlEl.addEventListener('input',debouncePreview);
urlEl.addEventListener('paste',function(){setTimeout(debouncePreview,50);});

/* --- Estado (SSE con fallback a polling) --- */
var ppIcon=document.getElementById('pp-icon');
var PLAY_PATH='<polygon points="5,3 19,12 5,21"/>';
var PAUSE_PATH='<rect x="5" y="4" width="4" height="16" rx="1"/><rect x="15" y="4" width="4" height="16" rx="1"/>';
var _pollTimer=null;
var _st=null;
function updateStatus(s){
  var dot=document.getElementById('dot');
  var stxt=document.getElementById('status-text');
  var np=document.getElementById('np');
  var vol=document.getElementById('vol');
  var pC=document.getElementById('progress-container');
  var pBar=document.getElementById('progress-bar');
  var pCur=document.getElementById('p-cur');
  var pTot=document.getElementById('p-tot');
  dot.classList.add('on');
  if(s.playing){
    stxt.textContent=s.paused?'Pausado':'Reproduciendo';
    np.textContent=s.title||'';
    ppIcon.innerHTML=s.paused?PLAY_PATH:PAUSE_PATH;
    pC.classList.add('visible');
    if(!pBar.dataset.seeking){pBar.value=s.percentage||0;}
    pCur.textContent=s.time||'00:00:00';
    pTot.textContent=s.totaltime||'00:00:00';
  }else{
    stxt.textContent='Sin reproduccion';
    np.textContent='';
    ppIcon.innerHTML=PLAY_PATH;
    pC.classList.remove('visible');
  }
  var v=s.volume;vol.textContent=(v!=null)?(s.muted?'🔇':v+'%'):'--';
  updateAdvanced(s);
  _st=s;
}
function fillSelect(sel,opts,current){
  if(!sel)return;
  var sig=JSON.stringify(opts);
  if(sel.dataset.sig!==sig){
    sel.innerHTML='';
    opts.forEach(function(o){
      var op=document.createElement('option');
      op.value=o.value;op.textContent=o.label;sel.appendChild(op);
    });
    sel.dataset.sig=sig;
  }
  sel.value=String(current);
}
function updateAdvanced(s){
  var muteBtn=document.getElementById('mute-btn');
  if(muteBtn)muteBtn.classList.toggle('active',!!s.muted);
  var tracks=document.getElementById('tracks');
  var aRow=document.getElementById('audio-row');
  var sRow=document.getElementById('sub-row');
  var repBtn=document.getElementById('rep-btn');
  var shufBtn=document.getElementById('shuf-btn');
  if(!tracks)return;
  if(!s.playing){
    tracks.classList.remove('visible');
    if(aRow)aRow.style.display='none';
    if(sRow)sRow.style.display='none';
    return;
  }
  var aud=s.audiostreams||[];
  if(aud.length>1){
    fillSelect(document.getElementById('audio-sel'),
      aud.map(function(t){return {value:t.index,label:t.label};}),
      (s.currentaudio==null?-1:s.currentaudio));
    if(aRow)aRow.style.display='';
  }else if(aRow){aRow.style.display='none';}
  var subs=s.subtitles||[];
  if(subs.length){
    var sopts=[{value:'off',label:'Subtitulos: desactivados'}].concat(
      subs.map(function(t){return {value:t.index,label:t.label};}));
    fillSelect(document.getElementById('sub-sel'),sopts,
      (s.subtitleenabled?s.currentsubtitle:'off'));
    if(sRow)sRow.style.display='';
  }else if(sRow){sRow.style.display='none';}
  if(repBtn){
    repBtn.classList.toggle('active',!!(s.repeat&&s.repeat!=='off'));
    repBtn.title='Repetir: '+(s.repeat||'off');
  }
  if(shufBtn)shufBtn.classList.toggle('active',!!s.shuffled);
  tracks.classList.add('visible');
}
function pollStatus(){
  fetch('/status').then(function(r){return r.json()}).then(updateStatus)
  .catch(function(){
    document.getElementById('dot').classList.remove('on');
    document.getElementById('status-text').textContent='Sin conexion';
  });
}
function startSSE(){
  if(typeof EventSource==='undefined'){startPolling();return;}
  var es=new EventSource('/events');
  es.onmessage=function(e){
    try{updateStatus(JSON.parse(e.data));}catch(err){}
  };
  es.onerror=function(){
    es.close();
    startPolling();
  };
}
function startPolling(){
  pollStatus();
  _pollTimer=setInterval(pollStatus,3000);
}
function seekTo(pct){
  fetch('/control',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'seek',value:parseFloat(pct)})
  });
}
startSSE();
</script>
</body>
</html>"""

# HTML embebido (pagina texto)

_HTML_TEXT = r"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#0d1117">
<meta name="color-scheme" content="dark">
<title>StreamNinja Remote</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  background:#0d1117;color:#c9d1d9;
  min-height:100vh;display:flex;align-items:flex-start;justify-content:center;
  padding:16px;
}
.card{
  background:#161b22;border:1px solid #30363d;border-radius:12px;
  padding:32px 24px;max-width:480px;width:100%;
  box-shadow:0 8px 32px rgba(0,0,0,.4);
}
h1{
  font-size:1.4em;text-align:center;margin-bottom:6px;
  color:#58a6ff;font-weight:600;
}
.sub{
  text-align:center;color:#8b949e;font-size:.85em;margin-bottom:24px;
}
label{
  display:block;font-size:.9em;color:#8b949e;margin-bottom:6px;
}
input[type=text]{
  width:100%;padding:14px 12px;
  background:#0d1117;color:#c9d1d9;
  border:1px solid #30363d;border-radius:8px;
  font-size:16px;outline:none;
  transition:border-color .2s;
}
input[type=text]:focus{border-color:#58a6ff}
input[type=text]::placeholder{color:#484f58}
.btn{
  display:block;width:100%;padding:14px;margin-top:16px;
  background:#e6edf3;color:#0d1117;
  border:1px solid #d0d7de;border-radius:8px;
  font-size:1em;font-weight:600;cursor:pointer;
  transition:background .15s,border-color .15s;
}
.btn:hover{background:#f0f6fc}
.btn:active{background:#d0d7de;transform:scale(.99)}
.btn:disabled{background:#21262d;color:#484f58;border-color:#21262d;cursor:not-allowed}
.msg{
  margin-top:14px;padding:10px 14px;border-radius:8px;
  font-size:.9em;text-align:center;display:none;
}
.msg.ok{display:flex;align-items:center;justify-content:center;gap:8px;background:#0d2818;color:#3fb950;border:1px solid #238636}
.msg.err{display:block;background:#2d1117;color:#f85149;border:1px solid #da3633}
.check-svg{width:20px;height:20px;flex-shrink:0}
.check-svg circle{stroke:#3fb950;stroke-width:2;fill:none;stroke-dasharray:52;stroke-dashoffset:52;animation:circ .4s ease forwards}
.check-svg path{stroke:#3fb950;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:20;stroke-dashoffset:20;animation:tick .3s .35s ease forwards}
@keyframes circ{to{stroke-dashoffset:0}}
@keyframes tick{to{stroke-dashoffset:0}}
.footer{
  text-align:center;color:#484f58;font-size:.75em;margin-top:20px;
}
</style>
</head>
<body>
<div class="card">
  <h1>StreamNinja Remote</h1>
  <p class="sub">Escribe texto para enviarlo a Kodi</p>
  <label for="txt">Texto</label>
  <input type="text" id="txt" placeholder="Escribe aqui..." autofocus>
  <button class="btn" id="send" onclick="enviar()">Enviar a Kodi</button>
  <div class="msg" id="msg"></div>
  <p class="footer">El servidor se cerrara automaticamente tras recibir el texto.</p>
  <p style="text-align:center;color:#484f58;font-size:.7em;margin-top:8px">Concepto: RubenSDFA1laberot</p>
</div>
<script>
function checkSVG(){
  return '<svg class="check-svg" viewBox="0 0 24 24">'
    +'<circle cx="12" cy="12" r="10"/>'
    +'<path d="M7 12.5l3 3 7-7"/></svg>';
}
function enviar(){
  var txt=document.getElementById('txt').value.trim();
  var msg=document.getElementById('msg');
  var btn=document.getElementById('send');
  msg.className='msg';msg.style.display='none';
  if(!txt){
    msg.className='msg err';msg.textContent='Escribe algo';msg.style.display='block';
    return;
  }
  btn.disabled=true;btn.textContent='Enviando...';
  fetch('/send',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text:txt})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    if(d.ok){
      msg.className='msg ok';
      msg.innerHTML=checkSVG()+'<span>Texto enviado a Kodi</span>';
      btn.textContent='Enviado';
    }else{
      msg.className='msg err';
      msg.textContent=d.error||'Error desconocido';
      btn.disabled=false;btn.textContent='Enviar a Kodi';
    }
    msg.style.display='';
  })
  .catch(function(){
    msg.className='msg err';
    msg.textContent='Error de conexion con Kodi';
    msg.style.display='block';
    btn.disabled=false;btn.textContent='Enviar a Kodi';
  });
}
document.getElementById('txt').addEventListener('keydown',function(e){
  if(e.key==='Enter'){e.preventDefault();enviar()}
});
</script>
</body>
</html>"""
