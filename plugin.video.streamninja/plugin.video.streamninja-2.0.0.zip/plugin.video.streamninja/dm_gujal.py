# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.

"""
This is not an exact copy of Gujal00's work, but it is based on it.
"""

import re
import urllib.parse
import requests
import xbmc

_UA_MOBILE = (
    "Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/55.0.2883.91 Mobile Safari/537.36"
)

HEADERS = {
    "User-Agent": _UA_MOBILE,
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}

COOKIES = {"lang": "es_ES", "ff": "off"}


def _parse_m3u8(text):
    """Extracts (quality, url) pairs from the M3U8 manifest.
    Looks first for PROGRESSIVE-URI (direct MP4), then HLS streams."""
    entries = re.findall(
        r'NAME="([^"]+)",PROGRESSIVE-URI="([^"]+)"', text
    )
    if not entries:
        entries = re.findall(r'NAME="(\d+)".*\n([^\n]+)', text)
    return entries


def _sort_key(elem):
    """Sorts by numeric resolution, descending."""
    try:
        return int(elem[0].split("@")[0])
    except (ValueError, IndexError):
        return 0


def play_dm_extreme(vid, max_quality=1080):
    """Complete resolution Gujal00-style with subtitles, sec tokens,
    and quality limiter.

    Args:
        vid: Dailymotion video ID.
        max_quality: Maximum allowed quality (e.g. 480, 720, 1080).

    Returns:
        Tuple (url, subtitles, mime) or (None, None, None) if it fails.
    """
    try:
        r = requests.get(
            "https://www.dailymotion.com/player/metadata/video/" + vid,
            headers=HEADERS, cookies=COOKIES, timeout=15,
        )
        if r.status_code != 200:
            raise ConnectionError("HTTP " + str(r.status_code))

        content = r.json()
        if content.get("error"):
            raise RuntimeError(content["error"].get("type", "Unknown"))

        # Extract Subtitles
        subs = []
        subs_obj = content.get("subtitles", {})
        if isinstance(subs_obj, dict):
            subs_data = subs_obj.get("data", {})
            if isinstance(subs_data, dict):
                for lang_key in subs_data:
                    urls = subs_data[lang_key].get("urls", [])
                    if urls:
                        subs.append(urls[0])

        # Extract HLS Stream
        cc = content.get("qualities", {})
        m_url = ""
        if "auto" in cc:
            for item in cc["auto"]:
                if item.get("type") == "application/x-mpegURL":
                    m_url = item.get("url")
                    break

        if not m_url:
            raise RuntimeError("No HLS stream")

        # Parse M3U8 manifest
        try:
            extra_cookie = None
            if ".m3u8?sec" in m_url:
                parts = m_url.split("?sec=")
                redirect_url = parts[0] + "?redirect=0&sec=" + urllib.parse.quote(parts[1])
                rr = requests.get(
                    redirect_url, cookies=r.cookies.get_dict(),
                    headers=HEADERS, timeout=10,
                )
                if rr.status_code > 200:
                    rr = requests.get(
                        m_url, cookies=r.cookies.get_dict(),
                        headers=HEADERS, timeout=10,
                    )
                mbtext = rr.text
                if rr.headers.get("set-cookie"):
                    extra_cookie = rr.headers["set-cookie"]
            else:
                mbtext = requests.get(m_url, headers=HEADERS, timeout=10).text

            mb = _parse_m3u8(mbtext)
            if mb:
                mb = sorted(mb, key=_sort_key, reverse=True)

                selected_url = None
                for quality, strurl in mb:
                    try:
                        q_val = int(quality.split("@")[0])
                    except (ValueError, IndexError):
                        q_val = 0
                    if q_val <= max_quality:
                        selected_url = strurl.split("#cell")[0]
                        break

                if not selected_url and mb:
                    selected_url = mb[-1][1].split("#cell")[0]

                if selected_url:
                    if extra_cookie:
                        final_url = (
                            selected_url + "|"
                            + urllib.parse.urlencode(HEADERS)
                            + "&Cookie=" + urllib.parse.quote(extra_cookie)
                        )
                    else:
                        final_url = selected_url + "|" + urllib.parse.urlencode(HEADERS)

                    return final_url, subs, "video/mp4"
            else:
                # No parseable qualities; return master m3u8
                final_url = m_url + "|" + urllib.parse.urlencode(HEADERS)
                return final_url, subs, "application/x-mpegURL"

        except Exception as e:
            xbmc.log(
                "[StreamNinja/dm_gujal] Extreme m3u8 parse failed: " + str(e),
                xbmc.LOGWARNING,
            )

        # Fallback: return master m3u8 directly
        final_url = m_url + "|" + urllib.parse.urlencode(HEADERS)
        return final_url, subs, "application/x-mpegURL"

    except Exception as e:
        xbmc.log("[StreamNinja/dm_gujal] extreme error: " + str(e), xbmc.LOGWARNING)
        return None, None, None


def play_dm_basic(vid):
    """Basic resolution with mobile User-Agent and cookies.

    Args:
        vid: Dailymotion video ID.

    Returns:
        Tuple (url, mime) or (None, None) if it fails.
    """
    try:
        r = requests.get(
            "https://www.dailymotion.com/player/metadata/video/" + vid,
            headers=HEADERS, cookies=COOKIES, timeout=15,
        )
        if r.status_code != 200:
            raise ConnectionError("HTTP " + str(r.status_code))

        content = r.json()
        if content.get("error"):
            raise RuntimeError(content["error"].get("type", "Unknown"))

        cc = content.get("qualities", {})
        m_url = ""
        if "auto" in cc:
            for item in cc["auto"]:
                if item.get("type") == "application/x-mpegURL":
                    m_url = item.get("url")
                    break

        if not m_url:
            raise RuntimeError("No HLS stream")

        try:
            mbtext = requests.get(m_url, headers=HEADERS, timeout=10).text
            mb = _parse_m3u8(mbtext)

            if mb:
                mb = sorted(mb, key=_sort_key, reverse=True)
                best_url = mb[0][1].split("#cell")[0]
                final_url = best_url + "|" + urllib.parse.urlencode(HEADERS)
                return final_url, "video/mp4"
            else:
                final_url = m_url + "|" + urllib.parse.urlencode(HEADERS)
                return final_url, "application/x-mpegURL"

        except Exception as e:
            xbmc.log(
                "[StreamNinja/dm_gujal] Basic m3u8 parse failed: " + str(e),
                xbmc.LOGWARNING,
            )

        # Fallback: return master m3u8 directly
        final_url = m_url + "|" + urllib.parse.urlencode(HEADERS)
        return final_url, "application/x-mpegURL"

    except Exception as e:
        xbmc.log("[StreamNinja/dm_gujal] basic error: " + str(e), xbmc.LOGWARNING)
        return None, None
