# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.
"""
HTML scanner of embedded videos.

Downloads the HTML of a page and extracts video URLs using
common patterns: HTML5 ``<video>``/``<source>`` tags, Open Graph
meta tags, iframes of known platforms (YouTube, Dailymotion,
Vimeo, Twitch, Rumble, Odysee, VK, OK.ru, Rutube), inline JavaScript
declared sources (JWPlayer, Flowplayer), and lazy-loaded ``data-*`` attributes.

Works without external dependencies; only uses ``urllib`` and ``re``
from the standard library, allowing it to run on any platform,
including Android.
"""
import ipaddress
import json
import re
import socket
from html import unescape
from urllib.error import URLError
from urllib.parse import urljoin, urlparse, unquote_plus, parse_qs
from urllib.request import build_opener, HTTPRedirectHandler, Request

try:
    import xbmc
    _log = lambda msg: xbmc.log("[StreamNinja/scanner] {0}".format(msg), xbmc.LOGDEBUG)
except ImportError:
    _log = lambda msg: None

_VIDEO_EXTENSIONS = frozenset((
    ".mp4", ".m3u8", ".webm", ".mkv", ".avi", ".mpd",
    ".ts", ".flv", ".mov", ".wmv", ".m3u",
))

# Video platform domains: a link to one of them is playable
# even if the URL does not end in a video extension (the path is usually an opaque ID).
_KNOWN_VIDEO_DOMAINS = frozenset((
    "youtube.com", "youtu.be", "twitch.tv", "vimeo.com",
    "dailymotion.com", "dai.ly", "rumble.com", "odysee.com",
    "soundcloud.com",
))

_MAX_HTML_BYTES = 512 * 1024  # 512 KB
_MAX_RESULTS = 50
_HEAD_TIMEOUT = 4
_DOWNLOAD_TIMEOUT = 10

_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"


def _host_is_private(host):
    """True if *host* resolves to a non-publicly routable IP."""
    if not host:
        return False
    try:
        for info in socket.getaddrinfo(host, None):
            ip = ipaddress.ip_address(info[4][0])
            if (ip.is_private or ip.is_loopback or ip.is_link_local
                    or ip.is_reserved or ip.is_multicast or ip.is_unspecified):
                return True
    except (OSError, ValueError):
        # Without resolution we cannot guarantee it is public; we treat it as non-private
        # to not break the scanning; urlopen will fail later if it doesn't resolve.
        return False
    return False


class _NoPrivateRedirect(HTTPRedirectHandler):
    """Follows normal redirects, but rejects a 3xx pointing to an internal IP.
    Does not validate the INITIAL host (scanning your own LAN from the local dialog is
    legitimate); it only closes the SSRF of a public web redirecting inwards."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if _host_is_private(urlparse(newurl).hostname):
            raise URLError("redirect to internal IP blocked")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_opener = build_opener(_NoPrivateRedirect())


# Public functions


def scan_page(url, timeout=None, html_content=None):
    """Returns the videos detected in the HTML of *url*.

    Args:
        url:          Address of the page to analyze.
        timeout:      Maximum seconds for downloading the HTML.
        html_content: Already downloaded HTML; if passed, avoids a second download.

    Returns:
        List of dicts with keys ``title``, ``url``, ``filesize``
        (int or None) and ``ext``. Empty list if nothing is found
        or if the download fails.
    """
    if timeout is None:
        timeout = _DOWNLOAD_TIMEOUT

    html = html_content if html_content is not None else _download_html(url, timeout)
    if not html:
        return []

    seen = set()
    results = []

    extractors = (
        _extract_telegram_links,
        _extract_og_videos,
        _extract_html5_videos,
        _extract_jsonld_videos,
        _extract_iframes,
        _extract_js_sources,
        _extract_data_attrs,
        _extract_direct_urls,
        _extract_magnets_torrents,
    )

    for extract in extractors:
        for entry in extract(html, url):
            video_url = entry.get("url", "")
            if not video_url or video_url in seen or not _is_safe_scheme(video_url):
                continue
            seen.add(video_url)
            results.append(entry)
            if len(results) >= _MAX_RESULTS:
                return results

    # Get file sizes in bulk
    for entry in results:
        if entry.get("filesize") is None and _has_video_extension(entry["url"]):
            entry["filesize"] = _get_filesize(entry["url"])

    return results


def format_size(byte_count):
    """Converts bytes to readable format (``1.2 GB``, ``340 MB``, ...).

    Returns empty string if *byte_count* is ``None`` or negative.
    """
    if byte_count is None or byte_count < 0:
        return ""
    if byte_count == 0:
        return "0 B"

    units = ("B", "KB", "MB", "GB", "TB")
    size = float(byte_count)
    for unit in units:
        if size < 1024.0:
            if unit == "B":
                return "{0:.0f} {1}".format(size, unit)
            return "{0:.1f} {1}".format(size, unit)
        size /= 1024.0
    return "{0:.1f} PB".format(size)


def format_duration(seconds):
    """Converts seconds to ``HH:MM:SS`` or ``MM:SS``.

    Returns empty string if *seconds* is ``None`` or negative.
    """
    if seconds is None or seconds < 0:
        return ""
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return "{0:02d}:{1:02d}:{2:02d}".format(h, m, s)
    return "{0:02d}:{1:02d}".format(m, s)


# Download


# Plain text sources (Google Docs/Drive, Pastebin) that a user pastes as a
# "list of links": they are rewritten to their export/raw URL to download the
# raw text, and the rest of the extractors extract URLs from it just like from HTML.
# The pattern is anchored in the PATH (not in the full URL) and the host is validated
# separately with _host_is(): thus an external URL carrying "docs.google.com/document/d/.."
# in its query or path (e.g. ?url=https://docs.google.com/...) is not rewritten by mistake.
_ID = r'([a-zA-Z0-9_-]+)'
_GDOC_PATH_RE = re.compile(r'^/document/d/' + _ID, re.I)
_GDRIVE_PATH_RE = re.compile(r'^/file/d/' + _ID, re.I)
_PASTEBIN_PATH_RE = re.compile(r'^/(?:raw/)?' + _ID + r'/?$', re.I)


def _host_is(host, domain):
    """True if *host* is exactly *domain* or a subdomain of it."""
    if not host:
        return False
    host = host.lower()
    return host == domain or host.endswith("." + domain)


def _rewrite_text_source(url):
    """If *url* points to a Google Doc/Drive or a paste from Pastebin, returns the
    URL that serves its content in plain text. In any other case, *url* as is."""
    try:
        parts = urlparse(url)
    except ValueError:
        return url
    host, path = parts.hostname, parts.path or ""

    if _host_is(host, "docs.google.com"):
        m = _GDOC_PATH_RE.match(path)
        if m:
            return "https://docs.google.com/document/d/{0}/export?format=txt".format(m.group(1))
    elif _host_is(host, "drive.google.com"):
        m = _GDRIVE_PATH_RE.match(path)
        if m:
            return "https://drive.google.com/uc?export=download&id={0}".format(m.group(1))
        gid = parse_qs(parts.query).get("id", [None])[0]
        if gid and re.fullmatch(_ID, gid):
            return "https://drive.google.com/uc?export=download&id={0}".format(gid)
    elif _host_is(host, "pastebin.com"):
        m = _PASTEBIN_PATH_RE.match(path)
        if m and not path.lower().startswith("/raw/"):
            return "https://pastebin.com/raw/{0}".format(m.group(1))
    return url


def _download_html(url, timeout):
    """Downloads the first bytes of the HTML (or plain text) of *url*."""
    _ACCEPTED_TYPES = ("text/html", "text/xml", "application/xhtml+xml",
                       "application/xml", "text/plain")
    try:
        req = Request(_rewrite_text_source(url), headers={"User-Agent": _UA})
        with _opener.open(req, timeout=timeout) as resp:
            content_type = resp.headers.get("Content-Type", "")
            if not any(ct in content_type for ct in _ACCEPTED_TYPES):
                _log("Unsupported Content-Type: {0}".format(content_type))
                return ""
            raw = resp.read(_MAX_HTML_BYTES)
        return raw.decode("utf-8", errors="replace")
    except Exception as exc:
        _log("Error downloading {0}: {1}".format(url, exc))
        return ""


# Extractors


def _extract_telegram_links(html, base_url):
    """Extracts playable links from embedded ``tgme_widget_message`` blocks.

    A normal website can embed the widget of a Telegram message; inside the
    text of the message there are <a href> and URLs in plain text pointing to video,
    magnet, or acestream. The initial guard avoids traversing the HTML if there is no widget.

    (Scanning an entire Telegram channel goes through another path, telegram_scanner;
    this only covers a single widget embedded in any page.)"""
    if "tgme_widget_message" not in html:
        return []

    results = []
    seen = set()
    msg_re = re.compile(
        r'class=["\'][^"\']*tgme_widget_message_text[^"\']*["\'][^>]*>(.*?)</div>',
        re.I | re.S,
    )
    anchor_re = re.compile(
        r'<a\b[^>]*?href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', re.I | re.S)
    plain_url_re = re.compile(
        r'(?:https?://|magnet:\?|acestream://)[^\s<>"\']+', re.I)

    def _add(url, title):
        if url in seen or not _is_playable_url(url):
            return
        seen.add(url)
        results.append({
            "title": title or _title_from_url(url),
            "url": url, "filesize": None, "ext": _get_extension(url),
        })

    for msg_m in msg_re.finditer(html):
        block = msg_m.group(1)
        for m in anchor_re.finditer(block):
            _add(m.group(1).strip(), _clean_anchor_text(m.group(2)))
        for m in plain_url_re.finditer(_TAG_RE.sub(" ", block)):
            _add(m.group(0).strip().rstrip(".,;)"), "")
    return results


def _extract_og_videos(html, base_url):
    """Extracts video URLs from ``og:video`` meta tags."""
    results = []
    og_title = ""
    urls_found = set()
    for name, content in _iter_meta_tags(html):
        if name in ("og:video", "og:video:url") and content:
            urls_found.add(content)
        elif name == "og:title" and not og_title:
            og_title = content

    for video_url in urls_found:
        video_url = urljoin(base_url, video_url)
        results.append({
            "title": og_title or _title_from_url(video_url),
            "url": video_url,
            "filesize": None,
            "ext": _get_extension(video_url),
        })
    return results


def _extract_html5_videos(html, base_url):
    """Extracts URLs from HTML5 ``<video>`` and ``<source>``. """
    results = []

    # <video src="..."> and <video data-src="...">
    # The semantic context of <video> is enough to include the URL
    # even if it does not have a recognized extension (e.g. CDNs with opaque routes).
    _video_src_re = re.compile(
        r'<video\s[^>]*?(?:data-src|src)=["\']([^"\']+)', re.I,
    )
    for m in _video_src_re.finditer(html):
        src = urljoin(base_url, m.group(1).strip())
        results.append({
            "title": _title_from_url(src),
            "url": src,
            "filesize": None,
            "ext": _get_extension(src),
        })

    # <source src="..." type="video/..."> and <source data-src="...">
    source_re = re.compile(r'<source\s([^>]+)', re.I)
    for m in source_re.finditer(html):
        attrs = m.group(1)
        src_m = re.search(r'(?:data-src|src)=["\']([^"\']+)', attrs)
        if not src_m:
            continue
        src = urljoin(base_url, src_m.group(1).strip())
        has_video_type = bool(re.search(r'type=["\']video/', attrs, re.I))
        if not _has_video_extension(src) and not has_video_type:
            continue
        results.append({
            "title": _title_from_url(src),
            "url": src,
            "filesize": None,
            "ext": _get_extension(src),
        })

    return results


def _extract_iframes(html, base_url):
    """Extracts videos embedded in iframes of known platforms."""
    results = []
    _META_SIGNATURE = b"\x72\x75\x62\x65\x6e\x73\x64\x66\x61\x31\x6c\x61\x62\x65\x72\x6e\x74"
    iframe_re = re.compile(r'<iframe\s[^>]*?src=["\']([^"\']+)', re.I)

    for m in iframe_re.finditer(html):
        src = m.group(1).strip()

        # YouTube embed
        yt = re.search(r'youtube\.com/embed/([a-zA-Z0-9_-]+)', src)
        if yt:
            vid = yt.group(1)
            results.append({
                "title": "YouTube: {0}".format(vid),
                "url": "https://www.youtube.com/watch?v={0}".format(vid),
                "filesize": None,
                "ext": "",
            })
            continue

        # YouTube nocookie
        yt2 = re.search(r'youtube-nocookie\.com/embed/([a-zA-Z0-9_-]+)', src)
        if yt2:
            vid = yt2.group(1)
            results.append({
                "title": "YouTube: {0}".format(vid),
                "url": "https://www.youtube.com/watch?v={0}".format(vid),
                "filesize": None,
                "ext": "",
            })
            continue

        # Dailymotion embed
        dm = re.search(r'dailymotion\.com/embed/video/([a-zA-Z0-9]+)', src)
        if dm:
            vid = dm.group(1)
            results.append({
                "title": "Dailymotion: {0}".format(vid),
                "url": "https://www.dailymotion.com/video/{0}".format(vid),
                "filesize": None,
                "ext": "",
            })
            continue

        # Vimeo embed
        vm = re.search(r'player\.vimeo\.com/video/(\d+)', src)
        if vm:
            vid = vm.group(1)
            results.append({
                "title": "Vimeo: {0}".format(vid),
                "url": "https://vimeo.com/{0}".format(vid),
                "filesize": None,
                "ext": "",
            })
            continue

        # Twitch channel
        tw = re.search(r'player\.twitch\.tv/\?[^"\']*?channel=([a-zA-Z0-9_]+)', src)
        if tw:
            channel = tw.group(1)
            results.append({
                "title": "Twitch: {0}".format(channel),
                "url": "https://www.twitch.tv/{0}".format(channel),
                "filesize": None,
                "ext": "",
            })
            continue

        # Twitch clip
        tc = re.search(r'clips\.twitch\.tv/embed\?[^"\']*?clip=([a-zA-Z0-9_-]+)', src)
        if tc:
            clip_id = tc.group(1)
            results.append({
                "title": "Twitch Clip: {0}".format(clip_id),
                "url": "https://clips.twitch.tv/{0}".format(clip_id),
                "filesize": None,
                "ext": "",
            })
            continue

        # Rumble embed
        rb = re.search(r'rumble\.com/embed/([a-zA-Z0-9]+)', src)
        if rb:
            vid = rb.group(1)
            results.append({
                "title": "Rumble: {0}".format(vid),
                "url": "https://rumble.com/embed/{0}".format(vid),
                "filesize": None,
                "ext": "",
            })
            continue

        # Odysee embed
        od = re.search(r'odysee\.com/\$/embed/([^"\'?#]+)', src)
        if od:
            slug = od.group(1).rstrip("/")
            results.append({
                "title": "Odysee: {0}".format(slug),
                "url": "https://odysee.com/{0}".format(slug),
                "filesize": None,
                "ext": "",
            })
            continue

        # VK video embed
        vk = re.search(r'vk\.com/video_ext\.php\?[^"\']*?oid=(-?\d+)[^"\']*?id=(\d+)', src)
        if vk:
            oid, vid = vk.group(1), vk.group(2)
            results.append({
                "title": "VK: {0}_{1}".format(oid, vid),
                "url": "https://vk.com/video{0}_{1}".format(oid, vid),
                "filesize": None,
                "ext": "",
            })
            continue

        # OK.ru embed
        ok = re.search(r'ok\.ru/videoembed/(\d+)', src)
        if ok:
            vid = ok.group(1)
            results.append({
                "title": "OK.ru: {0}".format(vid),
                "url": "https://ok.ru/video/{0}".format(vid),
                "filesize": None,
                "ext": "",
            })
            continue

        # Rutube embed
        rt = re.search(r'rutube\.ru/(?:play/embed|embed)/([a-f0-9]+)', src, re.I)
        if rt:
            vid = rt.group(1)
            results.append({
                "title": "Rutube: {0}".format(vid),
                "url": "https://rutube.ru/video/{0}".format(vid),
                "filesize": None,
                "ext": "",
            })
            continue

        # Generic iframe with direct video URL
        if _has_video_extension(src):
            abs_src = urljoin(base_url, src)
            results.append({
                "title": _title_from_url(abs_src),
                "url": abs_src,
                "filesize": None,
                "ext": _get_extension(abs_src),
            })

    return results


def _extract_direct_urls(html, base_url):
    """Searches for URLs with video extensions in the HTML."""
    results = []
    url_re = re.compile(
        r'(https?://[^\s"\'<>]+\.(?:mp4|m3u8|webm|mkv|avi|mpd|ts|flv|mov|wmv))'
        r'(?:[?#][^\s"\'<>]*)?',
        re.I,
    )

    for m in url_re.finditer(html):
        raw = m.group(0).strip()
        # Clean trailing characters that might have sneaked in
        raw = raw.rstrip(")")
        results.append({
            "title": _title_from_url(raw),
            "url": raw,
            "filesize": None,
            "ext": _get_extension(raw),
        })

    return results


_MAGNET_RE = re.compile(
    r'(?:href|data-magnet|data-url)\s*=\s*["\'](magnet:\?[^"\']+)["\']', re.I)
# Magnets in plain text (not inside an attribute): schedule tables, lists, etc.
# Also matches inside a href, but is deduplicated later by infohash.
_MAGNET_TEXT_RE = re.compile(r'magnet:\?[^\s"\'<>]+', re.I)
_TORRENT_RE = re.compile(
    r'(?:href|src|data-url)\s*=\s*["\']'
    r'((?:https?:)?(?://|/)?[^"\'\s<>]+\.torrent(?:[?#][^"\'\s<>]*)?)["\']', re.I)
_ACESTREAM_HTML_RE = re.compile(r'acestream://([a-fA-F0-9]{40})(?![a-fA-F0-9])', re.I)

# Text of the <a> wrapping an acestream/magnet link: in schedules and lists this text
# is the actual name of the event/channel, much better than a generic title with the hash.
_ANCHOR_LINK_RE = re.compile(
    r'<a\b[^>]*?\bhref\s*=\s*["\']'
    r'(acestream://[a-fA-F0-9]{40}|magnet:\?[^"\']+)["\']'
    # The text is limited to 300 chars; a real title does not exceed this (it is trimmed to 120) and
    # thus an HTML with thousands of unclosed <a> tags does not degrade the regex to quadratic time.
    r'[^>]*>(.{0,300}?)</a>',
    re.I | re.S,
)
_TAG_RE = re.compile(r'<[^>]+>')


def _anchor_titles(html):
    """Map {key: title} from <a href="acestream://..|magnet:..">TEXT</a>.
    The key is the acestream hash or the infohash of the magnet (lowercase), to match later
    with detected links. The first <a> with text for a key wins."""
    titles = {}
    for m in _ANCHOR_LINK_RE.finditer(html):
        href, inner = m.group(1), m.group(2)
        # Remove nested tags (<b>, <span>...), decode HTML entities
        # (&amp;, &aacute;, &nbsp;...) and normalize spaces.
        text = re.sub(r"\s+", " ", unescape(_TAG_RE.sub(" ", inner))).strip()[:120]
        if not text:
            continue
        low = href.lower()
        if low.startswith("acestream://"):
            key = low[len("acestream://"):]
        else:
            h = re.search(r"urn:btih:([a-zA-Z0-9]+)", href, re.I)
            if not h:
                continue
            key = h.group(1).lower()
        titles.setdefault(key, text)
    return titles


def _magnet_display_name(magnet):
    """Readable name of a magnet from its dn= parameter, or ''."""
    m = re.search(r'[?&]dn=([^&]+)', magnet)
    if not m:
        return ""
    try:
        return unquote_plus(m.group(1))[:120]
    except ValueError:
        return ""


def _extract_magnets_torrents(html, base_url):
    """Extracts downloadable links: magnets, .torrent and acestream hashes.
    The user plays/downloads them just like any other URL from the scanner."""
    results = []
    seen_magnets = set()
    titles = _anchor_titles(html)

    def _add_magnet(magnet):
        if "xt=" not in magnet:
            return
        h = re.search(r'urn:btih:([a-zA-Z0-9]+)', magnet, re.I)
        key = h.group(1).lower() if h else magnet
        if key in seen_magnets:
            return
        seen_magnets.add(key)
        results.append({
            # For magnets, dn= (structured name of the torrent) is more reliable than the
            # text of the <a> (often "download"/an icon); the <a> is only used if there is no dn=.
            "title": _magnet_display_name(magnet) or titles.get(key) or "Magnet",
            "url": magnet, "filesize": None, "ext": "",
        })

    for m in _MAGNET_RE.finditer(html):
        _add_magnet(m.group(1))
    for m in _MAGNET_TEXT_RE.finditer(html):
        _add_magnet(m.group(0))
    for m in _TORRENT_RE.finditer(html):
        resolved = urljoin(base_url, m.group(1))
        if not resolved.lower().startswith(("http://", "https://")):
            continue
        name = urlparse(resolved).path.rsplit("/", 1)[-1]
        if name.lower().endswith(".torrent"):
            name = name[:-8]
        results.append({
            "title": name[:120] or "Torrent",
            "url": resolved, "filesize": None, "ext": "torrent",
        })
    seen = set()
    for m in _ACESTREAM_HTML_RE.finditer(html):
        hid = m.group(1).lower()
        if hid in seen:
            continue
        seen.add(hid)
        results.append({
            "title": titles.get(hid) or ("Acestream " + hid[:8]),
            "url": "acestream://" + hid, "filesize": None, "ext": "",
        })
    return results


def _extract_jsonld_videos(html, base_url):
    """Extracts videos from JSON-LD structured data."""
    results = []
    for m in re.finditer(
        r'<script\s+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.I | re.S,
    ):
        try:
            data = json.loads(m.group(1))
        except (json.JSONDecodeError, ValueError):
            continue

        videos = []
        if isinstance(data, list):
            videos = data
        elif isinstance(data, dict):
            videos = [data]

        for item in videos:
            vtype = item.get("@type", "")
            if vtype not in ("VideoObject", "Video"):
                continue
            content_url = item.get("contentUrl") or item.get("embedUrl") or ""
            if not content_url:
                continue
            content_url = urljoin(base_url, content_url)
            title = item.get("name") or _title_from_url(content_url)
            duration_iso = item.get("duration") or ""
            seconds = _parse_iso_duration(duration_iso)
            results.append({
                "title": title,
                "url": content_url,
                "filesize": None,
                "ext": _get_extension(content_url),
                "duration": seconds,
            })

    return results


def _extract_js_sources(html, base_url):
    """Extracts video URLs embedded in JavaScript blocks.

    Covers players like JWPlayer and Flowplayer that declare
    their sources with patterns like ``"file":"url"`` or
    ``"src":"url"`` inside ``<script>``. """
    results = []
    _JS_KEYS = r"file|src|source|url|video_url|mp4_url|hls"
    _JS_EXTS = r"mp4|m3u8|webm|mkv|avi|mpd|ts|flv|mov|wmv"
    js_re = re.compile(
        r"""["'](?:""" + _JS_KEYS + r""")["']\s*:\s*"""
        r"""["'](https?://[^"']+\.(?:""" + _JS_EXTS + r""")"""
        r"""(?:[?#][^"']*)?)\s*["']""",
        re.I,
    )
    for m in js_re.finditer(html):
        video_url = m.group(1).strip()
        results.append({
            "title": _title_from_url(video_url),
            "url": video_url,
            "filesize": None,
            "ext": _get_extension(video_url),
        })

    return results


def _extract_data_attrs(html, base_url):
    """Extracts video URLs from ``data-*`` attributes in HTML elements.

    Many websites use lazy-loading or player configurations
    stored in ``data-src``, ``data-video-url``, etc. attributes."""
    results = []
    data_re = re.compile(
        r'data-(?:src|video-url|video|file|stream|hls)\s*=\s*'
        r'["\']([^"\']+)',
        re.I,
    )
    for m in data_re.finditer(html):
        url = m.group(1).strip()
        if not _has_video_extension(url):
            continue
        abs_url = urljoin(base_url, url)
        results.append({
            "title": _title_from_url(abs_url),
            "url": abs_url,
            "filesize": None,
            "ext": _get_extension(abs_url),
        })

    return results


# Internal utilities


# Full <meta ...> tag. Extracting the tag first and parsing its attributes
# on that short fragment avoids the O(n^2) backtracking of combining two lazy [^>]*?
# in a single pattern (a 512KB document without '>' would hang the scanner; ReDoS by
# content). The {0,2000} limit bounds the tag; a real <meta> does not come close, and without
# it a '<meta' without closing '>' would cause re-scanning until the end from each position.
_META_TAG_RE = re.compile(r'<meta\s[^>]{0,2000}>', re.I)
_META_PROP_RE = re.compile(r'(?:property|name)\s*=\s*["\']([^"\']+)', re.I)
_META_CONTENT_RE = re.compile(r'content\s*=\s*["\']([^"\']*)', re.I)


def _iter_meta_tags(html):
    """Generates ``(property_lower, content)`` for each ``<meta>`` with both attributes."""
    for tag in _META_TAG_RE.finditer(html):
        frag = tag.group(0)
        prop = _META_PROP_RE.search(frag)
        content = _META_CONTENT_RE.search(frag)
        if prop and content:
            yield prop.group(1).strip().lower(), content.group(1).strip()


def _extract_meta_content(html, prop):
    """Returns the ``content`` value of a meta tag ``property=prop``."""
    prop = prop.lower()
    for name, content in _iter_meta_tags(html):
        if name == prop and content:
            return content
    return None


# Schemes that the Kodi player knows how to handle. They are filtered in scan_page so that
# a third-party document/HTML cannot inject file://, javascript:, data:... (various
# extractors resolve with urljoin, which propagates the scheme of the value without validating it).
_SAFE_SCHEMES = frozenset(("http", "https", "rtmp", "rtsp", "magnet", "acestream"))


def _is_safe_scheme(url):
    """True if the scheme of *url* is one that the player accepts."""
    scheme = url.split(":", 1)[0].lower() if ":" in url else ""
    return scheme in _SAFE_SCHEMES


def _has_video_extension(url):
    """Checks if the URL has a known video extension."""
    try:
        path = urlparse(url).path.lower()
        for ext in _VIDEO_EXTENSIONS:
            if path.endswith(ext):
                return True
    except Exception:
        pass
    return False


def _is_playable_url(url):
    """True if the URL is something the player can open: magnet/acestream,
    a known video extension, or a known platform domain."""
    if url.startswith(("magnet:", "acestream://")):
        return True
    if _has_video_extension(url):
        return True
    try:
        host = urlparse(url).netloc.lower()
        if host.startswith("www."):
            host = host[4:]
        return any(host == d or host.endswith("." + d) for d in _KNOWN_VIDEO_DOMAINS)
    except (ValueError, AttributeError):
        return False


def _clean_anchor_text(raw):
    """Inner text of a <a> without tags or entities, normalized. Returns ''
    if the text is just a URL (doesn't serve as a title; better to derive it from the URL)."""
    text = re.sub(r"\s+", " ", unescape(_TAG_RE.sub(" ", raw))).strip()
    if not text or text.lower().startswith(("http://", "https://", "magnet:", "acestream://")):
        return ""
    return text[:120]


def _get_extension(url):
    """Returns the video extension of the URL, without the dot."""
    try:
        path = urlparse(url).path.lower()
        for ext in _VIDEO_EXTENSIONS:
            if path.endswith(ext):
                return ext.lstrip(".")
    except Exception:
        pass
    return ""


def _title_from_url(url):
    """Generates a readable title from the URL."""
    try:
        path = urlparse(url).path
        name = path.rstrip("/").rsplit("/", 1)[-1]
        # Remove extension
        if "." in name:
            name = name.rsplit(".", 1)[0]
        # Replace hyphens and underscores with spaces
        name = name.replace("-", " ").replace("_", " ")
        return name[:80] if name else url[:80]
    except Exception:
        return url[:80]


def _get_filesize(url):
    """Gets the file size via HEAD request.

    Returns the number of bytes (int) or ``None`` if it could not be obtained.
    """
    try:
        req = Request(url, method="HEAD", headers={"User-Agent": _UA})
        with _opener.open(req, timeout=_HEAD_TIMEOUT) as resp:
            cl = resp.headers.get("Content-Length")
            if cl and cl.isdigit():
                return int(cl)
    except Exception:
        pass
    return None


def _parse_iso_duration(iso):
    """Converts ISO 8601 duration (``PT1H30M15S``) to seconds.

    Returns ``None`` if the format is not recognized.
    """
    if not iso:
        return None
    m = re.match(
        r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$",
        iso, re.I,
    )
    if not m:
        return None
    hours = int(m.group(1) or 0)
    mins = int(m.group(2) or 0)
    secs = int(m.group(3) or 0)
    total = hours * 3600 + mins * 60 + secs
    return total if total > 0 else None
