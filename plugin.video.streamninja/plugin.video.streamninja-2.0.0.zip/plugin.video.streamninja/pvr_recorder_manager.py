# -*- coding: utf-8 -*-
# StreamNinja; Copyright (C) 2024-2026 RubénSDFA1laberot
# License: See LICENSE file.
# Interface and Background Coordinator for HLS PVR

import os
import re
import time
import urllib.parse
import xbmc
import xbmcgui
import xbmcaddon
from datetime import datetime

from hls_recorder import HLSRecorder, ffmpeg_available

_LOCALIZE = xbmcaddon.Addon().getLocalizedString
_KODI_WINDOW = xbmcgui.Window(10000)
_ACTIVE_REC_PROP = "streamninja_active_recordings"


def _active_recordings_count():
    try:
        return int(_KODI_WINDOW.getProperty(_ACTIVE_REC_PROP) or "0")
    except ValueError:
        return 0


def _inc_active_recordings():
    _KODI_WINDOW.setProperty(_ACTIVE_REC_PROP, str(_active_recordings_count() + 1))


def _dec_active_recordings():
    # Upon reaching 0 the property is cleared (not left at "0"): this way "empty" still
    # means "none active" and actual existing checks behave the same.
    n = _active_recordings_count() - 1
    if n > 0:
        _KODI_WINDOW.setProperty(_ACTIVE_REC_PROP, str(n))
    else:
        _KODI_WINDOW.clearProperty(_ACTIVE_REC_PROP)


def _get_setting(setting_id):
    return xbmcaddon.Addon().getSetting(setting_id)


def get_record_path():
    path = _get_setting("record_path")
    if not path:
        if not xbmcgui.Dialog().yesno(
            _LOCALIZE(30220),
            _LOCALIZE(30950)
        ):
            return ""
        path = xbmcgui.Dialog().browse(3, "Choose where to save live recordings", "files")
        if path:
            xbmcaddon.Addon().setSetting("record_path", path)
    return path


def _parse_time_label(label):
    """Converts '1 hour', '1h 30min', '30 min', '45' to minutes. Returns 0 if not applicable."""
    if not label:
        return 0
    label = label.strip().lower()
    if label in ("now", "unlimited", "no limit", "infinite", ""):
        return 0

    m = re.match(r'^(\d+)\s*h\s*(\d+)\s*min', label)
    if m:
        return int(m.group(1)) * 60 + int(m.group(2))

    m = re.match(r'^(\d+)\s*hour', label)
    if m:
        return int(m.group(1)) * 60

    m = re.match(r'^(\d+)\s*min', label)
    if m:
        return int(m.group(1))

    try:
        return int(label)
    except ValueError:
        return 0


def get_timer_mins():
    return _parse_time_label(_get_setting("record_timer"))


def get_delay_mins():
    return _parse_time_label(_get_setting("record_delay"))


def get_max_bandwidth():
    # record_quality is type="enum": Kodi returns the index (0=Maximum, 1=720, 2=480, 3=360),
    # not the text. The bps of each index; 0 = no cap.
    caps = (0, 3_000_000, 1_500_000, 800_000)
    try:
        idx = int(_get_setting("record_quality") or 0)
    except ValueError:
        idx = 0
    return caps[idx] if 0 <= idx < len(caps) else 0


def get_record_format():
    """Returns 'ask' | 'ts' | 'mp4' according to the format setting."""
    # record_format is type="enum": Kodi returns the index (0=Ask, 1=TS, 2=MP4).
    try:
        idx = int(_get_setting("record_format") or 0)
    except ValueError:
        idx = 0
    return ("ask", "ts", "mp4")[idx] if 0 <= idx < 3 else "ask"


def _sanitize_filename(raw_name):
    safe = "".join(c for c in raw_name if c.isalnum() or c in (' ', '-', '_')).strip()
    if not safe:
        safe = "HLS_Recording"
    # Sufficient margin below PATH_MAX (260) after concatenating folder + timestamp + extension.
    return safe[:80]


def _get_pvr_subfolder(base_path):
    pvr_dir = os.path.join(base_path, "Grabaciones_PVR")
    if not os.path.exists(pvr_dir):
        os.makedirs(pvr_dir, exist_ok=True)
    return pvr_dir


def _validate_stream_url(url):
    """True if url is http/https and does not carry Kodi pipe-headers.

    The recorder passes the URL as is to urllib (TS) and to FFmpeg `-i` (MP4); neither
    understands the `url|Header=Value` format, so it is rejected here instead of
    letting the upstream respond with 4xx with an opaque failure.
    """
    if not url or not url.strip():
        return False
    u = url.strip()
    if '|' in u:
        return False
    return urllib.parse.urlparse(u).scheme.lower() in ('http', 'https')


def _recover_orphan_partials(pvr_dir):
    """Promotes the .partial files left from a forced close to their final name.

    The caller invokes it only once per session, during the first recording, when
    no active .partial yet exists: this way it never touches one currently being written.
    Returns how many recordings were recovered.
    """
    recovered = 0
    try:
        entries = os.listdir(pvr_dir)
    except OSError:
        return 0
    for entry in entries:
        if not entry.endswith('.partial'):
            continue
        partial = os.path.join(pvr_dir, entry)
        final = partial[:-len('.partial')]
        try:
            if os.path.getsize(partial) == 0:
                os.remove(partial)
                continue
            # If the final file already exists it is a good recording; the .partial is residue.
            if os.path.exists(final):
                os.remove(partial)
                continue
            os.replace(partial, final)
            recovered += 1
            xbmc.log("[StreamNinja/PVR] Orphan recording recovered: {0}".format(entry), xbmc.LOGINFO)
        except OSError as e:
            xbmc.log("[StreamNinja/PVR] Could not recover {0}: {1!r}".format(entry, e), xbmc.LOGWARNING)
    return recovered


def start_recording_ui(url, canonical_name):
    if not _validate_stream_url(url):
        xbmcgui.Dialog().ok(
            _LOCALIZE(30221),
            _LOCALIZE(30951)
        )
        return

    dest_path = get_record_path()
    if not dest_path:
        return

    # fails if the path does not exist (USB not mounted, network down)
    if not os.path.isdir(dest_path):
        xbmcgui.Dialog().ok(
            _LOCALIZE(30222),
            _LOCALIZE(30952).format(dest_path)
        )
        return

    mins = get_timer_mins()
    delay_mins = get_delay_mins()
    pvr_dir = _get_pvr_subfolder(dest_path)

    # Recover .partial from a previous forced shutdown, only once per session.
    # An orphan only appears after a forced shutdown, which implies restarting Kodi;
    # window properties are cleared in that restart, so the flag is
    # empty in each new session. We recover during the first recording of the session:
    # at that moment no active .partial has been created yet (the recorder for this
    # recording starts further below), so it is impossible to step on a recording in
    # progress even if there are several in the background. Subsequent recordings do not recover.
    if not _KODI_WINDOW.getProperty("streamninja_orphans_recovered"):
        _KODI_WINDOW.setProperty("streamninja_orphans_recovered", "1")
        recovered = _recover_orphan_partials(pvr_dir)
        if recovered:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000),
                _LOCALIZE(30193).format(recovered),
                xbmcgui.NOTIFICATION_INFO, 4000
            )

    fmt = get_record_format()
    has_ffmpeg = ffmpeg_available()
    if fmt == "mp4":
        compress = has_ffmpeg
        if not has_ffmpeg:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30194),
                xbmcgui.NOTIFICATION_WARNING, 5000
            )
    elif fmt == "ts":
        compress = False
    else:  # "ask"
        compress = has_ffmpeg and bool(xbmcgui.Dialog().yesno(
            _LOCALIZE(30218),
            _LOCALIZE(30953),
            nolabel="Native TS",
            yeslabel="Compressed MP4",
        ))

    if delay_mins > 0:
        dp_delay = xbmcgui.DialogProgress()
        dp_delay.create(
            "Scheduled Recording: {0}".format(canonical_name),
            _LOCALIZE(30954).format(delay_mins)
        )
        total_secs = delay_mins * 60
        elapsed = 0
        monitor = xbmc.Monitor()
        while elapsed < total_secs:
            if dp_delay.iscanceled():
                dp_delay.close()
                xbmcgui.Dialog().notification(_LOCALIZE(30000), _LOCALIZE(30195), xbmcgui.NOTIFICATION_INFO)
                return
            remaining = total_secs - elapsed
            rm = remaining // 60
            rs = remaining % 60
            pct = int((elapsed / float(total_secs)) * 100)
            dp_delay.update(pct, "{0}m {1}s remaining to start recording...".format(rm, rs))
            if monitor.waitForAbort(1):
                dp_delay.close()
                return
            elapsed += 1
        dp_delay.close()

    safe_name = _sanitize_filename(canonical_name)
    date_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    ext = 'mp4' if compress else 'ts'
    filename = "{0} - {1}.{2}".format(safe_name, date_str, ext)

    fmt_label = ext.upper()
    out_file = os.path.join(pvr_dir, filename)
    # Atomic reservation of the name: instead of a racy exists(), the .partial is created
    # with O_EXCL. Closes the window where two recordings of the same channel in the
    # same second would choose the same name (exists() let both through
    # and the second truncated the .partial of the first). The recorder reopens this
    # same .partial (raw with 'wb', ffmpeg with -y) and its finally deletes empty ones.
    suffix = 2
    while True:
        if not os.path.exists(out_file):
            try:
                fd = os.open(out_file + ".partial",
                             os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.close(fd)
                break
            except FileExistsError:
                pass
        out_file = os.path.join(
            pvr_dir, "{0} - {1} ({2}).{3}".format(safe_name, date_str, suffix, ext))
        suffix += 1
    max_bw = get_max_bandwidth()
    xbmc.log("[StreamNinja/PVR] Recording started. Destination: {0} | Max quality: {1} bps | Format: {2}".format(out_file, max_bw if max_bw else 'No limit', ext), xbmc.LOGINFO)

    _inc_active_recordings()

    try:
        recorder = HLSRecorder(url, out_file, name=canonical_name, max_duration_mins=mins, max_bandwidth=max_bw, compress=compress)
        recorder.start()

        dp = xbmcgui.DialogProgress()
        dp.create("Recording ({0}): {1}".format(fmt_label, canonical_name), "Connecting to live stream...")

        in_background = False
        bg_dp = None

        recorder.playlist_resolved.wait(timeout=10)
        start_time = time.time()  # Starts counting after resolving the playlist, not before
        if max_bw > 0 and recorder.quality_status != "matched":
            if recorder.quality_status == "forced_lowest":
                xbmcgui.Dialog().notification(
                    _LOCALIZE(30000), _LOCALIZE(30196),
                    xbmcgui.NOTIFICATION_WARNING, 5000
                )
            elif recorder.quality_status in ("single", "error"):
                xbmcgui.Dialog().notification(
                    _LOCALIZE(30000), _LOCALIZE(30197),
                    xbmcgui.NOTIFICATION_INFO, 4000
                )

        while recorder.is_alive():
            if not in_background and dp.iscanceled():
                ans = xbmcgui.Dialog().yesno(
                    _LOCALIZE(30219),
                    _LOCALIZE(30955),
                    nolabel="Stop and Save",
                    yeslabel="Keep in background"
                )

                if not ans:  # 0 -> Stop
                    dp.update(100, "Closing file...")
                    recorder.stop()
                    recorder.join(timeout=5.0)
                    break
                else:  # 1 -> Background
                    dp.close()
                    in_background = True
                    bg_dp = xbmcgui.DialogProgressBG()
                    bg_dp.create("StreamNinja: Recording", canonical_name)

            run_mins = recorder.get_run_time_mins()
            run_secs = int(time.time() - start_time)

            if mins > 0:
                pct = min(int((run_mins / float(mins)) * 100), 100)
            else:
                pct = run_secs % 100  # No limit: cyclic activity bar (indicates "alive")

            sin_datos = (recorder.downloaded_bytes == 0 and run_secs > 10)
            estado_red = "[COLOR orange]" + _LOCALIZE(30961) + "[/COLOR]" if sin_datos else _LOCALIZE(30960)

            if in_background:
                if bg_dp and not bg_dp.isFinished():
                    bg_msg = _LOCALIZE(30962).format(recorder.format_bytes(recorder.downloaded_bytes), estado_red)
                    bg_dp.update(pct, heading="Recording ({0}): {1}".format(fmt_label, canonical_name), message=bg_msg)
            else:
                line1 = _LOCALIZE(30957).format(
                    run_mins, "{0} min".format(mins) if mins > 0 else "Infinite", fmt_label
                )
                line2 = _LOCALIZE(30958).format(recorder.format_bytes(recorder.downloaded_bytes))
                line3 = _LOCALIZE(30959).format(estado_red)
                dp.update(pct, line1 + "\n" + line2 + "\n" + line3)

            time.sleep(0.5)

        if in_background and bg_dp:
            bg_dp.close()
        elif not in_background:
            dp.close()

        if recorder.error_msg:
            xbmcgui.Dialog().ok(_LOCALIZE(30222), recorder.error_msg)
        elif recorder.downloaded_bytes == 0:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30199),
                _LOCALIZE(31108),
                xbmcgui.NOTIFICATION_WARNING
            )
        else:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30198),
                "{0} ({1})".format(canonical_name, recorder.format_bytes(recorder.downloaded_bytes)),
                xbmcgui.NOTIFICATION_INFO, 5000
            )
    finally:
        _dec_active_recordings()


def stop_all_recordings():
    if _active_recordings_count() <= 0:
        xbmcgui.Dialog().notification(_LOCALIZE(30000), _LOCALIZE(30190), xbmcgui.NOTIFICATION_INFO)
        return

    if xbmcgui.Dialog().yesno(
        _LOCALIZE(30223),
        _LOCALIZE(30956)
    ):
        _KODI_WINDOW.setProperty("streamninja_force_stop", "1")
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30191),
            xbmcgui.NOTIFICATION_INFO
        )
        # Wait for each recording to observe the signal and decrement in its
        # own finally block, instead of a fixed 3s sleep; a recorder blocked in
        # a segment (15s timeout) or in a reconnection _sleep may take
        # more than 3s to check _should_stop(), and with a short sleep the signal
        # disappeared before it saw it and it kept recording forever.
        monitor = xbmc.Monitor()
        deadline = time.time() + 20
        while _active_recordings_count() > 0 and time.time() < deadline:
            if monitor.waitForAbort(0.5):
                break
        # The signal is always cleared; leaving it active would abort any future
        # recording. The counter is not touched (each recording decrements it in its
        # finally block), so a retry reflects those that are actually still alive.
        _KODI_WINDOW.clearProperty("streamninja_force_stop")
        if _active_recordings_count() > 0:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30192),
                xbmcgui.NOTIFICATION_WARNING
            )