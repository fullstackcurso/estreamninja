# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.
"""
QR code generator for the remote server interface.

Encapsulates PNG image generation from a URL and writing it to disk.
The lifecycle of the temporary file is the caller's responsibility:
it must invoke cleanup() when the image is no longer needed.

Depends on the segno library (pure Python, BSD), included in lib/segno/.
If for any reason segno is not available, generate() returns None
and the caller must degrade the interface cleanly.
"""
import os
import sys
import tempfile


# --- Constants ---

# Scale factor of the QR module in pixels. With scale=8 a URL of
# ~22 characters generates a version 2 QR of ~176x176px, perfectly
# visible at the usual TV distance.
_QR_SCALE = 8

# Fixed name of the temporary file (in OS temporary directory).
# A deterministic name avoids garbage accumulation if the addon closes
# abruptly; the next run simply overwrites it.
_TMP_FILENAME = "streamninja_remote_qr.png"


# --- Public API ---

def generate(url):
    """Generates a QR code as PNG and writes it to a temporary file.

    The PNG is stored in the OS temporary directory under
    the name ``streamninja_remote_qr.png``.

    Args:
        url: Text string to encode in the QR. Typically an HTTP URL
             of the form ``http://192.168.1.x:8089``.

    Returns:
        Absolute path to the generated PNG file, or ``None`` if generation
        fails for any reason.
    """
    if not url:
        return None

    segno = _import_segno()
    if segno is None:
        return None

    try:
        output_path = os.path.join(tempfile.gettempdir(), _TMP_FILENAME)
        qr = segno.make(url, micro=False, error="M")
        qr.save(
            output_path,
            kind="png",
            scale=_QR_SCALE,
            dark="#000000",
            light="#ffffff",
            border=2,
        )
        return output_path
    except Exception:
        return None


def cleanup(path):
    """Removes the QR PNG file from the disk.

    It is safe to call this function even if ``path`` is None or the file
    no longer exists.

    Args:
        path: Path returned by :func:`generate`, or ``None``.
    """
    if not path:
        return
    try:
        os.remove(path)
    except OSError:
        pass


# --- Internals ---

def _import_segno():
    """Imports segno prioritizing the copy packaged with the addon.

    Adds ``lib/`` to sys.path (only once) so that the local copy has
    precedence over any system installation. If segno is not
    available in either location, returns None so that the
    caller can degrade the interface cleanly.
    """
    # Path to lib/ relative to this same file (works from any CWD)
    lib_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib")

    if lib_dir not in sys.path:
        sys.path.insert(0, lib_dir)

    try:
        import segno  # noqa: PLC0415
        return segno
    except ImportError:
        return None
