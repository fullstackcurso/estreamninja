# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.
"""
Context menu: Copy to StreamNinja.
Saves the path of the selected item in the addon's global property
so it can be pasted and played later.
"""
import sys
import xbmc
import xbmcaddon
import xbmcgui

_LOCALIZE = xbmcaddon.Addon().getLocalizedString

if __name__ == '__main__':
    try:
        item_url = sys.listitem.getPath()
        if item_url:
            xbmcgui.Window(10000).setProperty(
                "streamninja.clipboard.url", item_url
            )
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30186),
                xbmcgui.NOTIFICATION_INFO, 2000
            )
        else:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30187),
                xbmcgui.NOTIFICATION_WARNING, 2000
            )
    except Exception as e:
        xbmc.log("[StreamNinja] context_copy: {0}".format(e), xbmc.LOGERROR)

