# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for details.
#
# STREAMNINJA EXPERIMENTAL:
# StreamNinja is an experimental version where features that might eventually
# reach StreamNinja are tested. It stands out for being developed entirely in Spanish.
# 
# This version is not intended for the general public or other developers:
# the code lacks proper comments, is unpolished, and contains dead or disposable elements
# exclusively used for testing.
"""
External URL Player for StreamNinja

Allows the user to paste a video URL and play it in Kodi.
--
Starts a mini server on the local network that serves a web page
where the user can paste a URL.
Upon sending, Kodi receives it and acts.

Includes playback controls and real-time status using Kodi's JSON-RPC.

Original idea by RubenSDFA1laberot:
The implementation of an ephemeral local HTTP server that starts on demand
to send URLs or text to Kodi and automatically closes upon completion, leaving no open ports or forcing
the user to enable HTTP control in Kodi system settings.

If you decide to use this code in your own developments or are inspired by this original idea,
it is appreciated if you mention this project.

Intelligent detection:
  - Dailymotion (dailymotion.com / dai.ly)   -> dm_gujal
  - YouTube     (youtube.com / youtu.be)      -> plugin.video.youtube
  - Streams     (.m3u8 / .mp4 / .mpd / etc.)  -> direct playback
  - Torrents    (magnet: / .torrent)           -> plugin.video.elementum
  - AceStream   (acestream://)                -> script.module.horus
  - Other websites                            -> SendToKodi / yt-dlp
"""
# noinspection PyUnresolvedReferences
import sys
import os
import hashlib
import json
import time
import re
import socket
import subprocess
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import threading
import ytdlp_resolver
from xbmcaddon import Addon
_LOCALIZE = Addon().getLocalizedString


_ADDON_ID = "plugin.video.streamninja"
_MEDIA = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")
_profile_path = None
# _json_lock serialises file I/O (atomic load/save); _store_lock
# serialises the full read-modify-write logic of history and
# bookmarks, so two daemon threads cannot race and drop an entry.
# Lock acquisition order: _store_lock (outer) -> _json_lock (inner). Never
# the other way round. Network enrichment ALWAYS happens outside _store_lock.
_json_lock = threading.Lock()
_store_lock = threading.Lock()

# yt-dlp always attaches these browser headers; CDNs often reject them
# or they are redundant for Kodi. They are filtered out except for direct user links.
_GENERIC_HEADERS = {
    "user-agent", "accept", "accept-language", "accept-encoding",
    "sec-fetch-dest", "sec-fetch-mode", "sec-fetch-site",
    "sec-ch-ua", "sec-ch-ua-mobile", "sec-ch-ua-platform",
}
# Must match _MAX_HISTORY in url_remote.py; both processes trim the
# SAME url_history.json, and a different value would cause its length to oscillate.
MAX_HISTORY = 50
MAX_BOOKMARKS = 50
MAX_SCAN_HISTORY = 20
_DEBRID_CACHE_TTL = 600   # 10 min: Debrid links expire; conservative TTL
_DEBRID_CACHE_MAX = 20
_SCAN_CACHE_TTL = 600     # 10 min: web scan results kept in cache
_SCAN_CACHE_MAX = 15

_STREAM_EXTENSIONS = {
    ".m3u8", ".mp4", ".mkv", ".avi", ".ts", ".flv",
    ".mov", ".wmv", ".webm", ".mpd", ".m3u",
}

# The group captures the content ID; the optional suffix (?:[?&].*)? tolerates
# non-standard "?params" (the official wiki says the scheme doesn't include it, but
# this way a link with an unusual query string plays fine instead of failing).
_ACESTREAM_RE = re.compile(r"acestream://([0-9a-fA-F]{40})(?:[?&].*)?", re.IGNORECASE)
_ACE_HASH_RE = re.compile(r"[0-9a-fA-F]{40}")


def _ace_engine_alive(host, port, timeout=1):
    """True if the AceStream engine responds on host:port. Without the engine it
    fails fast due to a refused connection or short timeout, avoiding Kodi's
    30-second hang when trying to play directly with nothing listening."""
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True
    except (OSError, ValueError):
        return False


def _clip_via_cmd(cmd):
    try:
        out = subprocess.run(
            cmd, capture_output=True, encoding="utf-8",
            errors="replace", timeout=2,
        )
        return out.stdout.strip() if out.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def _get_system_clipboard_text():
    """Reads the OS clipboard, or '' if unavailable (other platform, no
    xclip/xsel, clipboard locked). In that case the button that uses it
    simply does not appear, without raising an error."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            import ctypes.wintypes
            CF_UNICODETEXT = 13
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            user32.GetClipboardData.restype = ctypes.c_void_p
            user32.GetClipboardData.argtypes = [ctypes.wintypes.UINT]
            kernel32.GlobalLock.restype = ctypes.c_void_p
            kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            if not user32.OpenClipboard(None):
                return ""
            try:
                handle = user32.GetClipboardData(CF_UNICODETEXT)
                if not handle:
                    return ""
                ptr = kernel32.GlobalLock(handle)
                if not ptr:
                    return ""
                try:
                    return ctypes.wstring_at(ptr).strip()
                finally:
                    kernel32.GlobalUnlock(handle)
            finally:
                user32.CloseClipboard()
        except Exception:
            return ""
    if sys.platform == "darwin":
        return _clip_via_cmd(["pbpaste"])
    # Linux/Unix. On Android there is no xclip/xsel nor a reliable subprocess.
    if xbmc.getCondVisibility("System.Platform.Android"):
        return ""
    return (_clip_via_cmd(["xclip", "-selection", "clipboard", "-o"])
            or _clip_via_cmd(["xsel", "-b", "-o"]))


_PLAYABLE_PREFIXES = ("http://", "https://", "magnet:", "acestream://")


def _looks_like_playable_url(text):
    """True if text looks playable: a supported scheme or a bare AceStream
    hash (40 hex). Size is capped: a real URL/magnet never exceeds a few
    KB, so a huge clipboard won't build an oversized plugin URL."""
    if not text or len(text) > 8192:
        return False
    return (text.lower().startswith(_PLAYABLE_PREFIXES)
            or bool(_ACE_HASH_RE.fullmatch(text)))


def _get_profile():
    global _profile_path
    if _profile_path is None:
        _profile_path = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile")
        )
        os.makedirs(_profile_path, exist_ok=True)
    return _profile_path


def _history_path():
    return os.path.join(_get_profile(), "url_history.json")


def _bookmarks_path():
    return os.path.join(_get_profile(), "url_bookmarks.json")


def _scan_history_path():
    return os.path.join(_get_profile(), "scan_history.json")


def _get_scan_history():
    return _load_json(_scan_history_path())


def _add_to_scan_history(raw_input, scan_type):
    raw_input = raw_input.strip()
    if not raw_input:
        return
    entries = _load_json(_scan_history_path())
    entries = [e for e in entries if e.get('input') != raw_input]
    if scan_type == 'telegram':
        name = raw_input.lstrip('@')
        for prefix in ('https://t.me/', 'http://t.me/', 't.me/'):
            if name.lower().startswith(prefix):
                name = name[len(prefix):]
                break
        name = name.split('/')[0].split('?')[0].strip()
        label = '@' + name if name else raw_input
    else:
        label = raw_input
        for prefix in ('https://www.', 'http://www.', 'https://', 'http://'):
            if label.lower().startswith(prefix):
                label = label[len(prefix):]
                break
        label = label[:80]
    entries.insert(0, {
        'input': raw_input,
        'label': label,
        'type': scan_type,
        'date': time.strftime('%d/%m/%Y %H:%M'),
        'timestamp': int(time.time()),
    })
    _save_json(_scan_history_path(), entries[:MAX_SCAN_HISTORY])


def _remove_from_scan_history(raw_input):
    entries = _load_json(_scan_history_path())
    _save_json(_scan_history_path(), [e for e in entries if e.get('input') != raw_input])


def _clear_scan_history():
    _save_json(_scan_history_path(), [])


def _get_setting_int(setting_id, default=0, max_val=None):
    """Lee un ajuste nativo de Kodi como entero con validacion.

    Los ajustes de tipo 'enum' en settings.xml devuelven el indice
    seleccionado como cadena (ej. "0", "2"). Esta funcion convierte
    a entero de forma segura, aplicando el valor por defecto si la
    cadena esta vacia, corrupta o fuera de rango.
    """
    try:
        val = int(xbmcaddon.Addon().getSetting(setting_id))
    except (ValueError, TypeError):
        return default
    if val < 0 or (max_val is not None and val > max_val):
        return default
    return val


def _load_json(path):
    with _json_lock:
        # A .tmp here is an orphan from a write that never reached os.replace:
        # under the same lock there is none in progress, so it is safe to delete.
        tmp = path + ".tmp"
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []


def _save_json(path, data):
    # Atomic write: tmp in the same directory + os.replace (atomic rename
    # on the same volume, guaranteed on Windows). fsync is best-effort for
    # durability against power loss; if the FS doesn't support it, replace still runs.
    # A mid-write failure leaves the previous JSON intact instead of truncating it.
    with _json_lock:
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass
            os.replace(tmp, path)
        except OSError as exc:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass
            xbmc.log("[StreamNinja] Error guardando {0}: {1}".format(path, exc),
                     xbmc.LOGWARNING)


def _load_list(path):
    """_load_json pero garantizando una lista. Historial y marcadores siempre
    son listas; un fichero manipulado a objeto JSON no debe reventar el bucle
    de los consumidores (mismo criterio que _load_history en url_remote)."""
    data = _load_json(path)
    return data if isinstance(data, list) else []


def parse_url_with_headers(raw_url):
    """Separa URL y headers en formato pipe.

    Entrada: "http://example.com/video.m3u8|User-Agent=xxx&Referer=yyy"
    Salida:  ("http://example.com/video.m3u8", {"User-Agent": "xxx", ...})
    """
    if not raw_url:
        return "", {}
    raw_url = raw_url.strip()
    if "|" not in raw_url:
        return raw_url, {}

    parts = raw_url.split("|", 1)
    url = parts[0].strip()
    headers_str = parts[1].strip()
    if not headers_str:
        return url, {}

    headers = {}
    for pair in headers_str.split("&"):
        if "=" in pair:
            key, value = pair.split("=", 1)
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] in ('"', "'") and value[-1] == value[0]:
                value = value[1:-1]
            if key:
                headers[key] = urllib.parse.unquote(value)
    return url, headers


def is_direct_stream(url):
    """Determina si la URL apunta a un stream reproducible directamente."""
    try:
        parsed = urllib.parse.urlparse(url)
        _, ext = os.path.splitext(parsed.path.lower())
        return ext in _STREAM_EXTENSIONS
    except Exception:
        return False


def build_kodi_url(url, headers=None):
    """Reconstruye URL con headers en formato pipe de Kodi."""
    if not headers:
        return url
    parts = ["{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in headers.items()]
    return url + "|" + "&".join(parts)


def detect_dailymotion_id(url):
    """Extracts the video ID from a Dailymotion URL, or returns None."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]

        if host.endswith("dailymotion.com"):
            match = re.match(r"/video/([a-zA-Z0-9]+)", parsed.path)
            if match:
                return match.group(1)
            match = re.match(r"/embed/video/([a-zA-Z0-9]+)", parsed.path)
            if match:
                return match.group(1)
        elif host == "dai.ly":
            vid = parsed.path.strip("/")
            if vid:
                return vid.split("_")[0].split("?")[0]
    except Exception:
        pass
    return None


def detect_youtube_id(url):
    """Extracts the video ID from a YouTube URL, or returns None."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]

        if host in ("youtube.com", "m.youtube.com"):
            if "/watch" in parsed.path:
                params = urllib.parse.parse_qs(parsed.query)
                vid_list = params.get("v", [])
                if vid_list:
                    return vid_list[0]
            elif "/shorts/" in parsed.path:
                match = re.match(r"/shorts/([a-zA-Z0-9_-]+)", parsed.path)
                if match:
                    return match.group(1)
            elif "/live/" in parsed.path:
                match = re.match(r"/live/([a-zA-Z0-9_-]+)", parsed.path)
                if match:
                    return match.group(1)
        elif host == "youtu.be":
            vid = parsed.path.strip("/")
            if vid:
                return vid
    except Exception:
        pass
    return None


def detect_url_type(raw_url):
    """Classifies a URL and returns (type, id_or_url).
    Types: 'dailymotion', 'youtube', 'rtve', 'torrent',
           'acestream', 'direct_stream', 'web_page'
    """
    url, _ = parse_url_with_headers(raw_url)

    if url.startswith("plugin://"):
        try:
            parsed = urllib.parse.urlparse(url)
            params = urllib.parse.parse_qs(parsed.query)
            if "url" in params:
                extracted = params["url"][0]
                # Raw ID resolution for catalogues and built-in players
                if "action" in params and params["action"][0] in ["play_video", "play_dm", "dm_gujal_search", "play_media"]:
                    if not extracted.startswith("http") and not "://" in extracted:
                        if len(extracted) != 24 or not all(c in "0123456789abcdefABCDEF" for c in extracted):
                            extracted = "https://www.dailymotion.com/video/" + extracted
                
                if extracted.startswith("http") or "://" in extracted:
                    url, _ = parse_url_with_headers(extracted)
                else:
                    return "internal_query", extracted
        except Exception:
            pass

    # Magnet links y ficheros .torrent
    if url.startswith("magnet:"):
        return "torrent", url
    try:
        parsed_path = urllib.parse.urlparse(url).path.lower()
        if parsed_path.endswith(".torrent"):
            return "torrent", url
    except Exception:
        pass

    # AceStream. Accepts the acestream:// scheme (with optional ?params suffix) and
    # the bare content ID (40 hex). We always return the canonical form
    # acestream://<lowercase hex>: the player does replace("acestream://")
    # case-sensitively and needs the id without uppercase scheme or query tail.
    ace_match = _ACESTREAM_RE.fullmatch(url)
    if ace_match:
        return "acestream", "acestream://" + ace_match.group(1).lower()
    if _ACE_HASH_RE.fullmatch(url):
        return "acestream", "acestream://" + url.lower()

    dm_id = detect_dailymotion_id(url)
    if dm_id:
        return "dailymotion", dm_id

    yt_id = detect_youtube_id(url)
    if yt_id:
        return "youtube", yt_id

    # RTVE Play
    rtve_match = re.match(
        r"https?://(?:www\.)?rtve\.es/(?:play/videos/.+/|v/)(\d+)/?", url)
    if not rtve_match:
        rtve_match = re.match(r"https?://ztnr\.rtve\.es/ztnr/(\d+)\.mpd", url)
    if rtve_match:
        return "rtve", rtve_match.group(1)



    # Enlaces internos de Kodi
    if url.startswith("plugin://"):
        return "kodi_plugin", url

    if is_direct_stream(url):
        return "direct_stream", raw_url

    return "web_page", url

_YT_RE = re.compile(
    r"(?:youtube\.com/watch\?.*?v=|youtu\.be/|youtube\.com/shorts/)"
    r"([A-Za-z0-9_-]{11})"
)
_DM_RE = re.compile(
    r"(?:dailymotion\.com/video/|dai\.ly/)([A-Za-z0-9]+)"
)
_VIMEO_RE = re.compile(r"vimeo\.com/(\d+)")
_RTVE_RE = re.compile(
    r"rtve\.es/(?:play/videos/.+/|v/)(\d+)"
)
_RTVE_MPD_RE = re.compile(r"ztnr\.rtve\.es/ztnr/(\d+)\.mpd")

_OG_RE = re.compile(
    r'<meta[^>]+(?:property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']'
    r'|content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\'])',
    re.IGNORECASE,
)
_LEGACY_BIN_RE = re.compile(r"^cnViZW5zZGZhMWxhYmVybnQ=://[a-f0-9]+$")  # Watermark
_THUMB_TIMEOUT = 3

# --- Twitch/Vimeo -> plugin:// of the native addon (only if installed) ---
_TW_VOD_RE = re.compile(
    r"(?:https?://)?(?:www\.|m\.)?twitch\.tv/videos/(\d+)", re.I)
_TW_CLIP_DOMAIN_RE = re.compile(
    r"(?:https?://)?clips\.twitch\.tv/([A-Za-z0-9_-]+)", re.I)
_TW_CLIP_PATH_RE = re.compile(
    r"(?:https?://)?(?:www\.|m\.)?twitch\.tv/[^/]+/clip/([A-Za-z0-9_-]+)", re.I)
_TW_LIVE_RE = re.compile(
    r"(?:https?://)?(?:www\.|m\.)?twitch\.tv/([a-zA-Z0-9_]{3,25})/?(?:\?[^/]*)?$", re.I)
# twitch.tv path prefixes that are not channels; treating them as channels would yield an invalid plugin://.
_TW_RESERVED = frozenset({
    "videos", "directory", "p", "search", "settings", "subscriptions",
    "wallet", "jobs", "turbo", "prime", "login", "signup", "logout",
    "downloads", "creatorcamp", "broadcast",
})
_VIMEO_PLAYER_RE = re.compile(
    r"(?:https?://)?player\.vimeo\.com/video/(\d+)(?:[?/]h(?:ash)?=([A-Za-z0-9]+))?", re.I)
_VIMEO_PAGE_RE = re.compile(
    r"(?:https?://)?(?:www\.)?vimeo\.com/(\d+)(?:/([A-Za-z0-9]+))?", re.I)


def _resolve_known_plugin(url):
    """Returns a plugin:// URL for the native Twitch/Vimeo addon if installed and
    the URL matches; otherwise None. Does not change existing behaviour: it only
    adds a direct path (better quality/auth, works on Android without yt-dlp)
    when the addon is present. Schemes taken from plugin.video.twitch / plugin.video.vimeo."""
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.twitch)"):
        m = _TW_VOD_RE.search(url)
        if m:
            return "plugin://plugin.video.twitch/?mode=play&video_id=" + m.group(1)
        m = _TW_CLIP_DOMAIN_RE.search(url) or _TW_CLIP_PATH_RE.search(url)
        if m:
            return "plugin://plugin.video.twitch/?mode=play&slug=" + m.group(1)
        m = _TW_LIVE_RE.search(url)
        if m and m.group(1).lower() not in _TW_RESERVED:
            return "plugin://plugin.video.twitch/?mode=play&channel_name=" + m.group(1)
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.vimeo)"):
        for rgx in (_VIMEO_PLAYER_RE, _VIMEO_PAGE_RE):
            m = rgx.search(url)
            if m:
                suffix = (":" + m.group(2)) if m.group(2) else ""
                return ("plugin://plugin.video.vimeo/play/?video_id="
                        + m.group(1) + suffix)
    return None


def _auto_thumb(url):
    """Devuelve la URL de miniatura para la URL dada, o cadena vacia.

    Soporta YouTube, Dailymotion y RTVE (sin HTTP), Vimeo (oEmbed)
    y webs genericas (og:image). En caso de error devuelve cadena vacia.
    """
    if not url:
        return ""
    # YouTube (sin peticion HTTP)
    m = _YT_RE.search(url)
    if m:
        return "https://img.youtube.com/vi/{0}/hqdefault.jpg".format(m.group(1))
    # Dailymotion (sin peticion HTTP)
    m = _DM_RE.search(url)
    if m:
        return "https://www.dailymotion.com/thumbnail/video/{0}".format(m.group(1))
    # RTVE; CDN de thumbnails publico (sin peticion extra)
    m = _RTVE_RE.search(url)
    if not m:
        m = _RTVE_MPD_RE.search(url)
    if m:
        return "https://img2.rtve.es/v/{0}/?w=480".format(m.group(1))
    # Vimeo; oEmbed API (sin autenticacion)
    m = _VIMEO_RE.search(url)
    if m:
        return _vimeo_thumb(url)
    # Webs genericas; intentar og:image
    if url.startswith("http"):
        return _og_thumb(url)
    return ""


def _vimeo_thumb(url):
    """Obtiene miniatura de Vimeo via oEmbed."""
    try:
        import requests
        r = requests.get(
            "https://vimeo.com/api/oembed.json",
            params={"url": url, "width": 480},
            timeout=_THUMB_TIMEOUT,
        )
        if r.status_code == 200:
            return r.json().get("thumbnail_url", "")
    except Exception:
        pass
    return ""


def _og_thumb(url):
    """Extrae la meta tag og:image del HTML de una pagina web."""
    try:
        import requests
        r = requests.get(
            url,
            timeout=_THUMB_TIMEOUT,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
            stream=True,
        )
        try:
            if r.status_code == 200:
                chunk = ""
                for c in r.iter_content(chunk_size=8192, decode_unicode=True):
                    if isinstance(c, bytes):
                        c = c.decode("utf-8", errors="ignore")
                    chunk += c
                    if len(chunk) > 32768:
                        break
                
                m = _OG_RE.search(chunk)
                if m:
                    return m.group(1) or m.group(2) or ""
        finally:
            r.close()
    except Exception:
        pass
    return ""


def _auto_label(url):
    """Genera un titulo legible para la URL dada.

    YouTube/DM/Vimeo: titulo real via oEmbed (sin autenticacion).
    RTVE: titulo real via API publica.
    Otras URLs: nombre derivado del path.
    """
    if not url:
        return ""
    try:
        import requests
        # YouTube
        m = _YT_RE.search(url)
        if m:
            r = requests.get(
                "https://www.youtube.com/oembed",
                params={"url": url, "format": "json"},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # Dailymotion
        m = _DM_RE.search(url)
        if m:
            r = requests.get(
                "https://www.dailymotion.com/services/oembed",
                params={"url": url, "format": "json"},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # Vimeo
        m = _VIMEO_RE.search(url)
        if m:
            r = requests.get(
                "https://vimeo.com/api/oembed.json",
                params={"url": url},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # RTVE; API publica de metadatos
        m = _RTVE_RE.search(url)
        if not m:
            m = _RTVE_MPD_RE.search(url)
        if m:
            rtve_id = m.group(1)
            try:
                r = requests.get(
                    "https://www.rtve.es/api/videos/{0}.json".format(rtve_id),
                    timeout=3,
                    headers={"User-Agent": "Mozilla/5.0"},
                )
                if r.status_code == 200:
                    data = r.json()
                    page = data.get("page", {})
                    items = page.get("items", [])
                    if items:
                        title = items[0].get("longTitle") or items[0].get("title", "")
                        if title:
                            return title
            except Exception:
                pass
            return "RTVE {0}".format(rtve_id)
    except Exception:
        pass
    # Fallback: limpiar path de la URL
    try:
        parsed = urllib.parse.urlparse(url)
        path = parsed.path.rstrip("/").rsplit("/", 1)[-1]
        if "." in path:
            path = path.rsplit(".", 1)[0]
        name = path.replace("-", " ").replace("_", " ")
        # Strip hex hashes (20-30 chars)
        name = re.sub(r"\s+[a-fA-F0-9]{20,30}$", "", name)
        return name.strip()[:80] if name.strip() else ""
    except Exception:
        return ""


def _add_to_history(raw_url, label=None, thumb=None):
    """Inserts the entry instantly; any missing thumbnail/title is
    fetched over the network in a background thread (the UI is never blocked)."""
    need_thumb = not thumb
    need_label = not label or label == raw_url
    with _store_lock:
        history = _load_list(_history_path())
        # Re-using thumb/label from a previous entry avoids another network round-trip.
        for h in history:
            if h.get("url") == raw_url:
                if need_thumb and h.get("thumb"):
                    thumb, need_thumb = h["thumb"], False
                if need_label and h.get("label") and h["label"] != raw_url:
                    label, need_label = h["label"], False
                break
        history = [h for h in history if h.get("url") != raw_url]
        entry = {
            "url": raw_url,
            "label": label or raw_url,
            "date": time.strftime("%d/%m/%Y %H:%M"),
            "timestamp": int(time.time()),
        }
        if thumb:
            entry["thumb"] = thumb
        history.insert(0, entry)
        _save_json(_history_path(), history[:MAX_HISTORY])
    if need_thumb or need_label:
        threading.Thread(
            target=_enrich_history_entry,
            args=(raw_url, need_thumb, need_label),
            daemon=True,
        ).start()


def _enrich_history_entry(url, need_thumb=True, need_label=True):
    """Fetches thumb/label over the network and applies them if the entry still exists.
    Does not write to disk if nothing is obtained. Idempotent."""
    try:
        thumb = _auto_thumb(url) if need_thumb else ""
        label = ""
        if need_label:
            fetched = _auto_label(url)
            if fetched and fetched != url:
                label = fetched
        if not thumb and not label:
            return
        with _store_lock:
            history = _load_list(_history_path())
            changed = False
            for h in history:
                if h.get("url") == url:
                    if thumb and not h.get("thumb"):
                        h["thumb"] = thumb
                        changed = True
                    if label and (not h.get("label") or h["label"] == url):
                        h["label"] = label
                        changed = True
                    break
            if changed:
                _save_json(_history_path(), history)
    except Exception as exc:
        # Daemon thread: a failure must not die silently (see logging section).
        xbmc.log("[StreamNinja] enrich history: {0}".format(exc), xbmc.LOGWARNING)


def _get_history():
    return _load_list(_history_path())


def _clear_history():
    with _store_lock:
        _save_json(_history_path(), [])


def _remove_from_history(url):
    with _store_lock:
        history = _load_list(_history_path())
        _save_json(_history_path(), [h for h in history if h.get("url") != url])


def _get_bookmarks():
    return _load_list(_bookmarks_path())


def _add_bookmark(name, url):
    """Saves the bookmark instantly; the thumbnail is fetched in the
    background to avoid freezing the UI with a synchronous HTTP request."""
    with _store_lock:
        bookmarks = _load_list(_bookmarks_path())
        if any(b.get("url") == url for b in bookmarks):
            return False
        bookmarks.append({
            "name": name,
            "url": url,
            "date": time.strftime("%d/%m/%Y %H:%M"),
        })
        # When the cap is reached we keep the NEWEST entries; trimming from the
        # start would discard the one the user just saved (we would return True
        # without having actually saved it).
        _save_json(_bookmarks_path(), bookmarks[-MAX_BOOKMARKS:])
    threading.Thread(
        target=_enrich_bookmark_thumb, args=(url,), daemon=True,
    ).start()
    return True


def _enrich_bookmark_thumb(url):
    """Fetches the thumbnail over the network and sets it if the bookmark still lacks one.
    Does not write to disk if _auto_thumb returns nothing."""
    try:
        thumb = _auto_thumb(url)
        if not thumb:
            return
        with _store_lock:
            bookmarks = _load_list(_bookmarks_path())
            changed = False
            for b in bookmarks:
                if b.get("url") == url and not b.get("thumb"):
                    b["thumb"] = thumb
                    changed = True
                    break
            if changed:
                _save_json(_bookmarks_path(), bookmarks)
    except Exception as exc:
        # Daemon thread: a failure must not die silently (see logging section).
        xbmc.log("[StreamNinja] enrich bookmark: {0}".format(exc), xbmc.LOGWARNING)


def _remove_bookmark(url):
    with _store_lock:
        bookmarks = _load_list(_bookmarks_path())
        new_bookmarks = [b for b in bookmarks if b.get("url") != url]
        _save_json(_bookmarks_path(), new_bookmarks)
    return len(bookmarks) != len(new_bookmarks)


def _rename_bookmark(url, new_name):
    with _store_lock:
        bookmarks = _load_list(_bookmarks_path())
        changed = False
        for b in bookmarks:
            if b.get("url") == url:
                b["name"] = new_name
                changed = True
                break
        if changed:
            _save_json(_bookmarks_path(), bookmarks)
    return changed


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _get_handle():
    """Obtiene el handle del plugin de forma segura."""
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1





def open_url_dialog():
    """Main Open URL menu."""
    h = _get_handle()

    li = xbmcgui.ListItem(
        label=_LOCALIZE(30100)
    )
    li.setArt({"icon": os.path.join(_MEDIA, "url_clipboard.png")})
    li.setInfo("video", {
        "plot": (
            "Paste a video link to play it.\n\n"
            "Supported URLs:\n"
            "  • Dailymotion: dailymotion.com/video/xxx\n"
            "  • YouTube: youtube.com/watch?v=xxx\n"
            "  • Torrent / Magnet: .torrent, magnet:?\n"
            "  • AceStream: acestream:// or content ID (hash)\n"
            "  • Direct stream: .m3u8, .m3u, .mp4, .mkv, .mpd, .avi, .ts, .flv, .mov, .wmv, .webm\n"
            "  • With headers: URL|User-Agent=xxx&Referer=yyy\n"
            "  • Other websites: automatic resolution"
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_input"), listitem=li, isFolder=False
    )

    # Paste system URL; only if system clipboard brings something playable.
    # First non-empty line (no split() by spaces; would break magnet with dn=).
    sys_clip = next(
        (ln.strip() for ln in _get_system_clipboard_text().splitlines() if ln.strip()),
        "",
    )
    if _looks_like_playable_url(sys_clip):
        clip_display = sys_clip[:70] + "..." if len(sys_clip) > 70 else sys_clip
        li = xbmcgui.ListItem(
            label=_LOCALIZE(30101)
        )
        li.setArt({"icon": os.path.join(_MEDIA, "url_paste.png")})
        li.setInfo("video", {
            "plot": (
                "Link detected in the system clipboard:\n{0}\n\n"
                "Press to play it directly without typing."
            ).format(clip_display),
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_play", url=sys_clip),
            listitem=li, isFolder=False,
        )

    try:
        win = xbmcgui.Window(10000)
        clipboard_url = win.getProperty("streamninja.clipboard.url").strip()
    except Exception:
        clipboard_url = ""
    if clipboard_url:
        url_display = clipboard_url[:70] + "..." if len(clipboard_url) > 70 else clipboard_url
        li = xbmcgui.ListItem(
            label=_LOCALIZE(30102)
        )
        li.setArt({"icon": os.path.join(_MEDIA, "url_paste.png")})
        li.setInfo("video", {
            "plot": (
                "Link in memory:\n{0}\n\n"
                "Press to play it directly "
                "without typing."
            ).format(url_display),
        })
        li.addContextMenuItems([
            (_LOCALIZE(30126), "RunPlugin({0})".format(_u(action="url_clipboard_clear")))
        ])
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_play_clipboard"),
            listitem=li, isFolder=False
        )

    li = xbmcgui.ListItem(
        label=_LOCALIZE(30103)
    )
    li.setArt({"icon": os.path.join(_MEDIA, "url_remote.png")})
    li.setInfo("video", {
        "plot": (
            "Opens a temporary server on the local network.\n\n"
            "From your mobile or PC browser, "
            "you can send links without having to type them "
            "with the remote.\n\n"
            "Ideal for devices without a keyboard."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_remote"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(
        label=_LOCALIZE(30104)
    )
    li.setArt({"icon": os.path.join(_MEDIA, "url_scan.png")})
    li.setInfo("video", {
        "plot": (
            "Paste the address of any website or public Telegram channel "
            "(@channel, t.me/channel) and the addon will detect all available "
            "videos.\n\n"
            "Shows title, duration, and size of each.\n\n"
            "On PC it uses yt-dlp (more complete).\n"
            "On Android it uses HTML analysis."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_scan"), listitem=li, isFolder=False
    )

    # My Debrid cloud (only if there is an active linked provider)
    if _debrid_active():
        provider = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
        li = xbmcgui.ListItem(label=_LOCALIZE(30105).format(provider))
        li.setArt({"icon": os.path.join(_MEDIA, "url_cloud.png")})
        li.setInfo("video", {
            "plot": (
                "Videos in your {0} account.\n\n"
                "Play or delete content from your cloud."
            ).format(provider),
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="debrid_library"), listitem=li, isFolder=True
        )

    history = _get_history()
    if history:
        li = xbmcgui.ListItem(
            label=_LOCALIZE(30106).format(len(history))
        )
        li.setArt({"icon": os.path.join(_MEDIA, "url_history.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_history"), listitem=li, isFolder=True
        )

    scan_history = _get_scan_history()
    if scan_history:
        li = xbmcgui.ListItem(
            label=_LOCALIZE(30107).format(len(scan_history))
        )
        li.setArt({"icon": os.path.join(_MEDIA, "scan_history.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="scan_history"), listitem=li, isFolder=True
        )

    bookmarks = _get_bookmarks()
    if bookmarks:
        li = xbmcgui.ListItem(
            label=_LOCALIZE(30108).format(len(bookmarks))
        )
        li.setArt({"icon": os.path.join(_MEDIA, "url_bookmarks.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_bookmarks"), listitem=li, isFolder=True
        )

    li = xbmcgui.ListItem(
        label=_LOCALIZE(30109)
    )
    li.setArt({"icon": os.path.join(_MEDIA, "mis_grabaciones.png")})
    li.setInfo("video", {
        "plot": (
            "Record a live HLS stream (.m3u8) to disk: TV, events, etc.\n\n"
            "With FFmpeg available it can compress to MP4; otherwise, it saves as TS.\n"
            "The destination folder is requested the first time."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="pvr_record"), listitem=li, isFolder=False
    )

    rec_active = xbmcgui.Window(10000).getProperty("streamninja_active_recordings")
    if rec_active:
        li = xbmcgui.ListItem(
            label=_LOCALIZE(30110)
        )
        li.setArt({"icon": os.path.join(_MEDIA, "mis_grabaciones.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="pvr_record_stop"), listitem=li, isFolder=False
        )

    # My Downloads
    li = xbmcgui.ListItem(
        label=_LOCALIZE(30111)
    )
    li.setArt({"icon": os.path.join(_MEDIA, "descargas.png")})
    li.setInfo("video", {
        "plot": (
            "Manage your locally downloaded videos.\n"
            "Play offline or delete files.\n\n"
            "Legal Disclaimer:\n"
            "The download functionality is provided as a\n"
            "neutral technical tool.\n"
            "All downloaded content is your sole and\n"
            "exclusive legal responsibility.\n"
            "StreamNinja does not allow downloading DRM-protected videos."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="show_downloads"),
        listitem=li, isFolder=True,
    )

    li = xbmcgui.ListItem(label=_LOCALIZE(30112))
    li.setArt({"icon": os.path.join(_MEDIA, "opciones.png")})
    li.setInfo("video", {
        "plot": (
            "Access general addon settings and additional utilities "
            "(Debrid, Maintenance, Accessibility, etc)."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="open_settings"), listitem=li, isFolder=True
    )

    # cacheToDisc=False: the menu depends on mutable state (bold, history,
    # clipboard, recordings); must always re-render, also when going back.
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


_resolveurl_mod = None
_resolveurl_tried = False


def _get_resolveurl():
    """Returns the resolveurl module if installed (Kodi adds it to sys.path
    when declared in addon.xml), or None. Caches the result; does not retry on
    failure. The import is heavy (loads hundreds of plugins), so it is done only once."""
    global _resolveurl_mod, _resolveurl_tried
    if _resolveurl_tried:
        return _resolveurl_mod
    _resolveurl_tried = True
    if not xbmc.getCondVisibility("System.HasAddon(script.module.resolveurl)"):
        return None
    try:
        import resolveurl
        _resolveurl_mod = resolveurl
    except Exception as e:
        xbmc.log("[StreamNinja] Could not load ResolveURL: {0}".format(e), xbmc.LOGWARNING)
    return _resolveurl_mod


def _resolveurl_resolve(url):
    """Resuelve url con ResolveURL si reconoce el dominio. None si no es soportado,
    falla, o delega en otro addon. valid_url() es regex local (sin red)."""
    mod = _get_resolveurl()
    if not mod:
        return None
    try:
        hmf = mod.HostedMediaFile(url)
        if not hmf.valid_url():
            return None
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30163),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        stream = hmf.resolve()
    except Exception as e:
        xbmc.log("[StreamNinja] ResolveURL error: {0}".format(e), xbmc.LOGWARNING)
        return None
    if not (isinstance(stream, str) and stream):
        return None
    # Some resolvers (youtube, vimeo...) return plugin://other.addon; that
    # delegation is handled better by yt-dlp, so we fall back to the next method.
    if stream.startswith("plugin://"):
        return None
    return stream


def _scrape_hosters(html):
    """Detects in the HTML links to hosters supported by ResolveURL and returns them
    in scanner format. [] if ResolveURL is missing or there is no HTML."""
    mod = _get_resolveurl()
    if not mod or not html:
        return []
    try:
        # ResolveURL's own regex only looks for href=; embedded hosters are almost
        # always in <iframe src=...>. We capture href and src (valid_url filters).
        links = mod.scrape_supported(html, regex=r'''(?:href|src)\s*=\s*['"]([^'"]+)''')
    except Exception as e:
        xbmc.log("[StreamNinja] scrape_supported error: {0}".format(e), xbmc.LOGWARNING)
        return []
    out = []
    for link in links:
        host = urllib.parse.urlparse(link).hostname or "link"
        out.append({"title": "Hoster: {0}".format(host), "url": link, "filesize": None, "ext": ""})
    return out


# --- DEBRID (CLOUD RESOLVER: AllDebrid / Real-Debrid / TorBox / Premiumize) ---

def _debrid_cache_path():
    return os.path.join(_get_profile(), "debrid_resolve_cache.json")


def _debrid_cache_key(provider, url):
    return hashlib.sha1("{0}|{1}".format(provider, url).encode("utf-8")).hexdigest()


def _debrid_cache_get(provider, url):
    data = _load_json(_debrid_cache_path())
    if not isinstance(data, dict):
        return None
    entry = data.get(_debrid_cache_key(provider, url))
    if entry and (time.time() - entry.get("ts", 0)) < _DEBRID_CACHE_TTL:
        return entry.get("stream")
    return None


def _debrid_cache_put(provider, url, stream):
    data = _load_json(_debrid_cache_path())
    if not isinstance(data, dict):
        data = {}
    data[_debrid_cache_key(provider, url)] = {"stream": stream, "ts": int(time.time())}
    if len(data) > _DEBRID_CACHE_MAX:
        recientes = sorted(
            data.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True
        )[:_DEBRID_CACHE_MAX]
        data = dict(recientes)
    _save_json(_debrid_cache_path(), data)


def _scan_cache_path():
    return os.path.join(_get_profile(), "scan_results_cache.json")


def _scan_cache_get(url):
    data = _load_json(_scan_cache_path())
    if not isinstance(data, dict):
        return None
    key = hashlib.sha1(url.encode("utf-8")).hexdigest()
    entry = data.get(key)
    if entry and (time.time() - entry.get("ts", 0)) < _SCAN_CACHE_TTL:
        return entry.get("videos")
    return None


def _scan_cache_put(url, videos):
    data = _load_json(_scan_cache_path())
    if not isinstance(data, dict):
        data = {}
    key = hashlib.sha1(url.encode("utf-8")).hexdigest()
    data[key] = {"videos": videos, "ts": int(time.time())}
    if len(data) > _SCAN_CACHE_MAX:
        data = dict(
            sorted(data.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)
            [:_SCAN_CACHE_MAX]
        )
    _save_json(_scan_cache_path(), data)


_DEBRID_PREFIX = {
    "AllDebrid": "alldebrid", "Real-Debrid": "realdebrid",
    "TorBox": "torbox", "Premiumize": "premiumize",
}


def _debrid_active():
    """True if there is an active Debrid provider with a linked account. Reads settings
    directly (same logic as debrid_resolver.is_authorized: token +
    <prefix>_authorized) to NOT import the 1285-line module on every menu render;
    the real import is done in _get_debrid() only when used."""
    try:
        addon = xbmcaddon.Addon()
        if addon.getSetting("debrid_enabled") != "true":
            return False
        prefix = _DEBRID_PREFIX.get(
            addon.getSetting("debrid_provider") or "AllDebrid", "alldebrid")
        return (bool(addon.getSetting(prefix + "_token"))
                and addon.getSetting(prefix + "_authorized") == "true")
    except Exception:
        return False


def _get_debrid():
    """Debrid resolver instance. Defensive import: if it fails, the addon
    keeps working as if Debrid did not exist."""
    try:
        import debrid_resolver
        return debrid_resolver.get_resolver()
    except Exception as e:
        xbmc.log("[StreamNinja] Debrid not available: {0}".format(e), xbmc.LOGWARNING)
        return None


def _play_resolved_stream(stream_url, headers=None, protocol="", strip_generic_headers=True):
    """Plays a resolved URL, configuring inputstream and headers.

    Args:
        stream_url: Direct stream URL.
        headers:    Dict of HTTP headers from yt-dlp (optional).
        protocol:   Protocol reported by yt-dlp (optional).
        strip_generic_headers: if True (auto-resolvers) discards
            generic browser headers; if False (direct link written
            by the user) keeps them as is, to not break a manual
            User-Agent that the CDN requires (avoids 403).
    """
    li = xbmcgui.ListItem(path=stream_url)

    # Extract only the real path (ignore query ?...)
    clean_path = urllib.parse.urlparse(stream_url).path.lower()

    meaningful_headers = {}
    if headers:
        if strip_generic_headers:
            meaningful_headers = {
                k: v for k, v in headers.items()
                if k.lower() not in _GENERIC_HEADERS
            }
        else:
            meaningful_headers = dict(headers)

    # Encode headers for setProperty (key=value&key2=value2 format)
    header_str = ""
    if meaningful_headers:
        header_str = "&".join(
            "{0}={1}".format(k, urllib.parse.quote(str(v), safe=""))
            for k, v in meaningful_headers.items()
        )

    is_mpd = clean_path.endswith(".mpd") or "mpd" in protocol
    is_m3u8 = clean_path.endswith(".m3u8") or "m3u8" in protocol

    if is_mpd:
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setMimeType("application/dash+xml")
        if header_str:
            li.setProperty("inputstream.adaptive.manifest_headers", header_str)
            li.setProperty("inputstream.adaptive.stream_headers", header_str)
    elif is_m3u8:
        li.setMimeType("application/x-mpegURL")
        # ISA plays HLS better than the internal demuxer (track selection and
        # adaptive bitrate). We force it if there are headers to inject or if the
        # addon is installed, even if the link is public and headerless.
        if header_str or xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
            li.setProperty("inputstream", "inputstream.adaptive")
            if header_str:
                li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                li.setProperty("inputstream.adaptive.stream_headers", header_str)
    elif header_str:
        # For mp4/other direct formats, use pipe (still supported)
        stream_url = "{0}|{1}".format(stream_url, header_str)
        li = xbmcgui.ListItem(path=stream_url)

    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    xbmc.Player().play(stream_url, li)
    

def play_acestream(content_id=None, ace_url=None, infohash=None, title="", icon="", plot=""):
    """Plays AceStream as Horus did: a content id, an infohash or a url
    (magnet/.torrent) ALWAYS go to the AceStream engine (not to Elementum). Precedence
    id > infohash > url. It is the public entry point equivalent to Horus's, so that
    any addon can call StreamNinja with the same pattern
    (plugin://plugin.video.streamninja/?action=acestream&id=...). If the native engine
    is not available it falls back to Horus/local engine/dialogue: thus it coexists with Horus."""
    addon = xbmcaddon.Addon()

    # Normalize and validate (Horus validates [0-9a-f]{40}; we do not build requests to the engine
    # with unsanitized input). content_id tolerates coming as 'acestream://<hash>'.
    content_id = (content_id or "").strip()
    if content_id:
        m = _ACESTREAM_RE.fullmatch(content_id)
        content_id = (m.group(1) if m else content_id).lower()
        if not re.fullmatch(r"[0-9a-f]{40}", content_id):
            content_id = ""
    infohash = (infohash or "").strip().lower()
    if infohash and not re.fullmatch(r"[0-9a-f]{40}", infohash):
        infohash = ""
    ace_url = (ace_url or "").strip()

    # A caller could send the AceStream via url= instead of id=: if the url is actually
    # an acestream://<hash>, treat it as content id (otherwise it would go by mistake to the torrent path).
    if ace_url and not content_id:
        m = _ACESTREAM_RE.fullmatch(ace_url)
        if m:
            content_id = m.group(1).lower()
            ace_url = ""

    if not (content_id or infohash or ace_url):
        xbmcgui.Dialog().ok(_LOCALIZE(30000), _LOCALIZE(31053))
        return

    # External player on Android (only applies to content id, same as Horus).
    if (content_id and xbmc.getCondVisibility("System.Platform.Android")
            and addon.getSetting("acestream_android_external") == "true"):
        intent = ('StartAndroidActivity("","org.acestream.action.start_content","",'
                  '"acestream:?content_id={0}")'.format(content_id))
        xbmc.log("[StreamNinja] AceStream app externa: {0}".format(intent), xbmc.LOGINFO)
        xbmc.executebuiltin(intent)
        return

    # Native local engine. DOES NOT install or start anything; requires engine listening.
    if addon.getSetting("acestream_enabled") != "false":
        try:
            import acestream_player
            if content_id:
                handled = acestream_player.play(content_id, title=title, icon=icon, plot=plot)
            else:
                # Precedence infohash > url.
                torrent_value = ("magnet:?xt=urn:btih:" + infohash) if infohash else ace_url
                handled = acestream_player.play_torrent(torrent_value, title=title, icon=icon, plot=plot)
            if handled:
                return
        except Exception as e:
            xbmc.log("[StreamNinja/url_player] acestream nativo: {0}".format(e), xbmc.LOGWARNING)

    _acestream_fallback(content_id, infohash, ace_url, title)


def _acestream_fallback(content_id, infohash, ace_url, title=""):
    """Fallback when the native engine is not available: Horus -> direct local
    engine -> dialogue. Horus is called via its plugin:// (they coexist, without collision)."""
    if xbmc.getCondVisibility("System.HasAddon(script.module.horus)"):
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30156),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        if content_id:
            q = {"action": "play", "id": content_id}
        elif infohash:
            q = {"action": "play", "infohash": infohash}
        else:
            q = {"action": "play", "url": ace_url}
        horus_url = "plugin://script.module.horus/?" + urllib.parse.urlencode(q)
        xbmc.executebuiltin('PlayMedia("{0}")'.format(horus_url))
        return

    addon = xbmcaddon.Addon()
    host = addon.getSetting("acestream_ip") or "127.0.0.1"
    port = addon.getSetting("acestream_port") or "6878"

    if (content_id or infohash) and _ace_engine_alive(host, port):
        # Without Horus but local engine listens; direct MPEG-TS stream.
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30157),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        selector = "id={0}".format(content_id) if content_id else "infohash={0}".format(infohash)
        target = "http://{0}:{1}/ace/getstream?{2}".format(host, port, selector)
        name = title or "AceStream"
        li = xbmcgui.ListItem(label=name, path=target)
        li.setContentLookup(False)
        li.setInfo("video", {"title": name})
        xbmc.Player().play(target, li)
        return

    xbmcgui.Dialog().ok(
        _LOCALIZE(30000),
        _LOCALIZE(31100).format(host, port),
    )


def _resolve_and_play(raw_url):
    """Detects URL type and plays with the appropriate method."""
    url_type, value = detect_url_type(raw_url)

    # Debrid Resolver: only intercepts magnets and unknown pages/hosters.
    # Types with their own resolver (dailymotion, youtube, rtve...) do not go through here.
    if url_type in ("torrent", "web_page") and _debrid_active():
        provider = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
        stream = _debrid_cache_get(provider, value)
        if not stream:
            try:
                stream = _get_debrid().resolve(value)
            except Exception as e:
                xbmc.log("[StreamNinja/Debrid] {0}".format(e), xbmc.LOGWARNING)
                stream = None
            if stream:
                _debrid_cache_put(provider, value, stream)
        if stream:
            _play_resolved_stream(stream)
            return

    if url_type == "internal_query":
        xbmcgui.Dialog().ok(
            _LOCALIZE(30212), 
            _LOCALIZE(31101)
        )
        return

    if url_type == "dailymotion":
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30158).format(value),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        played = False
        is_win = xbmc.getCondVisibility("System.Platform.Windows")

        # Read user configuration from Kodi native settings
        dm_level = _get_setting_int("dm_safe_level", default=0, max_val=3)

        # Order on Windows (user request): 1) script with system Python
        # (no yt-dlp, bypasses block), 2) yt-dlp as fallback, 3) internal resolver
        # (dm_gujal/direct according to dm_safe_level), 4) browser.
        # Method 0: system script, Windows only. Returns HLS without headers, so it
        # plays with _play_resolved_stream like any m3u8.
        if is_win:
            try:
                import dm_resolver
                _syspy = dm_resolver._dm_play_syspy(value)
                if _syspy and _syspy.get("url"):
                    _play_resolved_stream(_syspy["url"], protocol="m3u8")
                    played = True
            except Exception as e:
                xbmc.log("[StreamNinja/url_player] DM syspy: " + str(e), xbmc.LOGWARNING)

        # yt-dlp: primary on desktop non-Windows with dm_level 0/3 (previous behavior);
        # on Windows it acts as fallback of the script (hence 'is_win').
        is_desktop = xbmc.getCondVisibility(
            "System.Platform.Windows | System.Platform.Linux | "
            "System.Platform.OSX"
        )
        use_ytdlp_first = is_win or (dm_level == 3) or (is_desktop and dm_level == 0)

        # Method 1: yt-dlp
        if not played and use_ytdlp_first and ytdlp_resolver.is_available():
            dm_url = "https://www.dailymotion.com/video/" + value
            info = ytdlp_resolver.resolve_full(dm_url)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                played = True

        # Method 2: internal addon resolver
        if not played:
            try:
                import dm_resolver
                if is_win:
                    result = dm_resolver._dm_play(value, dm_level=dm_level, try_syspy=False)
                else:
                    result = dm_resolver._dm_play_android(
                        value, dm_level=dm_level)
                if result and result.get('url'):
                    stream_url = result['url']
                    
                    # Encode headers so Kodi includes them in CDN requests
                    headers_dict = result.get('headers')
                    header_str = ""
                    if headers_dict:
                        header_str = "&".join(
                            "{0}={1}".format(k, urllib.parse.quote(str(v), safe=""))
                            for k, v in headers_dict.items()
                        )
                        
                    mime_type = result.get('mime', '')
                    is_hls = 'mpegURL' in mime_type
                    
                    if not is_hls and header_str:
                        stream_url = "{0}|{1}".format(stream_url, header_str)

                    li = xbmcgui.ListItem(path=stream_url)
                    if mime_type:
                        li.setMimeType(mime_type)
                        
                    if is_hls and header_str:
                        # inputstream.adaptive needs headers in its properties
                        li.setProperty("inputstream", "inputstream.adaptive")
                        li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                        li.setProperty("inputstream.adaptive.stream_headers", header_str)
                        
                    li.setContentLookup(False)
                    subs = result.get('subs')
                    if subs and isinstance(subs, list):
                        li.setSubtitles(subs)
                    li.setProperty("IsPlayable", "true")
                    xbmc.Player().play(stream_url, li)
                    played = True
            except Exception as e:
                xbmc.log(
                    "[StreamNinja/url_player] _dm_play error: " + str(e),
                    xbmc.LOGWARNING,
                )

        # Method 3: browser as last resort
        if not played:
            dm_web = "https://www.dailymotion.com/video/" + value
            is_android = xbmc.getCondVisibility("System.Platform.Android")
            if is_android:
                opts = ["Open in browser", "Open in external app"]
                sel = xbmcgui.Dialog().select(_LOCALIZE(30213), opts)
                if sel < 0: return
                if sel == 0:
                    import webbrowser
                    webbrowser.open(dm_web)
                else:
                    xbmc.executebuiltin(
                        'StartAndroidActivity("","'
                        'android.intent.action.VIEW","","'
                        '{0}")'.format(dm_web))
            else:
                if xbmcgui.Dialog().yesno(
                    _LOCALIZE(30000),
                    _LOCALIZE(30213)):
                    import webbrowser
                    webbrowser.open(dm_web)

    elif url_type == "youtube":
        yt_web = "https://www.youtube.com/watch?v=" + value
        is_android = xbmc.getCondVisibility("System.Platform.Android")

        opts = []
        actions = []

        # YouTube Addon (does not ask for API key to play)
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            opts.append(_LOCALIZE(30757))
            actions.append("addon")
        # yt-dlp (PC)
        if ytdlp_resolver.is_available():
            opts.append(_LOCALIZE(30758))
            actions.append("ytdlp")
        # Native YouTube app (Android only)
        if is_android:
            opts.append(_LOCALIZE(30759))
            actions.append("yt_app")
        # Browser (always)
        opts.append(_LOCALIZE(30755))
        actions.append("browser")

        # If only one option, execute directly
        if len(opts) == 1:
            sel = 0
        else:
            sel = xbmcgui.Dialog().select(_LOCALIZE(30214), opts)
        if sel < 0:
            return

        act = actions[sel]
        if act == "ytdlp":
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30164),
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_full(yt_web)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
            else:
                xbmcgui.Dialog().ok(
                    _LOCALIZE(30000), _LOCALIZE(30213))
        elif act == "addon":
            xbmc.executebuiltin(
                'PlayMedia("plugin://plugin.video.youtube/play/?video_id={0}")'.format(value))
        elif act == "yt_app":
            xbmc.executebuiltin(
                'StartAndroidActivity(com.google.android.youtube,'
                '"android.intent.action.VIEW","",'
                '"{0}")'.format(yt_web))
        elif act == "browser":
            import webbrowser
            webbrowser.open(yt_web)

    elif url_type == "kodi_plugin":
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30160),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        xbmc.executebuiltin('PlayMedia("{0}")'.format(value))


    elif url_type == "direct_stream":
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30161),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        # The link was typed by the user; we keep their headers
        # (User-Agent, Referer...) intact to not cause 403 on CDN.
        url, headers = parse_url_with_headers(raw_url)
        _play_resolved_stream(url, headers=headers, strip_generic_headers=False)

    elif url_type == "torrent":
        has_elementum = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.elementum)"
        )
        if has_elementum:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30162),
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            elem_url = (
                "plugin://plugin.video.elementum/play?"
                + urllib.parse.urlencode({"uri": value})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(elem_url))
        else:
            # Without Elementum (and Debrid did not resolve above): try local AceStream
            # engine if active and alive. Additive: any failure falls back to dialogue.
            if xbmcaddon.Addon().getSetting("acestream_enabled") != "false":
                try:
                    import acestream_player
                    if acestream_player.play_torrent(value):
                        return
                except Exception as e:
                    xbmc.log("[StreamNinja/url_player] acestream torrent: {0}".format(e),
                             xbmc.LOGWARNING)
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                _LOCALIZE(31101),
            )

    elif url_type == "acestream":
        # value arrives canonicalized as 'acestream://<hex>'. Native logic + fallback
        # chain lives in play_acestream (shared with public 'acestream' action).
        play_acestream(content_id=value.replace("acestream://", ""))

    elif url_type == "rtve":
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30161),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        try:
            stream_url = "https://ztnr.rtve.es/ztnr/{0}.mpd".format(value)
            # Obtain Widevine token
            license_url = ""
            try:
                import requests
                r = requests.get(
                    "https://www.rtve.es/api/token/{0}".format(value),
                    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
                    timeout=5,
                )
                if r.status_code == 200:
                    token_data = r.json()
                    license_url = token_data.get("widevineURL", "")
            except Exception:
                pass

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Referer": "https://www.rtve.es/",
                "Origin": "https://www.rtve.es",
            }
            headers_string = "&".join(
                ["{0}={1}".format(k, urllib.parse.quote(v)) for k, v in headers.items()])

            li = xbmcgui.ListItem(path=stream_url)
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "mpd")
            li.setProperty("inputstream.adaptive.manifest_headers", headers_string)
            li.setProperty("inputstream.adaptive.stream_headers", headers_string)
            if license_url:
                li.setProperty("inputstream.adaptive.license_type",
                               "com.widevine.alpha")
                li.setProperty("inputstream.adaptive.license_key", license_url)
            li.setMimeType("application/dash+xml")
            li.setContentLookup(False)
            xbmc.Player().play(stream_url, li)
        except Exception as e:
            xbmc.log(
                "[StreamNinja/url_player] RTVE error: " + str(e),
                xbmc.LOGWARNING,
            )
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                "Error playing:\n{0}".format(str(e)),
            )



    elif url_type == "web_page":
        # Twitch/Vimeo with their native addon installed; direct plugin:// (first of
        # all). If there is no native addon, _resolve_known_plugin returns None and continues
        # with the normal flow below, which already covers these sites via yt-dlp/SendToKodi.
        native_plugin = _resolve_known_plugin(value)
        if native_plugin:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30170),
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(native_plugin))
            return

        # 0. ResolveURL: hosters (streamtape, dood, mixdrop...) that yt-dlp does not handle
        # well. valid_url() is local regex; if it does not recognize the domain it returns None
        # instantly and continues with yt-dlp.
        ru_stream = _resolveurl_resolve(value)
        if ru_stream:
            li = xbmcgui.ListItem(path=ru_stream)
            _low = ru_stream.split("|", 1)[0].lower()
            if ".m3u8" in _low:
                li.setMimeType("application/x-mpegURL")
            elif ".mpd" in _low:
                li.setProperty("inputstream", "inputstream.adaptive")
                li.setProperty("inputstream.adaptive.manifest_type", "mpd")
            li.setProperty("IsPlayable", "true")
            li.setContentLookup(False)
            xbmc.Player().play(ru_stream, li)
            return

        # 1. yt-dlp (supports hundreds of websites natively)
        if ytdlp_resolver.is_available():
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30164),
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_full(value)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                return
        elif xbmc.getCondVisibility("System.Platform.Android"):
            # Android: no Python for subprocess. yt-dlp in memory (Kodi 20+).
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30164),
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_in_memory(value)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                return

        # 2. SendToKodi
        # Special thanks to SendToKodi for their work and serving as inspiration.
        has_stk = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.sendtokodi)"
        )
        if has_stk:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30165),
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            stk_url = (
                "plugin://plugin.video.sendtokodi/?"
                + urllib.parse.urlencode({"url": value})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(stk_url))
            return

        # 3. YouTube addon (last resort)
        has_yt = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.youtube)"
        )
        if has_yt:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30166),
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            yt_url = (
                "plugin://plugin.video.youtube/uri2addon/?uri="
                + urllib.parse.quote(value)
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(yt_url))
        else:
            # 4. Open in browser / native app
            is_android = xbmc.getCondVisibility("System.Platform.Android")
            if is_android:
                opts = [_LOCALIZE(30755), _LOCALIZE(30756)]
                sel = xbmcgui.Dialog().select(_LOCALIZE(30217), opts)
                if sel < 0:
                    return
                if sel == 1:
                    xbmc.executebuiltin(
                        'StartAndroidActivity("",'
                        '"android.intent.action.VIEW","",'
                        '"{0}")'.format(value))
                else:
                    import webbrowser
                    webbrowser.open(value)
            else:
                msg = _LOCALIZE(30213)
                if xbmcgui.Dialog().yesno(_LOCALIZE(30000), msg):
                    import webbrowser
                    webbrowser.open(value)


def play_clipboard():
    """Plays directly the session clipboard URL."""
    try:
        win = xbmcgui.Window(10000)
        raw = win.getProperty("streamninja.clipboard.url").strip()
    except Exception:
        raw = ""

    if not raw:
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30177),
            xbmcgui.NOTIFICATION_WARNING, 2000
        )
        return

    threading.Thread(target=_add_to_history, args=(raw,), daemon=True).start()
    
    # Consume the clipboard so the button disappears
    win.clearProperty("streamninja.clipboard.url")

    
    _resolve_and_play(raw)


def _find_system_python(require_ytdlp=True):
    """Searches for the system Python executable (not Kodi's).

    Returns the absolute path of the executable or None.
    On Windows, 'python' is prioritized because 'python3' is usually
    the Microsoft Store stub that does not have yt-dlp installed.
    With require_ytdlp=True, it also verifies that yt_dlp is importable; with False
    it is enough for it to be a real Python 3 (to use it with the embedded yt-dlp).
    """
    import subprocess
    import shutil

    is_win = xbmc.getCondVisibility("System.Platform.Windows")
    candidates = ("python", "python3") if is_win else ("python3", "python")

    creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if is_win else 0

    for cmd in candidates:
        abs_path = shutil.which(cmd)
        if not abs_path:
            continue

        # Discard Microsoft Store stub (does not have packages)
        if "WindowsApps" in abs_path:
            continue

        try:
            # 1. Verify that it is a real Python 3
            proc = subprocess.run(
                [abs_path, "--version"],
                capture_output=True, text=True, timeout=5,
                creationflags=creation_flags,
            )
            if proc.returncode != 0 or "Python 3" not in (proc.stdout + proc.stderr):
                continue

            # 2. Verify that yt_dlp is importable from that Python
            if require_ytdlp:
                proc2 = subprocess.run(
                    [abs_path, "-c", "import yt_dlp"],
                    capture_output=True, text=True, timeout=10,
                    creationflags=creation_flags,
                )
                if proc2.returncode != 0:
                    continue

            return abs_path
        except Exception:
            continue
    return None




def _get_download_dest(title, ext=".mp4"):
    """Requests the destination folder from the user and returns the final path.

    If a path is configured in Kodi's native settings, it is used
    as the starting point for the selector. Returns empty string if the
    user cancels.
    """
    saved_path = xbmcaddon.Addon().getSetting("download_path") or ""

    dest_dir = xbmcgui.Dialog().browse(
        3, "Select where to save", "video",
        "", False, False, saved_path,
    )
    if not dest_dir:
        return ""

    safe_title = "".join(c for c in title if c.isalnum() or c in " -_").strip()
    if not safe_title:
        safe_title = "streamninja_download_{0}".format(int(time.time()))
    if len(safe_title) > 120:
        safe_title = safe_title[:120].rstrip()

    return os.path.join(dest_dir, "{0}{1}".format(safe_title, ext))


def _download_direct_url(url, dest, title, headers=None):
    """Downloads a file via HTTP with a progress bar.

    Works with any direct URL (MP4, MKV, etc.) without
    depending on platform-specific headers.
    """
    import requests
    dp = xbmcgui.DialogProgress()
    dp.create(_LOCALIZE(30900), _LOCALIZE(30901).format(title))
    tmp = dest + ".tmp"
    try:
        req_headers = headers or {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0.0.0 Safari/537.36",
        }
        with requests.get(url, headers=req_headers, stream=True, timeout=30) as r:
            if r.status_code >= 400:
                raise Exception(
                    "Server responded with code {0}".format(r.status_code))
            total = int(r.headers.get("content-length", 0))
            done = 0
            with open(tmp, "wb") as f:
                for chunk in r.iter_content(chunk_size=256 * 1024):
                    if dp.iscanceled():
                        break
                    f.write(chunk)
                    done += len(chunk)
                    if total > 0:
                        pct = int(done * 100 / total)
                        mb_done = done / (1024 * 1024)
                        mb_total = total / (1024 * 1024)
                        dp.update(pct, "{0:.1f} MB / {1:.1f} MB".format(
                            mb_done, mb_total))

        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp, dest)
            try:
                import download_manager
                download_manager.log_download(title, dest, "MP4")
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000), "Download completed:\n{0}".format(dest))
        elif os.path.exists(tmp):
            os.remove(tmp)
    except Exception as exc:
        try:
            dp.close()
        except Exception:
            pass
        if os.path.exists(tmp):
            os.remove(tmp)
        xbmc.log("[StreamNinja/url_player] Error in direct download: {0}".format(
            exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(_LOCALIZE(30000), "Error in download:\n{0}".format(
            str(exc)[:200]))


def _resolve_hls_master(m3u8_text, base_url):
    """If the text is an HLS master playlist, returns the absolute URL of the
    variant with the highest BANDWIDTH; if it is already a media playlist, returns None.

    Pure function (no network). For disk download, the highest quality is always
    chosen. The PVR recorder uses its own selection with a bitrate limit.
    """
    if "#EXT-X-STREAM-INF" not in m3u8_text:
        return None
    lines = m3u8_text.splitlines()
    best_bw = -1
    best_url = None
    for i, line in enumerate(lines):
        if not line.startswith("#EXT-X-STREAM-INF"):
            continue
        m = re.search(r"BANDWIDTH=(\d+)", line)
        bw = int(m.group(1)) if m else 0
        for j in range(i + 1, len(lines)):
            candidate = lines[j].strip()
            if candidate and not candidate.startswith("#"):
                if bw > best_bw:
                    best_bw = bw
                    best_url = urllib.parse.urljoin(base_url, candidate)
                break
    return best_url


def _download_hls_stream(playlist_url, dest, title, headers=None):
    """Downloads an HLS stream by concatenating its .ts segments.

    This version accepts
    arbitrary headers instead of using Dailymotion's.
    """
    import requests
    dp = xbmcgui.DialogProgress()
    dp.create(_LOCALIZE(30902), _LOCALIZE(30903))
    req_headers = headers or {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/120.0.0.0 Safari/537.36",
    }
    clean_url = playlist_url.split("|")[0] if "|" in playlist_url else playlist_url
    tmp = dest + ".tmp"
    try:
        with requests.get(clean_url, headers=req_headers, timeout=15) as r:
            if r.status_code >= 400:
                raise Exception(
                    "Server responded with code {0}".format(r.status_code))
            m3u8_text = r.text

        # If it is a master playlist, resolve the highest quality variant and
        # reload its media playlist. Relative segments resolve against
        # the variant URL, not against the master URL.
        variant_url = _resolve_hls_master(m3u8_text, clean_url)
        if variant_url:
            clean_url = variant_url
            with requests.get(clean_url, headers=req_headers, timeout=15) as r:
                if r.status_code >= 400:
                    raise Exception(
                        "Server responded with code {0}".format(r.status_code))
                m3u8_text = r.text

        # Without #EXT-X-ENDLIST it is usually a live broadcast; only the
        # currently available fragment can be captured. A warning is shown but it is allowed
        # to continue, to avoid breaking a badly labeled VOD (without ENDLIST) that
        # was previously downloaded anyway.
        if "#EXT-X-ENDLIST" not in m3u8_text:
            dp.close()
            if not xbmcgui.Dialog().yesno(
                    _LOCALIZE(30000),
                    _LOCALIZE(31052)):
                return
            dp = xbmcgui.DialogProgress()
            dp.create(_LOCALIZE(30902), _LOCALIZE(30903))

        if "?" in clean_url:
            params = "?" + clean_url.split("?")[1]
        else:
            params = ""

        segments = [
            ln for ln in m3u8_text.splitlines()
            if ln and not ln.startswith("#")
        ]
        if not segments:
            dp.close()
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000), _LOCALIZE(30909))
            return

        with open(tmp, "wb") as f_out:
            for idx, seg_name in enumerate(segments):
                if dp.iscanceled():
                    break

                if seg_name.startswith("http"):
                    seg_url = seg_name
                else:
                    seg_url = urllib.parse.urljoin(clean_url, seg_name)
                    # Add playlist parameters if the segment doesn't have its own
                    if params and "?" not in seg_url:
                        seg_url += params

                success = False
                for _attempt in range(3):
                    try:
                        with requests.get(seg_url, headers=req_headers, timeout=12) as seg_r:
                            seg_r.raise_for_status()
                            seg_data = seg_r.content
                        f_out.write(seg_data)
                        success = True
                        break
                    except Exception:
                        continue

                if not success:
                    raise Exception(
                        "Failed on segment {0}/{1}".format(idx + 1, len(segments)))

                pct = int((idx + 1) * 100 / len(segments))
                dp.update(pct, "Segment {0}/{1} - {2}".format(
                    idx + 1, len(segments), title))

        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp, dest)
            try:
                import download_manager
                download_manager.log_download(title, dest, "HLS")
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000), "HLS Download completed:\n{0}".format(dest))
        elif os.path.exists(tmp):
            os.remove(tmp)
    except Exception as exc:
        try:
            dp.close()
        except Exception:
            pass
        if os.path.exists(tmp):
            os.remove(tmp)
        xbmc.log("[StreamNinja/url_player] Error HLS download: {0}".format(
            exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            _LOCALIZE(30000), "Error in HLS download:\n{0}".format(str(exc)[:200]))


def _download_via_ytdlp(url, dest, title):
    """Downloads any URL supported by yt-dlp to disk.

    Generates an auxiliary script that runs yt-dlp as a library to
    avoid conflicts with Kodi's internal Python. Only available
    on desktop platforms with Python >= 3.10 in the PATH.
    """
    import subprocess

    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok(
            _LOCALIZE(30000),
            "Downloads with yt-dlp are not\n"
            "available on Android devices.\n\n"
            "Use a PC with Python 3.10+ installed.")
        return

    dp = xbmcgui.DialogProgress()
    dp.create(_LOCALIZE(30904), _LOCALIZE(30905))

    try:
        # Search for system Python. If it has yt-dlp it is used as-is; otherwise,
        # it looks for any Python 3 and adds the embedded yt-dlp via PYTHONPATH.
        dp.update(2, _LOCALIZE(30906))
        env = None
        py_cmd = _find_system_python()  # system Python with yt_dlp
        if not py_cmd:
            # Without yt-dlp in the system; any Python 3 + embedded yt-dlp.
            py_cmd = _find_system_python(require_ytdlp=False)
            if not py_cmd:
                dp.close()
                xbmcgui.Dialog().ok(
                    _LOCALIZE(30000),
                    "Python 3 is required on the system.\n\n"
                    "Download it from python.org and install it\n"
                    "checking 'Add to PATH'.\n\n"
                    "Then restart Kodi.")
                return
            dp.update(4, _LOCALIZE(30907))
            env = ytdlp_resolver._ytdlp_bundle_env()  # downloads the wheel + PYTHONPATH
            if env is None:
                dp.close()
                xbmcgui.Dialog().ok(
                    _LOCALIZE(30000),
                    "Could not prepare the embedded yt-dlp.\n\n"
                    "Usually a connection issue when downloading it.\n"
                    "Check your network and try again.")
                return

        # Ensure .mp4 extension
        if not dest.endswith(".mp4"):
            dest = os.path.splitext(dest)[0] + ".mp4"

        # Temporary files in addon profile
        tmp_dir = _get_profile()
        progress_file = os.path.join(tmp_dir, "_dl_progress.json")
        if os.path.exists(progress_file):
            os.remove(progress_file)

        helper_path = os.path.join(tmp_dir, "_dl_helper.py")
        script = (
            "import json\n"
            "import yt_dlp\n"
            "\n"
            "progress_file = {pf!r}\n"
            "\n"
            "def hook(d):\n"
            "    info = {{\"status\": d.get(\"status\", \"\"), "
            "\"percent\": 0, \"text\": \"\"}}\n"
            "    if d[\"status\"] == \"downloading\":\n"
            "        total = d.get(\"total_bytes\") or "
            "d.get(\"total_bytes_estimate\") or 0\n"
            "        done = d.get(\"downloaded_bytes\", 0)\n"
            "        speed = d.get(\"speed\") or 0\n"
            "        if total > 0:\n"
            "            info[\"percent\"] = int(done * 100 / total)\n"
            "            mb_d = done / (1024*1024)\n"
            "            mb_t = total / (1024*1024)\n"
            "            sp = speed / (1024*1024) if speed else 0\n"
            "            info[\"text\"] = "
            "f\"{{mb_d:.1f}}MB / {{mb_t:.1f}}MB ({{sp:.1f}} MB/s)\"\n"
            "        elif done > 0:\n"
            "            info[\"percent\"] = 50\n"
            "            info[\"text\"] = "
            "f\"Downloading: {{done/(1024*1024):.1f}}MB\"\n"
            "    elif d[\"status\"] == \"finished\":\n"
            "        info[\"percent\"] = 95\n"
            "        info[\"text\"] = \"Finishing...\"\n"
            "    with open(progress_file, \"w\") as f:\n"
            "        json.dump(info, f)\n"
            "\n"
            "opts = {{\n"
            "    \"format\": \"best[ext=mp4]/best\",\n"
            "    \"outtmpl\": {dest!r},\n"
            "    \"quiet\": True,\n"
            "    \"no_warnings\": True,\n"
            "    \"progress_hooks\": [hook],\n"
            "    \"noprogress\": True,\n"
            "}}\n"
            "try:\n"
            "    ydl = yt_dlp.YoutubeDL(opts)\n"
            "    ydl.download([{url!r}])\n"
            "    with open(progress_file, \"w\") as f:\n"
            "        json.dump({{\"status\": \"done\", \"percent\": 100, "
            "\"text\": \"Completed\"}}, f)\n"
            "except Exception as e:\n"
            "    with open(progress_file, \"w\") as f:\n"
            "        json.dump({{\"status\": \"error\", \"percent\": 0, "
            "\"text\": str(e)[:300]}}, f)\n"
        ).format(pf=progress_file, dest=dest, url=url)

        with open(helper_path, "w", encoding="utf-8") as f:
            f.write(script)

        # Run download
        dp.update(10, _LOCALIZE(30908))
        no_win = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        proc = subprocess.Popen(
            [py_cmd, helper_path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=no_win, env=env,
        )

        # Polling
        cancelled = False
        while proc.poll() is None:
            if dp.iscanceled():
                cancelled = True
                proc.kill()
                break
            if os.path.exists(progress_file):
                try:
                    with open(progress_file, "r") as f:
                        info = json.loads(f.read())
                    dp.update(
                        info.get("percent", 0),
                        info.get("text", "Downloading..."))
                except Exception:
                    pass
            time.sleep(0.5)

        dp.close()

        # Cleanup
        for tmp in [helper_path, progress_file]:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except Exception:
                    pass

        if cancelled:
            for ext in ["", ".part"]:
                p = dest + ext
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except Exception:
                        pass
            return

        if proc.returncode == 0 and os.path.exists(dest):
            try:
                import download_manager
                download_manager.log_download(title, dest, "YT-DLP")
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000), "Download completed:\n{0}".format(dest))
        else:
            stderr = ""
            try:
                stderr = proc.stderr.read().decode(
                    "utf-8", errors="replace")[:200]
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                "Error in download:\n{0}".format(stderr or "Unknown"))

    except Exception as exc:
        try:
            dp.close()
        except Exception:
            pass
        xbmc.log("[StreamNinja/url_player] Error yt-dlp download: {0}".format(
            exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            _LOCALIZE(30000), "Error preparing download:\n{0}".format(
                str(exc)[:200]))


def _resolve_and_download(raw_url):
    """Classifies the URL and launches the appropriate download."""
    url_type, value = detect_url_type(raw_url)

    if url_type == "dailymotion":
        label = _auto_label(raw_url) or value
        dm_url = "https://www.dailymotion.com/video/" + value

        # Read download mode from native Kodi settings
        dl_mode = _get_setting_int("dl_mode", default=0, max_val=4)

        ytdlp_ok = ytdlp_resolver.is_available()

        # If the user forced yt-dlp and does not have it
        if dl_mode in (3, 4) and not ytdlp_ok:
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                "The selected mode (YT-DLP/ULTRA) requires yt-dlp.\n\n"
                "Only available on PC with Python 3.10+.")
            return

        # If the mode is the default (0) but YT-DLP is not
        # installed, adapt based on platform instead of showing dry error.
        if dl_mode == 0 and not ytdlp_ok:
            is_android = xbmc.getCondVisibility("System.Platform.Android")
            if is_android:
                # Android/FireTV: yt-dlp cannot be installed, direct
                # fallback to the API without bothering the user.
                xbmcgui.Dialog().notification(
                    _LOCALIZE(30000), _LOCALIZE(30181),
                    xbmcgui.NOTIFICATION_INFO, 2000,
                )
                dl_mode = 2
            else:
                # Desktop (Linux/Mac/Win) without yt-dlp; inform the user
                # that a better option exists and let them choose.
                choice = xbmcgui.Dialog().yesno(
                    _LOCALIZE(30000),
                    "yt-dlp is not installed on this computer.\n\n"
                    "With yt-dlp, downloads are higher quality\n"
                    "and more reliable.\n\n"
                    "You can install it from Advanced Options >\n"
                    "PC Maintenance (yt-dlp).\n\n"
                    "Download now with the internal API?",
                    yeslabel="Download now",
                    nolabel="Cancel",
                )
                if choice:
                    dl_mode = 2
                else:
                    return

        if dl_mode in (0, 3, 4):
            dest = _get_download_dest(label)
            if dest:
                _download_via_ytdlp(dm_url, dest, label)

        # Mode 1 (SAFE MODE): resolve direct MP4 via internal API
        elif dl_mode == 1:
            try:
                import dm_resolver
                result = dm_resolver._dm_play_direct(value)
                if result and result.get("url") and result.get("mime") == "video/mp4":
                    dest = _get_download_dest(label)
                    if dest:
                        _download_direct_url(
                            result["url"], dest, label,
                            headers=result.get("headers"),
                        )
                else:
                    xbmcgui.Dialog().ok(
                        _LOCALIZE(30000),
                        "No direct MP4 links available.\n\n"
                        "Choose another mode in Advanced Options."
                    )
            except Exception as exc:
                xbmc.log(
                    "[StreamNinja] dl_mode 1 error: {0}".format(exc),
                    xbmc.LOGWARNING)
                xbmcgui.Dialog().ok(
                    _LOCALIZE(30000),
                    "Error resolving direct MP4.\n{0}".format(
                        str(exc)[:200]))

        # Mode 2 (HLS/Smart Fallback): resolve best available via internal API
        elif dl_mode == 2:
            try:
                import dm_resolver
                result = dm_resolver._dm_play_direct(value)
                if result and result.get("url"):
                    stream_url = result["url"]
                    mime = result.get("mime", "")
                    if "mpegURL" in mime:
                        dest = _get_download_dest(label, ext=".ts")
                        if dest:
                            if xbmcgui.Dialog().yesno(
                                _LOCALIZE(30224),
                                "The API only offers dynamic stream (HLS).\n"
                                "The download will join the segments "
                                "progressively, which may take longer "
                                "than a direct MP4.\n\nContinue?",
                            ):
                                _download_hls_stream(
                                    stream_url, dest, label,
                                    headers=result.get("headers"),
                                )
                    else:
                        dest = _get_download_dest(label)
                        if dest:
                            _download_direct_url(
                                stream_url, dest, label,
                                headers=result.get("headers"),
                            )
                else:
                    xbmcgui.Dialog().ok(
                        _LOCALIZE(30000),
                        "Could not resolve the content for download.\n\n"
                        "Try yt-dlp on PC or choose other content.")
            except Exception as exc:
                xbmc.log(
                    "[StreamNinja] dl_mode 2 error: {0}".format(exc),
                    xbmc.LOGWARNING)
                xbmcgui.Dialog().ok(
                    _LOCALIZE(30000),
                    "Error resolving content.\n{0}".format(
                        str(exc)[:200]))

    elif url_type in ("youtube", "web_page"):
        if not ytdlp_resolver.is_available():
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                "Downloading this content requires yt-dlp.\n\n"
                "Only available on PC (Windows/Linux/Mac)\n"
                "with Python 3.10+ installed.")
            return
        label = _auto_label(raw_url) or "video"
        dest = _get_download_dest(label)
        if not dest:
            return
        _download_via_ytdlp(raw_url, dest, label)

    elif url_type == "direct_stream":
        url, headers = parse_url_with_headers(raw_url)
        label = _auto_label(raw_url) or "stream"

        clean_path = urllib.parse.urlparse(url).path.lower()
        if clean_path.endswith(".m3u8"):
            dest = _get_download_dest(label, ext=".ts")
            if not dest:
                return
            if not xbmcgui.Dialog().yesno(
                    _LOCALIZE(30225),
                    "This stream will be downloaded in segments.\n"
                    "The process may be slow. Continue?"):
                return
            _download_hls_stream(url, dest, label, headers=headers or None)
        else:
            ext = os.path.splitext(clean_path)[1] or ".mp4"
            dest = _get_download_dest(label, ext=ext)
            if not dest:
                return
            h = headers if headers else None
            _download_direct_url(url, dest, label, headers=h)

    elif url_type == "rtve":
        if not ytdlp_resolver.is_available():
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                "Downloading RTVE requires yt-dlp.\n\n"
                "Only available on PC.")
            return
        label = _auto_label(raw_url) or "rtve"
        dest = _get_download_dest(label)
        if not dest:
            return
        _download_via_ytdlp(raw_url, dest, label)

    elif url_type == "torrent":
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                "To download torrents natively you need to install "
                "the Elementum addon.")
            return

        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30180),
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        
        elem_url = (
            "plugin://plugin.video.elementum/download?"
            + urllib.parse.urlencode({"uri": value})
        )
        xbmc.executebuiltin('RunPlugin("{0}")'.format(elem_url))

    else:
        if not ytdlp_resolver.is_available():
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                "Downloading this content requires yt-dlp.\n\n"
                "Only available on PC (Windows/Linux/Mac)\n"
                "with Python 3.10+ installed.")
            return
        label = _auto_label(raw_url) or "video"
        dest = _get_download_dest(label)
        if not dest:
            return
        _download_via_ytdlp(raw_url, dest, label)


def url_input():
    """Keyboard to paste a link and play it."""
    kb = xbmc.Keyboard("", _LOCALIZE(30700))
    kb.doModal()
    if not kb.isConfirmed():
        return

    raw = kb.getText().strip()
    if not raw:
        return

    if _ACE_HASH_RE.fullmatch(raw):
        raw = "acestream://" + raw.lower()

    valid_schemes = ("http://", "https://", "rtmp://", "rtsp://",
                     "magnet:?", "acestream://")
    if not raw.lower().startswith(valid_schemes):
        xbmcgui.Dialog().ok(
            _LOCALIZE(30000),
            "The URL does not seem valid.\n\n"
            "Supported schemes: http, https, rtmp, rtsp, magnet, acestream",
        )
        return

    threading.Thread(target=_add_to_history, args=(raw,), daemon=True).start()

    url_type, _ = detect_url_type(raw)
    type_labels = {
        "dailymotion": "Dailymotion",
        "youtube": "YouTube",
        "rtve": "RTVE",
        "torrent": "Torrent",
        "acestream": "AceStream",
        "direct_stream": "Direct stream",
        "web_page": "Web page",
    }
    detected = type_labels.get(url_type, "Unknown")
    url_display = raw[:50] + "..." if len(raw) > 50 else raw

    opts = [
        _LOCALIZE(30750).format(detected),
        _LOCALIZE(30751),
        _LOCALIZE(30752),
    ]
    _NOT_DOWNLOADABLE = {"acestream", "kodi_plugin", "internal_query"}
    if url_type not in _NOT_DOWNLOADABLE:
        opts.append(_LOCALIZE(30753).format(detected))

    sel = xbmcgui.Dialog().select(url_display, opts)

    if sel == 0:
        _resolve_and_play(raw)
    elif sel == 1:
        name_kb = xbmc.Keyboard("", _LOCALIZE(30701))
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            _add_bookmark(name_kb.getText().strip(), raw)
        _resolve_and_play(raw)
    elif sel == 2:
        name_kb = xbmc.Keyboard("", _LOCALIZE(30701))
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            if _add_bookmark(name_kb.getText().strip(), raw):
                xbmcgui.Dialog().notification(
                    _LOCALIZE(30000), _LOCALIZE(30171),
                    xbmcgui.NOTIFICATION_INFO,
                )
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().notification(
                    _LOCALIZE(30000), _LOCALIZE(30173),
                    xbmcgui.NOTIFICATION_INFO,
                )
    elif sel == 3:
        _resolve_and_download(raw)


def _action_art(icon_file, _cinema=False):
    """Art for action items (clear, shortcuts)."""
    icon = os.path.join(_MEDIA, icon_file)
    return {"icon": icon}


def url_history_menu():
    """History of played URLs."""
    h = _get_handle()
    history = _get_history()

    if not history:
        li = xbmcgui.ListItem(
            label=_LOCALIZE(31250)
        )
        li.setArt({"icon": os.path.join(_MEDIA, "info.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    li = xbmcgui.ListItem(
        label=_LOCALIZE(31251)
    )
    li.setArt(_action_art("adv_limpieza.png", False))
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_history_clear"), listitem=li, isFolder=False
    )

    for entry in history:
        raw_url = entry.get("url", "")
        label = entry.get("label", raw_url)
        date = entry.get("date", "")

        display = label[:80] + "..." if len(label) > 80 else label
        thumb = entry.get("thumb", "")
        plot = "URL: {0}\n\nDate: {1}".format(raw_url, date)
        li = xbmcgui.ListItem(label=display)
        li.setArt({
            "icon": thumb or "DefaultVideo.png",
            "thumb": thumb or "",
        })
        li.setInfo("video", {"plot": plot})

        cm = [
            (
                _LOCALIZE(30752),
                "RunPlugin({0})".format(
                    _u(action="url_bookmark_save_from_history", url=raw_url)
                ),
            ),
            (
                "Remove from history",
                "RunPlugin({0})".format(
                    _u(action="url_history_remove", url=raw_url)
                ),
            ),
        ]
        
        url_type, _ = detect_url_type(raw_url)
        _NOT_DOWNLOADABLE = {"acestream", "kodi_plugin", "internal_query"}
        if url_type not in _NOT_DOWNLOADABLE:
            cm.insert(0, (
                "Download",
                "RunPlugin({0})".format(_u(action="url_download", url=raw_url))
            ))
            
        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=raw_url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def scan_history_menu():
    """History of scanned websites and Telegram channels."""
    h = _get_handle()
    history = _get_scan_history()

    if not history:
        li = xbmcgui.ListItem(
            label=_LOCALIZE(31253)
        )
        li.setArt({"icon": os.path.join(_MEDIA, "info.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    li = xbmcgui.ListItem(
        label=_LOCALIZE(31252)
    )
    li.setArt({"icon": os.path.join(_MEDIA, "adv_limpieza.png")})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="scan_history_clear"), listitem=li, isFolder=False
    )

    for entry in history:
        raw_input = entry.get("input", "")
        label = entry.get("label", raw_input)
        scan_type = entry.get("type", "web")
        date = entry.get("date", "")

        display = "{0}: {1}".format(scan_type, label)
        li = xbmcgui.ListItem(label=display)
        icon = "url_scan.png" if scan_type == "web" else "url_remote.png"
        li.setArt({"icon": os.path.join(_MEDIA, icon)})
        li.setInfo("video", {"plot": "{0}\n\nScanned: {1}".format(raw_input, date)})
        cm = [
            (
                "Remove from history",
                "RunPlugin({0})".format(
                    _u(action="scan_history_remove", url=raw_input)
                ),
            ),
        ]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="scan_url", url=raw_input),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def url_bookmarks_menu():
    """Saved URL favorites."""
    h = _get_handle()
    bookmarks = _get_bookmarks()

    # Flow FavManager; direct access to the advanced favorites manager
    try:
        xbmcaddon.Addon("plugin.program.flowfavmanager")
        li_flow = xbmcgui.ListItem(
            label=_LOCALIZE(31254)
        )
        li_flow.setArt(_action_art("shortcut_addon.png", False))
        li_flow.setInfo("video", {
            "plot": "Opens the advanced utility to organize "
                    "and manage these favorites."
        })
        xbmcplugin.addDirectoryItem(
            handle=h,
            url="plugin://plugin.program.flowfavmanager/",
            listitem=li_flow, isFolder=False,
        )
    except Exception:
        li_flow = xbmcgui.ListItem(
            label=_LOCALIZE(31255)
        )
        li_flow.setArt(_action_art("shortcut_addon.png", False))
        li_flow.setInfo("video", {
            "plot": "Advanced favorites manager. "
                    "Press to install from GitHub."
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="flowfav_install"),
            listitem=li_flow, isFolder=False,
        )

    if not bookmarks:
        li = xbmcgui.ListItem(
            label=_LOCALIZE(31256)
        )
        li.setArt({"icon": os.path.join(_MEDIA, "info.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    for bm in bookmarks:
        url = bm.get("url", "")
        name = bm.get("name", url)
        date = bm.get("date", "")

        li = xbmcgui.ListItem(label=name)
        thumb = bm.get("thumb", "")
        plot = "URL: {0}\n\nSaved: {1}".format(url, date)
        li.setArt({
            "icon": thumb or "DefaultVideo.png",
            "thumb": thumb or "",
        })
        li.setInfo("video", {"plot": plot})

        cm = [
            (
                "Rename",
                "RunPlugin({0})".format(_u(action="url_bookmark_rename", url=url)),
            ),
            (
                "Delete favorite",
                "RunPlugin({0})".format(_u(action="url_bookmark_delete", url=url)),
            ),
        ]

        url_type, _ = detect_url_type(url)
        _NOT_DOWNLOADABLE = {"acestream", "kodi_plugin", "internal_query"}
        if url_type not in _NOT_DOWNLOADABLE:
            cm.insert(0, (
                "Download",
                "RunPlugin({0})".format(_u(action="url_download", url=url))
            ))

        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def bookmark_save_from_history(url):
    if not url:
        return
    kb = xbmc.Keyboard("", _LOCALIZE(30701))
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _add_bookmark(kb.getText().strip(), url):
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30171),
                xbmcgui.NOTIFICATION_INFO
            )
            xbmc.executebuiltin("Container.Refresh")
        else:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30173),
                xbmcgui.NOTIFICATION_INFO
            )


def bookmark_rename(url):
    if not url:
        return
    bookmarks = _get_bookmarks()
    current_name = ""
    for b in bookmarks:
        if b.get("url") == url:
            current_name = b.get("name", "")
            break

    kb = xbmc.Keyboard(current_name, _LOCALIZE(30702))
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _rename_bookmark(url, kb.getText().strip()):
            xbmc.executebuiltin("Container.Refresh")


def bookmark_delete(url):
    if not url:
        return
    if _remove_bookmark(url):
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30172), xbmcgui.NOTIFICATION_INFO
        )
        xbmc.executebuiltin("Container.Refresh")


def history_remove(url):
    if not url:
        return
    _remove_from_history(url)
    xbmc.executebuiltin("Container.Refresh")


def history_clear():
    if xbmcgui.Dialog().yesno(_LOCALIZE(30000), _LOCALIZE(31102)):
        _clear_history()
        xbmc.executebuiltin("Container.Refresh")


def play_url_action(raw_url):
    """Plays a URL, registering it in history."""
    if not raw_url:
        return
    threading.Thread(target=_add_to_history, args=(raw_url,), daemon=True).start()
    _resolve_and_play(raw_url)


def api_resolve_action(raw_url):
    """
    Native API for other Addons to use StreamNinja as a silent resolver.
    Supports direct links, Dailymotion, generic websites
    and platforms compatible with yt-dlp.
    Returns the result to the original Addon using setResolvedUrl.
    """
    try:
        handle = int(sys.argv[1])
    except Exception:
        handle = -1

    if handle == -1:
        xbmc.log("[StreamNinja API] Error: invalid handle.", xbmc.LOGERROR)
        return

    if not raw_url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    url_type, value = detect_url_type(raw_url)

    stream_url = ""
    header_str = ""
    mime_type = ""
    is_mpd = False
    is_m3u8 = False

    try:
        if url_type == "direct_stream":
            u, headers = parse_url_with_headers(raw_url)
            stream_url = u
            if headers:
                header_str = "&".join("{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in headers.items())
            if ".mpd" in stream_url.lower():
                is_mpd = True
                mime_type = "application/dash+xml"
            elif ".m3u8" in stream_url.lower() or "mpegurl" in stream_url.lower():
                is_m3u8 = True
                mime_type = "application/x-mpegURL"



        elif url_type == "dailymotion":
            # yt-dlp first, then internal resolver
            dm_full = "https://www.dailymotion.com/video/" + value
            if ytdlp_resolver.is_available():
                info = ytdlp_resolver.resolve_full(dm_full)
                if info and info.get("url"):
                    stream_url = info["url"]
                    h = info.get("headers", {})
                    if h:
                        header_str = "&".join("{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in h.items())
                    proto = info.get("protocol", "")
                    if "m3u8" in proto or ".m3u8" in stream_url.lower():
                        is_m3u8 = True
                        mime_type = "application/x-mpegURL"
            if not stream_url:
                try:
                    import dm_resolver
                    is_win = xbmc.getCondVisibility("System.Platform.Windows")
                    dm_level = _get_setting_int("dm_safe_level", default=0, max_val=3)
                    result = (dm_resolver._dm_play(value, dm_level=dm_level) if is_win
                              else dm_resolver._dm_play_android(value, dm_level=dm_level))
                    if result and result.get("url"):
                        stream_url = result["url"]
                        hd = result.get("headers", {})
                        if hd:
                            header_str = "&".join("{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in hd.items())
                        mt = result.get("mime", "")
                        if "mpegURL" in mt or ".m3u8" in stream_url.lower():
                            is_m3u8 = True
                            mime_type = "application/x-mpegURL"
                except Exception:
                    pass

        elif url_type == "web_page":
            # yt-dlp supports hundreds of websites
            if ytdlp_resolver.is_available():
                info = ytdlp_resolver.resolve_full(value)
                if info and info.get("url"):
                    stream_url = info["url"]
                    h = info.get("headers", {})
                    if h:
                        header_str = "&".join("{0}={1}".format(k, urllib.parse.quote(str(v), safe="")) for k, v in h.items())
                    proto = info.get("protocol", "")
                    if "m3u8" in proto or ".m3u8" in stream_url.lower():
                        is_m3u8 = True
                        mime_type = "application/x-mpegURL"
                    elif ".mpd" in stream_url.lower():
                        is_mpd = True
                        mime_type = "application/dash+xml"

        # Build ListItem and return to Kodi
        if stream_url:
            kodi_url = stream_url
            if header_str and not is_m3u8 and not is_mpd:
                kodi_url = "{0}|{1}".format(stream_url, header_str)

            li = xbmcgui.ListItem(path=kodi_url)
            if mime_type:
                li.setMimeType(mime_type)

            if is_mpd:
                li.setProperty("inputstream", "inputstream.adaptive")
                li.setProperty("inputstream.adaptive.manifest_type", "mpd")
                if header_str:
                    li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                    li.setProperty("inputstream.adaptive.stream_headers", header_str)
            elif is_m3u8:
                if header_str:
                    li.setProperty("inputstream", "inputstream.adaptive")
                    li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                    li.setProperty("inputstream.adaptive.stream_headers", header_str)

            li.setProperty("IsPlayable", "true")
            li.setContentLookup(False)
            xbmcplugin.setResolvedUrl(handle, True, li)
            return

        # Could not resolve
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

    except Exception as e:
        xbmc.log("[StreamNinja API] Error resolving URL: " + str(e), xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def scan_videos_dialog():
    """Scans a website or a public Telegram channel and allows playback."""
    kb = xbmc.Keyboard("", _LOCALIZE(30703))
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    if not url:
        return
    _run_scan(url)


def _run_scan(url):
    """Executes the scan for a known URL or channel."""
    import telegram_scanner

    # Telegram channels: own flow (accepts @channel, t.me/channel or bare name)
    if telegram_scanner.is_telegram(url):
        _scan_telegram_flow(url)
        return

    if not url.startswith(("http://", "https://")):
        xbmcgui.Dialog().ok(
            _LOCALIZE(30000),
            "Enter a URL (http:// or https://) or a Telegram "
            "channel (@channel, t.me/channel).",
        )
        return

    videos = _scan_cache_get(url)
    from_cache = videos is not None

    if not from_cache:
        pdp = xbmcgui.DialogProgress()
        pdp.create("Scanning videos", "Analyzing {0}...".format(url[:60]))
        try:
            videos = _scan_with_best_engine(url)
        except Exception as exc:
            xbmc.log(
                "[StreamNinja] Error scanning {0}: {1}".format(url[:60], exc),
                xbmc.LOGWARNING,
            )
            videos = []
        finally:
            pdp.close()

        if not videos:
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                "No videos found on this page.\n\n"
                "Try another URL or paste \n"
                "the video URL directly.",
            )
            return

        _add_to_scan_history(url, 'web')
        _scan_cache_put(url, videos)

    import html_scanner

    labels = []
    for v in videos:
        parts = [v.get("title") or v.get("url", "")[:60]]
        dur = v.get("duration")
        if dur:
            parts.append(html_scanner.format_duration(dur))
        size = v.get("filesize")
        if size:
            parts.append(html_scanner.format_size(size))
        ext = v.get("ext", "")
        if ext:
            parts.append(ext.upper())
        labels.append(" — ".join(parts))

    title = "Videos found ({0}){1}".format(
        len(videos), " — cache" if from_cache else ""
    )
    sel = xbmcgui.Dialog().select(title, labels)
    if sel < 0:
        return

    chosen = videos[sel]
    chosen_url = chosen.get("url", "")
    if chosen_url:
        _add_to_history(chosen_url, label=chosen.get("title"))
        _resolve_and_play(chosen_url)


def _scan_with_best_engine(url):
    """yt-dlp (PC, more complete) or html_scanner for videos; also ResolveURL
    detects embedded hosters (streamtape, dood...) that neither recognizes."""
    import html_scanner
    results = []
    if ytdlp_resolver.is_available():
        results = ytdlp_resolver.scan_videos(url)   # [] if it fails, never throws

    mod = _get_resolveurl()
    # HTML is only needed for the html_scanner fallback or for hoster scraping.
    # If yt-dlp has already resolved and ResolveURL is not present, it is not downloaded.
    html = ""
    if not results or mod:
        html = html_scanner._download_html(url, html_scanner._DOWNLOAD_TIMEOUT)
    if not results:
        results = html_scanner.scan_page(url, html_content=html)
    if mod and html:
        seen = {r.get("url") for r in results}
        for h in _scrape_hosters(html):
            if h["url"] not in seen:
                seen.add(h["url"])
                results.append(h)
    return results


def _scan_telegram_flow(channel):
    """Scans a public Telegram channel with incremental paging.
    Starts from the latest entries and allows loading older ones on demand.
    The label of each link is the message text (context, not just the URL)."""
    import telegram_scanner
    import html_scanner

    if telegram_scanner.is_private_invite(channel):
        xbmcgui.Dialog().ok(
            _LOCALIZE(30000),
            "It is an invitation link to a PRIVATE Telegram channel or group.\n\n"
            "Only public channels (t.me/name) can be scanned.",
        )
        return

    videos = []
    seen = set()
    cursor = None
    first = True

    while True:
        pdp = xbmcgui.DialogProgress()
        pdp.create(
            "Scanning Telegram",
            "Reading the latest entries..." if first else "Loading older ones...",
        )
        try:
            batch, cursor = telegram_scanner.scan_channel_paged(channel, before_id=cursor)
        except Exception as exc:
            xbmc.log(
                "[StreamNinja] Error scanning Telegram {0}: {1}".format(channel[:40], exc),
                xbmc.LOGWARNING,
            )
            batch, cursor = [], None
        finally:
            pdp.close()

        added = 0
        for v in batch:
            u = v.get("url", "")
            if u and u not in seen:
                seen.add(u)
                videos.append(v)
                added += 1

        if not videos:
            # Covers non-existent/empty channel and also network failure.
            xbmcgui.Dialog().ok(
                _LOCALIZE(30000),
                "Could not get video links from the channel.\n\n"
                "Verify that the name is correct, the channel is public "
                "(t.me/name), sharing videos, and that you have a connection.",
            )
            return

        if first:
            _add_to_scan_history(channel, 'telegram')
        elif added == 0:
            xbmcgui.Dialog().notification(
                "Telegram", "No new links in the previous entries",
                xbmcgui.NOTIFICATION_INFO, 2500,
            )
        first = False

        options = []
        for v in videos:
            parts = [v.get("title") or v.get("url", "")[:60]]
            dur = v.get("duration")
            if dur:
                parts.append(html_scanner.format_duration(dur))
            size = v.get("filesize")
            if size:
                parts.append(html_scanner.format_size(size))
            ext = v.get("ext", "")
            if ext:
                parts.append(ext.upper())
            options.append(" — ".join(parts))

        more_idx = -1
        if cursor:
            more_idx = len(options)
            options.append(_LOCALIZE(31258))

        sel = xbmcgui.Dialog().select(
            "Telegram: {0} links".format(len(videos)), options
        )
        if sel < 0:
            return
        if sel == more_idx:
            continue  # page backwards and reopen the accumulated list
        chosen = videos[sel]
        chosen_url = chosen.get("url", "")
        if chosen_url:
            _add_to_history(chosen_url, label=chosen.get("title"))
            _resolve_and_play(chosen_url)
        return


# --- DEBRID CLOUD LIBRARY ---

def debrid_library_menu():
    h = _get_handle()
    resolver = _get_debrid()
    if resolver is None:
        xbmcplugin.endOfDirectory(h)
        return
    # list_library() is a network call; without feedback Kodi only shows the
    # spinner and the user might think it's frozen.
    dp = xbmcgui.DialogProgress()
    dp.create("My Debrid Cloud", "Loading your library...")
    try:
        items = resolver.list_library()
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] library: {0}".format(e), xbmc.LOGWARNING)
        items = None
    finally:
        dp.close()
    if items is None:
        xbmcgui.Dialog().notification(
            "Debrid", _LOCALIZE(30178), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(h)
        return

    if not items:
        li = xbmcgui.ListItem(label=_LOCALIZE(31257))
        li.setArt({"icon": os.path.join(_MEDIA, "url_cloud.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for it in items:
        size_gb = (it.get("size", 0) or 0) / 1e9
        ready = it.get("ready")
        if ready:
            label = "{0}  [COLOR grey]({1:.2f} GB)[/COLOR]".format(
                it.get("filename", "?"), size_gb)
        else:
            label = "[COLOR grey]{0} ({1})[/COLOR]".format(
                it.get("filename", "?"), it.get("status", "processing"))
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultVideo.png"})
        item_id = it.get("id")
        if ready:
            li.setProperty("IsPlayable", "false")
            li.addContextMenuItems([
                ("View files",
                 "Container.Update({0})".format(_u(action="debrid_library_files", id=item_id))),
                ("Download to disk",
                 "RunPlugin({0})".format(_u(action="debrid_download", id=item_id, title=it.get("filename", "")))),
                ("Delete from cloud",
                 "RunPlugin({0})".format(_u(action="debrid_library_delete", id=item_id))),
            ])
            url = _u(action="debrid_library_play", id=item_id)
        else:
            url = ""
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def debrid_library_files(item_id):
    h = _get_handle()
    resolver = _get_debrid()
    if resolver is None or not item_id:
        xbmcplugin.endOfDirectory(h)
        return
    try:
        files = resolver.library_files(item_id)
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] files: {0}".format(e), xbmc.LOGWARNING)
        files = []
    for idx, f in enumerate(files):
        size_gb = (f.get("size", 0) or 0) / 1e9
        li = xbmcgui.ListItem(
            label="{0}  [COLOR grey]({1:.2f} GB)[/COLOR]".format(f.get("name", "?"), size_gb))
        li.setArt({"icon": "DefaultVideo.png"})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="debrid_library_play", id=item_id, file=idx),
            listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def debrid_library_play(item_id, file_index=None):
    resolver = _get_debrid()
    if resolver is None or not item_id:
        return
    try:
        if file_index is None:
            stream = resolver.resolve_library_item(item_id)
        else:
            stream = resolver.resolve_library_file(item_id, int(file_index))
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] play cloud: {0}".format(e), xbmc.LOGWARNING)
        stream = None
    if stream:
        _play_resolved_stream(stream)
    else:
        xbmcgui.Dialog().notification(
            "Debrid", _LOCALIZE(30179), xbmcgui.NOTIFICATION_WARNING, 3000)


def debrid_library_delete(item_id):
    if not item_id:
        return
    if not xbmcgui.Dialog().yesno("Debrid", "Delete this item from your cloud?"):
        return
    resolver = _get_debrid()
    if resolver is None:
        return
    try:
        resolver.delete_library_item(item_id)
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] delete cloud: {0}".format(e), xbmc.LOGWARNING)
    xbmc.executebuiltin("Container.Refresh")


def debrid_download(item_id, title=""):
    resolver = _get_debrid()
    if resolver is None or not item_id:
        return
    try:
        stream = resolver.resolve_library_item(item_id)
    except Exception as e:
        xbmc.log("[StreamNinja/Debrid] download cloud: {0}".format(e), xbmc.LOGWARNING)
        stream = None
    if not stream:
        xbmcgui.Dialog().notification(
            "Debrid", "Could not resolve to download",
            xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    title = title or "video"
    ext = os.path.splitext(urllib.parse.urlparse(stream).path)[1].lower()
    if ext not in _STREAM_EXTENSIONS:
        ext = ".mp4"
    dest = _get_download_dest(title, ext)
    if not dest:
        return
    _download_direct_url(stream, dest, title)


# --- LIVE HLS STREAMS RECORDER ---

def record_stream_dialog():
    """Prompts for a live HLS video URL and records it to disk using the PVR recorder."""
    import pvr_recorder_manager
    kb = xbmc.Keyboard("", _LOCALIZE(30705))
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    if not url:
        return
    name_kb = xbmc.Keyboard("Recording", _LOCALIZE(30706))
    name_kb.doModal()
    name = name_kb.getText().strip() if name_kb.isConfirmed() else ""
    pvr_recorder_manager.start_recording_ui(url, name or "Recording")


def stop_recordings():
    import pvr_recorder_manager
    pvr_recorder_manager.stop_all_recordings()
