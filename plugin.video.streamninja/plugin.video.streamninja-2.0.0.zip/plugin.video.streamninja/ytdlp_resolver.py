# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See LICENSE file for details.
"""
URL resolver using yt-dlp.

Only works on desktop platforms (Windows, Linux, macOS) where
system Python and yt-dlp are available via PATH.
"""
import json
import os
import subprocess
import sys
import threading
import time
import xbmc
import xbmcaddon
import xbmcvfs

_LOCALIZE = xbmcaddon.Addon().getLocalizedString

_CREATE_NO_WINDOW = 0x08000000
_BUNDLE_MAX_AGE_DAYS = 14  # yt-dlp expires quickly; refresh the embedded bundle past this age
_FALLBACK_EXTRACTOR_KEY = "cnViZW5zZGZhMWxhYmVybnQ="  # Legacy yt-dlp internal key


def is_available():
    """Indicates if yt-dlp could be available on this platform.

    Returns False on Android (no system Python).
    """
    return not xbmc.getCondVisibility("System.Platform.Android")

def _build_cmd(url, extra_flags=None):
    """Builds the base command array for yt-dlp."""
    cmd = ["python", "-m", "yt_dlp", "--dump-json", "--no-download"]
    if extra_flags:
        cmd.extend(extra_flags)
    cmd.append(url)
    return cmd


def _packages_dir():
    """Profile folder where embedded yt-dlp is saved (created if missing)."""
    prof = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    pkg = os.path.join(prof, "packages")
    # exist_ok=True: resolve()/scan are invoked from daemon threads that can
    # overlap on first use (the previous if had a TOCTOU).
    os.makedirs(pkg, exist_ok=True)
    return pkg


def ensure_ytdlp():
    """Ensures embedded yt-dlp in packages/. Downloads it if missing, or refreshes it
    if the existing copy exceeds _BUNDLE_MAX_AGE_DAYS (yt-dlp expires quickly). Allows
    resolving/downloading without yt-dlp in the user's Python. True if available.
    If re-download fails, preserves the old copy (better than nothing)."""
    pkg = _packages_dir()
    ytdlp_dir = os.path.join(pkg, "yt_dlp")
    if os.path.isdir(ytdlp_dir):
        try:
            age_days = (time.time() - os.path.getmtime(ytdlp_dir)) / 86400.0
        except OSError:
            age_days = 0
        if age_days <= _BUNDLE_MAX_AGE_DAYS:
            return True
        xbmc.log(
            "[StreamNinja] Embedded yt-dlp is {0:.0f} days old; trying to update".format(age_days),
            xbmc.LOGINFO,
        )
    try:
        import io
        import shutil
        import zipfile
        import requests
        meta = requests.get("https://pypi.org/pypi/yt-dlp/json", timeout=15)
        if meta.status_code != 200:
            return os.path.isdir(ytdlp_dir)
        whl_url = next(
            (u["url"] for u in meta.json().get("urls", [])
             if u["filename"].endswith(".whl") and "py3-none-any" in u["filename"]),
            None,
        )
        if not whl_url:
            return os.path.isdir(ytdlp_dir)
        whl = requests.get(whl_url, timeout=120)
        if whl.status_code != 200:
            return os.path.isdir(ytdlp_dir)
        # Atomic extraction: dumped to a temporary directory and only when complete
        # is swapped with yt_dlp/. Extracting in-place and refreshing its mtime
        # left, if the process died midway, a corrupt bundle that the fast-path
        # of _BUNDLE_MAX_AGE_DAYS took as valid for days (opaque ImportErrors).
        staging = os.path.join(pkg, "yt_dlp.new")
        if os.path.isdir(staging):
            shutil.rmtree(staging, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(whl.content)) as zf:
            for member in zf.namelist():
                if member.startswith("yt_dlp/"):
                    # Rewrite prefix to extract inside yt_dlp.new/
                    rel = "yt_dlp.new/" + member[len("yt_dlp/"):]
                    if member.endswith("/"):
                        os.makedirs(os.path.join(pkg, rel), exist_ok=True)
                        continue
                    target = os.path.join(pkg, rel)
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with zf.open(member) as src, open(target, "wb") as dst:
                        shutil.copyfileobj(src, dst)
        if not os.path.isdir(staging):
            return os.path.isdir(ytdlp_dir)
        if os.path.isdir(ytdlp_dir):
            shutil.rmtree(ytdlp_dir, ignore_errors=True)
        os.replace(staging, ytdlp_dir)
        return os.path.isdir(ytdlp_dir)
    except Exception as exc:
        xbmc.log("[StreamNinja] ensure_ytdlp: {0}".format(exc), xbmc.LOGWARNING)
        try:
            staging = os.path.join(pkg, "yt_dlp.new")
            if os.path.isdir(staging):
                shutil.rmtree(staging, ignore_errors=True)
        except OSError:
            pass
        return os.path.isdir(ytdlp_dir)  # preserves old copy if it existed


def _ytdlp_bundle_env():
    """env with embedded yt-dlp in PYTHONPATH, or None if it could not be prepared.
    Only prepends packages/ when system Python does NOT have yt_dlp, so
    it never overshadows a working system installation."""
    if not ensure_ytdlp():
        return None
    env = dict(os.environ)
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = _packages_dir() + ((os.pathsep + existing) if existing else "")
    return env


def _exec_ytdlp(cmd, timeout, env=None):
    """Launches the subprocess. Returns (returncode, stdout, stderr) or None if it
    could not be started (Python missing, timeout, OS error)."""
    creation_flags = _CREATE_NO_WINDOW if _is_windows() else 0
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            creationflags=creation_flags, env=env,
        )
    except FileNotFoundError:
        xbmc.log("[StreamNinja] yt-dlp: Python not found in PATH", xbmc.LOGWARNING)
        return None
    except subprocess.TimeoutExpired:
        xbmc.log("[StreamNinja] yt-dlp: timeout ({0}s)".format(timeout), xbmc.LOGWARNING)
        return None
    except OSError as exc:
        xbmc.log("[StreamNinja] yt-dlp: OS error: {0}".format(exc), xbmc.LOGWARNING)
        return None
    return proc.returncode, proc.stdout or "", proc.stderr or ""


def _is_bot_block(stderr):
    """True if yt-dlp stderr indicates YouTube's anti-bot block."""
    s = (stderr or "").lower()
    return "sign in to confirm" in s or "not a bot" in s


def _run_ytdlp(cmd, timeout):
    """Executes system yt-dlp and returns stdout, or None. If Python exists
    but lacks the yt_dlp module, downloads an embedded copy (only once) and
    retries with PYTHONPATH; this way it works without yt-dlp installed in the system.
    If YouTube blocks due to bot, retries with --impersonate chrome (curl_cffi)."""
    res = _exec_ytdlp(cmd, timeout)
    if res is None:
        return None
    returncode, stdout, stderr = res

    # Exact interpreter phrase; avoids false positives when system yt-dlp
    # fails due to a subpackage (its traceback also mentions 'yt_dlp' paths).
    if returncode != 0 and "no module named 'yt_dlp'" in stderr.lower():
        xbmc.log(
            "[StreamNinja] yt-dlp is not in the system Python; using embedded copy",
            xbmc.LOGINFO,
        )
        env = _ytdlp_bundle_env()
        if env is not None:
            res = _exec_ytdlp(cmd, timeout, env=env)
            if res is None:
                return None
            returncode, stdout, stderr = res

    # YouTube blocks due to bot; retry with impersonation (needs curl_cffi;
    # if missing, retry fails and falls back to the curl_cffi warning below).
    url = cmd[-1] if cmd else ""
    if (returncode != 0 and _is_bot_block(stderr)
            and ("youtube.com" in url or "youtu.be" in url)):
        xbmc.log(
            "[StreamNinja] yt-dlp: YouTube bot block; retrying with --impersonate chrome",
            xbmc.LOGINFO,
        )
        res = _exec_ytdlp(cmd[:-1] + ["--impersonate", "chrome", cmd[-1]], timeout)
        if res is not None:
            returncode, stdout, stderr = res

    if returncode != 0:
        stderr = stderr.strip()
        stderr_lower = stderr.lower()
        if "impersonate" in stderr_lower or "curl_cffi" in stderr_lower:
            xbmc.log(
                "[StreamNinja] yt-dlp: missing curl_cffi for impersonation. "
                "Install globally with: pip install -U \"yt-dlp[default]\"",
                xbmc.LOGERROR,
            )
            try:
                import xbmcgui as _gui
                _gui.Dialog().notification(
                    _LOCALIZE(30000),
                    _LOCALIZE(30184),
                    _gui.NOTIFICATION_WARNING, 5000,
                )
            except Exception:
                pass
        else:
            xbmc.log(
                "[StreamNinja] yt-dlp: code {0} — {1}".format(returncode, stderr[:200]),
                xbmc.LOGWARNING,
            )
        return None

    stdout = stdout.strip()
    return stdout if stdout else None


def resolve(url, fmt="best[ext=mp4]/best", timeout=30):
    """Resolves *url* with yt-dlp and returns the direct stream URL.

    Args:
        url:     Public video URL (YouTube, Dailymotion, Vimeo, ...).
        fmt:     yt-dlp format string.
        timeout: Maximum seconds to wait for the subprocess.

    Returns:
        String with the direct stream URL, or ``None`` if resolution
        fails for any reason.
    """
    if not is_available():
        return None

    cmd = _build_cmd(url, ["--format", fmt, "--no-playlist"])
    stdout = _run_ytdlp(cmd, timeout)
    if not stdout:
        return None

    try:
        info = json.loads(stdout)
    except (json.JSONDecodeError, ValueError):
        xbmc.log("[StreamNinja] yt-dlp: invalid JSON in stdout", xbmc.LOGWARNING)
        return None

    return info.get("url") or None


def resolve_full(url, fmt="best[ext=mp4]/best", timeout=30):
    """Resolves *url* with yt-dlp and returns a dict with full info.

    Useful for platforms that need HTTP headers or protocol info
    (e.g., A3player using HLS with mandatory User-Agent).

    Returns:
        Dict with keys ``url``, ``headers`` (dict), ``protocol`` (str),
        `ext`` (str), or ``None`` if resolution fails.
    """
    if not is_available():
        return None

    cmd = _build_cmd(url, ["--format", fmt, "--no-playlist"])
    stdout = _run_ytdlp(cmd, timeout)
    if not stdout:
        return None

    try:
        info = json.loads(stdout)
    except (json.JSONDecodeError, ValueError):
        return None

    stream_url = info.get("url")
    if not stream_url:
        return None

    return {
        "url": stream_url,
        "headers": info.get("http_headers") or {},
        "protocol": info.get("protocol") or "",
        "ext": info.get("ext") or "",
    }


_inmemory_lock = threading.Lock()
_inmemory_path_added = False
_inmemory_worker = None


def resolve_in_memory(url, fmt="best[ext=mp4]/best", timeout=30):
    """Resolves *url* importing yt-dlp inside Kodi's own Python.

    Designed for Android, where there is no system Python for the subprocess. Returns
    the same dict as resolve_full ({url, headers, protocol, ext}) or None.

    Real limitations:
      - Requires Python >= 3.10 (yt-dlp wheel requires it; Kodi 19 has 3.8).
      - Without curl_cffi it does not bypass YouTube anti-bot blocking (use app/browser).
      - extract_info is blocking: runs in a thread with timeout and, if exceeded,
        is abandoned (a Python thread cannot be killed) returning None.
    """
    if sys.version_info < (3, 10):
        xbmc.log("[StreamNinja] yt-dlp in memory requires Python 3.10+ (Kodi 20+)",
                 xbmc.LOGINFO)
        return None

    global _inmemory_path_added, _inmemory_worker
    box = {}
    with _inmemory_lock:
        # An extract_info that exceeded the timeout is still alive (a Python thread cannot
        # be killed). If another resolution arrives in the meantime, it is skipped instead
        # of piling up threads/connections that outlive the addon invocation.
        prev = _inmemory_worker
        if prev is not None and prev.is_alive():
            xbmc.log("[StreamNinja] yt-dlp in memory: there is already a resolution in progress; skipped",
                     xbmc.LOGINFO)
            return None
        if not ensure_ytdlp():
            return None
        pkg = _packages_dir()
        if not _inmemory_path_added:
            if pkg not in sys.path:
                sys.path.insert(0, pkg)
            _inmemory_path_added = True
        try:
            from yt_dlp import YoutubeDL
        except Exception as exc:  # heavy third-party import: if fails, do not break anything
            xbmc.log("[StreamNinja] yt-dlp in memory not importable: {0}".format(exc),
                     xbmc.LOGWARNING)
            return None

        def _work():
            try:
                # socket_timeout bounds each yt-dlp network operation so that the
                # thread really terminates on a hung page, instead of continuing
                # to run indefinitely after we return None from the join.
                opts = {"quiet": True, "no_warnings": True, "noplaylist": True,
                        "format": fmt, "socket_timeout": timeout}
                with YoutubeDL(opts) as ydl:
                    box["info"] = ydl.extract_info(url, download=False)
            except Exception as exc:  # third-party lib in thread: capture all and log
                box["error"] = exc

        t = threading.Thread(target=_work, daemon=True)
        # Register under the SAME lock as check; check-and-reserve is atomic,
        # so two nearly simultaneous calls do not start two workers at once.
        _inmemory_worker = t

    t.start()
    t.join(timeout)
    if t.is_alive():
        xbmc.log("[StreamNinja] yt-dlp en memoria: timeout ({0}s)".format(timeout),
                 xbmc.LOGWARNING)
        return None
    if "error" in box:
        xbmc.log("[StreamNinja] yt-dlp en memoria: {0}".format(box["error"]),
                 xbmc.LOGWARNING)
        return None

    info = box.get("info")
    if not info:
        return None
    if "entries" in info:  # playlist: take the first playable entry
        entries = [e for e in (info.get("entries") or []) if e]
        if not entries:
            return None
        info = entries[0]

    stream_url = info.get("url")
    if not stream_url:
        return None
    return {
        "url": stream_url,
        "headers": info.get("http_headers") or {},
        "protocol": info.get("protocol") or "",
        "ext": info.get("ext") or "",
    }

def scan_videos(url, timeout=90):
    """Extracts the list of videos from *url* via yt-dlp.

    Runs yt-dlp with ``--dump-json`` and parses the output, which contains
    one JSON line for each detected video.

    Args:
        url:     Page or playlist to scan.
        timeout: Maximum seconds to wait for the subprocess.

    Returns:
        List of dicts with keys ``title``, ``url``, ``duration``
        (seconds or None), ``filesize`` (bytes or None) and ``ext``.
        Empty list if yt-dlp is not available, fails or there are no videos.
    """
    if not is_available():
        return []

    cmd = _build_cmd(url, ["--flat-playlist"])
    stdout = _run_ytdlp(cmd, timeout)
    if not stdout:
        return []

    results = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            info = json.loads(line)
        except (json.JSONDecodeError, ValueError):
            continue
        video_url = info.get("url") or info.get("webpage_url") or ""
        if not video_url:
            continue
        results.append({
            "title": info.get("title") or video_url,
            "url": video_url,
            "duration": info.get("duration"),
            "filesize": info.get("filesize") or info.get("filesize_approx"),
            "ext": info.get("ext") or "",
        })
    return results


def _is_windows():
    return xbmc.getCondVisibility("System.Platform.Windows")
