# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubenSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later - See the LICENSE file.
import html as _html
import re
from urllib.parse import urlparse
from urllib.request import urlopen, Request

try:
    import xbmc
    _log = lambda msg: xbmc.log("[StreamNinja/tgscan] {0}".format(msg), xbmc.LOGDEBUG)
    _warn = lambda msg: xbmc.log("[StreamNinja/tgscan] {0}".format(msg), xbmc.LOGWARNING)
except ImportError:
    _log = lambda msg: None
    _warn = lambda msg: None

from _user_agents import UA_DESKTOP as _UA

_BASE = "https://t.me/s/{channel}"
_MAX_BYTES = 256 * 1024
_TIMEOUT = 12
_MAX_PAGES = 3
_MAX_RESULTS = 50

_VIDEO_EXTS = frozenset((".mp4", ".mkv", ".webm", ".avi", ".mov", ".m3u8", ".mpd", ".ts"))
_DOC_EXTS = frozenset((".torrent", ".zip", ".rar", ".7z", ".nfo"))


def scan_channel(channel_or_url, max_pages=_MAX_PAGES):
    """Scrapes a PUBLIC Telegram channel and returns the list of links.

    Compatibility: thin wrapper of scan_channel_paged that discards the
    continuation cursor (used by url_remote, which does not page on demand).
    """
    return scan_channel_paged(channel_or_url, max_pages)[0]


def scan_channel_paged(channel_or_url, max_pages=_MAX_PAGES, before_id=None):
    """Scrapes a public channel paging backwards from ``before_id``.

    Only works with public username channels (t.me/name); private ones
    (t.me/+..., joinchat) are not accessible without authentication.
    channel_or_url accepts: @channel, t.me/channel, telegram.me/channel,
    https://t.me/s/channel or the bare name.

    Returns (results, next_before_id). next_before_id is None when the
    end of the channel was reached; otherwise, it is used to request "older" posts.
    """
    channel = _normalize_channel(channel_or_url)
    if not channel:
        _log("Invalid channel: {0}".format(channel_or_url))
        return [], None

    seen = set()
    results = []
    cursor = before_id

    for _ in range(max(1, max_pages)):
        html = _fetch_page(channel, cursor)
        if not html:
            cursor = None
            break

        items = _extract_message_items(html, channel)
        if not items and "tgme_widget_message_wrap" not in html:
            # Page downloaded but without the expected message container:
            # private/empty channel, or Telegram changed the HTML and regexes no longer match.
            _warn("No recognizable messages in {0}: private/empty channel or Telegram HTML changed.".format(channel))
        for item in items:
            if item["url"] in seen:
                continue
            seen.add(item["url"])
            results.append(item)

        oldest = _extract_oldest_id(html)
        if not oldest or oldest == cursor:
            cursor = None          # page does not go back: end of channel
            break
        cursor = oldest
        if len(results) >= _MAX_RESULTS:
            break                  # messages remaining: cursor allows continuing

    return results, cursor


def is_telegram(text):
    """True if the text seems to refer to a Telegram channel (public or not)."""
    if not text:
        return False
    t = text.strip()
    low = t.lower()
    if t.startswith('@'):
        return True
    if 't.me/' in low or low.startswith('t.me') or 'telegram.me/' in low:
        return True
    # Bare handle: only [a-z0-9_], 5+ chars, no scheme or dot (not a domain)
    return '://' not in t and '.' not in t and bool(re.match(r'^[a-zA-Z0-9_]{5,}$', t))


def is_private_invite(text):
    """True for invitation links to PRIVATE channels/groups (not scannable)."""
    if not text:
        return False
    low = text.strip().lower()
    return (
        't.me/+' in low or 'telegram.me/+' in low
        or 't.me/joinchat/' in low or 'telegram.me/joinchat/' in low
        or low.lstrip('@').startswith('+')
    )


def _normalize_channel(raw):
    """Extracts the channel name from any input format."""
    raw = raw.strip()
    # Remove scheme and domain (t.me, telegram.me, with or without www. or /s/)
    raw = re.sub(r'^https?://', '', raw)
    raw = re.sub(r'^(?:www\.)?(?:t\.me|telegram\.me)/s/', '', raw)
    raw = re.sub(r'^(?:www\.)?(?:t\.me|telegram\.me)/', '', raw)
    raw = raw.lstrip('@').split('/')[0].split('?')[0].strip()
    # Valid name: letters, numbers, underscore, min 5 chars (Telegram limit)
    if re.match(r'^[a-zA-Z0-9_]{5,}$', raw):
        return raw
    return ""


def _fetch_page(channel, before_id=None):
    url = _BASE.format(channel=channel)
    if before_id:
        url += "?before={0}".format(before_id)
    try:
        req = Request(url, headers={
            "User-Agent": _UA,
            "Accept-Language": "es-ES,es;q=0.9",
        })
        with urlopen(req, timeout=_TIMEOUT) as resp:
            if resp.status != 200:
                _log("HTTP {0} for {1}".format(resp.status, url))
                return ""
            return resp.read(_MAX_BYTES).decode("utf-8", errors="replace")
    except OSError as exc:
        _log("Error downloading {0}: {1}".format(url, exc))
        return ""


def _extract_message_items(html, channel):
    results = []
    # Each message has a wrapper with data-post="channel/N"
    msg_re = re.compile(
        r'<div[^>]+class=["\'][^"\']*tgme_widget_message_wrap[^"\']*["\'][^>]*>'
        r'(.*?)'
        r'(?=<div[^>]+class=["\'][^"\']*tgme_widget_message_wrap|$)',
        re.S,
    )

    for msg_m in msg_re.finditer(html):
        block = msg_m.group(1)
        # Message text (to use as title)
        text_m = re.search(
            r'class=["\'][^"\']*tgme_widget_message_text[^"\']*["\'][^>]*>(.*?)</(?:div|p)>',
            block, re.S,
        )
        raw_text = ""
        if text_m:
            raw_text = re.sub(r'<[^>]+>', ' ', text_m.group(1)).strip()
            raw_text = _html.unescape(re.sub(r'\s+', ' ', raw_text))[:120]

        block_seen = set()

        # 1. Attached videos: <video src="..."> inside the block
        for vm in re.finditer(r'<video[^>]+src=["\']([^"\']+)["\']', block, re.I):
            src = vm.group(1).strip()
            if src and src not in block_seen:
                block_seen.add(src)
                results.append(_make_item(src, raw_text or _basename(src), ""))

        # 2. Attached documents: <a href="..."> inside a document wrapper.
        # We first check if the wrapper exists to avoid iterating all <a> in the block
        # on messages without attachments.
        if re.search(r'class=["\'][^"\']*tgme_widget_message_document[^"\']*["\']', block, re.I):
            for am in re.finditer(r'<a\s[^>]*?href=["\']([^"\']+)["\']', block, re.I):
                href = am.group(1).strip()
                if not href.startswith("http"):
                    continue
                ext = _ext(href)
                if (ext in _VIDEO_EXTS or ext in _DOC_EXTS) and href not in block_seen:
                    block_seen.add(href)
                    results.append(_make_item(href, raw_text or _basename(href), ext))

        # 3. External links in the message text (known video platforms)
        for lm in re.finditer(r'href=["\']([^"\']+)["\']', block, re.I):
            href = lm.group(1).strip()
            if not href.startswith("http"):
                continue
            if href in block_seen:
                continue
            # Exclude internal Telegram links and thumbnail CDNs
            if "t.me" in href or "telegram.org" in href or "telegra.ph" in href or "thumbs" in href:
                continue
            ext = _ext(href)
            if ext in _VIDEO_EXTS or ext in _DOC_EXTS or _is_known_platform(href):
                block_seen.add(href)
                results.append(_make_item(href, raw_text or _basename(href), ext))

    return results


def _extract_oldest_id(html):
    """Extracts the oldest message ID from the page for pagination."""
    ids = re.findall(r'data-post=["\'][^/]+/(\d+)["\']', html)
    if ids:
        try:
            return str(min(int(i) for i in ids))
        except ValueError:
            pass
    return None


def _make_item(url, title, ext):
    return {
        "url": url,
        "title": title or url[:80],
        "ext": ext.lstrip(".") if ext else _ext(url).lstrip("."),
        "filesize": None,
        "duration": None,
        "source": "telegram",
    }


def _basename(url):
    try:
        path = urlparse(url).path
        name = path.rstrip("/").rsplit("/", 1)[-1]
        if "." in name:
            name = name.rsplit(".", 1)[0]
        return name.replace("-", " ").replace("_", " ")[:80]
    except ValueError:
        return url[:80]


def _ext(url):
    try:
        path = urlparse(url).path.lower()
        if "." in path:
            return "." + path.rsplit(".", 1)[-1].split("?")[0]
    except ValueError:
        pass
    return ""


def _is_known_platform(url):
    return bool(re.search(
        r'(youtube\.com|youtu\.be|dailymotion\.com|vimeo\.com|'
        r'twitch\.tv|rumble\.com|odysee\.com|streamable\.com)',
        url, re.I,
    ))
