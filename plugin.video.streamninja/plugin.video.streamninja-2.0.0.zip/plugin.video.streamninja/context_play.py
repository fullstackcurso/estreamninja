# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.
"""
Context menu: Open with StreamNinja.
Extracts the path of the selected item and launches playback
through the addon's entry point.
"""
import sys
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui

_LOCALIZE = xbmcaddon.Addon().getLocalizedString

if __name__ == '__main__':
    try:
        item_url = sys.listitem.getPath()
        if item_url:
            safe_url = urllib.parse.quote(item_url, safe="")
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30159),
                xbmcgui.NOTIFICATION_INFO, 1500
            )
            xbmc.executebuiltin(
                'RunPlugin(plugin://plugin.video.streamninja/'
                '?action=url_play&url={0})'.format(safe_url)
            )
        else:
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30185),
                xbmcgui.NOTIFICATION_WARNING, 2000
            )
    except Exception as e:
        xbmc.log("[StreamNinja] context_play: {0}".format(e), xbmc.LOGERROR)

