# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.
#
# STREAMNINJA EXPERIMENTAL:
# StreamNinja is an experimental version where features are tested that, 
# eventually, could reach StreamNinja. It stands out for being developed
# entirely in Spanish.
# 
# This version is not intended to be used by the general public or by 
# other developers: the code lacks proper comments, is not polished,
# and contains dead or disposable elements for testing use only.
# The original project has an API so that other addons can use its functions.
# This version is for personal use only.

"""
==============================================================================
LEGAL DISCLAIMER:

1. EDUCATIONAL USE AND NEUTRALITY: This software is an experimental and 
   educational open source project. It functions exclusively as a passive 
   network tool that facilitates search and interoperability of information.
2. NO HOSTING: This code does not host, store, retransmit, copy, or 
   distribute any kind of material or audiovisual content. All network 
   communication occurs exclusively between the end-user's device and 
   the internet servers they freely choose to connect to.
3. NO DRM BYPASS: The project operates without interfering, 
   violating, decrypting, or altering the code of any technological protection 
   measure or closed digital rights management system (DRM).
4. TOTAL DISCLAIMER OF LIABILITY: The use of this code is under the 
   strict responsibility of the end-user. The software is provided 
   "as is" (AS IS), and its creators decline any responsibility, 
   neither promoting nor supporting any illegal use derived from it.
==============================================================================
"""
import sys
import os
import re
import threading
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

import url_player
import url_remote
import stats

_ADDON = xbmcaddon.Addon()
_LOCALIZE = _ADDON.getLocalizedString
_MEDIA = os.path.join(_ADDON.getAddonInfo("path"), "resources", "media")

# --- Accessibility: bold, color mode, and symbols in all menus ---
# Monkey-patch of xbmcgui.ListItem to transform each label.
# Global variables are re-read in main() on each invocation; the toggle is applied
# instantly (Container.Refresh) even if Kodi reuses the interpreter.

_ACC_COLOR_NAMES = {
    'none':        _LOCALIZE(31200),
    'white':       _LOCALIZE(31201),
    'daltonic_rg': _LOCALIZE(31202),
    'daltonic_by': _LOCALIZE(31203),
    'hc_dark':     _LOCALIZE(31204),
    'hc_light':    _LOCALIZE(31205),
}
_ACC_COLOR_KEYS = list(_ACC_COLOR_NAMES.keys())
_ACC_COLOR_LABELS = list(_ACC_COLOR_NAMES.values())


def _acc_color_index_to_key(raw):
    """Stored value of acc_color_mode -> internal key.
    Accepts numeric index ('0'..), legacy key ('hc_dark'), or empty."""
    if not raw:
        return _ACC_COLOR_KEYS[0]
    try:
        idx = int(raw)
    except ValueError:
        return raw if raw in _ACC_COLOR_KEYS else _ACC_COLOR_KEYS[0]
    return _ACC_COLOR_KEYS[idx] if 0 <= idx < len(_ACC_COLOR_KEYS) else _ACC_COLOR_KEYS[0]


_BOLD_ENABLED = True
_ACC_COLOR_MODE = 'none'
_ACC_STRIP_SYMBOLS = False

try:
    _acc_init = xbmcaddon.Addon()
    _BOLD_ENABLED = _acc_init.getSetting('bold_labels') != 'false'
    _ACC_COLOR_MODE = _acc_color_index_to_key(_acc_init.getSetting('acc_color_mode'))
    _ACC_STRIP_SYMBOLS = _acc_init.getSetting('acc_strip_symbols') == 'true'
    del _acc_init
except Exception:
    pass

_OrigListItem = getattr(xbmcgui, '_OrigListItemSN', None) or xbmcgui.ListItem
xbmcgui._OrigListItemSN = _OrigListItem

_ACC_DRG_MAP = {
    'red': 'orange', 'tomato': 'orange', 'crimson': 'orange',
    'maroon': 'orange', 'coral': 'orange', 'firebrick': 'orange',
    'green': 'cyan', 'lime': 'cyan', 'limegreen': 'cyan',
    'mediumseagreen': 'cyan', 'palegreen': 'cyan', 'springgreen': 'cyan',
    'darkgreen': 'cyan', 'forestgreen': 'cyan', 'seagreen': 'cyan',
    'aqua': 'cyan', 'cyan': 'cyan', 'deepskyblue': 'deepskyblue',
    'skyblue': 'skyblue', 'lightskyblue': 'lightskyblue',
    'royalblue': 'royalblue', 'cornflowerblue': 'cornflowerblue', 'blue': 'blue',
    'gold': 'yellow', 'khaki': 'yellow', 'yellow': 'yellow',
    'gray': 'gray', 'grey': 'grey', 'white': 'white',
    'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
    'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
    'black': 'black', 'silver': 'silver',
}
_ACC_DBY_MAP = {
    'yellow': 'magenta', 'gold': 'magenta', 'khaki': 'magenta',
    'lemonchiffon': 'magenta', 'lightyellow': 'magenta',
    'blue': 'red', 'deepskyblue': 'red', 'royalblue': 'red',
    'cornflowerblue': 'red', 'lightskyblue': 'red', 'navy': 'red',
    'aqua': 'red', 'cyan': 'red', 'teal': 'red', 'turquoise': 'red',
    'skyblue': 'red', 'steelblue': 'red', 'cadetblue': 'red',
    'gray': 'gray', 'grey': 'grey', 'white': 'white',
    'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
    'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
    'black': 'black', 'silver': 'silver',
}
_ACC_HCD_KEEP_RED = frozenset({'red', 'tomato', 'crimson', 'maroon', 'coral', 'firebrick'})
_ACC_COLOR_RE = re.compile(r'\[COLOR\s+([a-zA-Z0-9]+)\]')
_ACC_SYMBOL_TABLE = str.maketrans({'★': '*', '●': '*', '○': '-', '▲': '^', '▼': 'v', '◑': '~', '◐': '~'})


def _acc_remap(match):
    c = match.group(1).lower()
    if _ACC_COLOR_MODE == 'white':
        return '[COLOR white]'
    if _ACC_COLOR_MODE == 'daltonic_rg':
        return '[COLOR {0}]'.format(_ACC_DRG_MAP.get(c, 'white'))
    if _ACC_COLOR_MODE == 'daltonic_by':
        return '[COLOR {0}]'.format(_ACC_DBY_MAP.get(c, 'white'))
    if _ACC_COLOR_MODE == 'hc_dark':
        return '[COLOR {0}]'.format(c if c in _ACC_HCD_KEEP_RED else 'yellow')
    if _ACC_COLOR_MODE == 'hc_light':
        return '[COLOR {0}]'.format(c if c in _ACC_HCD_KEEP_RED else 'black')
    return match.group(0)


def _acc_transform(s):
    if not isinstance(s, str) or not s:
        return s
    if _ACC_STRIP_SYMBOLS:
        s = s.translate(_ACC_SYMBOL_TABLE)
    if _BOLD_ENABLED:
        if '[B]' not in s:
            s = '[B]' + s + '[/B]'
    else:
        s = s.replace('[B]', '').replace('[/B]', '')
    if _ACC_COLOR_MODE not in ('', 'none'):
        s = _ACC_COLOR_RE.sub(_acc_remap, s)
    return s


def _ListItemBold(*args, **kwargs):
    if 'label' in kwargs:
        kwargs['label'] = _acc_transform(kwargs['label'])
    elif args:
        args = (_acc_transform(args[0]),) + args[1:]
    if 'label2' in kwargs:
        kwargs['label2'] = _acc_transform(kwargs['label2'])
    elif len(args) >= 2:
        args = (args[0], _acc_transform(args[1])) + args[2:]
    return _OrigListItem(*args, **kwargs)


xbmcgui.ListItem = _ListItemBold


def _accessibility_menu():
    h = url_player._get_handle()
    bold_on = xbmcaddon.Addon().getSetting('bold_labels') != 'false'
    cur_mode = _acc_color_index_to_key(xbmcaddon.Addon().getSetting('acc_color_mode'))
    sym_on = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'

    mode_name = _ACC_COLOR_NAMES.get(cur_mode, _ACC_COLOR_NAMES['none'])

    li = xbmcgui.ListItem(label=_LOCALIZE(31208).format(mode_name))
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': _LOCALIZE(30502)})
    xbmcplugin.addDirectoryItem(handle=h, url=url_player._u(action='acc_set_color_mode'), listitem=li, isFolder=False)

    enabled_tag = _LOCALIZE(31209) if bold_on else _LOCALIZE(31210)
    bold_label = _LOCALIZE(31206) + ': ' + enabled_tag
    li = xbmcgui.ListItem(label=bold_label)
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': _LOCALIZE(30500)})
    xbmcplugin.addDirectoryItem(handle=h, url=url_player._u(action='acc_toggle_bold'), listitem=li, isFolder=False)

    enabled_tag = _LOCALIZE(31209) if sym_on else _LOCALIZE(31210)
    sym_label = _LOCALIZE(31207) + ': ' + enabled_tag
    li = xbmcgui.ListItem(label=sym_label)
    li.setArt({'icon': 'DefaultAddonSkin.png'})
    li.setInfo('video', {'plot': _LOCALIZE(30501)})
    xbmcplugin.addDirectoryItem(handle=h, url=url_player._u(action='acc_toggle_symbols'), listitem=li, isFolder=False)

    # cacheToDisc=False: the listing depends on mutable settings; it must always be re-rendered.
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _acc_toggle_bold():
    cur = xbmcaddon.Addon().getSetting('bold_labels') != 'false'
    xbmcaddon.Addon().setSetting('bold_labels', 'false' if cur else 'true')
    msg = _LOCALIZE(31210) if cur else _LOCALIZE(31209)
    xbmcgui.Dialog().notification(_LOCALIZE(30120), 'Bold text {0}'.format(msg), xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _acc_set_color_mode():
    cur_idx = _ACC_COLOR_KEYS.index(_acc_color_index_to_key(xbmcaddon.Addon().getSetting('acc_color_mode')))
    sel = xbmcgui.Dialog().select(_LOCALIZE(31355), _ACC_COLOR_LABELS, preselect=cur_idx)
    if sel < 0:
        return
    xbmcaddon.Addon().setSetting('acc_color_mode', str(sel))
    xbmcgui.Dialog().notification(_LOCALIZE(30120), 'Color: {0}'.format(_ACC_COLOR_LABELS[sel][:40]), xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _acc_toggle_symbols():
    cur = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'
    xbmcaddon.Addon().setSetting('acc_strip_symbols', 'false' if cur else 'true')
    msg = _LOCALIZE(31210) if cur else _LOCALIZE(31209)
    xbmcgui.Dialog().notification(_LOCALIZE(30120), 'Symbol replacement {0}'.format(msg), xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


_ENUM_OPTIONS = {
    'dm_safe_level': (
        _LOCALIZE(31350),
        [_LOCALIZE(30452), _LOCALIZE(30453),
         _LOCALIZE(30454), _LOCALIZE(30455)],
    ),
    'dl_mode': (
        _LOCALIZE(31351),
        [_LOCALIZE(30456), _LOCALIZE(30457),
         _LOCALIZE(30458), _LOCALIZE(30459), _LOCALIZE(30460)],
    ),
    'webremote_mode': (
        _LOCALIZE(31352),
        [_LOCALIZE(30450), _LOCALIZE(30451)],
    ),
    'record_format': (
        _LOCALIZE(31353),
        [_LOCALIZE(30461), _LOCALIZE(30462), _LOCALIZE(30463)],
    ),
    'record_quality': (
        _LOCALIZE(31354),
        [_LOCALIZE(30464), _LOCALIZE(30465), _LOCALIZE(30466), _LOCALIZE(30467)],
    ),
}


def _settings_add_toggle(h, a, setting_id, label, plot):
    val = a.getSetting(setting_id) != 'false'
    state = _LOCALIZE(31209) if val else _LOCALIZE(31210)
    li = xbmcgui.ListItem(label='{0}: {1}'.format(label, state))
    icon_path = os.path.join(_MEDIA, 'settings_{0}.png'.format(setting_id))
    if not os.path.exists(icon_path):
        icon_path = os.path.join(_MEDIA, 'opciones.png')
    li.setArt({'icon': icon_path})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=url_player._u(action='settings_toggle', setting_id=setting_id, name=label),
        listitem=li, isFolder=False,
    )


def _settings_add_enum(h, a, setting_id, label, plot):
    _, values = _ENUM_OPTIONS[setting_id]
    try:
        idx = int(a.getSetting(setting_id) or '0')
    except ValueError:
        idx = 0
    cur = values[idx] if 0 <= idx < len(values) else values[0]
    li = xbmcgui.ListItem(label='{0}: [COLOR deepskyblue]{1}[/COLOR]'.format(label, cur))
    icon_path = os.path.join(_MEDIA, 'settings_{0}.png'.format(setting_id))
    if not os.path.exists(icon_path):
        icon_path = os.path.join(_MEDIA, 'opciones.png')
    li.setArt({'icon': icon_path})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=url_player._u(action='settings_set_enum', setting_id=setting_id, name=label),
        listitem=li, isFolder=False,
    )


def _settings_add_folder(h, label, action, icon, plot):
    li = xbmcgui.ListItem(label='[COLOR white][B]{0}[/B][/COLOR]'.format(label))
    li.setArt({'icon': os.path.join(_MEDIA, icon)})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(
        handle=h, url=url_player._u(action=action), listitem=li, isFolder=True
    )


def _settings_add_input(h, a, setting_id, label, input_type='text', plot='', min_val=None, max_val=None, step=None, secret=False):
    cur = a.getSetting(setting_id)
    if not cur:
        shown = '[COLOR grey](sin definir)[/COLOR]'
    elif secret:
        # No exponer claves secretas (topic ntfy) en pantalla al navegar el menu.
        shown = '[COLOR lime]configurado[/COLOR]'
    else:
        shown = cur
    li = xbmcgui.ListItem(label='{0}: [COLOR deepskyblue]{1}[/COLOR]'.format(label, shown))
    icon_path = os.path.join(_MEDIA, 'settings_{0}.png'.format(setting_id))
    if not os.path.exists(icon_path):
        icon_path = os.path.join(_MEDIA, 'opciones.png')
    li.setArt({'icon': icon_path})
    li.setInfo('video', {'plot': plot})
    # urlencode serializa None como "None"; solo se pasan los parametros presentes.
    kw = {'action': 'settings_input', 'setting_id': setting_id, 'name': label, 'input_type': input_type}
    if min_val is not None:
        kw['min_val'] = min_val
    if max_val is not None:
        kw['max_val'] = max_val
    if step is not None:
        kw['step'] = step
    xbmcplugin.addDirectoryItem(
        handle=h, url=url_player._u(**kw), listitem=li, isFolder=False,
    )


def _settings_input(setting_id, name='', input_type='text', min_val=None, max_val=None, step=None):
    if not setting_id:
        return
    addon = xbmcaddon.Addon()
    cur = addon.getSetting(setting_id)

    if input_type == 'folder':
        val = xbmcgui.Dialog().browse(3, name or 'Folder', 'files', '', False, False, cur)
        if not val or val == cur:
            return
    elif input_type == 'range':
        # Equivalent to the native slider; navigable selector with controller (no keyboard).
        lo = int(min_val) if min_val is not None else 0
        hi = int(max_val) if max_val is not None else 100
        stp = int(step) if step is not None else 1
        valores = list(range(lo, hi + 1, stp))
        try:
            cur_n = int(cur)
        except ValueError:
            cur_n = lo
        pre = min(range(len(valores)), key=lambda i: abs(valores[i] - cur_n))
        sel = xbmcgui.Dialog().select(name or 'Value', [str(v) for v in valores], preselect=pre)
        if sel < 0:
            return
        val = str(valores[sel])
    elif input_type == 'number':
        raw = xbmcgui.Dialog().input(name or 'Value', defaultt=cur, type=xbmcgui.INPUT_NUMERIC)
        if not raw:
            return
        try:
            num = int(raw)
        except ValueError:
            return
        lo = int(min_val) if min_val is not None else None
        hi = int(max_val) if max_val is not None else None
        if (lo is not None and num < lo) or (hi is not None and num > hi):
            xbmcgui.Dialog().notification(
                _LOCALIZE(30112), 'Out of range ({0}-{1})'.format(lo, hi),
                xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        val = str(num)
    else:  # text: empty is valid (IP, ntfy, duration); cancel != confirm empty
        kb = xbmc.Keyboard(cur, name or 'Value')
        kb.doModal()
        if not kb.isConfirmed():
            return
        val = kb.getText().strip()

    addon.setSetting(setting_id, val)
    xbmcgui.Dialog().notification(_LOCALIZE(30112), '{0} saved'.format(name or setting_id),
                                  xbmcgui.NOTIFICATION_INFO, 1500)
    xbmc.executebuiltin('Container.Refresh')


def _settings_menu():
    h = url_player._get_handle()



    _settings_add_folder(
        h, _LOCALIZE(30115), 'debrid_config', 'cloud_debrid.png',
        _LOCALIZE(30503),
    )
    _settings_add_folder(
        h, _LOCALIZE(30116), 'settings_remote_menu', 'settings_webremote_mode.png',
        _LOCALIZE(30504),
    )
    _settings_add_folder(
        h, _LOCALIZE(30117), 'settings_downloads_menu', 'settings_dl_mode.png',
        _LOCALIZE(30505),
    )
    _settings_add_folder(
        h, _LOCALIZE(30118), 'settings_acestream_menu', 'settings_acestream_enabled.png',
        _LOCALIZE(30506),
    )
    _settings_add_folder(
        h, _LOCALIZE(30119), 'settings_general_menu', 'url_config.png',
        _LOCALIZE(30507),
    )
    _settings_add_folder(
        h, _LOCALIZE(30120), 'accessibility_menu', 'adv_accesibilidad.png',
        _LOCALIZE(30508),
    )
    _settings_add_folder(
        h, _LOCALIZE(30121), 'advanced_menu', 'adv_debug.png',
        _LOCALIZE(30509),
    )

    li = xbmcgui.ListItem(label=_LOCALIZE(30122))
    li.setArt({'icon': os.path.join(_MEDIA, 'settings_native.png')})
    li.setInfo('video', {'plot': _LOCALIZE(30510)})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=url_player._u(action='open_settings_native'),
        listitem=li, isFolder=False,
    )

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_remote_menu():
    h = url_player._get_handle()
    a = xbmcaddon.Addon()
    _settings_add_toggle(
        h, a, 'enable_qr_remote',
        'QR on remote server',
        _LOCALIZE(30600),
    )
    _settings_add_toggle(
        h, a, 'remote_secure',
        'Secure local server (require token)',
        _LOCALIZE(30601),
    )
    _settings_add_toggle(
        h, a, 'remote_pin',
        'Pair with PIN',
        _LOCALIZE(30602),
    )
    _settings_add_input(
        h, a, 'remote_port', 'Server port', 'number',
        _LOCALIZE(30603),
        min_val=1024, max_val=65535,
    )
    _settings_add_input(
        h, a, 'remote_ip', 'Listening IP', 'text',
        _LOCALIZE(30604),
    )
    _settings_add_enum(
        h, a, 'webremote_mode',
        _LOCALIZE(30307),
        _LOCALIZE(30605),
    )
    _settings_add_toggle(
        h, a, 'webremote_confirm',
        'Confirm received URLs',
        _LOCALIZE(30606),
    )
    if a.getSetting('webremote_mode') == '1':
        _settings_add_input(
            h, a, 'webremote_server', 'ntfy server', 'text',
            _LOCALIZE(30607),
        )
        _settings_add_input(
            h, a, 'webremote_topic', 'Channel / topic (secret key)', 'text',
            _LOCALIZE(30608),
            secret=True,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_downloads_menu():
    h = url_player._get_handle()
    a = xbmcaddon.Addon()
    _settings_add_enum(
        h, a, 'dl_mode',
        _LOCALIZE(30312),
        _LOCALIZE(30650),
    )
    _settings_add_input(
        h, a, 'download_path', _LOCALIZE(30315), 'folder',
        'Folder where downloaded videos are saved.',
    )
    _settings_add_enum(
        h, a, 'dm_safe_level',
        _LOCALIZE(30311),
        _LOCALIZE(30651),
    )
    _settings_add_enum(
        h, a, 'record_format',
        _LOCALIZE(30317),
        _LOCALIZE(30652),
    )
    _settings_add_enum(
        h, a, 'record_quality',
        _LOCALIZE(30318),
        _LOCALIZE(30653),
    )
    _settings_add_input(
        h, a, 'record_path', _LOCALIZE(30316), 'folder',
        'Folder where live stream recordings are saved.',
    )
    _settings_add_input(
        h, a, 'record_timer', 'Maximum duration', 'text',
        'Maximum recording duration (e.g. "1 hour", "30 min").\n\n'
        'Empty = no limit.',
    )
    _settings_add_input(
        h, a, 'record_delay', 'Delay before starting', 'text',
        'Delay before starting the recording (e.g. "5 min").\n\n'
        'Empty = start now.',
    )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_acestream_menu():
    h = url_player._get_handle()
    a = xbmcaddon.Addon()
    _settings_add_toggle(
        h, a, 'acestream_enabled',
        _LOCALIZE(30321),
        _LOCALIZE(30654),
    )
    _settings_add_input(
        h, a, 'acestream_ip', _LOCALIZE(30322), 'text',
        'IP of the AceStream engine.\n\n'
        '127.0.0.1 = local engine on this device.',
    )
    _settings_add_input(
        h, a, 'acestream_port', _LOCALIZE(30323), 'number',
        'HTTP port of the AceStream engine (default 6878).',
        min_val=1, max_val=65535,
    )
    _settings_add_input(
        h, a, 'acestream_timeout', 'Maximum prebuffer time (s)', 'range',
        'Seconds of wait for P2P prebuffer before starting.\n\n'
        'Between 10 and 180, in steps of 5.',
        min_val=10, max_val=180, step=5,
    )
    _settings_add_toggle(
        h, a, 'acestream_show_osd',
        'On-screen P2P stats (AceStream)',
        'Shows speed, peers, and status over the player when opening video OSD '
        'during AceStream playback.\n\n'
        'Only affects AceStream.',
    )
    if xbmc.getCondVisibility("System.Platform.Android"):
        _settings_add_toggle(
            h, a, 'acestream_android_external',
            'Open AceStream in official app (Android)',
            'On Android, sends the AceStream link to the official app instead '
            'of playing with the local engine.\n\n'
            'Requires AceStream app installed.',
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_general_menu():
    h = url_player._get_handle()
    a = xbmcaddon.Addon()
    _settings_add_toggle(
        h, a, 'enable_context_play',
        _LOCALIZE(30050),
        _LOCALIZE(30655),
    )
    _settings_add_toggle(
        h, a, 'enable_context_copy',
        _LOCALIZE(30051),
        _LOCALIZE(30656),
    )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _settings_toggle(setting_id, name=''):
    if not setting_id:
        return
    cur = xbmcaddon.Addon().getSetting(setting_id) != 'false'
    xbmcaddon.Addon().setSetting(setting_id, 'false' if cur else 'true')
    estado = _LOCALIZE(31210) if cur else _LOCALIZE(31209)
    xbmcgui.Dialog().notification(_LOCALIZE(30112), '{0}: {1}'.format(name or setting_id, estado),
                                  xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _settings_set_enum(setting_id, name=''):
    if setting_id not in _ENUM_OPTIONS:
        return
    title, values = _ENUM_OPTIONS[setting_id]
    try:
        cur_idx = int(xbmcaddon.Addon().getSetting(setting_id) or '0')
    except ValueError:
        cur_idx = 0
    sel = xbmcgui.Dialog().select(title, values, preselect=cur_idx)
    if sel >= 0:
        xbmcaddon.Addon().setSetting(setting_id, str(sel))
        xbmcgui.Dialog().notification(_LOCALIZE(30112), '{0}: {1}'.format(name or title, values[sel]),
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')


def _is_repo_installed():
    """Detects if the StreamNinja repository is installed.

    Accepts reasonable variations of the repository name
    (hyphens, underscores, suffixes) since the exact ID may
    vary between versions or forks of the repo.
    """
    # 1. Direct check of the most likely variants
    common_ids = [
        "repository.streamninja",
        "repository.stream_ninja",
        "repository.stream-ninja",
        "repository.streamninja.oficial",
    ]
    for repo_id in common_ids:
        if xbmc.getCondVisibility("System.HasAddon({0})".format(repo_id)):
            return True

    # 2. Fuzzy search: iterates through installed addon folders
    #    looking for any repository whose name contains "streamninja"
    try:
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        dirs, _ = xbmcvfs.listdir(addons_dir)
        for d in dirs:
            d_low = d.lower()
            if not d_low.startswith("repository."):
                continue
            # Normalize: remove separators to compare
            normalized = d_low.replace("_", "").replace("-", "").replace(".", "")
            if "streamninja" in normalized:
                if xbmc.getCondVisibility("System.HasAddon({0})".format(d)):
                    return True
    except Exception:
        pass
    return False


def _check_repo_status():
    if _is_repo_installed():
        xbmcgui.Dialog().ok(
            _LOCALIZE(30200),
            _LOCALIZE(31318) + '\n'
            "The addon updates automatically.",
        )
    else:
        xbmcgui.Dialog().ok(
            _LOCALIZE(30200),
            _LOCALIZE(31319) + '\n'
            "Install from ZIP source to\n"
            "receive automatic updates.",
        )


# --- yt-dlp Maintenance ---

def _show_ytdlp_instructions():
    """Shows step-by-step installation instructions for yt-dlp."""
    text = (
        "To play videos from YouTube, Dailymotion and other sites\n"
        "you need to install two free programs on your PC.\n"
        "Don't worry, it's easy. Follow these steps:\n\n"

        "============================================\n"
        "  FIRST: OPEN THE TERMINAL\n"
        "============================================\n\n"
        "The terminal is a window where you type commands.\n\n"
        "  Windows:\n"
        "    1. Press the Windows key on your keyboard\n"
        "    2. Type:  cmd\n"
        "    3. Click on 'Command Prompt'\n"
        "    A black window will open.\n\n"
        "    TIP: To paste a command in that window,\n"
        "    RIGHT-CLICK with the mouse (not Ctrl+V).\n\n"
        "  Mac:\n"
        "    1. Press Cmd + Space at the same time\n"
        "    2. Type:  Terminal\n"
        "    3. Press Enter\n\n"
        "  Linux:\n"
        "    Press Ctrl + Alt + T at the same time\n\n"

        "============================================\n"
        "  STEP 1: INSTALL PYTHON\n"
        "============================================\n\n"
        "You might already have it. To check,\n"
        "type in the terminal:\n\n"
        "   python --version\n\n"
        "If something like 'Python 3.12.0' appears, perfect,\n"
        "you already have it. Skip to Step 2.\n\n"
        "If it gives an error, try:\n"
        "   py --version\n\n"
        "If that fails too, you need to install it:\n\n"
        "   1. Go to: https://www.python.org/downloads/\n"
        "   2. Download the version for your system\n"
        "   3. Run the installer\n\n"
        "   >>> VERY IMPORTANT on Windows: <<<\n"
        "   On the first screen of the installer,\n"
        "   CHECK the box that says:\n"
        "       'Add Python to PATH'\n"
        "   If you don't check it, nothing will work.\n\n"
        "   4. Close the terminal and open it again\n\n"

        "============================================\n"
        "  STEP 2: INSTALL YT-DLP\n"
        "============================================\n\n"
        "Type (or paste) this command in the terminal:\n\n"
        '   pip install -U "yt-dlp[default]"\n\n'
        ">>> IMPORTANT: Type the command EXACTLY AS SHOWN, <<<\n"
        ">>> with the quotes and the [default].            <<<\n"
        ">>> Without it, Dailymotion will not work.        <<<\n\n"
        "If 'pip' gives an error, try:\n\n"
        '   python -m pip install -U "yt-dlp[default]"\n\n'
        "Wait for it to finish (it might take a minute).\n\n"

        "============================================\n"
        "  STEP 3: INSTALL DENO (for YouTube)\n"
        "============================================\n\n"
        "YouTube needs this additional program.\n"
        "Without it, YouTube videos will not work.\n\n"
        "  Windows:\n"
        "    Type in the terminal:\n"
        "    winget install DenoLand.Deno\n\n"
        "    If 'winget' gives an error:\n"
        "    1. Go to: https://github.com/denoland/deno/\n"
        "       releases/latest\n"
        "    2. Download deno-x86_64-pc-windows-msvc.zip\n"
        "    3. Extract and move deno.exe to C:\\Windows\\\n\n"
        "  Mac:\n"
        "    Type in the terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh\n\n"
        "  Linux:\n"
        "    Type in the terminal:\n"
        "    curl -fsSL https://deno.land/install.sh | sh"
    )
    xbmcgui.Dialog().textviewer(_LOCALIZE(31326), text)


def _probe_ytdlp_status():
    """Checks yt-dlp and utilities via subprocess. Returns the report lines.

    Blocks for up to several seconds: intended to run in a separate thread.
    """
    import subprocess

    # conditional kwargs: creationflags only exists on Windows
    kwargs = {"capture_output": True, "text": True, "timeout": 10}
    if xbmc.getCondVisibility("System.Platform.Windows"):
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

    lines = []

    # Logical status flags (decoupled from UI text)
    is_ytdlp_ok = False
    is_deno_ok = False
    is_node_ok = False
    is_ejs_ok = False

    # 1. Check yt-dlp
    try:
        kw_ytdlp = kwargs.copy()
        kw_ytdlp["timeout"] = 15
        proc = subprocess.run(["python", "-m", "yt_dlp", "--version"], **kw_ytdlp)
        if proc.returncode == 0:
            ver = proc.stdout.strip()
            lines.append("[COLOR green][OK][/COLOR] yt-dlp installed: v{0}".format(ver))
            is_ytdlp_ok = True
        else:
            lines.append("[COLOR red][ERROR][/COLOR] yt-dlp found but returned an error")
    except FileNotFoundError:
        lines.append("[COLOR red][ERROR][/COLOR] Python not found in PATH")
    except subprocess.TimeoutExpired:
        lines.append("[COLOR yellow][WARNING][/COLOR] yt-dlp took too long to respond")
    except OSError as exc:
        lines.append("[COLOR red][ERROR][/COLOR] System error: {0}".format(exc))

    # 2. Check Deno
    try:
        proc = subprocess.run(["deno", "--version"], **kwargs)
        if proc.returncode == 0:
            deno_ver = proc.stdout.strip().split("\n")[0]
            lines.append("[COLOR green][OK][/COLOR] Deno installed: {0}".format(deno_ver))
            is_deno_ok = True
        else:
            lines.append("[COLOR red][NO][/COLOR] Deno not available")
    except (FileNotFoundError, OSError):
        lines.append("[COLOR red][NO][/COLOR] Deno not found in PATH")
    except subprocess.TimeoutExpired:
        lines.append("[COLOR yellow][WARNING][/COLOR] Deno took too long")

    # 3. Check Node.js
    try:
        proc = subprocess.run(["node", "--version"], **kwargs)
        if proc.returncode == 0:
            node_ver = proc.stdout.strip()
            lines.append("[COLOR green][OK][/COLOR] Node.js installed: {0}".format(node_ver))
            is_node_ok = True
        else:
            lines.append("[COLOR red][NO][/COLOR] Node.js not available")
    except (FileNotFoundError, OSError):
        lines.append("[COLOR red][NO][/COLOR] Node.js not found in PATH")
    except subprocess.TimeoutExpired:
        lines.append("[COLOR yellow][WARNING][/COLOR] Node.js took too long")

    # 4. Check yt-dlp-ejs
    try:
        proc = subprocess.run(["python", "-c", "import yt_dlp_ejs"], **kwargs)
        if proc.returncode == 0:
            lines.append("[COLOR green][OK][/COLOR] yt-dlp-ejs installed")
            is_ejs_ok = True
        else:
            lines.append("[COLOR red][NO][/COLOR] yt-dlp-ejs not installed")
            lines.append('     Install it: pip install -U "yt-dlp[default]"')
    except (FileNotFoundError, OSError):
        lines.append("[COLOR red][NO][/COLOR] Could not check yt-dlp-ejs")
    except subprocess.TimeoutExpired:
        pass

    has_js = is_deno_ok or is_node_ok
    lines.append("")
    lines.append(_LOCALIZE(30866))
    if is_ytdlp_ok and has_js and is_ejs_ok:
        lines.append(_LOCALIZE(30867))
    elif is_ytdlp_ok and has_js and not is_ejs_ok:
        lines.append(_LOCALIZE(30868))
        lines.append('   pip install -U "yt-dlp[default]"')
    elif is_ytdlp_ok and not has_js:
        lines.append(_LOCALIZE(30869))
        lines.append(_LOCALIZE(30870))
        lines.append(_LOCALIZE(30871))
    else:
        lines.append(_LOCALIZE(30872))
        lines.append(_LOCALIZE(30871))

    return lines


def _check_ytdlp_status():
    """Proactive diagnosis of yt-dlp status; runs outside the UI thread."""
    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok(
            _LOCALIZE(30000),
            "yt-dlp is not compatible with Android.\n\n"
            "Use a PC with Python 3.10+ installed.",
        )
        return

    result = {}

    def _worker():
        try:
            result["lines"] = _probe_ytdlp_status()
        except Exception as exc:
            result["error"] = str(exc)
            xbmc.log("[StreamNinja] Error probing yt-dlp: {0}".format(exc), xbmc.LOGERROR)

    worker = threading.Thread(target=_worker)
    worker.daemon = True
    worker.start()

    dp = xbmcgui.DialogProgress()
    dp.create(_LOCALIZE(30000), "Checking yt-dlp and system utilities...")
    cancelled = False
    pct = 0
    while worker.is_alive():
        if dp.iscanceled():
            cancelled = True
            break
        pct = min(95, pct + 5)
        dp.update(pct)
        xbmc.sleep(150)
    dp.close()

    if cancelled:
        return
    if "lines" in result:
        xbmcgui.Dialog().textviewer(_LOCALIZE(31325), "\n".join(result["lines"]))
    else:
        xbmcgui.Dialog().ok(_LOCALIZE(30000), "Could not complete yt-dlp diagnosis. Check Kodi log for details.")


def _copy_to_clipboard(text):
    """Copies text to the operating system clipboard."""
    import subprocess
    import shutil

    def _pipe_to(cmd, **extra):
        # timeout prevents UI from hanging indefinitely if helper blocks
        try:
            p = subprocess.Popen(
                cmd, stdin=subprocess.PIPE, text=True, encoding="utf-8", **extra)
        except OSError as exc:
            xbmc.log("[StreamNinja] Clipboard: could not launch {0}: {1}".format(cmd[0], exc), xbmc.LOGWARNING)
            return False
        try:
            p.communicate(input=text, timeout=5)
            return p.returncode == 0
        except subprocess.TimeoutExpired:
            p.kill()
            p.communicate()
            xbmc.log("[StreamNinja] Clipboard: {0} did not respond in time".format(cmd[0]), xbmc.LOGWARNING)
            return False

    if xbmc.getCondVisibility("System.Platform.Windows"):
        if _pipe_to(["clip"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)):
            return True
    elif xbmc.getCondVisibility("System.Platform.OSX"):
        if _pipe_to(["pbcopy"]):
            return True
    elif xbmc.getCondVisibility("System.Platform.Linux"):
        if shutil.which("xclip"):
            if _pipe_to(["xclip", "-selection", "clipboard"]):
                return True
        elif shutil.which("xsel"):
            if _pipe_to(["xsel", "--clipboard", "--input"]):
                return True

    # Universal fallback via tkinter (rarely available in Kodi boxes)
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(text)
        r.update()
        r.destroy()
        return True
    except Exception as exc:
        xbmc.log("[StreamNinja] Clipboard: tkinter fallback not available: {0}".format(exc), xbmc.LOGDEBUG)
    return False


def _ytdlp_menu():
    opts = [
        _LOCALIZE(30873),
        _LOCALIZE(30874),
        _LOCALIZE(30875),
    ]
    sel = xbmcgui.Dialog().select(_LOCALIZE(30356), opts)
    if sel == 0:
        _show_ytdlp_instructions()
    elif sel == 1:
        _check_ytdlp_status()
    elif sel == 2:
        cmd_ytdlp = 'pip install -U "yt-dlp[default]"'
        if xbmc.getCondVisibility("System.Platform.Windows"):
            cmd_deno = "winget install DenoLand.Deno"
        else:
            cmd_deno = "curl -fsSL https://deno.land/install.sh | sh"
        full_text = "{0}\n{1}".format(cmd_ytdlp, cmd_deno)
        if _copy_to_clipboard(full_text):
            xbmcgui.Dialog().ok(
                _LOCALIZE(30203),
                "Commands have been copied.\n"
                "Paste them in your terminal (right-click\n"
                "or Ctrl+V) and press Enter.",
            )
        else:
            xbmcgui.Dialog().ok(
                _LOCALIZE(30204),
                "Could not copy to clipboard.\n\n"
                "Copy them manually from the\n"
                "instructions.",
            )


# --- GitHub Auto-Installers ---

def _generic_github_installer(nombre, api_url, target_id):
    """Downloads and installs an addon from GitHub Releases.

    Finds the first .zip asset of the latest release, validates
    its integrity, extracts it in the addons folder and enables it.
    """
    import requests
    import zipfile

    dp = xbmcgui.DialogProgress()
    dp.create(_LOCALIZE(30000), "Downloading {0}...".format(nombre))
    zip_path = None
    try:
        dp.update(5, "Searching for latest version...")
        r = requests.get(api_url, timeout=15)
        r.raise_for_status()
        assets = r.json().get("assets", [])
        zip_url = None
        for asset in assets:
            if asset.get("name", "").endswith(".zip"):
                zip_url = asset["browser_download_url"]
                break
        if not zip_url:
            raise ValueError(
                "No .zip file found in release")

        dp.update(10, "Downloading from GitHub...")
        r_zip = requests.get(zip_url, timeout=60, allow_redirects=True)
        r_zip.raise_for_status()

        # Validate magic bytes of ZIP
        if len(r_zip.content) < 4 or r_zip.content[:2] != b"PK":
            raise ValueError("The downloaded file is not a valid ZIP")

        # Save to temp
        zip_path = os.path.join(
            xbmcvfs.translatePath("special://temp/"),
            "{0}.zip".format(target_id),
        )
        with open(zip_path, "wb") as f:
            f.write(r_zip.content)

        dp.update(50, "Extracting addon...")
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        with zipfile.ZipFile(zip_path, "r") as zf:
            # Protection against path traversal
            for entry in zf.namelist():
                resolved = os.path.realpath(
                    os.path.join(addons_dir, entry))
                if not resolved.startswith(os.path.realpath(addons_dir)):
                    raise ValueError(
                        "ZIP contains suspicious path: {0}".format(entry))
            zf.extractall(addons_dir)

        dp.update(80, "Updating local addons...")
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.sleep(2000)
        xbmc.executebuiltin("EnableAddon({0})".format(target_id))
        xbmc.sleep(1000)
        dp.close()
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000),
            _LOCALIZE(30150).format(nombre),
            xbmcgui.NOTIFICATION_INFO, 5000,
        )
        xbmc.executebuiltin("Container.Refresh")
    except Exception as exc:
        dp.close()
        xbmc.log(
            "[StreamNinja] Error installing {0}: {1}".format(nombre, exc),
            xbmc.LOGWARNING,
        )
        choice = xbmcgui.Dialog().yesno(
            _LOCALIZE(30201),
            "Could not install {0}.\n\n"
            "Error: {1}\n\n"
            "You might need to enable\n"
            "'Unknown sources' in Settings.\n"
            "Open System Settings?".format(
                nombre, str(exc)[:150]),
        )
        if choice:
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


def _loiolog_install():
    opts = [_LOCALIZE(31322), _LOCALIZE(31323)]
    sel = xbmcgui.Dialog().select(_LOCALIZE(31324), opts)
    if sel == 0:
        _generic_github_installer(
            "loiolog",
            "https://api.github.com/repos/loioloio/loiolog/releases/latest",
            "plugin.program.loiolog",
        )
    elif sel == 1:
        xbmcgui.Dialog().ok(
            _LOCALIZE(30202),
            "Download the ZIP from:\n"
            "github.com/loioloio/loiolog/releases\n\n"
            "In Kodi: Add-ons > Install from ZIP file.",
        )


def _flowfav_install():
    """Installs Flow FavManager from GitHub Releases."""
    _generic_github_installer(
        "Flow FavManager",
        "https://api.github.com/repos/loioloio/flowfav/releases/latest",
        "plugin.program.flowfavmanager",
    )


def _user_message_dialog():
    """Opens Kodi keyboard for the user to write a report or comment."""
    addon = xbmcaddon.Addon()
    existing_msg = addon.getSetting('user_message').strip()

    kb = xbmc.Keyboard(existing_msg, _LOCALIZE(30704))
    kb.doModal()

    if not kb.isConfirmed():
        return

    raw_msg = kb.getText().strip()
    new_msg = raw_msg[:150]

    # Warn the user if message was trimmed
    if len(raw_msg) > 150:
        continuar = xbmcgui.Dialog().yesno(
            _LOCALIZE(30205),
            "Your message exceeds 150 characters and will be trimmed.\n\n"
            "This is how it will reach the StreamNinja team:\n\n"
            "\"{0}...\"\n\n"
            "Save anyway?".format(new_msg[:80])
        )
        if not continuar:
            return

    addon.setSetting('user_message', new_msg)

    if new_msg:
        xbmcgui.Dialog().ok(
            _LOCALIZE(30206),
            "Your report has been saved and will be sent automatically\n"
            "to the StreamNinja team.\n\n"
            "[COLOR yellow]Note:[/COLOR] If you return here and delete the text,\n"
            "the report will also be deleted."
        )
    else:
        xbmcgui.Dialog().ok(
            _LOCALIZE(30207),
            "You have left the message blank.\n"
            "The report has been removed."
        )


def _show_telemetry_info():
    """Shows detailed information about the anonymous report and allows sending it."""
    plot_text = (
        'Anonymously sends the addon identifier and version, Kodi version, operating system, and last connection date (to clean up inactive records). '
        'No IPs or personal data are stored. Only a random identifier (UUID) to avoid counting the same installation twice, along with the optional "Send Report" message. This helps plan updates and support. '
        'Do you want to send the report right now?'
    )
    confirm = xbmcgui.Dialog().yesno(
        _LOCALIZE(30208),
        plot_text,
        nolabel=_LOCALIZE(31313),
        yeslabel="Send now"
    )
    if confirm:
        import stats
        old_sync = stats._load_data().get('last_sync', 0)
        result = {}

        def _worker():
            try:
                stats._do_ping()
                result['done'] = True
            except Exception as e:
                result['error'] = str(e)

        t = threading.Thread(target=_worker, daemon=True)
        t.start()

        dp = xbmcgui.DialogProgress()
        dp.create(_LOCALIZE(30000), 'Sending anonymous report...')
        pct = 0
        while t.is_alive():
            if dp.iscanceled():
                break
            pct = min(95, pct + 5)
            dp.update(pct)
            xbmc.sleep(150)
        dp.close()

        new_sync = stats._load_data().get('last_sync', 0)
        if new_sync > old_sync:
            xbmcgui.Dialog().ok(_LOCALIZE(30208), "The report has been successfully sent to the project servers.")
        else:
            xbmcgui.Dialog().ok(_LOCALIZE(30208), "Could not send report. Check your network connection or try again later.")


# --- My Downloads ---

def _show_downloads():
    """Generates the visual directory of local downloads.

    Shows a link to Elementum (if installed), the history of
    downloaded files with existence checks on disk, and a legal disclaimer at the end.
    """
    import download_manager

    h = url_player._get_handle()
    url_base = sys.argv[0]

    # History of own downloads
    downloads = download_manager.get_downloads()
    if not downloads:
        li = xbmcgui.ListItem(label=_LOCALIZE(30123))
        li.setArt({"icon": "DefaultIconInfo.png"})
        li.setInfo("video", {
            "plot": "When you download a video, it will appear here.\n"
                    "Use Open URL > Download to save content.",
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url=url_player._u(action="noop"), listitem=li, isFolder=False,
        )
    else:
        for entry in downloads:
            file_path = entry.get("path", "")
            title = entry.get("title", "Untitled")
            date = entry.get("date", "")
            file_exists = os.path.exists(file_path)

            if file_exists:
                label = "{0} ({1})".format(title, date)
            else:
                label = "[COLOR grey][DELETED][/COLOR] {0}".format(title)

            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": "DefaultVideo.png"})
            li.setInfo("video", {
                "title": title,
                "plot": "File: {0}\nDownloaded on: {1}".format(
                    file_path, date),
            })

            # Context menu
            cm = [
                ("Remove from history",
                 "RunPlugin({0}?action=remove_download&dl_path={1})".format(
                     url_base,
                     urllib.parse.quote(file_path, safe=""))),
            ]
            if file_exists:
                li.setProperty("IsPlayable", "true")
                cm.append(
                    ("[COLOR red]DELETE FILE FROM DISK[/COLOR]",
                     "RunPlugin({0}?action=delete_download_file"
                     "&dl_path={1}&title={2})".format(
                          url_base,
                          urllib.parse.quote(file_path, safe=""),
                          urllib.parse.quote(title, safe=""))))

            li.addContextMenuItems(cm)
            # File present -> playable path (IsPlayable marked above).
            # File deleted -> noop: clicking does nothing instead of trying to open
            # an empty path (prevents "Playback failed" error and navigation to "").
            play_url = file_path if file_exists else url_player._u(action="noop")
            xbmcplugin.addDirectoryItem(
                handle=h, url=play_url, listitem=li, isFolder=False,
            )

    xbmcplugin.endOfDirectory(h)


def _delete_download_file(file_path, title):
    """Deletes a downloaded file from disk and history.

    Asks for explicit user confirmation before deleting to
    prevent accidental data loss.
    """
    import download_manager

    display_title = title or "Untitled"
    display_path = file_path or ""

    if not display_path:
        return

    confirmed = xbmcgui.Dialog().yesno(
        "Delete File",
        "You are about to delete this file from disk:\n\n"
        "[B]{0}[/B]\n\n"
        "This action is irreversible.".format(display_title),
    )
    if not confirmed:
        return

    try:
        if os.path.exists(display_path):
            os.remove(display_path)
            download_manager.remove_download(display_path)
            xbmcgui.Dialog().notification(
                _LOCALIZE(30000), _LOCALIZE(30151),
                xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().ok(
                "StreamNinja",
                "The file no longer exists at that path.")
            download_manager.remove_download(display_path)
    except Exception as exc:
        xbmcgui.Dialog().ok(
            "StreamNinja",
            "Could not delete:\n{0}".format(str(exc)[:200]))

    xbmc.executebuiltin("Container.Refresh")


# --- Advanced Menu Visual Builder ---

def advanced_menu():
    h = url_player._get_handle()
    url_base = sys.argv[0]

    if xbmc.getCondVisibility(
        "System.Platform.Windows | System.Platform.Linux | "
        "System.Platform.OSX"
    ):
        li = xbmcgui.ListItem("[COLOR white]" + _LOCALIZE(30125) + "[/COLOR]")
        li.setArt({"icon": os.path.join(_MEDIA, "adv_ytdlp.png")})
        li.setInfo("video", {
            "plot": "Instructions for installing yt-dlp on your PC,\n"
                    "current status diagnosis, and copying\n"
                    "commands to clipboard.",
        })
        xbmcplugin.addDirectoryItem(
            h, "{0}?action=ytdlp_menu".format(url_base), li, False,
        )

    if xbmc.getCondVisibility("System.HasAddon(plugin.program.loiolog)"):
        li = xbmcgui.ListItem("[COLOR white]" + _LOCALIZE(31320) + "[/COLOR]")
        li.setArt({"icon": os.path.join(_MEDIA, "adv_log.png")})
        li.setInfo("video", {
            "plot": "Advanced tool to view and filter\n"
                    "the Kodi log. Press to open.",
        })
        xbmcplugin.addDirectoryItem(
            h, "{0}?action=open_loiolog".format(url_base), li, False,
        )
    else:
        li = xbmcgui.ListItem("[COLOR white]" + _LOCALIZE(31321) + "[/COLOR]")
        li.setArt({"icon": os.path.join(_MEDIA, "adv_log.png")})
        li.setInfo("video", {
            "plot": "Tool to diagnose problems.\n"
                    "Press to install from GitHub.",
        })
        xbmcplugin.addDirectoryItem(
            h, "{0}?action=loiolog_install".format(url_base), li, False,
        )

    if _is_repo_installed():
        li = xbmcgui.ListItem(_LOCALIZE(31318))
    else:
        li = xbmcgui.ListItem(_LOCALIZE(31319))
    li.setArt({"icon": "DefaultAddonRepository.png"})
    li.setInfo("video", {
        "plot": "Verify that the repository is linked\n"
                "to receive automatic updates.",
    })
    xbmcplugin.addDirectoryItem(
        h, "{0}?action=check_repo_status".format(url_base), li, False,
    )

    addon = xbmcaddon.Addon()
    existing_msg = addon.getSetting('user_message').strip()
    msg_label = (
        _LOCALIZE(31316) if existing_msg else _LOCALIZE(31315)
    )
    li = xbmcgui.ListItem(msg_label)
    li.setArt({"icon": "DefaultAddonContextItem.png"})
    li.setInfo("video", {
        "plot": "Report a problem or leave a comment (max. 150 characters)\n"
                "that will reach the StreamNinja team directly.\n"
                "Ideal for errors or feedback.",
    })
    xbmcplugin.addDirectoryItem(
        h, "{0}?action=user_message_dialog".format(url_base), li, False,
    )

    li = xbmcgui.ListItem(label=_LOCALIZE(31317))
    icon_path = os.path.join(_MEDIA, 'settings_enable_telemetry.png')
    if not os.path.exists(icon_path):
        icon_path = os.path.join(_MEDIA, 'opciones.png')
    li.setArt({'icon': icon_path})
    plot_text = (
        'Anonymously sends the addon identifier and version, Kodi version, '
        'operating system, and last connection date (to clean up inactive records).\n\n'
        'No IPs or personal data are stored. Only a random identifier (UUID) '
        'to avoid counting the same installation twice, along with the optional '
        '"Send Report" message. This helps plan updates and support.'
    )
    li.setInfo('video', {'plot': plot_text})
    xbmcplugin.addDirectoryItem(
        h, "{0}?action=show_telemetry_info".format(url_base), li, False,
    )

    xbmcplugin.endOfDirectory(h)


def _parse_qs(qs):
    _seed = "cnViZW5zZGZhMWxhYmVybnQ="
    return dict(urllib.parse.parse_qsl(qs))


def _ensure_disclaimer_file(addon):
    """Generates an AVISO_CREDENCIALES.txt file in the addon configuration folder (legal CYA)."""
    try:
        prof = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        os.makedirs(prof, exist_ok=True)
        disc_path = os.path.join(prof, "AVISO_CREDENCIALES.txt")
        if not os.path.exists(disc_path):
            with open(disc_path, "w", encoding="utf-8") as f:
                f.write(
                    "*** IMPORTANT WARNING ABOUT THE USE OF CREDENTIALS ***\n\n"
                    "StreamNinja developers DO NOT promote, facilitate, or approve\n"
                    "the sharing of tokens, accounts, or credentials from third-party services.\n\n"
                    "The login functionality of this addon has been developed\n"
                    "EXCLUSIVELY for strictly personal use. Its purpose is to allow\n"
                    "legitimate users to enjoy content to which they have a legal right\n"
                    "within the Kodi interface.\n\n"
                    "Any extraction, copying, distribution, or sharing of the files\n"
                    "in this folder (including 'auth_vault.json') with third parties is\n"
                    "the sole and exclusive responsibility of the user, and goes against the project's philosophy.\n\n"
                    "Technical clarification: Credentials are saved in plain text because Kodi is unable\n"
                    "to read encrypted files. If there were any way to encrypt\n"
                    "credentials, it would have been done without hesitation.\n\n"
                    "StreamNinja does not store credentials on external servers and is not\n"
                    "responsible for the misuse of the tools provided here.\n"
                )
    except Exception:
        pass


def main():
    addon = xbmcaddon.Addon()
    global _BOLD_ENABLED, _ACC_COLOR_MODE, _ACC_STRIP_SYMBOLS
    _BOLD_ENABLED = addon.getSetting('bold_labels') != 'false'
    _raw_color = addon.getSetting('acc_color_mode')
    _ACC_COLOR_MODE = _acc_color_index_to_key(_raw_color)
    # Migration: old versions saved the key ('hc_dark'); the native enum
    # expects an index. We rewrite once to keep both consistent.
    if _raw_color and not _raw_color.isdigit():
        addon.setSetting('acc_color_mode', str(_ACC_COLOR_KEYS.index(_ACC_COLOR_MODE)))
    _ACC_STRIP_SYMBOLS = addon.getSetting('acc_strip_symbols') == 'true'
    _ensure_disclaimer_file(addon)

    stats.ping()
    qs = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = _parse_qs(qs)
    action = params.get("action", "")

    try:
        if not action or action == "url_dialog":
            url_player.open_url_dialog()
        elif action == "url_input":
            url_player.url_input()
        elif action == "url_play_clipboard":
            try:
                win = xbmcgui.Window(10000)
                clipboard_url = win.getProperty("streamninja.clipboard.url").strip()
                if clipboard_url:
                    url_player.play_url_action(clipboard_url)
                else:
                    xbmcgui.Dialog().notification(_LOCALIZE(30000), _LOCALIZE(30154), xbmcgui.NOTIFICATION_WARNING)
            except Exception as e:
                xbmc.log("[StreamNinja] Error reading clipboard: {0}".format(e), xbmc.LOGWARNING)
        elif action == "url_clipboard_clear":
            try:
                win = xbmcgui.Window(10000)
                win.clearProperty("streamninja.clipboard.url")

                xbmc.executebuiltin("Container.Refresh")
                xbmcgui.Dialog().notification(_LOCALIZE(30000), _LOCALIZE(30153), xbmcgui.NOTIFICATION_INFO, 1500)
            except Exception as e:
                xbmc.log("[StreamNinja] Error clearing clipboard: {0}".format(e), xbmc.LOGWARNING)
        elif action == "url_remote":
            url_remote.start_remote()
        elif action == "url_scan":
            url_player.scan_videos_dialog()
        elif action == "scan_history":
            url_player.scan_history_menu()
        elif action == "scan_url":
            url = params.get("url")
            if url:
                url_player._run_scan(url)
        elif action == "scan_history_remove":
            url = params.get("url")
            if url:
                url_player._remove_from_scan_history(url)
                xbmc.executebuiltin("Container.Refresh")
        elif action == "scan_history_clear":
            url_player._clear_scan_history()
            xbmc.executebuiltin("Container.Refresh")
        elif action == "url_history":
            url_player.url_history_menu()
        elif action == "url_bookmarks":
            url_player.url_bookmarks_menu()
        elif action in ("url_bookmark_add", "url_bookmark_save_from_history"):
            url = params.get("url")
            if url:
                url_player.bookmark_save_from_history(url)
        elif action in ("url_bookmark_remove", "url_bookmark_delete"):
            url = params.get("url")
            if url:
                url_player.bookmark_delete(url)
        elif action == "url_bookmark_rename":
            url = params.get("url")
            if url:
                url_player.bookmark_rename(url)
        elif action in ("history_clear", "url_history_clear"):
            url_player.history_clear()
        elif action in ("history_remove", "url_history_remove"):
            url = params.get("url")
            if url:
                url_player.history_remove(url)
        elif action == "url_play":
            url = params.get("url")
            if url:
                url_player.play_url_action(url)
        elif action == "acestream":
            # Entry point compatible with Horus: play&id/url/infohash from Horus
            # maps to action=acestream&... in StreamNinja. Allows other addons to call
            # StreamNinja with the same pattern without colliding with Horus.
            url_player.play_acestream(
                content_id=params.get("id"),
                ace_url=params.get("url"),
                infohash=params.get("infohash"),
                title=params.get("title", ""),
                icon=params.get("iconimage", ""),
                plot=params.get("plot", ""),
            )
        elif action == "url_download":
            url = params.get("url", "")
            if url:
                url_player._resolve_and_download(url)
        elif action == "api_resolve":
            url = params.get("url")
            if url:
                url_player.api_resolve_action(url)
        elif action == "pv":
            url = params.get("vid") or params.get("url")
            if url:
                url_player.play_url_action(url)
        elif action == "copy_url":
            url = params.get("url")
            if url:
                xbmcgui.Window(10000).setProperty("streamninja.clipboard.url", url)
                xbmcgui.Dialog().notification(_LOCALIZE(30000), _LOCALIZE(30152), xbmcgui.NOTIFICATION_INFO, 1500)

        elif action == "open_settings":
            _settings_menu()
        elif action == "open_settings_native":
            xbmcaddon.Addon("plugin.video.streamninja").openSettings()
            xbmc.executebuiltin("Container.Refresh")
        elif action == "settings_remote_menu":
            _settings_remote_menu()
        elif action == "settings_downloads_menu":
            _settings_downloads_menu()
        elif action == "settings_acestream_menu":
            _settings_acestream_menu()
        elif action == "settings_general_menu":
            _settings_general_menu()
        elif action == "settings_toggle":
            _settings_toggle(params.get("setting_id", ""), params.get("name", ""))
        elif action == "settings_set_enum":
            _settings_set_enum(params.get("setting_id", ""), params.get("name", ""))
        elif action == "settings_input":
            _settings_input(
                params.get("setting_id", ""), params.get("name", ""),
                params.get("input_type", "text"),
                params.get("min_val"), params.get("max_val"), params.get("step"),
            )
        elif action == "advanced_menu":
            advanced_menu()


        elif action == "check_repo_status":
            _check_repo_status()
        elif action == "loiolog_install":
            _loiolog_install()
        elif action == "open_loiolog":
            xbmc.executebuiltin("RunAddon(plugin.program.loiolog)")
        elif action == "flowfav_install":
            _flowfav_install()
        elif action == "ytdlp_menu":
            _ytdlp_menu()
        elif action == "user_message_dialog":
            _user_message_dialog()
        elif action == "show_telemetry_info":
            _show_telemetry_info()
        elif action == "open_flowfav":
            xbmc.executebuiltin(
                "RunAddon(plugin.program.flowfavmanager)")

        # --- My Downloads ---
        elif action == "show_downloads":
            _show_downloads()
        elif action == "remove_download":
            import download_manager
            dl_path = params.get("dl_path", "")
            if dl_path:
                download_manager.remove_download(dl_path)
                xbmc.executebuiltin("Container.Refresh")
        elif action == "delete_download_file":
            _delete_download_file(
                params.get("dl_path", ""),
                params.get("title", ""))

        # --- Debrid (cloud) ---
        elif action == "debrid_config":
            _debrid_config_menu()
        elif action == "debrid_set_provider":
            _debrid_set_provider()
        elif action == "debrid_authorize_pin":
            _debrid_authorize_pin()
        elif action == "debrid_authorize_key":
            _debrid_authorize_key()
        elif action == "debrid_account":
            _debrid_account()
        elif action == "debrid_deauthorize":
            _debrid_deauthorize()
        elif action == "debrid_toggle_enabled":
            _debrid_toggle_enabled()
        elif action == "debrid_toggle_cached":
            _debrid_toggle_setting("debrid_cached_only")
        elif action == "debrid_toggle_cleanup":
            _debrid_toggle_setting("debrid_auto_cleanup")
        elif action == "debrid_toggle_quality":
            _debrid_toggle_setting("debrid_auto_quality")
        elif action == "debrid_library":
            url_player.debrid_library_menu()
        elif action == "debrid_library_files":
            url_player.debrid_library_files(params.get("id"))
        elif action == "debrid_library_play":
            url_player.debrid_library_play(params.get("id"), params.get("file"))
        elif action == "debrid_library_delete":
            url_player.debrid_library_delete(params.get("id"))
        elif action == "debrid_download":
            url_player.debrid_download(params.get("id"), params.get("title", ""))

        # --- Live HLS Recorder ---
        elif action == "pvr_record":
            url_player.record_stream_dialog()
        elif action == "pvr_record_stop":
            url_player.stop_recordings()

        elif action == "accessibility_menu":
            _accessibility_menu()
        elif action == "acc_toggle_bold":
            _acc_toggle_bold()
        elif action == "acc_set_color_mode":
            _acc_set_color_mode()
        elif action == "acc_toggle_symbols":
            _acc_toggle_symbols()
        elif action == "noop":
            pass  # informative item only, no action
        else:
            # Unknown action (old or tampered URL): close directory,
            # or Kodi stays with spinning wheel waiting for endOfDirectory.
            xbmc.log("[StreamNinja] Unknown action: {0}".format(action), xbmc.LOGWARNING)
            h = url_player._get_handle()
            if h >= 0:
                xbmcplugin.endOfDirectory(h, succeeded=False)

    except Exception as e:
        xbmc.log("[StreamNinja] Error in default.py routing: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            _LOCALIZE(30000), _LOCALIZE(30155),
            xbmcgui.NOTIFICATION_ERROR, 4000)
        # If action was a directory action, close it as failed to not hang the
        # menu. In RunPlugin handle is -1 and is omitted (no directory to close).
        h = url_player._get_handle()
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)


# --- DEBRID CONFIGURATION (cloud: AllDebrid / Real-Debrid / TorBox / Premiumize) ---

def _debrid_reset_instance():
    try:
        import debrid_resolver
        debrid_resolver.reset_resolver()
    except Exception:
        pass


def _debrid_config_menu():
    """Configuration menu for the Debrid resolver: status, provider, account linking,
    and behavior options."""
    addon = xbmcaddon.Addon()
    h = url_player._get_handle()
    provider = addon.getSetting("debrid_provider") or "AllDebrid"
    enabled = addon.getSetting("debrid_enabled") == "true"

    authorized = False
    user = ""
    supports_pin = True
    try:
        import debrid_resolver
        r = debrid_resolver.get_resolver()
        authorized = r.is_authorized()
        user = r.stored_user()
        supports_pin = r.SUPPORTS_PIN
    except Exception:
        pass

    def _add(label, action, plot="", icon="info.png"):
        # A color at the start wraps the entire button (action) -> to white.
        # A color in the middle only tints the value (status/provider) -> respected.
        if label.startswith("[COLOR"):
            label = re.sub(r"\[/?COLOR[^\]]*\]", "", label)
        li = xbmcgui.ListItem(label="[COLOR white]{0}[/COLOR]".format(label))
        icon_path = os.path.join(_MEDIA, icon)
        li.setArt({"icon": icon_path, "thumb": icon_path})
        if plot:
            li.setInfo("video", {"plot": plot})
        # action="" -> informational item only; "noop" prevents Kodi from trying
        # to play an empty path (CVideoPlayer::OpenInputStream - error opening []).
        url = url_player._u(action=action) if action else url_player._u(action="noop")
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    yes_tag = _LOCALIZE(31211)
    no_tag = _LOCALIZE(31212)

    if authorized:
        estado = "[COLOR lime]{0}{1}[/COLOR]".format(provider, " - " + user if user else "")
        estado_action = "debrid_account"
        estado_plot = _LOCALIZE(31261) + ". Press to view status and available traffic."
    else:
        estado = "[COLOR gray]" + _LOCALIZE(31262) + "[/COLOR]"
        estado_action = "debrid_authorize_pin" if supports_pin else "debrid_authorize_key"
        estado_plot = "No account linked. Press to link your {0} account.".format(provider)
    _add(_LOCALIZE(30800).format(estado), estado_action, estado_plot, icon="adv_usuario.png")

    en_label = _LOCALIZE(31209) if enabled else _LOCALIZE(31210)
    _add(_LOCALIZE(30801).format(en_label), "debrid_toggle_enabled",
         "If enabled, premium magnets and hoster links are resolved "
         "with your account before the normal method.",
         icon="url_cloud.png")

    _add(_LOCALIZE(30802).format(provider), "debrid_set_provider",
         "Debrid service to use: AllDebrid, Real-Debrid, TorBox, or Premiumize.",
         icon="catalogo.png")

    if not authorized:
        if supports_pin:
            _add(_LOCALIZE(30803), "debrid_authorize_pin",
                 "Shows a code to enter on the provider website and links "
                 "your account automatically.",
                 icon="loiolink.png")
        _add(_LOCALIZE(30804), "debrid_authorize_key",
             "Paste the API key of your account (you can find it on the provider website).",
             icon="url_config.png")
    else:
        _add(_LOCALIZE(30805), "debrid_account",
             "Check your account status (premium, expiration).",
             icon="bt_ranking.png")
        _add(_LOCALIZE(30806), "debrid_deauthorize",
             "Removes the linked account from this addon.",
             icon="adv_borrar.png")

    cached = addon.getSetting("debrid_cached_only") == "true"
    _add(_LOCALIZE(30807).format(yes_tag if cached else no_tag),
        "debrid_toggle_cached",
        "If enabled, a magnet that is not already in the cloud is skipped.",
        icon="adv_cache.png")

    cleanup = addon.getSetting("debrid_auto_cleanup") == "true"
    _add(_LOCALIZE(30808).format(yes_tag if cleanup else no_tag),
        "debrid_toggle_cleanup",
        "Deletes the torrent from the cloud automatically after playback ends.",
        icon="adv_limpieza.png")

    quality = addon.getSetting("debrid_auto_quality") == "true"
    _add(_LOCALIZE(30809).format(yes_tag if quality else no_tag),
        "debrid_toggle_quality",
        "In Debrid torrents or folders with multiple files, automatically plays "
        "the largest video file (highest quality) without asking.",
        icon="adv_hd.png")

    xbmcplugin.endOfDirectory(h)


def _debrid_set_provider():
    opciones = ["AllDebrid", "Real-Debrid", "TorBox", "Premiumize"]
    cur = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
    pre = opciones.index(cur) if cur in opciones else 0
    sel = xbmcgui.Dialog().select(_LOCALIZE(30251) + " Provider", opciones, preselect=pre)
    if sel < 0:
        return
    xbmcaddon.Addon().setSetting("debrid_provider", opciones[sel])
    _debrid_reset_instance()
    xbmcaddon.Addon().setSetting("debrid_hosts_cache", "")  # invalidates hosts from previous provider
    xbmc.executebuiltin("Container.Refresh")


def _debrid_authorize_pin():
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_pin()
    except Exception as e:
        xbmcgui.Dialog().ok(_LOCALIZE(30251), "Error linking account:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification(
            _LOCALIZE(30251), _LOCALIZE(31261), xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")


def _debrid_authorize_key():
    key = xbmcgui.Dialog().input(_LOCALIZE(30707))
    if not key:
        return
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_apikey(key)
    except Exception as e:
        xbmcgui.Dialog().ok(_LOCALIZE(30251), "Error:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification(
            _LOCALIZE(30251), _LOCALIZE(31261), xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")


def _debrid_deauthorize():
    if not xbmcgui.Dialog().yesno(_LOCALIZE(30251), _LOCALIZE(31103)):
        return
    try:
        import debrid_resolver
        debrid_resolver.get_resolver().deauthorize()
    except Exception:
        pass
    _debrid_reset_instance()
    xbmcgui.Dialog().notification(
        _LOCALIZE(30251), _LOCALIZE(31262), xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def _debrid_account():
    import debrid_resolver
    try:
        info = debrid_resolver.get_resolver().account_info()
    except debrid_resolver.DebridNetworkError as e:
        xbmc.log("[StreamNinja] debrid account (network): {0}".format(e), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            _LOCALIZE(30251), "Could not contact service.\nCheck your internet connection.")
        return
    except Exception as e:
        xbmcgui.Dialog().ok(_LOCALIZE(30251), "Could not query account:\n{0}".format(e))
        return
    lineas = [
        "User: {0}".format(info.get("username", "?")),
        "Status: {0}".format("Premium" if info.get("premium") else "Not premium"),
    ]
    expiry = info.get("expiry_text") or ""
    if expiry:
        days = info.get("days")
        dtxt = " ({0} days)".format(days) if isinstance(days, int) else ""
        lineas.append("Valid until: {0}{1}".format(expiry, dtxt))
    extra = info.get("extra") or ""
    if extra:
        lineas.append(extra)
    xbmcgui.Dialog().ok(_LOCALIZE(30210), "\n".join(lineas))


def _debrid_toggle_enabled():
    addon = xbmcaddon.Addon()
    if addon.getSetting("debrid_enabled") == "true":
        addon.setSetting("debrid_enabled", "false")
        xbmcgui.Dialog().notification(
            _LOCALIZE(30251), _LOCALIZE(31259), xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        return
    if addon.getSetting("debrid_disclaimer_seen") != "true":
        if not xbmcgui.Dialog().yesno(
            _LOCALIZE(30211),
            "The resolver uses YOUR Debrid account to play links and magnets "
            "that YOU provide.\n\n"
            "You are responsible for the content you access and for complying with the law of your "
            "country and terms of your Debrid service.\n\n"
            "Activate the Debrid Resolver?",
        ):
            return
        addon.setSetting("debrid_disclaimer_seen", "true")
    addon.setSetting("debrid_enabled", "true")
    xbmcgui.Dialog().notification(
        _LOCALIZE(30251), _LOCALIZE(31260), xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")


def _debrid_toggle_setting(key):
    """Inverts a boolean Debrid setting (cached_only / auto_cleanup / auto_quality)."""
    addon = xbmcaddon.Addon()
    addon.setSetting(key, "false" if addon.getSetting(key) == "true" else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")


if __name__ == "__main__":
    main()

