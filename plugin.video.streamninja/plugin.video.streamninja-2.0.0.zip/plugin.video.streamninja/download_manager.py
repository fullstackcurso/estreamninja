# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.
"""
Manages the addon's local downloads history.

Stores a persistent registry in ``downloads_history.json`` inside
the addon's profile directory (``special://profile/``). Entries
are kept in reverse chronological order and are limited to a
configurable maximum to prevent uncontrolled growth.
"""
import json
import os
import threading
import time

import xbmcaddon
import xbmcvfs

# Limit of entries stored in the history.
_MAX_ENTRIES = 50

# Serializes the read-modify-write cycle of the history. Covers concurrency
# within the same process; between separate RunPlugin invocations the last
# write wins, acceptable for a history (not critical data).
_LOCK = threading.Lock()

# Path to the history JSON (created on demand).
_HISTORY_FILE = None


def _get_history_path():
    """Returns the absolute path to the history file.

    Creates the profile directory if it does not exist yet.
    """
    global _HISTORY_FILE
    if _HISTORY_FILE is None:
        profile = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile"))
        # exist_ok=True: the module's _LOCK does not cover RunPlugin invocations in
        # separate processes, which could pass exists() at the same time and clash.
        os.makedirs(profile, exist_ok=True)
        _HISTORY_FILE = os.path.join(profile, "downloads_history.json")
    return _HISTORY_FILE


def get_downloads():
    """Reads the downloads history and returns a list of dicts.

    Each entry contains the keys ``title``, ``path``, ``source``
    and ``date``. If the file does not exist or is corrupt, returns
    an empty list without propagating exceptions.
    """
    path = _get_history_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, list):
            return []
        return data
    except (json.JSONDecodeError, IOError, OSError):
        return []


def log_download(title, file_path, source=""):
    """Registers a new download at the beginning of the history.

    Args:
        title:     Readable title of the downloaded content.
        file_path: Absolute path to the file saved on disk.
        source:    Identifier of the engine used (``MP4``, ``HLS``,
                   ``YT-DLP``).
    """
    entry = {
        "title": str(title),
        "path": str(file_path),
        "source": str(source),
        "date": time.strftime("%d/%m/%Y %H:%M"),
    }
    with _LOCK:
        downloads = get_downloads()
        downloads.insert(0, entry)
        downloads = downloads[:_MAX_ENTRIES]
        _save(downloads)


def remove_download(file_path):
    """Removes all entries whose path matches from the history.

    Does not touch the physical file on disk; only updates the JSON.
    """
    with _LOCK:
        downloads = get_downloads()
        filtered = [d for d in downloads if d.get("path") != file_path]
        _save(filtered)


def _save(data):
    """Writes the list of downloads to the JSON file atomically."""
    path = _get_history_path()
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except (IOError, OSError):
        # Direct attempt if rename fails (e.g. unsupported fs). The .tmp remains
        # orphan: valid data goes to 'path', so it is discarded.
        try:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False)
        except (IOError, OSError):
            pass
        try:
            os.remove(tmp)
        except OSError:
            pass
