# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.
"""
Dailymotion resolver for StreamNinja.
"""
import re
from urllib.parse import quote, urljoin
import xbmc
try:
    import requests
except ImportError:
    requests = None

_HEADERS_DM_DESKTOP = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}

def _log_error(msg):
    xbmc.log("[StreamNinja] " + str(msg), xbmc.LOGERROR)

def _fetch_master_text(url, headers, timeout=15):
    """Text of Dailymotion's master HLS. The direct way with Kodi's old urllib3
    sometimes receives a 403 on the CDN; if it fails, it retries with a 'warmed-up'
    Session that first visits dailymotion.com to obtain cookies
    (ts_e/dmvk/__qca). Devuelve el texto o None."""
    if not requests:
        return None
    try:
        r = requests.get(url, headers=headers, timeout=timeout)
        if r.status_code == 200 and r.text:
            return r.text
        xbmc.log("[StreamNinja] DM direct master status={0}".format(r.status_code), xbmc.LOGWARNING)
    except Exception as exc:
        _log_error("DM direct master: {0}".format(exc))
    try:
        s = requests.Session()
        s.get("https://www.dailymotion.com/", headers=headers, timeout=timeout)
        r = s.get(url, headers=headers, timeout=timeout)
        if r.status_code == 200 and r.text:
            xbmc.log("[StreamNinja] DM master via cookie warmup OK", xbmc.LOGINFO)
            return r.text
        xbmc.log("[StreamNinja] DM master warmup status={0}".format(r.status_code), xbmc.LOGWARNING)
    except Exception as exc:
        _log_error("DM master warmup: {0}".format(exc))
    return None


def _fetch_hls_variants(master_url, headers=None):
    """Descarga un master playlist HLS y devuelve las variantes ordenadas por ancho de banda."""
    if not requests:
        return []
    variants = []
    req_headers = headers if headers else {}
    try:
        text = _fetch_master_text(master_url, req_headers)
        if not text:
            return variants

        lines = text.strip().splitlines()
        
        current_label = "unknown"
        current_bw = 0
        expecting_url = False
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            if line.startswith('#EXT-X-STREAM-INF'):
                res_match = re.search(r'RESOLUTION=(\d+x\d+)', line)
                bw_match = re.search(r'BANDWIDTH=(\d+)', line)
                current_label = res_match.group(1) if res_match else "unknown"
                current_bw = int(bw_match.group(1)) if bw_match else 0
                expecting_url = True
            elif expecting_url and not line.startswith('#'):
                stream_url = line
                if not stream_url.startswith('http'):
                    stream_url = urljoin(master_url, stream_url)
                variants.append({'label': current_label, 'url': stream_url, 'bandwidth': current_bw})
                expecting_url = False
                
        variants.sort(key=lambda x: x.get('bandwidth', 0), reverse=True)
    except Exception as exc:
        _log_error("HLS variants lookup error: {0}".format(exc))
    return variants


def _dm_play_direct(vid, max_quality=1080):
    if not requests:
        return None
    if not isinstance(vid, str) or not vid.strip():
        return None
        
    vid_safe = quote(vid.strip())
    try:
        meta_url = "https://www.dailymotion.com/player/metadata/video/{0}".format(vid_safe)
        r = requests.get(meta_url, headers=_HEADERS_DM_DESKTOP, timeout=15)
        if r.status_code != 200:
            return None
            
        data = r.json()
        if data.get("error"):
            return None

        qualities = data.get("qualities", {})
        subtitles = []
        subs_data = data.get("subtitles", {})
        if isinstance(subs_data, dict):
            for lang, sub_list in subs_data.items():
                if isinstance(sub_list, list):
                    for sub in sub_list:
                        if isinstance(sub, dict) and sub.get("url"):
                            subtitles.append(sub.get("url"))

        best_mp4 = None
        best_res = 0
        for res_key, formats in qualities.items():
            if res_key == "auto":
                continue
            try:
                res_val = int(res_key)
            except (ValueError, TypeError):
                continue
                
            if res_val > max_quality:
                continue
                
            for fmt in formats:
                if isinstance(fmt, dict) and fmt.get("type") == "video/mp4" and res_val > best_res:
                    best_mp4 = fmt.get("url")
                    best_res = res_val
                    
        if best_mp4:
            return {"url": best_mp4, "mime": "video/mp4", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}

        hls_url = None
        if "auto" in qualities:
            for item in qualities["auto"]:
                if isinstance(item, dict) and item.get("type") == "application/x-mpegURL":
                    hls_url = item.get("url")
                    break
                    
        if hls_url:
            variants = _fetch_hls_variants(hls_url, headers=_HEADERS_DM_DESKTOP)
            if variants:
                filtered = []
                for v in variants:
                    label = v.get("label", "")
                    try:
                        height = int(label.split("x")[1].split(" ")[0]) if "x" in label else 0
                    except (ValueError, IndexError):
                        height = 0
                    if height > 0 and height <= max_quality:
                        filtered.append(v)
                target = filtered[0] if filtered else variants[-1]
                return {"url": target["url"], "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}
            return {"url": hls_url, "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}
    except Exception as exc:
        _log_error("_dm_play_direct error: {0}".format(exc))
    return None

_DM_SYSPY_SCRIPT = r'''
import sys, json, re
try:
    import requests
    _GET = lambda u, h: requests.get(u, headers=h, timeout=15)
    _STATUS = lambda r: r.status_code
    _TEXT = lambda r: r.text
except ImportError:
    import urllib.request
    def _GET(u, h):
        return urllib.request.urlopen(urllib.request.Request(u, headers=h), timeout=15)
    _STATUS = lambda r: r.getcode()
    _TEXT = lambda r: r.read().decode()
vid = sys.argv[1]
hdr = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin":"https://www.dailymotion.com","Referer":"https://www.dailymotion.com/"}
r = _GET("https://www.dailymotion.com/player/metadata/video/"+vid, hdr)
if _STATUS(r) != 200:
    sys.exit(1)
data = json.loads(_TEXT(r))
if data.get("error"):
    sys.exit(2)
hls = ""
for it in data.get("qualities",{}).get("auto",[]):
    if it.get("type") == "application/x-mpegURL":
        hls = it.get("url",""); break
if not hls:
    sys.exit(3)
r2 = _GET(hls, hdr)
if _STATUS(r2) != 200:
    sys.exit(4)
master = _TEXT(r2)
m = re.findall(r"NAME=\"(\d+)\"[^\n]*\n([^\n]+)", master)
m.sort(key=lambda x: int(x[0]), reverse=True)
url = (m[0][1] if m else hls).split("#cell")[0]
print(json.dumps({"url": url}))
'''


def _dm_play_syspy(vid):
    """Resolves a Dailymotion video by launching the SYSTEM's Python (modern TLS),
    WITHOUT yt-dlp. Solves the DM 403 on Windows when Kodi's old urllib3 is
    blocked. Windows only; None if not applicable or fails. Returns {'url','mime'}."""
    if not xbmc.getCondVisibility("System.Platform.Windows"):
        return None
    if not isinstance(vid, str) or not re.match(r"^[A-Za-z0-9]{1,16}$", vid):
        return None
    try:
        import json
        import subprocess
        proc = subprocess.run(
            ["python", "-c", _DM_SYSPY_SCRIPT, vid],
            capture_output=True, text=True, timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
        )
        if proc.returncode == 0 and proc.stdout.strip():
            url = json.loads(proc.stdout).get("url", "")
            if url:
                xbmc.log(
                    "[StreamNinja] DM resolved with system Python (without yt-dlp)",
                    xbmc.LOGINFO,
                )
                return {"url": url, "mime": "application/x-mpegURL"}
        xbmc.log("[StreamNinja] DM syspy rc={0}".format(proc.returncode), xbmc.LOGWARNING)
    except FileNotFoundError:
        xbmc.log("[StreamNinja] DM syspy: python not found in PATH", xbmc.LOGWARNING)
    except Exception as exc:
        _log_error("DM syspy: {0}".format(exc))
    return None


def _dm_play(vid, dm_level=0, max_quality=1080, try_syspy=True):
    # Windows: the system's Python (modern TLS) resolves DM without yt-dlp and avoids the
    # 403 suffered by Kodi's old urllib3. If it fails (no python), the cascade continues.
    # try_syspy=False when the caller already tried on their own (do not repeat).
    if try_syspy:
        syspy = _dm_play_syspy(vid)
        if syspy:
            return syspy
    try:
        import dm_gujal
        if dm_level == 2:
            url, subs, mime = dm_gujal.play_dm_extreme(vid, max_quality=max_quality)
            if url: return {'url': url, 'subs': subs, 'mime': mime or 'application/x-mpegURL'}
        elif dm_level == 1:
            url, mime = dm_gujal.play_dm_basic(vid)
            if url: return {'url': url, 'mime': mime or 'application/x-mpegURL'}
        else:
            url, subs, mime = dm_gujal.play_dm_extreme(vid, max_quality=max_quality)
            if url: return {'url': url, 'subs': subs, 'mime': mime or 'application/x-mpegURL'}
            url, mime = dm_gujal.play_dm_basic(vid)
            if url: return {'url': url, 'mime': mime or 'application/x-mpegURL'}
    except Exception as exc:
        _log_error("dm_gujal play error: {0}".format(exc))

    result = _dm_play_direct(vid, max_quality=max_quality)
    if result:
        return result
    return None

def _dm_play_android(vid, dm_level=0, max_quality=1080):
    result = _dm_play_direct(vid, max_quality=max_quality)
    if not result or not result.get('url'):
        result = _dm_play(vid, dm_level=dm_level, max_quality=max_quality)

    if result is None:
        return None

    result.pop('headers', None)
    return result

