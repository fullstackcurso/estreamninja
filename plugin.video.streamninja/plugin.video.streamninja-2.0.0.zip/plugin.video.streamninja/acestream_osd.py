# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.
"""
P2P statistics HUD over the Kodi video player (window 12901),
equivalent to Horus OSD. Defensive design:

  - Single owner: a generation token protected by a lock. Each start() invalidates
    the previous thread, so playing two streams in a row does not leave two sets of
    controls hanging in the window.
  - The thread can NEVER break playback: everything runs inside try/except and controls
    are removed in finally (end of playback, Kodi shutdown, or generation handover).
  - No network usage while the OSD is hidden: stat_url is only polled when the user opens
    the video OSD. When not in use, it consumes nothing.

The background uses a tinted resources/media/white.png (standard Kodi trick: 1px white
texture + colorDiffuse), which always exists, instead of relying on skin textures.
"""
import os
import threading
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_VIDEO_OSD = 12901

_lock = threading.Lock()
_generation = 0  # the thread only acts while its generation remains active


def start(stat_url):
    """Starts the HUD for the session whose stat_url is passed. Invalidates any previous HUD
    (the generation token makes the previous thread exit and remove its controls)."""
    if not stat_url:
        return
    global _generation
    with _lock:
        _generation += 1
        my_gen = _generation
    threading.Thread(target=_run, args=(stat_url, my_gen), daemon=True).start()


def _media(name):
    return os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media", name)


def _skin_resolution():
    """(width, height) of the skin to anchor the panel to the top right in any resolution."""
    try:
        tree = ET.parse(xbmcvfs.translatePath("special://skin/addon.xml"))
        res = tree.find("./extension/res")
        if res is None:
            res = tree.find("./res")
        return int(res.attrib["width"]), int(res.attrib["height"])
    except Exception:
        return 1280, 720


class _Hud:
    def __init__(self):
        screen_w, _ = _skin_resolution()
        pw, ph = 380, 156
        x = max(0, screen_w - pw - 40)
        y = 60
        tx, tw = x + 20, pw - 40

        bg = xbmcgui.ControlImage(x, y, pw, ph, _media("white.png"))
        try:
            bg.setColorDiffuse("0xD90A0E14")
        except Exception:
            pass
        self.l_title = xbmcgui.ControlLabel(tx, y + 12, tw, 26, "StreamNinja · AceStream",
                                            textColor="0xFF22D3EE")
        self.l_status = xbmcgui.ControlLabel(tx, y + 46, tw, 24, "", textColor="0xFFFFFFFF")
        self.l_speed = xbmcgui.ControlLabel(tx, y + 76, tw, 24, "", textColor="0xFFFFFFFF")
        self.l_peers = xbmcgui.ControlLabel(tx, y + 106, tw, 24, "", textColor="0xFFFFFFFF")
        self._controls = [bg, self.l_title, self.l_status, self.l_speed, self.l_peers]

        self._win = xbmcgui.Window(_VIDEO_OSD)
        self._added = False

    def show(self):
        if self._added:
            return
        for c in self._controls:
            self._win.addControl(c)
        self._added = True

    def hide(self):
        if not self._added:
            return
        self._added = False
        for c in self._controls:
            try:
                self._win.removeControl(c)
            except Exception:
                pass

    def update(self, data):
        # Only metrics of verified unit: status, peers and speed_down (KB/s, as used by
        # the prebuffer). speed_up is shown if the engine provides it. We do not show totals
        # of download/upload because their unit in the API is not confirmed.
        status = data.get("status", "")
        peers = data.get("peers", 0)
        down = data.get("speed_down", 0)
        up = data.get("speed_up", 0)
        self.l_status.setLabel("Status: {0}".format(status or "—"))
        self.l_speed.setLabel(
            "[COLOR FF86EFAC]↓ {0} KB/s[/COLOR]    [COLOR FFFCA5A5]↑ {1} KB/s[/COLOR]".format(down, up))
        self.l_peers.setLabel("Peers: {0}".format(peers))


def _stats(stat_url):
    """GET stats reusing the player client; tolerates the {response:{}} wrapper."""
    import acestream_player
    raw = acestream_player._api_get(stat_url, timeout=3)
    if not isinstance(raw, dict):
        return {}
    inner = raw.get("response")
    return inner if isinstance(inner, dict) else raw


def _run(stat_url, my_gen):
    monitor = xbmc.Monitor()
    player = xbmc.Player()

    # Wait for the real AV start; starting the loop with isPlaying()==False would close it
    # immediately and the OSD would never be seen.
    for _ in range(150):  # ~30 s in 200 ms steps
        if my_gen != _generation or monitor.abortRequested():
            return
        if player.isPlaying():
            break
        if monitor.waitForAbort(0.2):
            return
    else:
        return  # the AV never started

    # File of OUR session; if it changes, another playback took over and we should not
    # leave the OSD on top (we don't compare against playback_url because Kodi can normalize it).
    try:
        our_file = player.getPlayingFile()
    except Exception:
        our_file = ""

    hud = None
    visible = False
    try:
        hud = _Hud()
        while my_gen == _generation and not monitor.abortRequested():
            if not player.isPlaying():
                break
            try:
                current = player.getPlayingFile()
            except Exception:
                current = ""
            if our_file and current and current != our_file:
                break
            osd_open = xbmc.getCondVisibility("Window.IsActive(videoosd)")
            if osd_open and not visible:
                hud.show()
                visible = True
            elif not osd_open and visible:
                hud.hide()
                visible = False
            if visible:
                hud.update(_stats(stat_url))
            if monitor.waitForAbort(1):
                break
    except Exception as e:
        xbmc.log("[StreamNinja/acestream_osd] {0}".format(e), xbmc.LOGWARNING)
    finally:
        if hud is not None:
            hud.hide()
