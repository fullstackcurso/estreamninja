# -*- coding: utf-8 -*-
# StreamNinja
# Created by RubénSDFA1laberot (github.com/fullstackcurso)
# License: GPL-2.0-or-later. See the LICENSE file for more details.
"""
Native AceStream player: talks directly to the local AceStream engine
(HTTP API on port 6878) without relying on Horus.

Requires the engine to be already listening; does NOT install or start it. If the engine
does not respond, play() returns False and the caller falls back to its chain.

Engine API verified at wiki.acestream.media/Engine_HTTP_API:
  - GET /ace/getstream?id=<40hex>&format=json -> {playback_url, stat_url, command_url}
  - GET stat_url -> {status: "prebuf"|"dl", peers, speed_down (KB/s), total_progress}
    total_progress is only valid in VOD; it does not exist in live channels.
  - GET command_url?method=stop -> closes the P2P session.
"""
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

_LOCALIZE = xbmcaddon.Addon().getLocalizedString

# Player with callbacks alive for the duration of playback; if garbage collected,
# it would stop receiving onPlayBack* and the session would never close.
_active_player = None


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[StreamNinja/acestream] {0}".format(msg), level)


def _api_get(url, timeout):
    """GET that returns the engine's JSON dict, or None on any failure."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "StreamNinja"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, OSError, ValueError):
        return None


def _settings():
    addon = xbmcaddon.Addon()
    ip = addon.getSetting("acestream_ip") or "127.0.0.1"
    port = addon.getSetting("acestream_port") or "6878"
    try:
        timeout = int(addon.getSetting("acestream_timeout") or 45)
    except ValueError:
        timeout = 45
    return ip, port, max(10, timeout)


def engine_alive(ip, port, timeout=2):
    """True if the engine responds to get_version (liveness + readiness in one call)."""
    res = _api_get(
        "http://{0}:{1}/webui/api/service?method=get_version&format=json".format(ip, port),
        timeout,
    )
    if not isinstance(res, dict):
        return False
    # The response may come wrapped in {"result": {"version": ...}} or flat {"version": ...}.
    inner = res.get("result") if isinstance(res.get("result"), dict) else res
    return bool(inner.get("version"))


def _open_session(ip, port, selector):
    """Opens a stream session. *selector* is the query fragment identifying the
    content: 'id=<hash>' (content id), 'infohash=<hash>' (torrent) or 'url=<urlencoded>'
    (link to a .torrent; the engine downloads and parses it itself). Returns
    (playback_url, stat_url, command_url) or None."""
    res = _api_get(
        "http://{0}:{1}/ace/getstream?{2}&format=json".format(ip, port, selector),
        timeout=15,
    )
    if not isinstance(res, dict):
        return None
    # Some versions wrap the content in {"response": {...}, "error": ...};
    # others return it flat. We tolerate both.
    if res.get("error"):
        _log("engine returned error: {0}".format(res["error"]), xbmc.LOGWARNING)
        return None
    data = res.get("response") if isinstance(res.get("response"), dict) else res
    playback = data.get("playback_url")
    if not playback:
        return None
    return playback, data.get("stat_url"), data.get("command_url")


def _stop_session(command_url):
    if command_url:
        _api_get(command_url + "?method=stop", timeout=5)


def _prebuffer(stat_url, command_url, timeout):
    """Prebuffering dialog until status='dl'. Returns True if ready to play,
    False if cancelled/timed out. Closes the session if the user cancels."""
    monitor = xbmc.Monitor()
    dp = xbmcgui.DialogProgress()
    dp.create(_LOCALIZE(30000), _LOCALIZE(31050))
    # Real wall time; if the stats poll slows down, the timeout must still be
    # measured in real seconds, not in loop iterations.
    start = time.time()
    deadline = start + timeout
    # Absolute limit; even if the engine remains in 'prebuf', we do not wait indefinitely.
    hard_deadline = start + timeout + 120
    try:
        while True:
            now = time.time()
            elapsed = int(now - start)
            if now >= deadline:
                break
            if dp.iscanceled() or monitor.abortRequested():
                _stop_session(command_url)
                return False

            stats = _api_get(stat_url, timeout=3) or {}
            data = stats.get("response", stats) if isinstance(stats, dict) else {}
            status = data.get("status")
            if status == "dl":
                return True

            # While the engine is actively prebuffering, give it more margin (slow networks or
            # few peers) instead of cutting off due to the base timeout. Bounded by hard_deadline.
            if status == "prebuf":
                deadline = min(now + timeout, hard_deadline)

            peers = data.get("peers", 0)
            speed = data.get("speed_down", 0)  # already in KB/s
            # total_progress only exists in VOD; in live streams, we move the bar with
            # elapsed time just to give visual feedback, it is not real buffering.
            try:
                pct = int(data.get("total_progress") or 0)
            except (TypeError, ValueError):
                pct = 0
            if pct <= 0:
                pct = min(95, int(elapsed * 100 / timeout))
            dp.update(
                pct,
                _LOCALIZE(31051).format(
                    peers, speed, elapsed),
            )

            if monitor.waitForAbort(1):  # 1s sleep interruptible by Kodi shutdown
                _stop_session(command_url)
                return False
    finally:
        dp.close()

    # Timeout without reaching 'dl': offer to play anyway instead of failing dry.
    if xbmcgui.Dialog().yesno(
            _LOCALIZE(30000),
            _LOCALIZE(31052)):
        return True
    _stop_session(command_url)
    return False


class _AcePlayer(xbmc.Player):
    """Closes the engine's P2P session when playback ends."""

    def __init__(self, command_url):
        super().__init__()
        self._command_url = command_url

    def _cleanup(self):
        cmd, self._command_url = self._command_url, None
        if cmd:
            _stop_session(cmd)

    def onPlayBackStopped(self):
        self._cleanup()

    def onPlayBackEnded(self):
        self._cleanup()

    def onPlayBackError(self):
        self._cleanup()


def _play_session(ip, port, selector, timeout, label, icon="", plot=""):
    """Opens, prebuffers, and plays an engine session. Returns True if the engine
    managed the request (played or user cancelled) and False if it did not return a session.
    """
    global _active_player
    session = _open_session(ip, port, selector)
    if not session:
        return False
    playback_url, stat_url, command_url = session

    # From here, the engine responds and there is interaction with the user; if they cancel or the
    # buffer doesn't arrive, it's their choice, not a failure -> True (do not fall back).
    if stat_url and not _prebuffer(stat_url, command_url, timeout):
        return True

    li = xbmcgui.ListItem(label=label, path=playback_url)
    li.setContentLookup(False)  # avoids HEAD probe which hangs with progressive MPEG-TS
    li.setProperty("IsPlayable", "true")
    if icon:
        li.setArt({"icon": icon, "thumb": icon})
    li.setInfo("video", {"title": label, "plot": plot} if plot else {"title": label})

    # If there was another AceStream session in progress, close it deterministically before
    # starting this one; overwriting _active_player might garbage collect the previous one
    # and fail to trigger its stop callback, leaving its session open.
    if _active_player is not None:
        _active_player._cleanup()

    _active_player = _AcePlayer(command_url)
    _active_player.play(playback_url, li)

    # OSD of statistics P2P (optional). Lazy import; if disabled or the module
    # fails, playback is not affected at all.
    if stat_url and xbmcaddon.Addon().getSetting("acestream_show_osd") != "false":
        try:
            import acestream_osd
            acestream_osd.start(stat_url)
        except Exception as e:
            _log("OSD not available: {0}".format(e), xbmc.LOGWARNING)
    return True


def play(content_id, title="", icon="", plot=""):
    """Plays an AceStream content ID (40 hex) via the local engine.

    Returns True if the engine managed the request (played, or the user cancelled
    prebuffering: in both cases it should NOT fall back to Horus). Returns False
    only if the engine is not available or did not return a session, so that the caller
    can continue with its fallback chain.
    """
    ip, port, timeout = _settings()
    if not engine_alive(ip, port):
        return False
    return _play_session(ip, port, "id={0}".format(content_id), timeout,
                         title or "AceStream", icon, plot)


def _torrent_selector(value):
    """Query selector for the engine from a magnet or a .torrent URL.
    Magnet -> 'infohash=<btih 40hex>'. URL .torrent -> 'url=<urlencoded>' (the engine
    downloads and parses it). None if it is a magnet without a 40 hex infohash (base32 / BT v2,
    which the engine does not support)."""
    if value.lower().startswith("magnet:"):
        m = re.search(r"urn:btih:([a-fA-F0-9]{40})", value, re.I)
        return "infohash={0}".format(m.group(1).lower()) if m else None
    return "url={0}".format(urllib.parse.quote(value, safe=""))


def play_torrent(value, title="", icon="", plot=""):
    """Plays a magnet or a .torrent URL with the local AceStream engine.

    Same return contract as play(): True if the engine managed it, False if not
    available or the request could not be constructed (the caller does its fallback).
    """
    ip, port, timeout = _settings()
    if not engine_alive(ip, port):
        return False
    selector = _torrent_selector(value)
    if not selector:
        return False
    return _play_session(ip, port, selector, timeout,
                         title or "AceStream Torrent", icon, plot)
